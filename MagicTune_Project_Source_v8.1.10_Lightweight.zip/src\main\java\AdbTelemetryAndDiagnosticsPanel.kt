package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.adb.AdbDiagnosticReport
import com.example.core.adb.AdbTelemetrySnapshot
import com.example.core.adb.DiagnosticSeverity
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdbTelemetryHudCard(
    telemetry: AdbTelemetrySnapshot,
    isWirelessConnected: Boolean,
    connectedPort: Int,
    detectedConnectPort: Int?,
    onPing: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val displayPort = when {
        isWirelessConnected && connectedPort > 0 -> connectedPort
        telemetry.activePort > 0 -> telemetry.activePort
        detectedConnectPort != null && detectedConnectPort > 0 -> detectedConnectPort
        else -> 0
    }
    val lanTarget = if (!telemetry.lanIp.isNullOrBlank() && displayPort > 0) {
        "${telemetry.lanIp}:$displayPort"
    } else null

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("adb_telemetry_hud_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1222)),
        border = BorderStroke(
            1.dp,
            if (isWirelessConnected) MagicEmerald.copy(alpha = 0.65f) else MagicCyan.copy(alpha = 0.35f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(if (isWirelessConnected) MagicEmerald else MagicAmber)
                    )
                    Text(
                        text = if (isWirelessConnected) {
                            "LIVE TLS • ${telemetry.activeHost}:$displayPort"
                        } else if (displayPort > 0) {
                            "RADAR PHÁT HIỆN CỔNG :$displayPort"
                        } else {
                            "TELEMETRY ADB KHÔNG DÂY"
                        },
                        color = if (isWirelessConnected) MagicEmeraldLight else MagicCyanLight,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Box(
                    modifier = Modifier
                        .defaultMinSize(minHeight = 36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicCyan.copy(alpha = 0.16f))
                        .border(1.dp, MagicCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .clickable(enabled = isWirelessConnected) { onPing() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("adb_ping_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = "Đo độ trễ Ping ADB",
                            tint = if (isWirelessConnected) MagicCyan else TextMuted,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = telemetry.lastLatencyMs?.let { "${it}ms" } ?: "Ping",
                            color = if (isWirelessConnected) MagicCyanLight else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TelemetryRowItem(
                    label = "Giao thức",
                    value = telemetry.protocolLabel,
                    accent = MagicCyan
                )
                if (telemetry.certFingerprintSha256.isNotBlank()) {
                    TelemetryRowItem(
                        label = "RSA SHA-256",
                        value = telemetry.certFingerprintSha256,
                        accent = MagicEmerald
                    )
                }
                if (isWirelessConnected) {
                    TelemetryRowItem(
                        label = "Danh tính",
                        value = telemetry.uidIdentity,
                        accent = MagicEmerald
                    )
                }
                TelemetryRowItem(
                    label = "Lệnh / TB",
                    value = "${telemetry.totalCommandsExecuted} lệnh" +
                        (telemetry.avgLatencyMs?.let { " • ~${it}ms" } ?: ""),
                    accent = MagicCyanLight
                )
            }

            if (lanTarget != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF030712))
                        .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                        .clickable {
                            val cmd = "adb connect $lanTarget"
                            clipboard.setText(AnnotatedString(cmd))
                            Toast.makeText(context, "📋 Đã sao chép: $cmd", Toast.LENGTH_SHORT).show()
                        }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .testTag("copy_lan_adb_connect_button"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Kết nối LAN từ PC / LADB:",
                            color = TextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "adb connect $lanTarget",
                            color = MagicCyanLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Sao chép lệnh adb connect",
                        tint = MagicCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryRowItem(
    label: String,
    value: String,
    accent: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(accent.copy(alpha = 0.08f))
            .border(1.dp, accent.copy(alpha = 0.28f), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
        )
    }
}

@Composable
fun AdbDiagnosticReportCard(
    report: AdbDiagnosticReport?,
    isRunning: Boolean,
    onRunDiagnostics: () -> Unit,
    onResetRsaKeys: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("adb_diagnostics_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A101E)),
        border = BorderStroke(
            1.dp,
            when {
                report?.overallReady == true -> MagicEmerald.copy(alpha = 0.6f)
                report != null -> MagicAmber.copy(alpha = 0.55f)
                else -> MagicBorder
            }
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = MagicCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "CHẨN ĐOÁN 6 ĐIỂM & TỰ PHỤC HỒI",
                        color = MagicCyanLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                if (isRunning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = MagicCyan,
                        strokeWidth = 2.dp
                    )
                }
            }

            AnimatedVisibility(visible = report != null) {
                if (report != null) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        report.steps.forEach { step ->
                            val (tintColor, iconVec) = when (step.severity) {
                                DiagnosticSeverity.PASS -> MagicEmerald to Icons.Default.CheckCircle
                                DiagnosticSeverity.WARN -> MagicAmber to Icons.Default.Warning
                                DiagnosticSeverity.FAIL -> MagicRose to Icons.Default.Close
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(tintColor.copy(alpha = 0.08f))
                                    .border(1.dp, tintColor.copy(alpha = 0.3f), RoundedCornerShape(9.dp))
                                    .padding(horizontal = 9.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = iconVec,
                                    contentDescription = step.title,
                                    tint = tintColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = step.title,
                                        color = TextPrimary,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = step.detail,
                                        color = TextSecondary,
                                        fontSize = 10.5.sp,
                                        lineHeight = 14.sp
                                    )
                                }
                                if (step.latencyMs != null) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MagicEmerald.copy(alpha = 0.2f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "${step.latencyMs}ms",
                                            color = MagicEmeraldLight,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                }
                            }
                        }

                        if (report.recommendedAction.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(
                                        if (report.overallReady) MagicEmerald.copy(alpha = 0.14f)
                                        else MagicAmber.copy(alpha = 0.14f)
                                    )
                                    .padding(9.dp)
                            ) {
                                Text(
                                    text = "💡 ${report.recommendedAction}",
                                    color = if (report.overallReady) MagicEmeraldLight else MagicAmber,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onRunDiagnostics,
                    enabled = !isRunning,
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(1f)
                        .defaultMinSize(minHeight = 36.dp)
                        .testTag("run_adb_diagnostics_button"),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicSurfaceCard,
                        contentColor = MagicCyanLight
                    ),
                    border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                ) {
                    Icon(imageVector = Icons.Default.Build, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (report == null) "Chẩn Đoán 6 Điểm" else "Quét Lại",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Button(
                    onClick = onResetRsaKeys,
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(1f)
                        .defaultMinSize(minHeight = 36.dp)
                        .testTag("reset_adb_rsa_keys_button"),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1E293B),
                        contentColor = MagicAmber
                    ),
                    border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Reset Khóa RSA",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}
