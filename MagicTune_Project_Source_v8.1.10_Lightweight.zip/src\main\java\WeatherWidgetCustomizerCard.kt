package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.widget.HomeWidgetPinHelper
import com.example.core.widget.MagicTuneCalendarWeatherWidgetProvider
import com.example.core.widget.MagicTuneCalendarWeatherWidgetProvider.Companion.WeatherWidgetCustomConfig
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicAmberLight
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicPurpleLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicRoseLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@Composable
fun WeatherWidgetCustomizerCard(
    initiallyExpanded: Boolean = false
) {
    val context = LocalContext.current
    var config by remember {
        mutableStateOf(MagicTuneCalendarWeatherWidgetProvider.loadCustomConfig(context))
    }
    var isExpanded by remember { mutableStateOf(initiallyExpanded) }

    fun applyAndSync(newConfig: WeatherWidgetCustomConfig, toastMsg: String? = null) {
        config = newConfig
        MagicTuneCalendarWeatherWidgetProvider.saveCustomConfig(context, newConfig)
        if (!toastMsg.isNullOrBlank()) {
            Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("weather_widget_customizer_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
        border = BorderStroke(1.2.dp, MagicCyan.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header + Badge Free Vĩnh Viễn
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(5.dp))
                                .background(MagicCyan.copy(alpha = 0.22f))
                                .border(0.8.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(5.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Ô #11",
                                color = MagicCyanLight,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "TUỲ CHỈNH WIDGET ĐỒNG HỒ & THỜI TIẾT",
                            color = MagicCyanLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(5.dp))
                                .background(MagicEmerald.copy(alpha = 0.22f))
                                .border(0.8.dp, MagicEmerald.copy(alpha = 0.6f), RoundedCornerShape(5.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "FREE",
                                color = MagicEmeraldLight,
                                fontSize = 8.8.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                    Text(
                        text = "Ẩn/hiện mục • Phóng to/thu nhỏ cỡ chữ • Về mặc định 1 chạm",
                        color = TextSecondary,
                        fontSize = 10.2.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "Thu gọn tuỳ chỉnh Widget" else "Mở tuỳ chỉnh Widget",
                    tint = MagicCyanLight,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Hàng nút mở nhanh + Về Mặc Định
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { isExpanded = !isExpanded },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 42.dp)
                        .testTag("toggle_weather_widget_customizer_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicCyan,
                        contentColor = Color(0xFF020617)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = if (isExpanded) "Thu Gọn Bảng Tuỳ Chỉnh" else "Tuỳ Chỉnh Ẩn/Hiện & Cỡ Chữ",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                OutlinedButton(
                    onClick = {
                        val def = MagicTuneCalendarWeatherWidgetProvider.resetCustomConfigToDefault(context)
                        config = def
                        Toast.makeText(context, "↺ Đã khôi phục Widget Đồng hồ & Thời tiết về kích thước mặc định 100%!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .heightIn(min = 42.dp)
                        .testTag("reset_weather_widget_default_btn"),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MagicAmber),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, tint = MagicAmberLight, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Về Mặc Định",
                        color = MagicAmberLight,
                        fontSize = 10.8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                WeatherWidgetCustomizerBody(
                    config = config,
                    onUpdateConfig = { newCfg, msg -> applyAndSync(newCfg, msg) },
                    onResetDefault = {
                        val def = MagicTuneCalendarWeatherWidgetProvider.resetCustomConfigToDefault(context)
                        config = def
                        Toast.makeText(context, "↺ Đã khôi phục toàn bộ nội dung & cỡ chữ Widget về Mặc định (100%)!", Toast.LENGTH_SHORT).show()
                    },
                    onPinWidget = {
                        HomeWidgetPinHelper.allWidgets.firstOrNull { it.id == "widget_weather_calendar" }?.let { spec ->
                            HomeWidgetPinHelper.requestPinWidget(context, spec)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun WeatherWidgetCustomizeDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var config by remember {
        mutableStateOf(MagicTuneCalendarWeatherWidgetProvider.loadCustomConfig(context))
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 680.dp)
                .testTag("weather_widget_customize_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF070E1C)),
            border = BorderStroke(1.2.dp, MagicCyan)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "🎛️ TUỲ CHỈNH WIDGET ĐỒNG HỒ & THỜI TIẾT",
                            color = MagicCyanLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "🎁 Miễn phí vĩnh viễn cho mọi máy • Áp dụng tức thì ra màn hình chính",
                            color = MagicEmeraldLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Đóng", tint = Color.White)
                    }
                }

                HorizontalDivider(color = MagicBorder.copy(alpha = 0.6f))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    WeatherWidgetCustomizerBody(
                        config = config,
                        onUpdateConfig = { newCfg, msg ->
                            config = newCfg
                            MagicTuneCalendarWeatherWidgetProvider.saveCustomConfig(context, newCfg)
                            if (!msg.isNullOrBlank()) {
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            }
                        },
                        onResetDefault = {
                            val def = MagicTuneCalendarWeatherWidgetProvider.resetCustomConfigToDefault(context)
                            config = def
                            Toast.makeText(context, "↺ Đã khôi phục toàn bộ nội dung & cỡ chữ Widget về Mặc định (100%)!", Toast.LENGTH_SHORT).show()
                        },
                        onPinWidget = {
                            HomeWidgetPinHelper.allWidgets.firstOrNull { it.id == "widget_weather_calendar" }?.let { spec ->
                                HomeWidgetPinHelper.requestPinWidget(context, spec)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun WeatherWidgetCustomizerBody(
    config: WeatherWidgetCustomConfig,
    onUpdateConfig: (WeatherWidgetCustomConfig, String?) -> Unit,
    onResetDefault: () -> Unit,
    onPinWidget: () -> Unit
) {
    val maxScale = config.maxScalePct
    val isAnyEnlarged = maxScale > 100
    val isOverflowRiskHigh = config.hasEnlargedTextOverflowWarning ||
        (config.forecastStripScalePct > 100 && config.showClock7DayStrip)

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        HorizontalDivider(color = MagicBorder.copy(alpha = 0.5f))

        // 1. CẢNH BÁO TRÀN NỘI DUNG KHI PHÓNG TO > 100%
        if (isAnyEnlarged) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        if (isOverflowRiskHigh) MagicRose.copy(alpha = 0.18f)
                        else MagicAmber.copy(alpha = 0.16f)
                    )
                    .border(
                        1.dp,
                        if (isOverflowRiskHigh) MagicRose else MagicAmber,
                        RoundedCornerShape(10.dp)
                    )
                    .padding(10.dp)
                    .testTag("widget_overflow_warning_banner"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Cảnh báo tràn Widget",
                    tint = if (isOverflowRiskHigh) MagicRoseLight else MagicAmberLight,
                    modifier = Modifier.size(20.dp)
                )
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "⚠️ CẢNH BÁO: KÍCH THƯỚC CHỮ ĐANG PHÓNG TO ($maxScale%)",
                        color = if (isOverflowRiskHigh) MagicRoseLight else MagicAmberLight,
                        fontSize = 10.8.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Chỉnh kích thước nội dung quá to trong khi hiển thị đầy đủ các mục có thể làm chữ hoặc hàng cuối bị tràn ra khỏi bảng Widget. Hãy ẩn bớt mục phụ hoặc bấm [↺ Về Mặc Định 100%] nếu bị tràn!",
                        color = Color.White,
                        fontSize = 9.8.sp,
                        lineHeight = 13.5.sp
                    )
                }
            }
        }

        // 2. BA CHẾ ĐỘ BỐ CỤC NHANH (1 CHẠM ĐỠ RỐI MẮT)
        Text(
            text = "1️⃣ CHỌN NHANH BỐ CỤC HIỂN THỊ (CHỐNG RỐI MẮT):",
            color = MagicAmberLight,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Black
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Mặc định đầy đủ
            PresetButton(
                modifier = Modifier.weight(1f),
                title = "✨ Đầy Đủ",
                subtitle = "Mặc định 100%",
                accent = MagicCyan,
                onClick = onResetDefault
            )
            // Gọn gàng đỡ rối
            PresetButton(
                modifier = Modifier.weight(1f),
                title = "🍃 Gọn Gàng",
                subtitle = "Ẩn mục phụ, chữ 105%",
                accent = MagicEmerald,
                onClick = {
                    onUpdateConfig(
                        WeatherWidgetCustomConfig(
                            showLocation = true,
                            showSolarDate = true,
                            showLunarDate = true,
                            showLunarCanChi = false,
                            showClockSeconds = false,
                            showWeatherCondition = true,
                            showRainPercent = true,
                            showWeatherSubDetails = false,
                            showHourly24h = true,
                            showDaily7d = false,
                            showClock7DayStrip = false,
                            clockScalePct = 105,
                            tempScalePct = 105,
                            dateLunarScalePct = 105,
                            weatherInfoScalePct = 105,
                            forecastStripScalePct = 100,
                            overallGlobalScalePct = 100,
                            secondsScalePct = 100,
                            canChiScalePct = 100,
                            weatherSubScalePct = 100
                        ),
                        "🍃 Đã áp dụng bố cục Gọn Gàng (Ẩn số giây & mục phụ, phóng nhẹ chữ 105% cực thoáng mắt)!"
                    )
                }
            )
            // Tối giản Chữ To
            PresetButton(
                modifier = Modifier.weight(1f),
                title = "🎯 Tối Giản To",
                subtitle = "Chỉ Giờ + Nhiệt + Lịch",
                accent = MagicPurpleLight,
                onClick = {
                    onUpdateConfig(
                        WeatherWidgetCustomConfig(
                            showLocation = true,
                            showSolarDate = true,
                            showLunarDate = true,
                            showLunarCanChi = false,
                            showClockSeconds = false,
                            showWeatherCondition = true,
                            showRainPercent = true,
                            showWeatherSubDetails = false,
                            showHourly24h = false,
                            showDaily7d = false,
                            showClock7DayStrip = false,
                            clockScalePct = 120,
                            tempScalePct = 120,
                            dateLunarScalePct = 115,
                            weatherInfoScalePct = 115,
                            forecastStripScalePct = 100,
                            overallGlobalScalePct = 105,
                            secondsScalePct = 100,
                            canChiScalePct = 100,
                            weatherSubScalePct = 100
                        ),
                        "🎯 Đã áp dụng bố cục Tối Giản Chữ To (Đã tự ẩn số giây cho gọn, hiện Đồng hồ & Nhiệt độ to rõ 120%)!"
                    )
                }
            )
        }

        // 3. TUỲ CHỈNH KÍCH THƯỚC TỪNG NHÓM NỘI DUNG (75% -> 145%)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "2️⃣ LÀM TO / THU NHỎ KÍCH THƯỚC TỪNG NỘI DUNG:",
                color = MagicCyanLight,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                text = "↺ Bấm 100% để về chuẩn",
                color = TextMuted,
                fontSize = 9.5.sp
            )
        }

        WidgetScaleRow(
            title = "🌐 Tỉ lệ phóng to / thu nhỏ toàn bộ Widget",
            scalePercent = config.overallGlobalScalePct,
            onChange = { newVal -> onUpdateConfig(config.copy(overallGlobalScalePct = newVal), null) }
        )
        WidgetScaleRow(
            title = if (config.clockScalePct > 100) "⏰ Cỡ chữ Đồng hồ (Đã tự ẩn giây cho gọn)" else "⏰ Cỡ chữ Đồng hồ",
            scalePercent = config.clockScalePct,
            onChange = { newVal ->
                val autoSeconds = if (newVal > 100) false else if (config.clockScalePct > 100 && newVal <= 100) true else config.showClockSeconds
                onUpdateConfig(config.copy(clockScalePct = newVal, showClockSeconds = autoSeconds), null)
            }
        )
        WidgetScaleRow(
            title = "⏱️ Cỡ chữ Giây (:ss) đồng hồ",
            scalePercent = config.secondsScalePct,
            onChange = { newVal -> onUpdateConfig(config.copy(secondsScalePct = newVal), null) }
        )
        WidgetScaleRow(
            title = "🌡️ Cỡ chữ Nhiệt độ chính",
            scalePercent = config.tempScalePct,
            onChange = { newVal -> onUpdateConfig(config.copy(tempScalePct = newVal), null) }
        )
        WidgetScaleRow(
            title = "📅 Cỡ chữ Ngày Dương & Âm lịch",
            scalePercent = config.dateLunarScalePct,
            onChange = { newVal -> onUpdateConfig(config.copy(dateLunarScalePct = newVal), null) }
        )
        WidgetScaleRow(
            title = "✨ Cỡ chữ Dòng Can Chi & Lễ Tết",
            scalePercent = config.canChiScalePct,
            onChange = { newVal -> onUpdateConfig(config.copy(canChiScalePct = newVal), null) }
        )
        WidgetScaleRow(
            title = "📍 Cỡ chữ Khu vực & Mô tả thời tiết",
            scalePercent = config.weatherInfoScalePct,
            onChange = { newVal -> onUpdateConfig(config.copy(weatherInfoScalePct = newVal), null) }
        )
        WidgetScaleRow(
            title = "💨 Cỡ chữ Chi tiết phụ (Độ ẩm • Gió • UV)",
            scalePercent = config.weatherSubScalePct,
            onChange = { newVal -> onUpdateConfig(config.copy(weatherSubScalePct = newVal), null) }
        )
        WidgetScaleRow(
            title = "📊 Cỡ chữ Dự báo 24H / 7 Ngày & Dải lịch cuối",
            scalePercent = config.forecastStripScalePct,
            onChange = { newVal -> onUpdateConfig(config.copy(forecastStripScalePct = newVal), null) }
        )

        // 4. BẬT / TẮT ẨN HIỆN TỪNG MỤC NỘI DUNG TRÊN WIDGET
        Text(
            text = "3️⃣ ẨN / HIỆN TỪNG MỤC TRÊN BẢNG WIDGET (BẤM ĐỂ BẬT/TẮT):",
            color = MagicEmeraldLight,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Black
        )

        WidgetToggleItem(
            title = "⏱️ Giây đồng hồ (:59)",
            subtitle = if (config.clockScalePct > 100) {
                "Đã tự động ẩn khi Đồng hồ > 100% để tránh bóp hẹp số giây (Bấm để đưa Đồng hồ về 100% & hiện lại giây)"
            } else {
                "Hiện bộ đếm giây thời gian thực cạnh giờ:phút (Khi chỉnh Đồng hồ > 100% sẽ tự ẩn cho gọn)"
            },
            checked = config.showClockSeconds && config.clockScalePct <= 100,
            onToggle = { wantShow ->
                if (wantShow && config.clockScalePct > 100) {
                    onUpdateConfig(
                        config.copy(showClockSeconds = true, clockScalePct = 100),
                        "⏱️ Đã đưa cỡ Đồng hồ về mặc định 100% để hiển thị số giây không bị bóp hẹp!"
                    )
                } else {
                    onUpdateConfig(config.copy(showClockSeconds = wantShow), null)
                }
            }
        )
        WidgetToggleItem(
            title = "📍 Tên khu vực / Tỉnh thành",
            subtitle = "Hiện địa điểm đang theo dõi thời tiết trên bảng Widget",
            checked = config.showLocation,
            onToggle = { onUpdateConfig(config.copy(showLocation = it), null) }
        )
        WidgetToggleItem(
            title = "☀️ Ngày Dương lịch hôm nay",
            subtitle = "Hiện Thứ, Ngày/Tháng/Năm Dương lịch",
            checked = config.showSolarDate,
            onToggle = { onUpdateConfig(config.copy(showSolarDate = it), null) }
        )
        WidgetToggleItem(
            title = "🌙 Ngày Âm lịch hôm nay",
            subtitle = "Hiện ngày tháng Âm lịch truyền thống Việt Nam",
            checked = config.showLunarDate,
            onToggle = { onUpdateConfig(config.copy(showLunarDate = it), null) }
        )
        WidgetToggleItem(
            title = "✨ Dòng Can Chi Ngày/Tháng & Lễ Tết",
            subtitle = "Dòng Can Chi chi tiết ở chế độ Đồng hồ (Ẩn đi giúp khung lịch gọn hơn)",
            checked = config.showLunarCanChi,
            onToggle = { onUpdateConfig(config.copy(showLunarCanChi = it), null) }
        )
        WidgetToggleItem(
            title = "🌤️ Trạng thái bầu trời (Nắng / Mưa / Quang đãng)",
            subtitle = "Dòng mô tả tình trạng thời tiết hiện tại dưới nhiệt độ lớn",
            checked = config.showWeatherCondition,
            onToggle = { onUpdateConfig(config.copy(showWeatherCondition = it), null) }
        )
        WidgetToggleItem(
            title = "☔ Tỷ lệ khả năng mưa %",
            subtitle = "Dòng báo phần trăm xác suất mưa tại khu vực của bạn",
            checked = config.showRainPercent,
            onToggle = { onUpdateConfig(config.copy(showRainPercent = it), null) }
        )
        WidgetToggleItem(
            title = "💨 Độ ẩm • Tốc độ gió • Chỉ số UV",
            subtitle = "Ẩn dòng này nếu bạn muốn cột thời tiết bên phải thoáng hơn",
            checked = config.showWeatherSubDetails,
            onToggle = { onUpdateConfig(config.copy(showWeatherSubDetails = it), null) }
        )
        WidgetToggleItem(
            title = "🕒 Bảng Dự báo theo giờ (24H)",
            subtitle = "Hiện các khung giờ tiếp theo trong ngày ở chế độ Dự báo",
            checked = config.showHourly24h,
            onToggle = { onUpdateConfig(config.copy(showHourly24h = it), null) }
        )
        WidgetToggleItem(
            title = "📆 Bảng Dự báo 7 ngày tới",
            subtitle = "Ẩn bảng này nếu bạn chỉ cần xem dự báo 24H trong ngày cho đỡ rối mắt",
            checked = config.showDaily7d,
            onToggle = { onUpdateConfig(config.copy(showDaily7d = it), null) }
        )
        WidgetToggleItem(
            title = "🗓️ Dải Lịch 7 ngày Dương & Âm cuối bảng",
            subtitle = "Hàng 7 ô lịch Thứ 2 -> Chủ Nhật ở dưới cùng Widget Đồng hồ",
            checked = config.showClock7DayStrip,
            onToggle = { onUpdateConfig(config.copy(showClock7DayStrip = it), null) }
        )

        // 5. HÀNG NÚT KHÔI PHỤC MẶC ĐỊNH & GHIM RA MÀN HÌNH CHÍNH
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onResetDefault,
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 44.dp)
                    .testTag("customizer_bottom_reset_default_btn"),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, MagicAmber)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = MagicAmberLight, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = "↺ Khôi Phục Mặc Định (100%)",
                    color = MagicAmberLight,
                    fontSize = 10.8.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
            }

            Button(
                onClick = onPinWidget,
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 44.dp)
                    .testTag("customizer_bottom_pin_widget_btn"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MagicEmerald,
                    contentColor = Color(0xFF020617)
                )
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Ghim Widget (Free)",
                    fontSize = 10.8.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun PresetButton(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(accent.copy(alpha = 0.14f))
            .border(1.dp, accent.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = title,
            color = Color.White,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Black,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = subtitle,
            color = accent,
            fontSize = 8.8.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun WidgetScaleRow(
    title: String,
    scalePercent: Int,
    onChange: (Int) -> Unit
) {
    val isEnlarged = scalePercent > 100
    val badgeColor = when {
        scalePercent >= 115 -> MagicRoseLight
        scalePercent > 100 -> MagicAmberLight
        scalePercent < 100 -> MagicCyanLight
        else -> MagicEmeraldLight
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(9.dp))
            .background(MagicSurfaceCard)
            .border(
                0.8.dp,
                if (isEnlarged) MagicAmber.copy(alpha = 0.55f) else MagicBorder.copy(alpha = 0.5f),
                RoundedCornerShape(9.dp)
            )
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 6.dp)) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 10.8.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = when {
                    scalePercent > 105 -> "Đang phóng to ($scalePercent%) • Coi chừng tràn bảng"
                    scalePercent > 100 -> "Phóng nhẹ ($scalePercent%)"
                    scalePercent < 100 -> "Thu gọn ($scalePercent%)"
                    else -> "Kích thước chuẩn mặc định (100%)"
                },
                color = badgeColor,
                fontSize = 9.2.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            // Nút Giảm -5%
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(Color(0xFF1E293B))
                    .border(0.8.dp, MagicBorder, RoundedCornerShape(7.dp))
                    .clickable { onChange((scalePercent - 5).coerceIn(60, 160)) },
                contentAlignment = Alignment.Center
            ) {
                Text("−", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black)
            }

            // Nút Reset 100%
            Box(
                modifier = Modifier
                    .defaultMinSize(minWidth = 48.dp, minHeight = 32.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(badgeColor.copy(alpha = 0.16f))
                    .border(0.8.dp, badgeColor.copy(alpha = 0.6f), RoundedCornerShape(7.dp))
                    .clickable { onChange(100) }
                    .padding(horizontal = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "$scalePercent%",
                    color = badgeColor,
                    fontSize = 10.2.sp,
                    fontWeight = FontWeight.Black
                )
            }

            // Nút Tăng +5%
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(Color(0xFF1E293B))
                    .border(0.8.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(7.dp))
                    .clickable { onChange((scalePercent + 5).coerceIn(60, 160)) },
                contentAlignment = Alignment.Center
            ) {
                Text("+", color = MagicCyanLight, fontSize = 15.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun WidgetToggleItem(
    title: String,
    subtitle: String,
    checked: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(9.dp))
            .background(MagicSurfaceCard)
            .border(
                0.8.dp,
                if (checked) MagicEmerald.copy(alpha = 0.45f) else MagicBorder.copy(alpha = 0.45f),
                RoundedCornerShape(9.dp)
            )
            .clickable { onToggle(!checked) }
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp),
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            Text(
                text = title,
                color = if (checked) Color.White else TextSecondary,
                fontSize = 10.8.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                color = TextMuted,
                fontSize = 9.2.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(if (checked) MagicEmerald.copy(alpha = 0.22f) else Color(0xFF1E293B))
                .border(
                    1.dp,
                    if (checked) MagicEmerald else MagicBorder,
                    RoundedCornerShape(8.dp)
                )
                .padding(horizontal = 10.dp, vertical = 5.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                if (checked) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = MagicEmeraldLight,
                        modifier = Modifier.size(12.dp)
                    )
                }
                Text(
                    text = if (checked) "HIỆN" else "ĐÃ ẨN",
                    color = if (checked) MagicEmeraldLight else TextMuted,
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}
