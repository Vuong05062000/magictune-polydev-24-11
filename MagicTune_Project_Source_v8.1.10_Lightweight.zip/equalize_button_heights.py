import os
import re

# Determine src directory
candidates = [
    r"C:\Users\Administrator\.gemini\antigravity\scratch\MagicTune\src\main\java",
    "/workspace/magic_src/src/main/java",
    "src/main/java"
]

src_dir = None
for c in candidates:
    if os.path.exists(c):
        src_dir = c
        break

if not src_dir:
    print("Error: src_dir not found!")
    exit(1)

print(f"Using src_dir: {src_dir}")

heightin_pattern = re.compile(r"heightIn\(min\s*=\s*(32|34|36|38|40|42|44|46|48|50)\.dp\)")

total_modified_files = 0
total_modified_rows = 0
total_modified_weights = 0
total_modified_heightin = 0

for fname in sorted(os.listdir(src_dir)):
    if not fname.endswith(".kt"):
        continue
    fpath = os.path.join(src_dir, fname)
    with open(fpath, "r", encoding="utf-8") as f:
        content = f.read()

    # Skip files that don't have any UI elements
    if "Button" not in content and "Row" not in content and "heightIn" not in content:
        continue

    orig_content = content
    lines = content.split("\n")
    new_lines = []
    i = 0
    modified_rows = 0
    modified_weights = 0
    modified_heightin = 0

    while i < len(lines):
        line = lines[i]

        # 1. Row multi-button detection
        if re.search(r"\bRow\s*\(", line) or line.strip() == "Row {":
            chunk = "\n".join(lines[i:min(len(lines), i + 60)])
            btns = re.findall(r"\b(Button|OutlinedButton)\s*\(", chunk)
            if len(btns) >= 2:
                # Find end of Row parameters
                row_end = i
                while row_end < min(len(lines), i + 10) and ") {" not in lines[row_end] and "){" not in lines[row_end] and lines[row_end].strip() != "Row {":
                    row_end += 1
                row_block = "\n".join(lines[i:row_end + 1])
                if "IntrinsicSize" not in row_block:
                    if "Modifier.fillMaxWidth()" in row_block:
                        row_block = row_block.replace("Modifier.fillMaxWidth()", "Modifier.fillMaxWidth().height(IntrinsicSize.Min)")
                        modified_rows += 1
                    elif "modifier = Modifier." in row_block:
                        row_block = re.sub(r"(modifier\s*=\s*Modifier\.)", r"\1height(IntrinsicSize.Min).", row_block, count=1)
                        modified_rows += 1
                    elif line.strip() == "Row {":
                        row_block = row_block.replace("Row {", "Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {")
                        modified_rows += 1
                    else:
                        row_block = re.sub(r"(Row\s*\()", r"\1modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min), ", row_block, count=1)
                        modified_rows += 1
                    for rline in row_block.split("\n"):
                        new_lines.append(rline)
                    i = row_end + 1
                    continue

        # 2. Button weight check -> add .fillMaxHeight()
        if ".weight(" in line and ".fillMaxHeight()" not in line:
            line = line.replace(".weight(", ".fillMaxHeight().weight(")
            modified_weights += 1

        # 3. Standardize fragmented heightIn
        if heightin_pattern.search(line):
            line = heightin_pattern.sub("defaultMinSize(minHeight = 36.dp)", line)
            modified_heightin += 1

        # 4. In AdbTelemetryAndDiagnosticsPanel or other files, normalize 48dp on buttons
        if fname == "AdbTelemetryAndDiagnosticsPanel.kt":
            if "defaultMinSize(minHeight = 48.dp)" in line:
                line = line.replace("defaultMinSize(minHeight = 48.dp)", "defaultMinSize(minHeight = 36.dp)")
                modified_heightin += 1

        new_lines.append(line)
        i += 1

    updated_content = "\n".join(new_lines)

    # 5. Ensure imports if modified and needed
    if modified_rows > 0 or modified_weights > 0 or modified_heightin > 0:
        has_wildcard = "import androidx.compose.foundation.layout.*" in updated_content
        if not has_wildcard:
            imports_to_add = []
            if modified_rows > 0 and "import androidx.compose.foundation.layout.IntrinsicSize" not in updated_content:
                imports_to_add.append("import androidx.compose.foundation.layout.IntrinsicSize")
            if modified_weights > 0 and "import androidx.compose.foundation.layout.fillMaxHeight" not in updated_content:
                imports_to_add.append("import androidx.compose.foundation.layout.fillMaxHeight")
            if modified_heightin > 0 and "import androidx.compose.foundation.layout.defaultMinSize" not in updated_content:
                imports_to_add.append("import androidx.compose.foundation.layout.defaultMinSize")
            if imports_to_add:
                import_block = "\n".join(imports_to_add) + "\n"
                # Add after package line
                updated_content = re.sub(r"(package [^\n]+\n)", r"\1\n" + import_block, updated_content, count=1)

    if updated_content != orig_content:
        with open(fpath, "w", encoding="utf-8") as f:
            f.write(updated_content)
        total_modified_files += 1
        total_modified_rows += modified_rows
        total_modified_weights += modified_weights
        total_modified_heightin += modified_heightin
        print(f"Updated {fname}: rows={modified_rows}, weights={modified_weights}, heightIn={modified_heightin}")

print("------------------------------------------------------------------")
print(f"Summary: {total_modified_files} files updated.")
print(f"Total Rows added IntrinsicSize.Min: {total_modified_rows}")
print(f"Total Button weights added .fillMaxHeight(): {total_modified_weights}")
print(f"Total heightIn standardized to defaultMinSize(minHeight = 36.dp): {total_modified_heightin}")
