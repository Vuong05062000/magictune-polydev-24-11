package com.example.ui.components

import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.core.license.LicenseManager
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicPurple
import com.example.ui.theme.MagicPurpleLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicRoseLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextMuted
import java.net.URLEncoder
import kotlinx.coroutines.launch

@Composable
fun ProLicenseCard(
    modifier: Modifier = Modifier,
    cardNumberBadge: String = "Ô #00",
    onLicenseActivated: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val proStateVersion by LicenseManager.proStateVersionFlow.collectAsStateWithLifecycle()
    val isProFlowState by LicenseManager.isProFlow.collectAsStateWithLifecycle()

    var isSimulateFree by remember { mutableStateOf(false) }
    var isPro by remember(isProFlowState) { mutableStateOf(isProFlowState) }
    var isAccountPro by remember { mutableStateOf(false) }
    var deviceId by remember { mutableStateOf("") }
    var proPrice by remember { mutableStateOf("50.000đ") }
    var proOriginalPrice by remember { mutableStateOf("80.000đ") }
    var accountProPrice by remember { mutableStateOf("100.000đ") }
    var accountProOriginalPrice by remember { mutableStateOf("160.000đ") }
    var isProSaleActive by remember { mutableStateOf(true) }
    var remainingTrials by remember { mutableIntStateOf(5) }
    var totalTrialLimit by remember { mutableIntStateOf(5) }

    val authSession by com.example.core.auth.FirebaseAuthManager.authSessionFlow.collectAsStateWithLifecycle()

    // 0 = Gói Pro Thiết Bị, 1 = Gói Pro Tài Khoản (chỉ hiển thị & cho phép chọn khi đã đăng nhập tài khoản)
    var isUserLoggedIn by remember(authSession) {
        mutableStateOf(authSession.isLoggedIn)
    }
    var selectedPackage by remember { mutableIntStateOf(0) }
    var inputLicenseKey by remember { mutableStateOf("") }
    var isCheckingCloud by remember { mutableStateOf(false) }

    suspend fun refreshLocalStateAsync(ctx: Context) {
        val loaded = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val simFree = LicenseManager.isAdminSimulateFreeMode(ctx)
            val pro = !simFree && LicenseManager.isProActivated(ctx)
            val accPro = !simFree && LicenseManager.isAccountProActivated(ctx)
            val devId = LicenseManager.getDeviceId(ctx)
            val pPrice = LicenseManager.getProPrice(ctx)
            val pOrigPrice = LicenseManager.getProOriginalPrice(ctx)
            val accPrice = LicenseManager.getAccountProPrice(ctx)
            val accOrigPrice = LicenseManager.getAccountProOriginalPrice(ctx)
            val saleActive = LicenseManager.isProSaleActive(ctx)
            val remTrials = LicenseManager.getRemainingFreeTrials(ctx)
            val totLimit = LicenseManager.getFreeTrialLimit(ctx)
            val loggedIn = com.example.core.auth.FirebaseAuthManager.authSessionFlow.value.isLoggedIn ||
                (com.example.core.auth.FirebaseAuthManager.getCurrentUser() != null)
            object {
                val sFree = simFree
                val p = pro
                val aPro = accPro
                val dId = devId
                val pp = pPrice
                val pop = pOrigPrice
                val ap = accPrice
                val aop = accOrigPrice
                val sa = saleActive
                val rt = remTrials
                val tl = totLimit
                val li = loggedIn
            }
        }
        isSimulateFree = loaded.sFree
        isPro = loaded.p
        isAccountPro = loaded.aPro
        deviceId = loaded.dId
        proPrice = loaded.pp
        proOriginalPrice = loaded.pop
        accountProPrice = loaded.ap
        accountProOriginalPrice = loaded.aop
        isProSaleActive = loaded.sa
        remainingTrials = loaded.rt
        totalTrialLimit = loaded.tl
        isUserLoggedIn = loaded.li
        if (!loaded.li && selectedPackage == 1) {
            selectedPackage = 0
        }
    }

    fun refreshLocalState(ctx: Context) {
        coroutineScope.launch {
            refreshLocalStateAsync(ctx)
        }
    }

    LaunchedEffect(proStateVersion, isProFlowState, authSession) {
        refreshLocalStateAsync(context)
    }

    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                val c = ctx ?: context
                refreshLocalState(c)
            }
        }
        val filter = IntentFilter().apply {
            addAction(LicenseManager.ACTION_PRO_ACTIVATED)
            addAction(LicenseManager.ACTION_CONFIG_UPDATED)
        }
        androidx.core.content.ContextCompat.registerReceiver(
            context,
            receiver,
            filter,
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
        onDispose {
            try {
                context.unregisterReceiver(receiver)
            } catch (_: Throwable) {}
        }
    }

    // ĐIỀU KIỆN HIỂN THỊ Ô #00:
    // Theo yêu cầu: Ô #00 chỉ cần hiện khi người dùng đã dùng hết lượt miễn phí hoặc khi admin bật chế độ trải nghiệm giao diện free
    val shouldShowCard = when {
        isSimulateFree -> true
        isPro -> true
        remainingTrials <= 0 -> true
        else -> false
    }

    if (!shouldShowCard) {
        return
    }

    if (isPro) {
        // =========================================================================
        // GIAO DIỆN KHI ĐÃ KÍCH HOẠT BẢN QUYỀN PRO VĨNH VIỄN (VÀ KHÔNG BẬT GIẢ LẬP FREE)
        // =========================================================================
        val fixedKey = remember(deviceId, isAccountPro) {
            if (isAccountPro) LicenseManager.generateAccountProLicenseKeyForDevice(deviceId)
            else LicenseManager.generateLicenseKeyForDevice(deviceId)
        }

        val proBorderBrush = remember { Brush.horizontalGradient(listOf(MagicEmerald, MagicCyan)) }
        Card(
            modifier = modifier
                .fillMaxWidth()
                .testTag("pro_license_card_activated"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.2.dp, proBorderBrush)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald.copy(alpha = 0.22f))
                                .border(1.dp, MagicEmerald, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = cardNumberBadge,
                                color = MagicEmeraldLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicEmerald.copy(alpha = 0.2f))
                                .border(1.dp, MagicEmerald, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isAccountPro) "✓ PRO TK" else "✓ PRO MÁY",
                                color = MagicEmeraldLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = "Pro License",
                            tint = MagicEmerald,
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = "💎 BẢN QUYỀN MAGICTUNE PRO VĨNH VIỄN",
                            color = MagicEmeraldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Text(
                        text = "ID Máy: $deviceId • ${if (isAccountPro) "👑 Gói Pro Tài Khoản" else "📱 Gói Pro Thiết Bị"}",
                        color = MagicCyanLight,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "Thiết bị đã được mở khóa toàn bộ tính năng VIP, dịch màn hình, tối ưu sâu hệ thống, dọn ứng dụng rác và gỡ lỗi không giới hạn.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )

                // Hiển thị Key bản quyền cố định của máy để người dùng lưu giữ
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF090F1D))
                        .border(1.dp, MagicCyan.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "🔑 Key bản quyền của máy:",
                            color = TextSecondary,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = fixedKey,
                            color = Color.White,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(7.dp))
                            .background(MagicCyan)
                            .clickable {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                if (clipboard != null) {
                                    clipboard.setPrimaryClip(ClipData.newPlainText("ProKey", fixedKey))
                                    Toast.makeText(context, "📋 Đã sao chép Key: $fixedKey", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Không truy cập được Clipboard", Toast.LENGTH_SHORT).show()
                                }
                            }
                            .padding(horizontal = 9.dp, vertical = 5.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(12.dp))
                            Text("Sao chép", color = Color(0xFF020617), fontSize = 10.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    } else {
        // =========================================================================
        // GIAO DIỆN NGƯỜI DÙNG FREE (HOẶC KHI ADMIN BẬT "TRẢI NGHIỆM GIAO DIỆN FREE"):
        // HIỂN THỊ TRỰC TIẾP MÃ QR CHUYỂN KHOẢN VIETQR + THÔNG TIN NGÂN HÀNG + NHẬP KEY Ở ĐẦU TRANG
        // =========================================================================
        val bankName = LicenseManager.getPaymentBankName(context)
        val bankCode = LicenseManager.getPaymentBankCode(context)
        val accountNumber = LicenseManager.getPaymentAccountNumber(context)
        val accountHolder = LicenseManager.getPaymentAccountHolder(context)

        val effectiveSelectedPackage = if (isUserLoggedIn) selectedPackage else 0
        val activePriceStr = if (effectiveSelectedPackage == 1) accountProPrice else proPrice
        val activeTransferContent = if (effectiveSelectedPackage == 1) "TKPRO $deviceId" else deviceId
        val numericAmount = activePriceStr.replace(Regex("[^0-9]"), "").ifBlank { "50000" }
        val encodedHolder = try {
            URLEncoder.encode(accountHolder, "UTF-8")
        } catch (_: Exception) {
            accountHolder
        }
        val encodedAddInfo = try {
            URLEncoder.encode(activeTransferContent, "UTF-8")
        } catch (_: Exception) {
            activeTransferContent
        }
        val qrUrl = "https://img.vietqr.io/image/$bankCode-$accountNumber-compact2.png?amount=$numericAmount&addInfo=$encodedAddInfo&accountName=$encodedHolder"

        val freeBorderBrush = remember { Brush.horizontalGradient(listOf(MagicAmber, MagicPurpleLight, MagicCyan)) }
        Card(
            modifier = modifier
                .fillMaxWidth()
                .testTag("pro_license_card_free_qr"),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.5.dp, freeBorderBrush)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Nếu Admin đang bật chế độ Giả lập Free, hiển thị thanh báo nhỏ để Admin biết & có thể tắt nhanh 1 chạm
                if (isSimulateFree) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicAmber.copy(alpha = 0.18f))
                            .border(1.dp, MagicAmber, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Science,
                                contentDescription = null,
                                tint = MagicAmber,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "🧪 Góc nhìn Người Dùng Free (Admin đang bật thử nghiệm)",
                                color = MagicAmber,
                                fontSize = 10.2.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicAmber)
                                .clickable {
                                    LicenseManager.setAdminSimulateFreeMode(context, false)
                                    refreshLocalState(context)
                                    Toast.makeText(
                                        context,
                                        "👑 Đã tắt giả lập Free và khôi phục giao diện Pro cho Admin!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Tắt thử Free",
                                color = Color(0xFF020617),
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                // Tiêu đề thẻ Free + Số lượt dùng thử còn lại (Tách hàng riêng cho mác & tiêu đề)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicAmber.copy(alpha = 0.22f))
                                .border(1.dp, MagicAmber, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = cardNumberBadge,
                                color = MagicAmber,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicRose.copy(alpha = 0.22f))
                                .border(1.dp, MagicRoseLight, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "FREE • Còn $remainingTrials/$totalTrialLimit lượt",
                                color = MagicRoseLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode,
                            contentDescription = "Nâng cấp Pro",
                            tint = MagicAmber,
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = "🔓 TRẠNG THÁI: BẢN MIỄN PHÍ • NÂNG CẤP PRO VĨNH VIỄN",
                            color = MagicAmber,
                            fontSize = 12.8.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Text(
                        text = "ID Máy: $deviceId • Còn $remainingTrials/$totalTrialLimit lượt dùng thử miễn phí",
                        color = MagicCyanLight,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Bảng so sánh trực quan quyền lợi Free vs Pro để người dùng thấy rõ lợi ích nâng cấp
                ProBenefitsComparisonSection(
                    proPrice = proPrice,
                    accountProPrice = accountProPrice,
                    totalTrialLimit = totalTrialLimit,
                    proOriginalPrice = proOriginalPrice,
                    accountProOriginalPrice = accountProOriginalPrice,
                    isProSaleActive = isProSaleActive
                )

                if (isProSaleActive && (proOriginalPrice.isNotBlank() || accountProOriginalPrice.isNotBlank())) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicRose.copy(alpha = 0.15f))
                            .border(1.dp, MagicRose.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Text("🔥", fontSize = 12.sp)
                            Text(
                                text = "ĐANG GIẢM GIÁ PRO! Khóa ưu đãi vĩnh viễn ngay hôm nay.",
                                color = MagicRoseLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Chọn gói nâng cấp: Chỉ hiện và cho chuyển khoản gói Pro Tài Khoản khi người dùng ĐÃ ĐĂNG NHẬP tài khoản
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val isPkg0 = effectiveSelectedPackage == 0
                    Surface(
                        onClick = { selectedPackage = 0 },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        color = if (isPkg0) MagicEmerald.copy(alpha = 0.18f) else Color(0xFF090F1D),
                        border = BorderStroke(if (isPkg0) 1.5.dp else 1.dp, if (isPkg0) MagicEmerald else MagicBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(9.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = "📱 PRO THIẾT BỊ",
                                color = if (isPkg0) MagicEmeraldLight else Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                            if (isProSaleActive && proOriginalPrice.isNotBlank() && proOriginalPrice != proPrice) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = proOriginalPrice,
                                        color = TextMuted,
                                        fontSize = 10.sp,
                                        textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MagicRose.copy(alpha = 0.25f))
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text("GIẢM", color = MagicRoseLight, fontSize = 7.5.sp, fontWeight = FontWeight.Black)
                                    }
                                }
                            }
                            Text(
                                text = proPrice,
                                color = MagicCyanLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Vĩnh viễn theo ID máy $deviceId",
                                color = TextSecondary,
                                fontSize = 9.2.sp
                            )
                        }
                    }

                    if (isUserLoggedIn) {
                        val isPkg1 = effectiveSelectedPackage == 1
                        Surface(
                            onClick = { selectedPackage = 1 },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = if (isPkg1) MagicAmber.copy(alpha = 0.18f) else Color(0xFF090F1D),
                            border = BorderStroke(if (isPkg1) 1.5.dp else 1.dp, if (isPkg1) MagicAmber else MagicBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(9.dp),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(
                                    text = "👑 PRO TÀI KHOẢN",
                                    color = if (isPkg1) MagicAmber else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )
                                if (isProSaleActive && accountProOriginalPrice.isNotBlank() && accountProOriginalPrice != accountProPrice) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = accountProOriginalPrice,
                                            color = TextMuted,
                                            fontSize = 10.sp,
                                            textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                                        )
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MagicRose.copy(alpha = 0.25f))
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        ) {
                                            Text("GIẢM", color = MagicRoseLight, fontSize = 7.5.sp, fontWeight = FontWeight.Black)
                                        }
                                    }
                                }
                                Text(
                                    text = accountProPrice,
                                    color = MagicAmber,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "Đổi máy tự do (1 máy/lần)",
                                    color = TextSecondary,
                                    fontSize = 9.2.sp
                                )
                            }
                        }
                    }
                }

                // Khung hiển thị trực tiếp Mã QR Chuyển Khoản VietQR + Thông tin Ngân hàng ngay đầu trang
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF090F1D))
                        .border(1.dp, MagicCyan.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (effectiveSelectedPackage == 1) {
                                "🏦 QUÉT MÃ VIETQR NÂNG CẤP PRO TÀI KHOẢN ($accountProPrice)"
                            } else {
                                "🏦 QUÉT MÃ VIETQR NÂNG CẤP PRO THIẾT BỊ ($proPrice)"
                            },
                            color = MagicCyanLight,
                            fontSize = 11.2.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )

                        Box(
                            modifier = Modifier
                                .size(196.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White)
                                .padding(6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            AsyncImage(
                                model = qrUrl,
                                contentDescription = "Mã QR chuyển khoản VietQR nâng cấp Pro",
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = "Ngân hàng: $bankName • STK: $accountNumber",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Chủ TK: $accountHolder • Số tiền: $activePriceStr",
                                color = MagicEmeraldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Nội dung CK bắt buộc: $activeTransferContent",
                                color = MagicAmber,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                        }

                        // Hàng nút Sao chép STK & Sao chép Nội dung CK
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                    if (clipboard != null) {
                                        clipboard.setPrimaryClip(ClipData.newPlainText("AccountNumber", accountNumber))
                                        Toast.makeText(context, "📋 Đã sao chép STK: $accountNumber", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Không truy cập được Clipboard", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 38.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Chép STK", color = MagicCyanLight, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                            }

                            Button(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                    if (clipboard != null) {
                                        clipboard.setPrimaryClip(ClipData.newPlainText("TransferContent", activeTransferContent))
                                        Toast.makeText(context, "📋 Đã sao chép nội dung CK: $activeTransferContent", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Không truy cập được Clipboard", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 38.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Chép Nội Dung CK", color = Color(0xFF020617), fontSize = 10.5.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                            }
                        }

                        // Nút Báo Đã Chuyển Khoản để tự động kích hoạt / báo Admin duyệt
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    val msg = if (effectiveSelectedPackage == 1) {
                                        "Khách báo đã chuyển $accountProPrice mua Pro Tài Khoản ($activeTransferContent)"
                                    } else {
                                        "Khách báo đã chuyển $proPrice mua Pro Thiết Bị ($activeTransferContent)"
                                    }
                                    try {
                                        LicenseManager.logCustomerPaymentIntent(context, "CLICKED_I_PAID", msg)
                                    } catch (_: Throwable) {}
                                    isCheckingCloud = true
                                    val activated = LicenseManager.refreshProStatus(context)
                                    isCheckingCloud = false
                                    refreshLocalState(context)
                                    if (activated) {
                                        onLicenseActivated()
                                        Toast.makeText(context, "🎉 Đã xác nhận thanh toán và kích hoạt Bản PRO thành công!", Toast.LENGTH_LONG).show()
                                    } else {
                                        Toast.makeText(
                                            context,
                                            "✅ Đã gửi thông báo chuyển khoản tới hệ thống! Hệ thống sẽ tự động mở khóa Pro ngay sau khi nhận được giao dịch.",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            },
                            enabled = !isCheckingCloud,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 40.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MagicAmber)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isCheckingCloud) "⏳ Đang kiểm tra trạng thái Pro trên Cloud..." else "⚡ Tôi Đã Chuyển Khoản (Báo Duyệt & Tự Mở Pro)",
                                color = Color(0xFF020617),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                // Ô nhập mã Key kích hoạt trực tiếp hoặc Quét khôi phục Pro theo ID máy
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = inputLicenseKey,
                        onValueChange = { inputLicenseKey = it },
                        modifier = Modifier.weight(1f),
                        placeholder = {
                            Text(
                                text = "Nhập mã Key Pro (XXXX-...)",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MagicCyan,
                            unfocusedBorderColor = MagicBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Button(
                        onClick = {
                            val cleanKey = inputLicenseKey.trim()
                            if (cleanKey.isBlank()) {
                                Toast.makeText(context, "Vui lòng nhập mã Key kích hoạt!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (cleanKey.uppercase().startsWith("TKPR") && !isUserLoggedIn) {
                                Toast.makeText(
                                    context,
                                    "🔒 Key Pro Tài Khoản (TKPR-...) yêu cầu bạn Đăng Nhập tài khoản trước để gắn quyền Pro vào tài khoản thật!",
                                    Toast.LENGTH_LONG
                                ).show()
                                return@Button
                            }
                            if (isSimulateFree) {
                                LicenseManager.setAdminSimulateFreeMode(context, false)
                            }
                            if (LicenseManager.verifyLicenseKey(context, cleanKey)) {
                                refreshLocalState(context)
                                onLicenseActivated()
                                Toast.makeText(context, "🎉 Kích hoạt Bản Quyền PRO Vĩnh Viễn thành công!", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "❌ Mã Key không hợp lệ cho thiết bị $deviceId!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.heightIn(min = 50.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald)
                    ) {
                        Icon(Icons.Default.Key, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Kích Hoạt", color = Color(0xFF020617), fontSize = 11.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                    }
                }

                Button(
                    onClick = {
                        coroutineScope.launch {
                            isCheckingCloud = true
                            val restored = LicenseManager.checkDeviceRecognizedProInCloud(context, forceRefresh = true)
                            isCheckingCloud = false
                            refreshLocalState(context)
                            if (restored || isPro) {
                                onLicenseActivated()
                                Toast.makeText(context, "🎉 Đã tìm thấy thiết bị $deviceId trên Cloud và khôi phục Pro thành công!", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(
                                    context,
                                    if (isSimulateFree) "🧪 Đang bật chế độ Giả lập Free nên hệ thống giữ nguyên giao diện Free! Hãy bấm 'Tắt thử Free' ở góc trên thẻ nếu muốn về lại Pro."
                                    else "⚠️ Chưa tìm thấy bản quyền Pro trên Cloud cho ID máy $deviceId.",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    },
                    enabled = !isCheckingCloud,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 40.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard)
                ) {
                    Icon(Icons.Default.Sync, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "🔄 Quét & Tự Khôi Phục Pro Theo ID Máy ($deviceId)",
                        color = MagicCyanLight,
                        fontSize = 10.8.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
