package com.example.core.widget

import androidx.compose.ui.geometry.Offset

/**
 * Thư viện Nét Bút Tâm Chuẩn (Vector Centerlines) & Đa Biến Thể Viết Tay cho 26 chữ cái (A–Z).
 * - Biến thể 0 (Primary): Nét in hoa chuẩn, rõ ràng dùng để hiển thị xem trước và làm mẫu mặc định.
 * - Các biến thể bổ sung: Bao gồm kiểu viết liền 1 nét, tách 2–4 nét, đảo thứ tự nét hoặc đảo chiều vẽ
 *   (đặc biệt cho A, E, F, H, I, K, M, N, T, X, Y, Z và các chữ cong O, Q, C, G, S, P, R, B, D, J, L, U, V, W)
 *   giúp nhận diện chính xác ngay cả khi người dùng không vẽ mẫu thủ công.
 */
object AutoLetterTemplates {

    private fun s(vararg pts: Pair<Int, Int>): List<Offset> =
        pts.map { Offset(it.first.toFloat(), it.second.toFloat()) }

    private fun normalizeVariant(raw: List<List<Offset>>): List<List<Offset>> =
        GestureLauncherOverlay.normalizeStrokesForTemplate(raw, pointsPerStroke = 24)

    private val rawVariantsByChar: Map<Char, List<List<List<Offset>>>> = mapOf(
        'A' to listOf(
            // 0: Chuẩn 3 nét (/ + \ + -)
            listOf(s(50 to 6, 14 to 94), s(50 to 6, 86 to 94), s(27 to 62, 73 to 62)),
            // 1: 2 nét (/\ liền + -)
            listOf(s(14 to 94, 50 to 6, 86 to 94), s(27 to 62, 73 to 62)),
            // 2: 2 nét từ đỉnh (/\ + -)
            listOf(s(50 to 6, 14 to 94), s(50 to 6, 86 to 94), s(73 to 62, 27 to 62)),
            // 3: Viết liền 1 nét từ dưới trái
            listOf(s(14 to 94, 50 to 6, 86 to 94, 73 to 62, 27 to 62)),
            // 4: Viết liền 1 nét từ trên đỉnh
            listOf(s(50 to 6, 14 to 94, 50 to 6, 86 to 94, 27 to 62, 73 to 62))
        ),
        'B' to listOf(
            // 0: Chuẩn 2 nét (| + 2 bụng)
            listOf(
                s(20 to 6, 20 to 94),
                s(20 to 6, 64 to 6, 82 to 18, 82 to 36, 64 to 48, 20 to 48, 68 to 48, 86 to 60, 86 to 82, 68 to 94, 20 to 94)
            ),
            // 1: 3 nét (| + bụng trên + bụng dưới)
            listOf(
                s(20 to 6, 20 to 94),
                s(20 to 6, 64 to 6, 82 to 18, 82 to 36, 64 to 48, 20 to 48),
                s(20 to 48, 68 to 48, 86 to 60, 86 to 82, 68 to 94, 20 to 94)
            ),
            // 2: Viết liền 1 nét
            listOf(
                s(20 to 94, 20 to 6, 64 to 6, 82 to 18, 82 to 36, 64 to 48, 20 to 48, 68 to 48, 86 to 60, 86 to 82, 68 to 94, 20 to 94)
            )
        ),
        'C' to listOf(
            // 0: Chuẩn 1 nét cong từ trên xuống dưới
            listOf(s(84 to 20, 64 to 6, 36 to 6, 16 to 24, 10 to 50, 16 to 76, 36 to 94, 64 to 94, 84 to 80)),
            // 1: C góc cạnh viết nhanh
            listOf(s(84 to 10, 20 to 10, 20 to 90, 84 to 90))
        ),
        'D' to listOf(
            // 0: Chuẩn 2 nét (| + vòng phải)
            listOf(
                s(20 to 6, 20 to 94),
                s(20 to 6, 56 to 6, 82 to 22, 88 to 50, 82 to 78, 56 to 94, 20 to 94)
            ),
            // 1: Viết liền 1 nét
            listOf(s(20 to 6, 20 to 94, 56 to 94, 82 to 78, 88 to 50, 82 to 22, 56 to 6, 20 to 6))
        ),
        'E' to listOf(
            // 0: Chuẩn 4 nét (| + trên + giữa + dưới)
            listOf(
                s(22 to 8, 22 to 92),
                s(22 to 8, 82 to 8),
                s(22 to 50, 72 to 50),
                s(22 to 92, 82 to 92)
            ),
            // 1: 3 nét (└ liền + trên + giữa)
            listOf(
                s(22 to 8, 22 to 92, 82 to 92),
                s(22 to 8, 82 to 8),
                s(22 to 50, 72 to 50)
            ),
            // 2: 2 nét ([ liền + gạch giữa)
            listOf(
                s(82 to 8, 22 to 8, 22 to 92, 82 to 92),
                s(22 to 50, 72 to 50)
            ),
            // 3: Viết liền 1 nét kiểu viết tay
            listOf(s(82 to 8, 22 to 8, 22 to 50, 72 to 50, 22 to 50, 22 to 92, 82 to 92)),
            // 4: Viết liền 1 nét bo tròn kiểu 3 ngược
            listOf(s(78 to 14, 50 to 6, 22 to 22, 22 to 42, 62 to 50, 22 to 58, 22 to 78, 50 to 94, 78 to 86))
        ),
        'F' to listOf(
            // 0: Chuẩn 3 nét (| + trên + giữa)
            listOf(
                s(24 to 8, 24 to 94),
                s(24 to 8, 82 to 8),
                s(24 to 50, 72 to 50)
            ),
            // 1: 2 nét (┌ liền + gạch giữa)
            listOf(
                s(82 to 8, 24 to 8, 24 to 94),
                s(24 to 50, 72 to 50)
            ),
            // 2: 2 nét (| + gạch trên, gạch giữa) — nét dọc sau
            listOf(
                s(24 to 8, 82 to 8),
                s(24 to 8, 24 to 94),
                s(24 to 50, 72 to 50)
            ),
            // 3: Viết liền 1 nét
            listOf(s(82 to 8, 24 to 8, 24 to 50, 72 to 50, 24 to 50, 24 to 94))
        ),
        'G' to listOf(
            // 0: Chuẩn 1 nét (C + móc ngang vào trong)
            listOf(s(84 to 22, 64 to 6, 36 to 6, 16 to 24, 10 to 50, 16 to 78, 38 to 94, 68 to 94, 86 to 78, 86 to 54, 54 to 54)),
            // 1: 2 nét (C + góc ┐)
            listOf(
                s(84 to 22, 64 to 6, 36 to 6, 16 to 24, 10 to 50, 16 to 78, 38 to 94, 68 to 94, 86 to 78),
                s(54 to 54, 86 to 54, 86 to 92)
            ),
            // 2: 1 nét có chân kéo xuống
            listOf(s(84 to 22, 64 to 6, 36 to 6, 16 to 24, 10 to 50, 16 to 78, 38 to 94, 68 to 94, 86 to 76, 86 to 54, 54 to 54, 86 to 54, 86 to 92))
        ),
        'H' to listOf(
            // 0: Chuẩn 3 nét (| trái + | phải + - giữa)
            listOf(
                s(20 to 6, 20 to 94),
                s(80 to 6, 80 to 94),
                s(20 to 50, 80 to 50)
            ),
            // 1: 2 nét (trái + ngang liền, phải)
            listOf(
                s(20 to 6, 20 to 94, 20 to 50, 80 to 50),
                s(80 to 6, 80 to 94)
            ),
            // 2: Viết liền 1 nét
            listOf(s(20 to 6, 20 to 94, 20 to 50, 80 to 50, 80 to 6, 80 to 94))
        ),
        'I' to listOf(
            // 0: Chuẩn 1 nét dọc từ trên xuống
            listOf(s(50 to 6, 50 to 94)),
            // 1: 3 nét có gạch đầu & chân
            listOf(
                s(28 to 8, 72 to 8),
                s(50 to 8, 50 to 92),
                s(28 to 92, 72 to 92)
            ),
            // 2: 1 nét dọc từ dưới lên
            listOf(s(50 to 94, 50 to 6))
        ),
        'J' to listOf(
            // 0: Chuẩn 1 nét móc
            listOf(s(68 to 8, 68 to 72, 58 to 90, 38 to 94, 22 to 82, 18 to 66)),
            // 1: 2 nét có gạch ngang trên đầu
            listOf(
                s(30 to 8, 84 to 8),
                s(68 to 8, 68 to 72, 58 to 90, 38 to 94, 22 to 82, 18 to 66)
            )
        ),
        'K' to listOf(
            // 0: Chuẩn 2 nét (| + <)
            listOf(
                s(22 to 6, 22 to 94),
                s(80 to 8, 22 to 52, 82 to 94)
            ),
            // 1: 3 nét (| + / + \)
            listOf(
                s(22 to 6, 22 to 94),
                s(80 to 8, 22 to 52),
                s(34 to 43, 82 to 94)
            ),
            // 2: Viết liền 1 nét
            listOf(s(22 to 6, 22 to 94, 22 to 52, 80 to 8, 22 to 52, 82 to 94))
        ),
        'L' to listOf(
            // 0: Chuẩn 1 nét liền
            listOf(s(22 to 6, 22 to 92, 82 to 92)),
            // 1: 2 nét tách rời
            listOf(s(22 to 6, 22 to 92), s(22 to 92, 82 to 92))
        ),
        'M' to listOf(
            // 0: Chuẩn 1 nét liền (từ dưới trái lên)
            listOf(s(12 to 94, 16 to 8, 50 to 62, 84 to 8, 88 to 94)),
            // 1: 2 nét (| trái + /\|)
            listOf(
                s(14 to 8, 14 to 94),
                s(14 to 8, 50 to 62, 86 to 8, 86 to 94)
            ),
            // 2: 4 nét tách rời
            listOf(
                s(14 to 8, 14 to 94),
                s(14 to 8, 50 to 62),
                s(50 to 62, 86 to 8),
                s(86 to 8, 86 to 94)
            ),
            // 3: Viết liền từ trên trái xuống (| + lên + chữ V + |)
            listOf(s(14 to 8, 14 to 94, 14 to 8, 50 to 62, 86 to 8, 86 to 94))
        ),
        'N' to listOf(
            // 0: Chuẩn 1 nét liền (từ dưới trái lên)
            listOf(s(18 to 94, 18 to 8, 82 to 92, 82 to 6)),
            // 1: 2 nét (| trái + \|)
            listOf(
                s(18 to 8, 18 to 94),
                s(18 to 8, 82 to 92, 82 to 6)
            ),
            // 2: 3 nét (| + \ + |)
            listOf(
                s(18 to 8, 18 to 94),
                s(18 to 8, 82 to 94),
                s(82 to 8, 82 to 94)
            ),
            // 3: 1 nét từ trên trái xuống, vòng lên
            listOf(s(18 to 8, 18 to 94, 18 to 8, 82 to 92, 82 to 6))
        ),
        'O' to listOf(
            // 0: Chuẩn 1 nét ngược chiều kim đồng hồ
            listOf(s(50 to 6, 24 to 14, 10 to 36, 10 to 64, 24 to 86, 50 to 94, 76 to 86, 90 to 64, 90 to 36, 76 to 14, 50 to 6)),
            // 1: 1 nét thuận chiều kim đồng hồ
            listOf(s(50 to 6, 76 to 14, 90 to 36, 90 to 64, 76 to 86, 50 to 94, 24 to 86, 10 to 64, 10 to 36, 24 to 14, 50 to 6))
        ),
        'P' to listOf(
            // 0: Chuẩn 2 nét (| + vòng trên)
            listOf(
                s(22 to 6, 22 to 94),
                s(22 to 8, 64 to 8, 84 to 18, 84 to 38, 64 to 50, 22 to 50)
            ),
            // 1: Viết liền 1 nét
            listOf(s(22 to 94, 22 to 8, 64 to 8, 84 to 18, 84 to 38, 64 to 50, 22 to 50))
        ),
        'Q' to listOf(
            // 0: Chuẩn 2 nét (O ngược chiều KĐH + gạch đuôi)
            listOf(
                s(50 to 6, 24 to 14, 10 to 36, 10 to 64, 24 to 86, 50 to 94, 76 to 86, 90 to 64, 90 to 36, 76 to 14, 50 to 6),
                s(56 to 62, 90 to 96)
            ),
            // 1: 2 nét (O thuận chiều KĐH + gạch đuôi)
            listOf(
                s(50 to 6, 76 to 14, 90 to 36, 90 to 64, 76 to 86, 50 to 94, 24 to 86, 10 to 64, 10 to 36, 24 to 14, 50 to 6),
                s(56 to 62, 90 to 96)
            ),
            // 2: Viết liền 1 nét
            listOf(s(50 to 6, 24 to 14, 10 to 36, 10 to 64, 24 to 86, 50 to 94, 76 to 86, 90 to 64, 90 to 36, 76 to 14, 50 to 6, 72 to 74, 92 to 96))
        ),
        'R' to listOf(
            // 0: Chuẩn 2 nét (| + vòng + chân đá)
            listOf(
                s(22 to 6, 22 to 94),
                s(22 to 8, 64 to 8, 82 to 18, 82 to 38, 64 to 50, 22 to 50, 50 to 50, 84 to 94)
            ),
            // 1: 3 nét (| + vòng + chân đá)
            listOf(
                s(22 to 6, 22 to 94),
                s(22 to 8, 64 to 8, 82 to 18, 82 to 38, 64 to 50, 22 to 50),
                s(48 to 50, 84 to 94)
            ),
            // 2: Viết liền 1 nét
            listOf(s(22 to 94, 22 to 8, 64 to 8, 82 to 18, 82 to 38, 64 to 50, 22 to 50, 50 to 50, 84 to 94))
        ),
        'S' to listOf(
            // 0: Chuẩn 1 nét cong uốn lượn
            listOf(s(80 to 18, 62 to 6, 36 to 6, 18 to 18, 18 to 34, 36 to 46, 66 to 54, 84 to 68, 84 to 84, 64 to 94, 34 to 94, 16 to 82)),
            // 1: S góc cạnh viết nhanh
            listOf(s(80 to 10, 22 to 10, 20 to 46, 82 to 54, 80 to 90, 18 to 90))
        ),
        'T' to listOf(
            // 0: Chuẩn 2 nét (ngang trên trước + dọc sau)
            listOf(
                s(12 to 8, 88 to 8),
                s(50 to 8, 50 to 94)
            ),
            // 1: 2 nét (dọc trước + ngang trên sau)
            listOf(
                s(50 to 8, 50 to 94),
                s(12 to 8, 88 to 8)
            ),
            // 2: Viết liền 1 nét
            listOf(s(12 to 8, 88 to 8, 50 to 8, 50 to 94))
        ),
        'U' to listOf(
            // 0: Chuẩn 1 nét cong
            listOf(s(18 to 8, 18 to 68, 28 to 86, 50 to 94, 72 to 86, 82 to 68, 82 to 8)),
            // 1: 1 nét có móc kéo thẳng chân phải
            listOf(s(18 to 8, 18 to 68, 28 to 86, 50 to 94, 72 to 86, 82 to 68, 82 to 8, 82 to 92))
        ),
        'V' to listOf(
            // 0: Chuẩn 1 nét nhọn
            listOf(s(14 to 8, 50 to 94, 86 to 8)),
            // 1: 2 nét
            listOf(s(14 to 8, 50 to 94), s(86 to 8, 50 to 94))
        ),
        'W' to listOf(
            // 0: Chuẩn 1 nét liền
            listOf(s(8 to 8, 28 to 94, 50 to 32, 72 to 94, 92 to 8)),
            // 1: 2 nét (V + V)
            listOf(s(8 to 8, 28 to 94, 50 to 26), s(50 to 26, 72 to 94, 92 to 8)),
            // 2: 4 nét rời
            listOf(s(8 to 8, 28 to 94), s(28 to 94, 50 to 26), s(50 to 26, 72 to 94), s(72 to 94, 92 to 8))
        ),
        'X' to listOf(
            // 0: Chuẩn 2 nét (\ rồi /)
            listOf(s(14 to 8, 86 to 92), s(86 to 8, 14 to 92)),
            // 1: 2 nét đảo thứ tự (/ rồi \)
            listOf(s(86 to 8, 14 to 92), s(14 to 8, 86 to 92)),
            // 2: Viết liền 1 nét từ trên trái
            listOf(s(14 to 8, 86 to 92, 86 to 8, 14 to 92)),
            // 3: Viết liền 1 nét từ dưới trái
            listOf(s(14 to 92, 86 to 8, 14 to 8, 86 to 92))
        ),
        'Y' to listOf(
            // 0: Chuẩn 2 nét (\ ngắn + / thẳng chân đứng)
            listOf(s(16 to 8, 50 to 50), s(84 to 8, 50 to 50, 50 to 94)),
            // 1: 3 nét (\ + / + |)
            listOf(s(16 to 8, 50 to 50), s(84 to 8, 50 to 50), s(50 to 50, 50 to 94)),
            // 2: 2 nét chéo (/ dài xuống đáy trái)
            listOf(s(16 to 8, 50 to 52), s(84 to 8, 22 to 94)),
            // 3: Viết liền 1 nét (chữ U có chân hoặc chéo liền)
            listOf(s(16 to 8, 50 to 50, 84 to 8, 50 to 50, 50 to 94))
        ),
        'Z' to listOf(
            // 0: Chuẩn 1 nét
            listOf(s(14 to 10, 86 to 10, 14 to 90, 86 to 90)),
            // 1: 2 nét có gạch ngang giữa thân
            listOf(s(14 to 10, 86 to 10, 14 to 90, 86 to 90), s(32 to 50, 68 to 50)),
            // 2: 3 nét tách rời
            listOf(s(14 to 10, 86 to 10), s(86 to 10, 14 to 90), s(14 to 90, 86 to 90))
        )
    )

    private val normalizedCache: Map<Char, List<List<List<Offset>>>> by lazy {
        rawVariantsByChar.mapValues { (_, variants) ->
            variants.mapNotNull { variant ->
                normalizeVariant(variant).takeIf { it.isNotEmpty() }
            }
        }
    }

    fun getPrimaryTemplate(char: Char): List<List<Offset>>? {
        val upper = char.uppercaseChar()
        return normalizedCache[upper]?.firstOrNull()
    }

    fun getAllNormalizedVariants(char: Char): List<List<List<Offset>>> {
        val upper = char.uppercaseChar()
        return normalizedCache[upper].orEmpty()
    }
}
