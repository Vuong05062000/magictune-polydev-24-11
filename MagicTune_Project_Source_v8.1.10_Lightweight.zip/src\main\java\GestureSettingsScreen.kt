package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.widget.AppIconImage
import com.example.core.widget.GestureLauncherOverlay
import com.example.core.widget.LauncherAppItem
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicPurple
import com.example.ui.theme.MagicPurpleLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun GestureSettingsScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    // Chỉ đọc RAM @Volatile trong remember (0ms), tuyệt đối không đọc file JSON hay SharedPreferences nặng trên Main Thread
    var apps by remember {
        mutableStateOf(GestureLauncherOverlay.peekCachedInstalledApps().orEmpty())
    }
    val appByPkgMap = remember(apps) { apps.associateBy { it.packageName } }
    var gestureMap by remember { mutableStateOf<Map<Char, String>>(emptyMap()) }
    var editingChar by remember { mutableStateOf<Char?>(null) }
    var templateStudioChar by remember { mutableStateOf<Char?>(null) }
    var templateVersion by remember { mutableIntStateOf(0) }
    var isDirectLaunch by remember { mutableStateOf(false) }
    var isSettingsLoaded by remember { mutableStateOf(false) }
    var customTemplatesMap by remember { mutableStateOf<Map<Char, List<List<Offset>>>>(emptyMap()) }
    var userTemplateChars by remember { mutableStateOf<Set<Char>>(emptySet()) }

    LaunchedEffect(templateVersion) {
        val (loadedTemplates, loadedUserChars) = withContext(Dispatchers.Default) {
            val map = mutableMapOf<Char, List<List<Offset>>>()
            for (c in 'A'..'Z') {
                val tmpl = GestureLauncherOverlay.getCustomTemplate(context, c)
                if (tmpl != null) {
                    map[c] = tmpl
                }
            }
            val userChars = GestureLauncherOverlay.getUserTemplateChars(context)
            Pair(map.toMap(), userChars)
        }
        customTemplatesMap = loadedTemplates
        userTemplateChars = loadedUserChars
    }

    LaunchedEffect(Unit) {
        try {
            val loadedTuple = withContext(Dispatchers.IO) {
                GestureLauncherOverlay.ensureAutoTemplatesSeeded(context)
                val cachedOrHydrated = GestureLauncherOverlay.peekOrHydrateInstalledApps(context)
                val loadedApps = (if (cachedOrHydrated.isNotEmpty()) {
                    cachedOrHydrated
                } else {
                    GestureLauncherOverlay.getInstalledLauncherApps(context)
                }).distinctBy { it.packageName }
                val loadedGestureMap = GestureLauncherOverlay.getOrInitAllGestureMappings(context, loadedApps)
                val directLaunch = GestureLauncherOverlay.isDirectLaunchAfterDraw(context)
                val prefs = context.getSharedPreferences("magictune_gestures", android.content.Context.MODE_PRIVATE)
                val pendingChar = prefs.getString("pending_assign_char", null)?.trim()?.firstOrNull()?.uppercaseChar()
                if (pendingChar != null && pendingChar in 'A'..'Z') {
                    prefs.edit().remove("pending_assign_char").apply()
                }
                Triple(loadedApps, loadedGestureMap, Pair(directLaunch, pendingChar))
            }
            apps = loadedTuple.first
            gestureMap = loadedTuple.second
            isDirectLaunch = loadedTuple.third.first
            val pendingChar = loadedTuple.third.second
            if (pendingChar != null && pendingChar in 'A'..'Z') {
                editingChar = pendingChar
            }
            templateVersion++
            // Làm mới ngầm danh sách nếu có ứng dụng mới cài đặt mà không chặn UI
            GestureLauncherOverlay.prewarmCacheAsync(context)
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            Toast.makeText(context, "Không tải được danh sách ứng dụng. Hãy mở lại mục Cài đặt chữ.", Toast.LENGTH_LONG).show()
        } finally {
            isSettingsLoaded = true
        }
    }

    val letterList = remember { ('A'..'Z').toList() }

    if (!isSettingsLoaded) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                CircularProgressIndicator(color = MagicCyanLight)
                Text("Đang tải danh sách ứng dụng và nét vẽ…", color = TextSecondary, fontSize = 12.sp)
            }
        }
    } else LazyColumn(
        state = listState,
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Ô #46: Trạm Điều Khiển Vẽ Chữ Cái (A-Z), Tạo Nét Vẽ Mẫu & Chọn Cơ Chế Mở App
        item(key = "gesture_card_35") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(
                1.5.dp,
                Brush.linearGradient(listOf(MagicCyan, MagicEmerald))
            )
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan.copy(alpha = 0.22f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Ô #46",
                            color = MagicCyanLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "So khớp Nét Vẽ Mẫu thông minh • Tùy chọn Hiện kết quả hoặc Mở thẳng",
                        color = MagicEmeraldLight,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text(
                    text = "✍️ Vẽ Chữ Mở App & Tạo Nét Vẽ Mẫu Chuẩn Xác",
                    color = Color.White,
                    fontSize = 14.5.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "• Tạo Nét Vẽ Mẫu riêng cho từng chữ cái (A–Z) theo thói quen tay của bạn: Khi vẽ trên màn hình, hệ thống đối chiếu độ tương đồng với nét vẽ mẫu đã thiết lập để mở đúng ứng dụng 100%.\n• Bạn có thể chọn cơ chế Hiện bảng kết quả sau khi vẽ hoặc Mở thẳng ứng dụng ngay sau khi vẽ!",
                    color = TextSecondary,
                    fontSize = 11.5.sp,
                    lineHeight = 16.5.sp
                )

                // HỘP LỰA CHỌN CƠ CHẾ SAU KHI VẼ: HIỆN KẾT QUẢ vs MỞ THẲNG NGAY SAU KHI VẼ
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                    border = BorderStroke(
                        1.2.dp,
                        if (isDirectLaunch) MagicEmerald.copy(alpha = 0.7f) else MagicCyan.copy(alpha = 0.6f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "⚡ Cơ Chế Hành Động Sau Khi Vẽ:",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = if (isDirectLaunch)
                                        "Đang chọn: MỞ THẲNG NGAY SAU KHI VẼ (Vẽ xong tự động phóng thẳng vào ứng dụng khớp nhất)"
                                    else
                                        "Đang chọn: HIỆN KẾT QUẢ SAU KHI VẼ (Hiện bảng độ tương đồng % & danh sách app để chọn)",
                                    color = if (isDirectLaunch) MagicEmeraldLight else MagicCyanLight,
                                    fontSize = 10.5.sp,
                                    lineHeight = 14.5.sp
                                )
                            }
                            Switch(
                                checked = isDirectLaunch,
                                onCheckedChange = { direct ->
                                    isDirectLaunch = direct
                                    GestureLauncherOverlay.setDirectLaunchAfterDraw(context, direct)
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color(0xFF020617),
                                    checkedTrackColor = MagicEmerald,
                                    uncheckedThumbColor = MagicCyanLight,
                                    uncheckedTrackColor = Color(0xFF334155)
                                )
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (!isDirectLaunch) MagicCyan.copy(alpha = 0.22f)
                                        else Color(0xFF0F172A)
                                    )
                                    .border(
                                        1.dp,
                                        if (!isDirectLaunch) MagicCyanLight else Color(0xFF334155),
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable {
                                        isDirectLaunch = false
                                        GestureLauncherOverlay.setDirectLaunchAfterDraw(context, false)
                                    }
                                    .padding(vertical = 8.dp, horizontal = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (!isDirectLaunch) "👁️ Hiện Kết Quả Sau Vẽ ✓" else "👁️ Hiện Kết Quả Sau Vẽ",
                                    color = if (!isDirectLaunch) MagicCyanLight else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = if (!isDirectLaunch) FontWeight.Black else FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (isDirectLaunch) MagicEmerald.copy(alpha = 0.25f)
                                        else Color(0xFF0F172A)
                                    )
                                    .border(
                                        1.dp,
                                        if (isDirectLaunch) MagicEmeraldLight else Color(0xFF334155),
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable {
                                        isDirectLaunch = true
                                        GestureLauncherOverlay.setDirectLaunchAfterDraw(context, true)
                                    }
                                    .padding(vertical = 8.dp, horizontal = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (isDirectLaunch) "🚀 Mở Thẳng Sau Vẽ ✓" else "🚀 Mở Thẳng Sau Vẽ",
                                    color = if (isDirectLaunch) MagicEmeraldLight else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isDirectLaunch) FontWeight.Black else FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                // TRẠM QUẢN LÝ NÉT VẼ MẪU TỔNG QUAN (HỖ TRỢ TẠO TỰ ĐỘNG 26/26 ĐA BIẾN THỂ + TỰ VẼ ĐÈ)
                val userTmplCount = userTemplateChars.size
                val autoTmplCount = (customTemplatesMap.size - userTmplCount).coerceAtLeast(0)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MagicPurple.copy(alpha = 0.14f))
                        .border(1.dp, MagicPurple.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "✨ Nét Vẽ Mẫu Đã Thiết Lập: ${customTemplatesMap.size}/26 chữ cái",
                            color = MagicPurpleLight,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = if (customTemplatesMap.isEmpty())
                                "Chưa có nét mẫu. Bấm '⚡ Tạo Tự Động 26/26' để nạp ngay toàn bộ mẫu chuẩn hoặc tự vẽ theo tay bạn."
                            else
                                "$autoTmplCount mẫu tự động đa biến thể • $userTmplCount mẫu bạn tự vẽ (có thể vẽ đè bất kỳ chữ nào)",
                            color = Color.White.copy(alpha = 0.88f),
                            fontSize = 10.5.sp,
                            lineHeight = 14.sp
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    val updated = withContext(Dispatchers.IO) {
                                        GestureLauncherOverlay.autoGenerateAllTemplates(
                                            context = context,
                                            overwriteUserTemplates = false
                                        )
                                    }
                                    templateVersion++
                                    Toast.makeText(
                                        context,
                                        "⚡ Đã nạp tự động $updated mẫu chuẩn đa biến thể (giữ nguyên $userTmplCount mẫu bạn tự vẽ)!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 7.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicCyan,
                                contentColor = Color(0xFF020617)
                            )
                        ) {
                            Text(
                                text = "⚡ Tạo Tự Động 26/26",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                        Button(
                            onClick = { templateStudioChar = 'G' },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 7.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicPurple,
                                contentColor = Color.White
                            )
                        ) {
                            Text(
                                text = "✍️ Tạo / Sửa Nét Mẫu",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { GestureLauncherOverlay.show(context) },
                        modifier = Modifier
                            .weight(1.4f)
                            .heightIn(min = 48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicEmerald,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "✍️ MỞ BẢNG VẼ THỬ NGAY",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            coroutineScope.launch {
                                val resetMap = withContext(Dispatchers.IO) {
                                    GestureLauncherOverlay.resetDefaultGestureMappings(context)
                                }
                                gestureMap = resetMap
                                Toast.makeText(
                                    context,
                                    "✅ Đã đồng bộ & làm mới mặc định 26 chữ cái A–Z!",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicCyanLight)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Mặc Định A–Z",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                    }
                }
            }
        }
        }

        // Ô #47: Danh Sách 26 Chữ Cái A-Z Gắn Ứng Dụng & Nét Vẽ Mẫu
        item(key = "gesture_card_36_header") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan.copy(alpha = 0.22f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Ô #47",
                            color = MagicCyanLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
                Text(
                    text = "🔤 Danh Sách Thiết Lập 26 Chữ Cái (A–Z) & Nét Vẽ Mẫu",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Bấm '✍️ Vẽ Mẫu' để tạo nét vẽ chuẩn cho chữ đó hoặc 'Đổi App' để gán ứng dụng",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        }

        items(
            items = letterList,
            key = { "gesture_letter_$it" },
            contentType = { "gesture_letter_row" }
        ) { c ->
            val pkg = gestureMap[c]
            val matchedApp = if (pkg != null) appByPkgMap[pkg] else null
            val savedTemplate = customTemplatesMap[c]
            val hasTemplate = savedTemplate != null
            val isUserDrawnTemplate = c in userTemplateChars

            Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { editingChar = c },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                        border = BorderStroke(
                            1.dp,
                            when {
                                hasTemplate -> MagicEmerald.copy(alpha = 0.65f)
                                matchedApp != null -> MagicCyan.copy(alpha = 0.4f)
                                else -> MagicBorder
                            }
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 9.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(RoundedCornerShape(11.dp))
                                            .background(MagicCyan.copy(alpha = 0.16f))
                                            .border(1.dp, MagicCyan.copy(alpha = 0.55f), RoundedCornerShape(11.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = c.toString(),
                                            color = MagicCyanLight,
                                            fontSize = 16.5.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }

                                    if (matchedApp != null) {
                                        AppIconImage(
                                            packageName = matchedApp.packageName,
                                            label = matchedApp.label,
                                            modifier = Modifier.size(36.dp),
                                            cornerRadius = 10.dp
                                        )
                                    }

                                    // Nếu đã tạo Nét Vẽ Mẫu cho chữ cái này -> Hiển thị ô xem trước nét vẽ mẫu trực quan
                                    if (savedTemplate != null) {
                                        MiniStrokePreviewBox(
                                            normalizedStrokes = savedTemplate,
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clickable { templateStudioChar = c }
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(5.dp))
                                            .background(
                                                when {
                                                    isUserDrawnTemplate -> MagicEmerald.copy(alpha = 0.18f)
                                                    hasTemplate -> MagicCyan.copy(alpha = 0.16f)
                                                    matchedApp != null -> MagicCyan.copy(alpha = 0.14f)
                                                    else -> Color(0xFF334155).copy(alpha = 0.45f)
                                                }
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = when {
                                                isUserDrawnTemplate -> "✍️ Mẫu tự vẽ"
                                                hasTemplate -> "⚡ Mẫu tự động"
                                                matchedApp != null -> "Đã gán App"
                                                else -> "Chưa gán"
                                            },
                                            color = when {
                                                isUserDrawnTemplate -> MagicEmeraldLight
                                                hasTemplate -> MagicCyanLight
                                                matchedApp != null -> MagicCyanLight
                                                else -> TextSecondary
                                            },
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                if (hasTemplate) MagicEmerald.copy(alpha = 0.2f)
                                                else MagicPurple.copy(alpha = 0.16f)
                                            )
                                            .border(
                                                1.dp,
                                                if (hasTemplate) MagicEmerald else MagicPurple.copy(alpha = 0.55f),
                                                RoundedCornerShape(8.dp)
                                            )
                                            .clickable { templateStudioChar = c }
                                            .padding(horizontal = 8.dp, vertical = 5.dp)
                                    ) {
                                        Text(
                                            text = if (hasTemplate) "✍️ Sửa Mẫu" else "✍️ Vẽ Mẫu",
                                            color = if (hasTemplate) MagicEmeraldLight else MagicPurpleLight,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MagicCyan.copy(alpha = 0.14f))
                                            .border(1.dp, MagicCyan.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                                            .clickable { editingChar = c }
                                            .padding(horizontal = 8.dp, vertical = 5.dp)
                                    ) {
                                        Text(
                                            text = "Đổi App",
                                            color = MagicCyanLight,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                }
                            }

                            Text(
                                text = matchedApp?.label ?: "Chưa gán ứng dụng",
                                color = if (matchedApp != null) Color.White else TextMuted,
                                fontSize = 12.8.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Text(
                                text = when {
                                    isUserDrawnTemplate -> "✍️ Đang dùng nét vẽ tay riêng của bạn • ${matchedApp?.packageName ?: "Chưa gán app"}"
                                    hasTemplate -> "⚡ Đang dùng mẫu chuẩn tự động (đa biến thể) • ${matchedApp?.packageName ?: "Chưa gán app"}"
                                    else -> (matchedApp?.packageName ?: "Chạm để chọn ứng dụng mở khi vẽ chữ $c")
                                },
                                color = if (isUserDrawnTemplate) MagicEmeraldLight else if (hasTemplate || matchedApp != null) MagicCyanLight else MagicAmber,
                                fontSize = 10.sp,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
    }

    // DIALOG TẠO & KIỂM TRA NÉT VẼ MẪU CHO CHỮ CÁI A–Z
    templateStudioChar?.let { initialChar ->
        CustomTemplateStudioDialog(
            initialChar = initialChar,
            apps = apps,
            gestureMap = gestureMap,
            onDismiss = { templateStudioChar = null },
            onTemplateSavedOrCleared = {
                templateVersion++
            }
        )
    }

    // DIALOG CHỌN ỨNG DỤNG CHO CHỮ CÁI A–Z
    editingChar?.let { charToEdit ->
        var filterQuery by remember { mutableStateOf("") }
        val filteredApps = remember(filterQuery, apps) {
            if (filterQuery.isBlank()) apps
            else {
                val norm = GestureLauncherOverlay.normalizeAppText(filterQuery)
                apps.filter {
                    it.normalizedLabel.contains(norm) || it.packageName.lowercase().contains(norm)
                }
            }
        }

        Dialog(onDismissRequest = { editingChar = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 560.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                border = BorderStroke(1.5.dp, MagicCyan)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Chọn Ứng Dụng Cho Chữ '$charToEdit'",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black
                    )
                    OutlinedTextField(
                        value = filterQuery,
                        onValueChange = { filterQuery = it },
                        placeholder = { Text("Tìm tên ứng dụng...", color = TextMuted, fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MagicCyanLight) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    LazyColumn(
                        modifier = Modifier.weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        itemsIndexed(
                            items = filteredApps,
                            key = { _, app -> app.packageName },
                            contentType = { _, _ -> "gesture_picker_app" }
                        ) { _, app ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MagicSurfaceCard)
                                    .clickable {
                                        GestureLauncherOverlay.setGestureForChar(context, charToEdit, app.packageName)
                                        gestureMap = gestureMap.toMutableMap().apply {
                                            put(charToEdit, app.packageName)
                                        }
                                        Toast.makeText(
                                            context,
                                            "✅ Đã gán chữ '$charToEdit' ➔ ${app.label}",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        editingChar = null
                                    }
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                AppIconImage(
                                    packageName = app.packageName,
                                    label = app.label,
                                    modifier = Modifier.size(38.dp),
                                    cornerRadius = 10.dp
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = app.label,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = app.packageName,
                                        color = TextMuted,
                                        fontSize = 10.5.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (gestureMap[charToEdit] != null) {
                            TextButton(
                                onClick = {
                                    GestureLauncherOverlay.clearGestureForChar(context, charToEdit)
                                    gestureMap = gestureMap.toMutableMap().apply {
                                        remove(charToEdit)
                                    }
                                    Toast.makeText(
                                        context,
                                        "Đã bỏ gán ứng dụng cho chữ '$charToEdit'",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    editingChar = null
                                }
                            ) {
                                Text("🗑️ Bỏ gán chữ '$charToEdit'", color = MagicAmber, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Spacer(modifier = Modifier.width(8.dp))
                        }

                        TextButton(onClick = { editingChar = null }) {
                            Text("Đóng", color = MagicCyanLight, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniStrokePreviewBox(
    normalizedStrokes: List<List<Offset>>,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(9.dp))
            .background(Color(0xFF020617))
            .border(1.dp, MagicEmerald.copy(alpha = 0.65f), RoundedCornerShape(9.dp))
            .padding(4.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width.coerceAtLeast(1f)
            val h = size.height.coerceAtLeast(1f)
            val strokeStyle = Stroke(width = 3.5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            for (s in normalizedStrokes) {
                val p0 = s.firstOrNull() ?: continue
                if (s.size > 1) {
                    val path = Path().apply {
                        moveTo((p0.x / 100f) * w, (p0.y / 100f) * h)
                        for (i in 1 until s.size) {
                            lineTo((s[i].x / 100f) * w, (s[i].y / 100f) * h)
                        }
                    }
                    drawPath(path = path, color = MagicEmeraldLight, style = strokeStyle)
                }
            }
        }
    }
}

@Composable
private fun CustomTemplateStudioDialog(
    initialChar: Char,
    apps: List<LauncherAppItem>,
    gestureMap: Map<Char, String>,
    onDismiss: () -> Unit,
    onTemplateSavedOrCleared: () -> Unit
) {
    val context = LocalContext.current
    var activeChar by remember { mutableStateOf(initialChar.uppercaseChar()) }
    var refreshKey by remember { mutableIntStateOf(0) }
    val savedTemplate = remember(activeChar, refreshKey) {
        GestureLauncherOverlay.getCustomTemplate(context, activeChar)
    }
    val isUserTemplate = remember(activeChar, refreshKey) {
        GestureLauncherOverlay.isUserCustomTemplate(context, activeChar)
    }
    val strokes = remember(activeChar) { mutableStateListOf<List<Offset>>() }
    var currentStroke by remember(activeChar) { mutableStateOf<List<Offset>>(emptyList()) }
    val assignedApp = remember(activeChar, gestureMap, apps) {
        val pkg = gestureMap[activeChar]
        apps.find { it.packageName == pkg }
    }

    val liveSimilarity: Int? = remember(strokes.size, savedTemplate, activeChar, refreshKey) {
        if (strokes.isEmpty() || savedTemplate == null) null
        else GestureLauncherOverlay.computeBestSimilarityForLetter(
            context = context,
            char = activeChar,
            drawnStrokes = strokes.toList()
        )?.roundToInt()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(8.dp),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.5.dp, Brush.linearGradient(listOf(MagicCyan, MagicEmerald)))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "✍️ Tạo Nét Vẽ Mẫu Cho Chữ '$activeChar'",
                            color = Color.White,
                            fontSize = 15.5.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = if (assignedApp != null)
                                "Ứng dụng gán: ${assignedApp.label} (${assignedApp.packageName})"
                            else
                                "Chưa gán ứng dụng cho chữ '$activeChar'",
                            color = MagicEmeraldLight,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Đóng", tint = TextSecondary)
                    }
                }

                // Thanh cuộn ngang chọn nhanh chữ cái A–Z ngay trong hộp thoại
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ('A'..'Z').forEach { c ->
                        val isSel = c == activeChar
                        val hasTmpl = remember(c, refreshKey) {
                            GestureLauncherOverlay.hasCustomTemplate(context, c)
                        }
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    when {
                                        isSel -> MagicCyan
                                        hasTmpl -> MagicEmerald.copy(alpha = 0.22f)
                                        else -> MagicSurfaceCard
                                    }
                                )
                                .border(
                                    1.dp,
                                    when {
                                        isSel -> Color.White
                                        hasTmpl -> MagicEmerald
                                        else -> MagicBorder
                                    },
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    activeChar = c
                                    strokes.clear()
                                    currentStroke = emptyList()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = c.toString(),
                                color = if (isSel) Color(0xFF020617) else if (hasTmpl) MagicEmeraldLight else Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                // Trạng thái Nét Vẽ Mẫu hiện tại & Độ tương đồng khi vẽ thử
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MagicSurfaceCard)
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = when {
                            savedTemplate != null && isUserTemplate ->
                                "✍️ Đang dùng mẫu bạn tự vẽ (${savedTemplate.size} nét). Có thể vẽ lại để cập nhật."
                            savedTemplate != null ->
                                "⚡ Đang dùng mẫu tự động đa biến thể (${savedTemplate.size} nét chuẩn). Vẽ lên bảng nếu muốn thay bằng nét tay riêng!"
                            else ->
                                "💡 Hãy vẽ chữ '$activeChar' theo thói quen của bạn lên bảng bên dưới rồi bấm Lưu Mẫu!"
                        },
                        color = if (savedTemplate != null) MagicEmeraldLight else TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.weight(1f)
                    )
                    if (liveSimilarity != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    if (liveSimilarity >= 65) MagicEmerald.copy(alpha = 0.25f)
                                    else MagicAmber.copy(alpha = 0.25f)
                                )
                                .border(
                                    1.dp,
                                    if (liveSimilarity >= 65) MagicEmeraldLight else MagicAmber,
                                    RoundedCornerShape(6.dp)
                                )
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "Khớp ${liveSimilarity}%",
                                color = if (liveSimilarity >= 65) MagicEmeraldLight else MagicAmber,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                // Bảng Vẽ Nét Mẫu Tương Tác
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(276.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF020617))
                        .border(1.5.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(activeChar) {
                                awaitEachGesture {
                                    val down = awaitFirstDown(requireUnconsumed = false)
                                    val pts = mutableListOf(down.position)
                                    currentStroke = pts.toList()
                                    while (true) {
                                        val event = awaitPointerEvent()
                                        val change = event.changes.firstOrNull() ?: break
                                        if (change.pressed) {
                                            pts.add(change.position)
                                            currentStroke = pts.toList()
                                            change.consume()
                                        } else {
                                            break
                                        }
                                    }
                                    if (pts.size >= 2) {
                                        strokes.add(pts.toList())
                                    }
                                    currentStroke = emptyList()
                                }
                            }
                    ) {
                        val pad = 28f
                        val availW = (size.width - pad * 2f).coerceAtLeast(1f)
                        val availH = (size.height - pad * 2f).coerceAtLeast(1f)

                        // Vẽ mẫu đã lưu (nét mờ phía dưới để đối chiếu)
                        if (savedTemplate != null) {
                            val ghostStyle = Stroke(width = 14f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                            for (s in savedTemplate) {
                                val p0 = s.firstOrNull() ?: continue
                                if (s.size > 1) {
                                    val path = Path().apply {
                                        moveTo(pad + (p0.x / 100f) * availW, pad + (p0.y / 100f) * availH)
                                        for (i in 1 until s.size) {
                                            lineTo(pad + (s[i].x / 100f) * availW, pad + (s[i].y / 100f) * availH)
                                        }
                                    }
                                    drawPath(path = path, color = MagicEmerald.copy(alpha = 0.28f), style = ghostStyle)
                                }
                            }
                        }

                        // Vẽ nét mới đang viết
                        val activeBrush = Brush.linearGradient(listOf(MagicCyanLight, MagicEmerald))
                        val activeStyle = Stroke(width = 18f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                        for (s in strokes.toList()) {
                            val p0 = s.firstOrNull() ?: continue
                            if (s.size > 1) {
                                val path = Path().apply {
                                    moveTo(p0.x, p0.y)
                                    for (i in 1 until s.size) {
                                        lineTo(s[i].x, s[i].y)
                                    }
                                }
                                drawPath(path = path, brush = activeBrush, style = activeStyle)
                            }
                        }
                        val activeCurStroke = currentStroke
                        val curP0 = activeCurStroke.firstOrNull()
                        if (curP0 != null && activeCurStroke.size > 1) {
                            val path = Path().apply {
                                moveTo(curP0.x, curP0.y)
                                for (i in 1 until activeCurStroke.size) {
                                    lineTo(activeCurStroke[i].x, activeCurStroke[i].y)
                                }
                            }
                            drawPath(path = path, brush = activeBrush, style = activeStyle)
                        }
                    }

                    if (strokes.isEmpty() && currentStroke.isEmpty()) {
                        Text(
                            text = "✍️ Vẽ nét mẫu chữ '$activeChar' vào đây...",
                            color = TextMuted.copy(alpha = 0.65f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }

                // Hàng nút điều khiển: Vẽ lại | Xóa mẫu | Lưu Nét Vẽ Mẫu (thu nhỏ -40% chiều cao nút và -30% độ to tên nút giúp bảng vẽ cực kỳ rộng rãi)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            strokes.clear()
                            currentStroke = emptyList()
                        },
                        modifier = Modifier.weight(0.95f).height(28.dp),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicCyanLight)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(10.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("Vẽ Lại", fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }

                    if (savedTemplate != null) {
                        OutlinedButton(
                            onClick = {
                                GestureLauncherOverlay.clearCustomTemplate(context, activeChar)
                                strokes.clear()
                                currentStroke = emptyList()
                                refreshKey++
                                onTemplateSavedOrCleared()
                                Toast.makeText(
                                    context,
                                    "🗑️ Đã xóa nét vẽ mẫu của chữ '$activeChar'",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            modifier = Modifier.weight(1f).height(28.dp),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                            border = BorderStroke(1.dp, MagicRose.copy(alpha = 0.6f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicRose)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(10.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text("Xóa Mẫu", fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                    }

                    Button(
                        onClick = {
                            if (strokes.isEmpty()) {
                                Toast.makeText(
                                    context,
                                    "⚠️ Vui lòng vẽ ít nhất 1 nét lên bảng trước khi lưu mẫu!",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@Button
                            }
                            val ok = GestureLauncherOverlay.saveCustomTemplate(
                                context,
                                activeChar,
                                strokes.toList()
                            )
                            if (ok) {
                                strokes.clear()
                                currentStroke = emptyList()
                                refreshKey++
                                onTemplateSavedOrCleared()
                                Toast.makeText(
                                    context,
                                    "✅ Đã lưu Nét Vẽ Mẫu cho chữ '$activeChar' thành công!",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        },
                        modifier = Modifier.weight(1.4f).height(28.dp),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicEmerald,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Text(
                            text = "💾 Lưu Mẫu '$activeChar'",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
