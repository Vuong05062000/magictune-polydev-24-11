package com.example.core.keyboard

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Dịch Vụ Bàn Phím Hệ Thống Mặc Định (System-wide Magic Virtual Keyboard):
 * Cho phép biến Bàn phím MagicTune thành Bàn phím Mặc định của điện thoại,
 * hoạt động mượt mà 100%, 0ms độ trễ trên tất cả các ứng dụng (Zalo, Messenger, Chrome, Notes, Taobao...).
 */
class MagicTuneInputMethodService : InputMethodService() {

    private var isSymbolModeActive = false
    private var isSymbolPage2 = false
    private var isClipboardMode = false // Luôn ưu tiên mở bàn phím chữ đầu tiên
    private var isEmojiMode = false
    private var activeAutofillAccount: String? = null
    private var lastDetectedAccount: String = ""
    private val sessionPasswordBuilder = StringBuilder()
    private val sessionAccountBuilder = StringBuilder()
    private var selectedEmojiCategoryIndex = 0
    private var keyboardContainerLayout: LinearLayout? = null
    private var clipboardManager: ClipboardManager? = null

    private var isShiftActive = false
    private var isCapsLockActive = false
    private var lastShiftTapMs = 0L
    private var lastSpaceTapMs = 0L
    private var isEnglishMode = false
    private val letterKeyViews = mutableListOf<Pair<TextView, String>>()
    private var shiftKeyView: TextView? = null
    private var capsLockToolbarBtn: TextView? = null

    private var shiftNormalBg: GradientDrawable? = null
    private var shiftActiveBg: GradientDrawable? = null
    private var shiftCapsBg: GradientDrawable? = null
    private var capsToolbarNormalBg: GradientDrawable? = null
    private var capsToolbarActiveBg: GradientDrawable? = null

    private var otpBannerSlot: android.widget.FrameLayout? = null
    private var autofillBannerSlot: android.widget.FrameLayout? = null
    private var toolbarKbBtn: TextView? = null
    private var toolbarClipBtn: TextView? = null
    private var toolbarLangBtn: TextView? = null
    private var toolbarClearClipBtn: TextView? = null
    private var toolbarKbActiveBg: GradientDrawable? = null
    private var toolbarKbInactiveBg: GradientDrawable? = null
    private var toolbarClipActiveBg: GradientDrawable? = null
    private var toolbarClipInactiveBg: GradientDrawable? = null

    private var alphaKeysContainer: LinearLayout? = null
    private var symbolPage1Container: LinearLayout? = null
    private var symbolPage2Container: LinearLayout? = null
    private var emojiContainer: LinearLayout? = null
    private var emojiCategoryBtns: List<TextView> = emptyList()
    private var emojiGridContainer: LinearLayout? = null
    private var lastRenderedEmojiTabIdx = -1
    private var clipboardContainer: LinearLayout? = null
    private var clipboardListLayout: LinearLayout? = null
    private var lastOtpCodeRendered: String? = null
    private var lastAutofillKey: String? = null

    private fun updateShiftVisuals() {
        val isShift = isShiftActive || isCapsLockActive
        capsLockToolbarBtn?.apply {
            text = if (isCapsLockActive) "🔠 HOA 100%" else "🔠 HOA"
            setTextColor(if (isCapsLockActive) Color.WHITE else Color.parseColor("#E2E8F0"))
            val targetBg = if (isCapsLockActive) {
                capsToolbarActiveBg ?: makeKeyDrawable(
                    Color.parseColor("#1D4ED8"),
                    strokeColor = Color.parseColor("#60A5FA")
                ).also { capsToolbarActiveBg = it }
            } else {
                capsToolbarNormalBg ?: makeKeyDrawable(
                    Color.parseColor("#1F2937"),
                    strokeColor = Color.parseColor("#4B5563")
                ).also { capsToolbarNormalBg = it }
            }
            if (background !== targetBg) background = targetBg
        }
        if (isSymbolModeActive || isEmojiMode || isClipboardMode) return
        shiftKeyView?.apply {
            text = if (isCapsLockActive) "⇪" else "⇧"
            val targetBg = when {
                isCapsLockActive -> shiftCapsBg ?: makeKeyDrawable(Color.parseColor("#1D4ED8")).also { shiftCapsBg = it }
                isShiftActive -> shiftActiveBg ?: makeKeyDrawable(Color.parseColor("#3B82F6")).also { shiftActiveBg = it }
                else -> shiftNormalBg ?: makeKeyDrawable(Color.parseColor("#272A32")).also { shiftNormalBg = it }
            }
            if (background !== targetBg) background = targetBg
            setTextColor(if (isShift) Color.parseColor("#93C5FD") else Color.parseColor("#E2E8F0"))
        }
        for ((tv, lowerKey) in letterKeyViews) {
            val targetText = if (isShift) lowerKey.uppercase() else lowerKey
            if (tv.text != targetText) {
                tv.text = targetText
            }
        }
    }

    private val accountListener: () -> Unit = {
        keyboardContainerLayout?.post {
            lastAutofillKey = null
            updateSystemKeyboardKeys()
        }
    }

    private val otpListener: (MagicOtpManager.OtpInfo?) -> Unit = {
        keyboardContainerLayout?.post {
            refreshOtpBannerOnly()
        }
    }

    private val sharedClipListener: () -> Unit = {
        keyboardContainerLayout?.post {
            if (isClipboardMode) refreshClipboardContent()
        }
    }

    override fun onCreate() {
        super.onCreate()
        try {
            MagicClipboardStore.ensureWatching(applicationContext)
            MagicClipboardStore.addChangeListener(sharedClipListener)
            MagicOtpManager.addOtpListener(otpListener)
            MagicAccountManager.addChangeListener(accountListener)
            clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        try {
            MagicClipboardStore.removeChangeListener(sharedClipListener)
            MagicOtpManager.removeOtpListener(otpListener)
            MagicAccountManager.removeChangeListener(accountListener)
        } catch (_: Throwable) {}
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean {
        // Luôn giữ giao diện pop-up gọn gàng dưới đáy màn hình khi xoay ngang máy (landscape)
        return false
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Khoảng đệm khung ngoài kết hợp thanh đệm đáy công thái học giúp nâng bàn phím lên cao vừa tầm ngón cái
            setPadding(dp(2), dp(6), dp(2), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#121316"))
                setStroke(dp(1.2f), Color.parseColor("#3F444D"))
            }
        }
        keyboardContainerLayout = root
        initPersistentKeyboardScaffold(root)
        updateSystemKeyboardKeys()
        return root
    }

    private var isEmailOrUriField = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val variation = (info?.inputType ?: 0) and android.text.InputType.TYPE_MASK_VARIATION
        isEmailOrUriField = variation == android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == android.text.InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
            variation == android.text.InputType.TYPE_TEXT_VARIATION_URI ||
            variation == android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == android.text.InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD

        isClipboardMode = false // Luôn mở bàn phím đầu tiên
        isEmojiMode = false
        isEnglishMode = false // Mặc định ban đầu khi mở bàn phím luôn ưu tiên Tiếng Việt (VN)
        isSymbolModeActive = false
        isSymbolPage2 = false
        isCapsLockActive = false
        isShiftActive = !isEmailOrUriField
        sessionPasswordBuilder.setLength(0)
        sessionAccountBuilder.setLength(0)
        if (MagicAccountManager.isLikelyAccountOrEmailField(info)) {
            val existing = currentInputConnection?.getTextBeforeCursor(80, 0)?.toString()?.trim().orEmpty()
            if (existing.isNotEmpty() && !existing.contains(" ")) {
                lastDetectedAccount = existing
            }
        }
        checkAutoCapitalization()
        MagicClipboardStore.ensureWatching(applicationContext)
        updateSystemKeyboardKeys()

        // Tự động kiểm tra và điền mã OTP nếu trường nhập liệu là mã số hoặc OTP
        val recentOtpOnStart = MagicOtpManager.getRecentValidOtp()
        if (recentOtpOnStart != null && MagicOtpManager.isAutoFillEnabled(applicationContext)) {
            val inputType = info?.inputType ?: 0
            val isNumberType = (inputType and android.text.InputType.TYPE_MASK_CLASS) == android.text.InputType.TYPE_CLASS_NUMBER ||
                (inputType and android.text.InputType.TYPE_MASK_CLASS) == android.text.InputType.TYPE_CLASS_PHONE
            val hint = info?.hintText?.toString()?.lowercase().orEmpty()
            val isOtpField = isNumberType || hint.contains("otp") || hint.contains("mã") || hint.contains("xác thực")
            if (isOtpField) {
                keyboardContainerLayout?.postDelayed({
                    try {
                        val currentValid = MagicOtpManager.getRecentValidOtp()
                        if (currentValid != null && currentValid.code == recentOtpOnStart.code) {
                            currentInputConnection?.commitText(currentValid.code, 1)
                            MagicOtpManager.clearLatestOtp()
                            refreshOtpBannerOnly()
                            android.widget.Toast.makeText(
                                applicationContext,
                                "⚡ Đã tự động điền mã OTP: ${currentValid.code}",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (_: Throwable) {}
                }, 150L)
            }
        }
    }

    override fun onUpdateSelection(
        oldSelStart: Int,
        oldSelEnd: Int,
        newSelStart: Int,
        newSelEnd: Int,
        candidatesStart: Int,
        candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        if (!isCapsLockActive && !isSymbolModeActive && !isEmojiMode && !isClipboardMode) {
            checkAutoCapitalization()
        }
    }

    override fun onWindowShown() {
        super.onWindowShown()
        MagicClipboardStore.syncFromSystemClipboard(applicationContext)
        if (isClipboardMode) refreshClipboardContent()
    }

    private fun triggerKeyHaptic(view: View?) {
        try {
            view?.performHapticFeedback(
                HapticFeedbackConstants.KEYBOARD_TAP,
                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
            )
        } catch (_: Throwable) {}
    }

    private fun makeKeyDrawable(
        bgColor: Int,
        strokeColor: Int = Color.parseColor("#4B5563"),
        strokeWidthPx: Int = dp(1.2f)
    ): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(6).toFloat()
            setColor(bgColor)
            setStroke(strokeWidthPx, strokeColor)
        }
    }

    private fun applyTelex(currentText: String, typedKey: String): String {
        return VietnameseInputEngine.applyTelex(currentText, typedKey)
    }

    private fun checkAutoCapitalization() {
        if (isEmailOrUriField || isCapsLockActive) return
        val conn = currentInputConnection ?: return
        val before = conn.getTextBeforeCursor(16, 0)?.toString().orEmpty()
        // Tự động viết hoa chữ cái đầu câu chuẩn Tiếng Việt:
        // 1. Ô nhập đang trống (hoặc chỉ có khoảng trắng)
        // 2. Ngay sau dấu xuống dòng (\n)
        // 3. Ngay sau dấu kết thúc câu (. ! ? …) có kèm ít nhất 1 dấu cách (không bật ngay sau dấu chấm liền để gõ link/email dễ dàng)
        val shouldCapitalize = before.isEmpty() ||
            before.isBlank() ||
            before.endsWith("\n") ||
            Regex("(?s).*\\n\\s+$").matches(before) ||
            Regex("(?s).*[.?!…]\\s+$").matches(before)

        if (shouldCapitalize != isShiftActive) {
            isShiftActive = shouldCapitalize
            keyboardContainerLayout?.post { updateShiftVisuals() }
        }
    }

    /**
     * Chỉ thay thế phần hậu tố thay đổi trong từ, đồng thời giải phóng trạng thái composing (nếu có)
     * để không bao giờ bị nuốt lệnh xóa ký tự cũ trên WebView, Chrome, Facebook, Messenger, Zalo, TikTok.
     */
    private fun commitVietnameseChange(before: String, afterTelex: String) {
        val conn = currentInputConnection ?: return
        var commonPrefix = 0
        val minLen = minOf(before.length, afterTelex.length)
        while (commonPrefix < minLen && before[commonPrefix] == afterTelex[commonPrefix]) {
            commonPrefix++
        }
        val deleteCount = before.length - commonPrefix
        val newSuffix = afterTelex.substring(commonPrefix)
        try {
            conn.finishComposingText()
            if (deleteCount > 0) {
                conn.deleteSurroundingText(deleteCount, 0)
            }
            if (newSuffix.isNotEmpty()) {
                conn.commitText(newSuffix, 1)
            }
        } catch (_: Throwable) {}
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        checkAndAutoSaveCredentials()
    }

    private fun checkAndAutoSaveCredentials() {
        try {
            val pwd = sessionPasswordBuilder.toString().trim()
            val targetAcc = activeAutofillAccount ?: lastDetectedAccount
            val pkg = currentInputEditorInfo?.packageName.orEmpty()
            if (pwd.length >= 4 && targetAcc.isNotBlank()) {
                MagicAccountManager.saveCredential(applicationContext, targetAcc, pwd, pkg)
                android.widget.Toast.makeText(
                    applicationContext,
                    "🔑 Đã tự động ghi nhớ tài khoản & mật khẩu: $targetAcc",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
                sessionPasswordBuilder.setLength(0)
            }
        } catch (_: Throwable) {}
    }

    private fun performBackspace() {
        val conn = currentInputConnection ?: return
        val selectedText = conn.getSelectedText(0)
        if (!selectedText.isNullOrEmpty()) {
            conn.commitText("", 1)
        } else {
            // Xóa chuẩn cả biểu tượng cảm xúc Emoji (Surrogate Pair 2 ký tự UTF-16)
            val before = conn.getTextBeforeCursor(2, 0)
            if (before != null && before.length == 2 && Character.isSurrogatePair(before[0], before[1])) {
                conn.deleteSurroundingText(2, 0)
            } else {
                conn.deleteSurroundingText(1, 0)
            }
        }
        if (sessionPasswordBuilder.isNotEmpty()) {
            sessionPasswordBuilder.deleteCharAt(sessionPasswordBuilder.length - 1)
        }
        if (sessionAccountBuilder.isNotEmpty()) {
            sessionAccountBuilder.deleteCharAt(sessionAccountBuilder.length - 1)
            val cur = sessionAccountBuilder.toString().trim()
            if (cur.isNotEmpty() && !cur.contains(" ")) {
                lastDetectedAccount = cur
            }
        }
        checkAutoCapitalization()
    }

    private fun performFastEditorSend() {
        val conn = currentInputConnection ?: return
        checkAndAutoSaveCredentials()
        try {
            val beforeText = conn.getTextBeforeCursor(100, 0)?.toString()?.trim().orEmpty()
            if (beforeText.isNotEmpty()) {
                val candidate = beforeText.split(" ", "\n").lastOrNull()?.trim().orEmpty()
                if (candidate.isNotEmpty()) {
                    MagicAccountManager.learnAccountFromInput(applicationContext, candidate, currentInputEditorInfo?.packageName.orEmpty())
                    lastDetectedAccount = candidate
                }
            }
        } catch (_: Throwable) {}
        val editorInfo = currentInputEditorInfo
        val actionId = if (editorInfo != null) {
            editorInfo.imeOptions and EditorInfo.IME_MASK_ACTION
        } else {
            EditorInfo.IME_ACTION_UNSPECIFIED
        }
        val handled = when (actionId) {
            EditorInfo.IME_ACTION_SEND,
            EditorInfo.IME_ACTION_GO,
            EditorInfo.IME_ACTION_SEARCH,
            EditorInfo.IME_ACTION_DONE,
            EditorInfo.IME_ACTION_NEXT -> conn.performEditorAction(actionId)
            else -> false
        }
        if (!handled) {
            if (!sendDefaultEditorAction(true)) {
                conn.commitText("\n", 1)
            }
        }
    }

    /**
     * Khoảng đệm công thái học dưới đáy bàn phím ("khoảng đệm để nâng bàn phím cao lên chút")
     * giúp nâng hàng nút cuối (123, 😊, dấu phẩy, Dấu cách, dấu chấm, Nhập) lên vị trí dễ bấm nhất.
     */
    private fun buildErgonomicBottomSpacer(): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(30)
            )
            setPadding(0, dp(4), 0, dp(4))
            val pillIndicator = View(this@MagicTuneInputMethodService).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(3).toFloat()
                    setColor(Color.parseColor("#334155"))
                }
                layoutParams = LinearLayout.LayoutParams(dp(56), dp(4))
            }
            addView(pillIndicator)
        }
    }

    private fun initPersistentKeyboardScaffold(container: LinearLayout) {
        container.removeAllViews()
        lastOtpCodeRendered = null
        lastAutofillKey = null
        alphaKeysContainer = null
        symbolPage1Container = null
        symbolPage2Container = null
        emojiContainer = null
        clipboardContainer = null
        clipboardListLayout = null
        emojiGridContainer = null
        emojiCategoryBtns = emptyList()
        letterKeyViews.clear()
        shiftKeyView = null

        // 1. Slot OTP Banner
        val otpSlot = android.widget.FrameLayout(this).apply {
            visibility = View.GONE
        }
        otpBannerSlot = otpSlot
        container.addView(otpSlot, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        // 2. Thanh công cụ cố định
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(3), dp(6), dp(3))
        }
        toolbarKbActiveBg = makeKeyDrawable(Color.parseColor("#2563EB"))
        toolbarKbInactiveBg = makeKeyDrawable(Color.parseColor("#374151"))
        toolbarClipActiveBg = makeKeyDrawable(Color.parseColor("#2563EB"))
        toolbarClipInactiveBg = makeKeyDrawable(Color.parseColor("#374151"))

        val kbModeBtn = TextView(this).apply {
            text = "⌨️"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = toolbarKbActiveBg
            setOnClickListener {
                triggerKeyHaptic(this)
                isClipboardMode = false
                isEmojiMode = false
                updateSystemKeyboardKeys()
            }
        }
        toolbarKbBtn = kbModeBtn
        toolbar.addView(kbModeBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(4) })

        val clipModeBtn = TextView(this).apply {
            text = "📋"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = toolbarClipInactiveBg
            setOnClickListener {
                triggerKeyHaptic(this)
                isClipboardMode = !isClipboardMode
                if (isClipboardMode) isEmojiMode = false
                updateSystemKeyboardKeys()
            }
        }
        toolbarClipBtn = clipModeBtn
        toolbar.addView(clipModeBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(4) })

        val langBtn = TextView(this).apply {
            text = "🌐 VN"
            setTextColor(Color.parseColor("#10B981"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = makeKeyDrawable(Color.parseColor("#1F2937"))
            setOnClickListener {
                triggerKeyHaptic(this)
                isEnglishMode = !isEnglishMode
                if (isEmojiMode || isClipboardMode) {
                    isEmojiMode = false
                    isClipboardMode = false
                }
                updateSystemKeyboardKeys()
            }
        }
        toolbarLangBtn = langBtn
        toolbar.addView(langBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(4) })

        capsToolbarActiveBg = makeKeyDrawable(Color.parseColor("#1D4ED8"), strokeColor = Color.parseColor("#60A5FA"))
        capsToolbarNormalBg = makeKeyDrawable(Color.parseColor("#1F2937"), strokeColor = Color.parseColor("#4B5563"))
        val capsLockBtn = TextView(this).apply {
            text = "🔠 HOA"
            setTextColor(Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(8), dp(5), dp(8), dp(5))
            background = capsToolbarNormalBg
            setOnClickListener {
                triggerKeyHaptic(this)
                isCapsLockActive = !isCapsLockActive
                isShiftActive = isCapsLockActive
                lastShiftTapMs = 0L
                if (isCapsLockActive) {
                    isSymbolModeActive = false
                    isEmojiMode = false
                    isClipboardMode = false
                } else {
                    checkAutoCapitalization()
                }
                if (isEmojiMode || isClipboardMode) {
                    isEmojiMode = false
                    isClipboardMode = false
                }
                updateSystemKeyboardKeys()
            }
        }
        capsLockToolbarBtn = capsLockBtn
        toolbar.addView(capsLockBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        toolbar.addView(View(this), LinearLayout.LayoutParams(0, 0, 1f))

        val clearBtn = TextView(this).apply {
            text = "🗑️ Xóa hết"
            setTextColor(Color.parseColor("#F87171"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            visibility = View.GONE
            setOnClickListener {
                triggerKeyHaptic(this)
                MagicClipboardStore.clearAll(applicationContext, preservePinned = false)
                refreshClipboardContent()
            }
        }
        toolbarClearClipBtn = clearBtn
        toolbar.addView(clearBtn)
        container.addView(toolbar)

        // 3. Slot gợi ý tài khoản & mật khẩu
        val autoSlot = android.widget.FrameLayout(this).apply {
            visibility = View.GONE
        }
        autofillBannerSlot = autoSlot
        container.addView(autoSlot, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        // 4. Bộ bàn phím chữ ABC được dựng sẵn 1 lần duy nhất
        val alphaView = buildKeysRowsContainer(
            rows = listOf(
                listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
                listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
                listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
                listOf("⇧", "z", "x", "c", "v", "b", "n", "m", "⌫"),
                listOf("123", "😊", ",", "Dấu cách", ".", "↵ Nhập")
            ),
            isSymbolLayout = false
        )
        alphaKeysContainer = alphaView
        container.addView(alphaView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        // 5. Khoảng đệm công thái học cuối đáy (tái sử dụng)
        container.addView(buildErgonomicBottomSpacer())
    }

    private fun ensureSymbolContainer(page2: Boolean): LinearLayout {
        val existing = if (page2) symbolPage2Container else symbolPage1Container
        if (existing != null) return existing
        val rows = if (page2) {
            listOf(
                listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
                listOf("=", "^", "`", "±", "×", "÷", "√", "∞", "≈", "≠"),
                listOf("€", "£", "¥", "₩", "฿", "¢", "≤", "≥", "§", "¶"),
                listOf("?123", "«", "»", "©", "®", "™", "°", "…", "⌫"),
                listOf("ABC", "😊", ",", "Dấu cách", ".", "↵ Nhập")
            )
        } else {
            listOf(
                listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
                listOf("@", "#", "$", "%", "&", "-", "+", "(", ")", "/"),
                listOf("_", "\\", "|", "~", "<", ">", "[", "]", "{", "}"),
                listOf("=\\<", "*", "\"", "'", ":", ";", "!", "?", "⌫"),
                listOf("ABC", "😊", ",", "Dấu cách", ".", "↵ Nhập")
            )
        }
        val built = buildKeysRowsContainer(rows, isSymbolLayout = true).apply {
            visibility = View.GONE
        }
        if (page2) symbolPage2Container = built else symbolPage1Container = built
        keyboardContainerLayout?.let { root ->
            val spacerIdx = (root.childCount - 1).coerceAtLeast(0)
            root.addView(built, spacerIdx, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }
        return built
    }

    private fun buildKeysRowsContainer(rows: List<List<String>>, isSymbolLayout: Boolean): LinearLayout {
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        for (row in rows) {
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            for (key in row) {
                val baseColor = when (key) {
                    "↵ Nhập" -> Color.parseColor("#1E3A8A")
                    "123", "ABC", "=\\<", "?123", "😊", "⌫", "⇧" -> Color.parseColor("#272A32")
                    else -> Color.parseColor("#1D2026")
                }
                val pressedColor = when (key) {
                    "↵ Nhập" -> Color.parseColor("#38BDF8")
                    else -> Color.parseColor("#3B82F6")
                }
                val normalBg = makeKeyDrawable(baseColor)
                val pressedBg = makeKeyDrawable(
                    pressedColor,
                    strokeColor = Color.parseColor("#93C5FD"),
                    strokeWidthPx = dp(1.5f)
                )
                if (!isSymbolLayout && key == "⇧") {
                    shiftNormalBg = normalBg
                    shiftActiveBg = makeKeyDrawable(Color.parseColor("#3B82F6"))
                    shiftCapsBg = makeKeyDrawable(Color.parseColor("#1D4ED8"))
                }

                val keyBtn = TextView(this).apply {
                    text = key
                    gravity = Gravity.CENTER
                    includeFontPadding = false
                    setTextSize(
                        TypedValue.COMPLEX_UNIT_SP,
                        when {
                            key == "↵ Nhập" -> 12.5f
                            key == "=\\<" || key == "?123" -> 13.5f
                            key == "😊" -> 16f
                            key.length > 2 -> 14f
                            else -> 18.5f
                        }
                    )
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(
                        when (key) {
                            "↵ Nhập" -> Color.parseColor("#38BDF8")
                            "123", "ABC", "=\\<", "?123", "⌫", "⇧" -> Color.parseColor("#E2E8F0")
                            else -> Color.WHITE
                        }
                    )
                    background = normalBg

                    val repeatDeleteRunnable = object : Runnable {
                        override fun run() {
                            if (isPressed) {
                                performBackspace()
                                triggerKeyHaptic(this@apply)
                                postDelayed(this, 85L)
                            }
                        }
                    }

                    val longPressShiftRunnable = object : Runnable {
                        override fun run() {
                            if (isPressed) {
                                isCapsLockActive = true
                                isShiftActive = true
                                lastShiftTapMs = 0L
                                triggerKeyHaptic(this@apply)
                                updateShiftVisuals()
                            }
                        }
                    }

                    setOnTouchListener { v, event ->
                        val tv = v as TextView
                        val isDeferToUpKey = (key == "." || key == ",")
                        when (event.actionMasked) {
                            MotionEvent.ACTION_DOWN -> {
                                v.isPressed = true
                                v.background = pressedBg
                                v.scaleX = 0.94f
                                v.scaleY = 0.94f
                                triggerKeyHaptic(v)

                                if (key == "⇧") {
                                    v.removeCallbacks(longPressShiftRunnable)
                                    v.postDelayed(longPressShiftRunnable, 340L)
                                }

                                if (!isDeferToUpKey) {
                                    val conn = currentInputConnection
                                    val currentLabel = tv.text?.toString().orEmpty()
                                    when (currentLabel) {
                                        "⌫" -> {
                                            performBackspace()
                                            v.postDelayed(repeatDeleteRunnable, 350L)
                                        }
                                        "😊" -> {
                                            isEmojiMode = true
                                            isClipboardMode = false
                                            v.post { updateSystemKeyboardKeys() }
                                        }
                                        "⇧", "⇪" -> {
                                            val now = android.os.SystemClock.uptimeMillis()
                                            if (isCapsLockActive) {
                                                isCapsLockActive = false
                                                isShiftActive = false
                                                lastShiftTapMs = 0L
                                            } else if (!isSymbolModeActive && (now - lastShiftTapMs) < 480L) {
                                                isCapsLockActive = true
                                                isShiftActive = true
                                                lastShiftTapMs = 0L
                                            } else {
                                                isShiftActive = !isShiftActive
                                                isCapsLockActive = false
                                                lastShiftTapMs = now
                                            }
                                            updateShiftVisuals()
                                        }
                                        "123" -> {
                                            isSymbolModeActive = true
                                            isSymbolPage2 = false
                                            v.post { updateSystemKeyboardKeys() }
                                        }
                                        "ABC" -> {
                                            isSymbolModeActive = false
                                            isSymbolPage2 = false
                                            v.post { updateSystemKeyboardKeys() }
                                        }
                                        "=\\<" -> {
                                            isSymbolPage2 = true
                                            v.post { updateSystemKeyboardKeys() }
                                        }
                                        "?123" -> {
                                            isSymbolPage2 = false
                                            v.post { updateSystemKeyboardKeys() }
                                        }
                                        "Dấu cách", " " -> {
                                            conn?.commitText(" ", 1)
                                            checkAutoCapitalization()
                                            lastSpaceTapMs = android.os.SystemClock.uptimeMillis()
                                        }
                                        "?", "!" -> {
                                            conn?.commitText(currentLabel, 1)
                                        }
                                        "↵ Nhập" -> {
                                            performFastEditorSend()
                                            checkAutoCapitalization()
                                        }
                                        else -> {
                                            val isUpper = isShiftActive || isCapsLockActive
                                            val textToCommit = if (!isSymbolModeActive && currentLabel.length == 1 && isUpper) currentLabel.uppercase() else currentLabel
                                            if (MagicAccountManager.isPasswordField(currentInputEditorInfo)) {
                                                sessionPasswordBuilder.append(textToCommit)
                                            } else if (MagicAccountManager.isLikelyAccountOrEmailField(currentInputEditorInfo)) {
                                                sessionAccountBuilder.append(textToCommit)
                                                val cur = sessionAccountBuilder.toString().trim()
                                                if (cur.isNotEmpty() && !cur.contains(" ")) {
                                                    lastDetectedAccount = cur
                                                }
                                            }
                                            if (!isEnglishMode && !isSymbolModeActive && textToCommit.length == 1) {
                                                val before = conn?.getTextBeforeCursor(32, 0)?.toString() ?: ""
                                                val afterTelex = applyTelex(before, textToCommit)
                                                if (afterTelex != before + textToCommit) {
                                                    commitVietnameseChange(before, afterTelex)
                                                } else {
                                                    conn?.commitText(textToCommit, 1)
                                                }
                                            } else {
                                                conn?.commitText(textToCommit, 1)
                                            }
                                            if (!isSymbolModeActive && isShiftActive && !isCapsLockActive) {
                                                isShiftActive = false
                                                v.post { updateShiftVisuals() }
                                            } else if (isCapsLockActive) {
                                                isShiftActive = true
                                            }
                                        }
                                    }
                                }
                                true
                            }
                            MotionEvent.ACTION_UP -> {
                                val wasPressed = v.isPressed
                                v.isPressed = false
                                v.removeCallbacks(repeatDeleteRunnable)
                                v.removeCallbacks(longPressShiftRunnable)
                                v.scaleX = 1.0f
                                v.scaleY = 1.0f
                                if (!isSymbolLayout && key == "⇧") {
                                    updateShiftVisuals()
                                } else {
                                    v.background = normalBg
                                }
                                if (isDeferToUpKey && wasPressed) {
                                    val slop = dp(6).toFloat()
                                    val insideX = event.x >= -slop && event.x <= v.width + slop
                                    val insideY = event.y >= -slop && event.y <= v.height + slop
                                    if (insideX && insideY) {
                                        currentInputConnection?.commitText(key, 1)
                                    }
                                }
                                true
                            }
                            MotionEvent.ACTION_CANCEL -> {
                                v.isPressed = false
                                v.removeCallbacks(repeatDeleteRunnable)
                                v.removeCallbacks(longPressShiftRunnable)
                                v.scaleX = 1.0f
                                v.scaleY = 1.0f
                                if (!isSymbolLayout && key == "⇧") {
                                    updateShiftVisuals()
                                } else {
                                    v.background = normalBg
                                }
                                true
                            }
                            else -> false
                        }
                    }
                }

                if (!isSymbolLayout) {
                    if (key == "⇧") {
                        shiftKeyView = keyBtn
                    } else if (key.length == 1 && key[0].isLetter()) {
                        letterKeyViews.add(keyBtn to key.lowercase())
                    }
                }

                val lp = LinearLayout.LayoutParams(
                    0,
                    dp(51), // Độ cao nút 51dp chuẩn gọn gàng
                    when (key) {
                        "Dấu cách" -> 4.30f // Dấu cách rộng rãi, cân đối vùng ngón cái tránh bấm nhầm dấu chấm
                        ",", "." -> 0.62f   // Thu gọn nút dấu phẩy và dấu chấm
                        "😊" -> 0.78f       // Nút mở nhanh bộ Icon cảm xúc
                        "↵ Nhập" -> 1.30f   // Nút Nhập gọn gàng
                        "123", "ABC" -> 1.00f
                        "⌫", "⇧", "=\\<", "?123" -> 1.45f
                        else -> 1.0f
                    }
                ).apply {
                    val hMargin = if (key == "." || key == ",") dp(2.5f) else dp(0.5f)
                    setMargins(hMargin, dp(0.5f), hMargin, dp(0.5f))
                }
                rowLayout.addView(keyBtn, lp)
            }
            wrapper.addView(rowLayout, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }
        return wrapper
    }

    private fun refreshOtpBannerOnly() {
        val slot = otpBannerSlot ?: return
        val recentOtp = MagicOtpManager.getRecentValidOtp()
        val codeKey = recentOtp?.let { "${it.code}|${it.sender}" }
        if (codeKey == null) {
            lastOtpCodeRendered = null
            slot.visibility = View.GONE
            return
        }
        slot.visibility = View.VISIBLE
        if (lastOtpCodeRendered == codeKey && slot.childCount > 0) return
        lastOtpCodeRendered = codeKey
        slot.removeAllViews()

        val otpBanner = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#064E3B"))
                setStroke(dp(1.2f), Color.parseColor("#10B981"))
            }
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(dp(4), dp(2), dp(4), dp(4))
            }
        }
        otpBanner.addView(TextView(this).apply {
            text = "⚡"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(2), 0, dp(4), 0)
        })
        val textLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        textLayout.addView(TextView(this).apply {
            text = "MÃ OTP: ${recentOtp.code}"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(null, Typeface.BOLD)
        })
        textLayout.addView(TextView(this).apply {
            text = "Từ ${recentOtp.sender} • Chạm để điền ngay"
            setTextColor(Color.parseColor("#A7F3D0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
        })
        otpBanner.addView(textLayout)
        otpBanner.addView(TextView(this).apply {
            text = "⚡ ĐIỀN"
            setTextColor(Color.parseColor("#020617"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(6).toFloat()
                setColor(Color.parseColor("#34D399"))
            }
            setOnClickListener {
                triggerKeyHaptic(this)
                currentInputConnection?.commitText(recentOtp.code, 1)
                MagicOtpManager.clearLatestOtp()
                refreshOtpBannerOnly()
                android.widget.Toast.makeText(
                    applicationContext,
                    "⚡ Đã tự động điền mã OTP: ${recentOtp.code}",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
        })
        otpBanner.addView(TextView(this).apply {
            text = "✕"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(8), dp(4), dp(4), dp(4))
            setOnClickListener {
                triggerKeyHaptic(this)
                MagicOtpManager.clearLatestOtp()
                refreshOtpBannerOnly()
            }
        })
        slot.addView(otpBanner)
    }

    private fun refreshAutofillBannerOnly() {
        val slot = autofillBannerSlot ?: return
        if (isClipboardMode || isEmojiMode) {
            slot.visibility = View.GONE
            return
        }
        val isAccountTarget = MagicAccountManager.isLikelyAccountOrEmailField(currentInputEditorInfo)
        val isPasswordTarget = MagicAccountManager.isPasswordField(currentInputEditorInfo)
        val allAccounts = if (isAccountTarget || isPasswordTarget) MagicAccountManager.getAccounts(applicationContext) else emptyList()
        val key = "${isAccountTarget}|${isPasswordTarget}|${activeAutofillAccount.orEmpty()}|${allAccounts.size}"

        if (!((isPasswordTarget && allAccounts.any { it.hasPassword() }) || (isAccountTarget && allAccounts.isNotEmpty()))) {
            lastAutofillKey = key
            slot.visibility = View.GONE
            return
        }
        slot.visibility = View.VISIBLE
        if (lastAutofillKey == key && slot.childCount > 0) return
        lastAutofillKey = key
        slot.removeAllViews()

        val suggestionScroll = android.widget.HorizontalScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isHorizontalScrollBarEnabled = false
        }
        val suggestionLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }

        if (isPasswordTarget && allAccounts.any { it.hasPassword() }) {
            val targetCred = if (!activeAutofillAccount.isNullOrBlank()) {
                allAccounts.firstOrNull { it.identifier.equals(activeAutofillAccount, ignoreCase = true) && it.hasPassword() }
            } else null ?: allAccounts.firstOrNull { it.hasPassword() }
            if (targetCred != null) {
                suggestionLayout.addView(TextView(this).apply {
                    text = "🔑 Điền mật khẩu cho: ${targetCred.identifier} (••••••••)"
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                    setTypeface(null, Typeface.BOLD)
                    setPadding(dp(12), dp(6), dp(12), dp(6))
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dp(8).toFloat()
                        setColor(Color.parseColor("#064E3B"))
                        setStroke(dp(1.2f), Color.parseColor("#10B981"))
                    }
                    setOnClickListener {
                        triggerKeyHaptic(this)
                        val pwd = MagicAccountManager.decryptPassword(applicationContext, targetCred.passwordEncrypted)
                        if (pwd.isNotBlank()) {
                            currentInputConnection?.commitText(pwd, 1)
                            MagicAccountManager.recordAccountUsed(applicationContext, targetCred.identifier)
                            android.widget.Toast.makeText(
                                applicationContext,
                                "✨ Đã tự động điền mật khẩu: ${targetCred.identifier}",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                })
            }
        } else {
            suggestionLayout.addView(TextView(this).apply {
                text = "👤 Gợi ý:"
                setTextColor(Color.parseColor("#38BDF8"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setTypeface(null, Typeface.BOLD)
                setPadding(dp(4), dp(3), dp(4), dp(3))
            })
            for (acc in allAccounts.take(6)) {
                val chipText = if (acc.hasPassword()) "${acc.identifier} 🔑" else acc.identifier
                suggestionLayout.addView(
                    TextView(this).apply {
                        text = chipText
                        setTextColor(Color.WHITE)
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                        setTypeface(null, Typeface.BOLD)
                        setPadding(dp(10), dp(4), dp(10), dp(4))
                        background = makeKeyDrawable(
                            Color.parseColor("#1E293B"),
                            strokeColor = if (acc.hasPassword()) Color.parseColor("#10B981") else Color.parseColor("#38BDF8"),
                            strokeWidthPx = dp(1f)
                        )
                        setOnClickListener {
                            triggerKeyHaptic(this)
                            currentInputConnection?.commitText(acc.identifier, 1)
                            activeAutofillAccount = acc.identifier
                            lastDetectedAccount = acc.identifier
                            MagicAccountManager.recordAccountUsed(applicationContext, acc.identifier)
                            android.widget.Toast.makeText(
                                applicationContext,
                                "👤 Đã điền: ${acc.identifier}",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                        setOnLongClickListener {
                            triggerKeyHaptic(this)
                            MagicAccountManager.deleteAccount(applicationContext, acc.identifier)
                            lastAutofillKey = null
                            refreshAutofillBannerOnly()
                            android.widget.Toast.makeText(
                                applicationContext,
                                "🗑️ Đã xóa: ${acc.identifier}",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                            true
                        }
                    },
                    LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                        setMargins(dp(3), 0, dp(3), 0)
                    }
                )
            }
        }

        suggestionScroll.addView(suggestionLayout)
        slot.addView(
            suggestionScroll,
            android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(dp(2), dp(1), dp(2), dp(2))
            }
        )
    }

    private fun ensureClipboardContainer(): LinearLayout {
        clipboardContainer?.let { return it }
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val scroll = android.widget.HorizontalScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val listLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        clipboardListLayout = listLayout
        scroll.addView(listLayout)
        wrapper.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(260)))
        clipboardContainer = wrapper
        keyboardContainerLayout?.let { root ->
            val spacerIdx = (root.childCount - 1).coerceAtLeast(0)
            root.addView(wrapper, spacerIdx, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }
        return wrapper
    }

    private fun refreshClipboardContent() {
        ensureClipboardContainer()
        val listLayout = clipboardListLayout ?: return
        listLayout.removeAllViews()
        val entries = MagicClipboardStore.getDetailedEntries(applicationContext)
        if (entries.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "Chưa có nội dung trong bộ nhớ tạm (Ghim tối đa 3 mục • Lưu 15 ngày)"
                setTextColor(Color.parseColor("#94A3B8"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(40), dp(20), dp(40))
            }
            listLayout.addView(emptyTv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            return
        }
        for (entry in entries) {
            val itemCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), dp(6), dp(8), dp(6))
                background = if (entry.isPinned) {
                    makeKeyDrawable(Color.parseColor("#1E3A8A"), Color.parseColor("#60A5FA"))
                } else {
                    makeKeyDrawable(Color.parseColor("#1F2937"), Color.parseColor("#4B5563"))
                }
                layoutParams = LinearLayout.LayoutParams(dp(170), dp(246)).apply {
                    setMargins(dp(4), 0, dp(4), 0)
                }
                setOnClickListener {
                    triggerKeyHaptic(this)
                    currentInputConnection?.commitText(entry.text, 1)
                }
            }
            val cardHeader = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 0, 0, dp(4))
            }
            cardHeader.addView(TextView(this).apply {
                text = if (entry.isPinned) "📌 Đã ghim" else "📌 Ghim"
                setTextColor(if (entry.isPinned) Color.parseColor("#FDE047") else Color.parseColor("#94A3B8"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
                setPadding(dp(4), dp(2), dp(4), dp(2))
                setOnClickListener {
                    triggerKeyHaptic(this)
                    val ok = MagicClipboardStore.togglePin(applicationContext, entry.text)
                    if (!ok && !entry.isPinned) {
                        android.widget.Toast.makeText(applicationContext, "Chỉ được ghim tối đa 3 văn bản hay sử dụng!", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    refreshClipboardContent()
                }
            })
            itemCard.addView(cardHeader)
            itemCard.addView(TextView(this).apply {
                text = entry.text
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                maxLines = 11
                ellipsize = TextUtils.TruncateAt.END
            })
            listLayout.addView(itemCard)
        }
    }

    private fun ensureEmojiContainer(): LinearLayout {
        emojiContainer?.let { return it }
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val categoryBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(2), dp(6), dp(4))
        }
        val allTabs = listOf("🕒" to "Gần đây") + MagicEmojiCatalog.categories.map { it.icon to it.title }
        val btns = mutableListOf<TextView>()
        allTabs.forEachIndexed { idx, (icon, _) ->
            val tabBtn = TextView(this).apply {
                text = icon
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                setPadding(0, dp(5), 0, dp(5))
                setOnClickListener {
                    triggerKeyHaptic(this)
                    selectedEmojiCategoryIndex = idx
                    refreshEmojiGridContent(forceRebuild = true)
                }
            }
            btns.add(tabBtn)
            categoryBar.addView(
                tabBtn,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(dp(2), 0, dp(2), 0)
                }
            )
        }
        emojiCategoryBtns = btns
        wrapper.addView(categoryBar)

        val emojiScroll = android.widget.ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }
        emojiGridContainer = grid
        emojiScroll.addView(grid)
        wrapper.addView(emojiScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(172)))

        val emojiBottomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(2), dp(2), 0)
        }
        val backToAbcBtn = TextView(this).apply {
            text = "ABC"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTypeface(null, Typeface.BOLD)
            background = makeKeyDrawable(Color.parseColor("#272A32"))
            setOnClickListener {
                triggerKeyHaptic(this)
                isEmojiMode = false
                updateSystemKeyboardKeys()
            }
        }
        val spaceEmojiBtn = TextView(this).apply {
            text = "Dấu cách"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTypeface(null, Typeface.BOLD)
            background = makeKeyDrawable(Color.parseColor("#1D2026"))
            setOnClickListener {
                triggerKeyHaptic(this)
                currentInputConnection?.commitText(" ", 1)
            }
        }
        val deleteEmojiBtn = TextView(this).apply {
            text = "⌫"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            setTypeface(null, Typeface.BOLD)
            background = makeKeyDrawable(Color.parseColor("#272A32"))
            val repeatDel = object : Runnable {
                override fun run() {
                    if (isPressed) {
                        performBackspace()
                        triggerKeyHaptic(this@apply)
                        postDelayed(this, 85L)
                    }
                }
            }
            setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.isPressed = true
                        triggerKeyHaptic(v)
                        performBackspace()
                        v.postDelayed(repeatDel, 350L)
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.isPressed = false
                        v.removeCallbacks(repeatDel)
                        true
                    }
                    else -> false
                }
            }
        }
        val sendEmojiBtn = TextView(this).apply {
            text = "↵ Nhập"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#38BDF8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTypeface(null, Typeface.BOLD)
            background = makeKeyDrawable(Color.parseColor("#1E3A8A"))
            setOnClickListener {
                triggerKeyHaptic(this)
                performFastEditorSend()
            }
        }
        emojiBottomRow.addView(backToAbcBtn, LinearLayout.LayoutParams(0, dp(46), 1.3f).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) })
        emojiBottomRow.addView(spaceEmojiBtn, LinearLayout.LayoutParams(0, dp(46), 3.6f).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) })
        emojiBottomRow.addView(deleteEmojiBtn, LinearLayout.LayoutParams(0, dp(46), 1.3f).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) })
        emojiBottomRow.addView(sendEmojiBtn, LinearLayout.LayoutParams(0, dp(46), 1.4f).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) })
        wrapper.addView(emojiBottomRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        emojiContainer = wrapper
        keyboardContainerLayout?.let { root ->
            val spacerIdx = (root.childCount - 1).coerceAtLeast(0)
            root.addView(wrapper, spacerIdx, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }
        return wrapper
    }

    private fun refreshEmojiGridContent(forceRebuild: Boolean = false) {
        ensureEmojiContainer()
        emojiCategoryBtns.forEachIndexed { idx, btn ->
            val isSelected = selectedEmojiCategoryIndex == idx
            btn.background = makeKeyDrawable(
                if (isSelected) Color.parseColor("#2563EB") else Color.parseColor("#1E293B"),
                if (isSelected) Color.parseColor("#93C5FD") else Color.parseColor("#334155")
            )
        }
        val gridContainer = emojiGridContainer ?: return
        if (!forceRebuild && lastRenderedEmojiTabIdx == selectedEmojiCategoryIndex && selectedEmojiCategoryIndex != 0 && gridContainer.childCount > 0) {
            return
        }
        lastRenderedEmojiTabIdx = selectedEmojiCategoryIndex
        gridContainer.removeAllViews()

        val emojisToShow = if (selectedEmojiCategoryIndex == 0) {
            MagicEmojiCatalog.getRecentEmojis(applicationContext)
        } else {
            MagicEmojiCatalog.categories.getOrNull(selectedEmojiCategoryIndex - 1)?.emojis.orEmpty()
        }
        val columns = 8
        var currentRow: LinearLayout? = null
        emojisToShow.forEachIndexed { index, emoji ->
            if (index % columns == 0) {
                currentRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    weightSum = columns.toFloat()
                }
                gridContainer.addView(
                    currentRow,
                    LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(2) }
                )
            }
            val emojiTv = TextView(this).apply {
                text = emoji
                gravity = Gravity.CENTER
                includeFontPadding = false
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 21f)
                background = makeKeyDrawable(Color.parseColor("#1D2026"), Color.parseColor("#2E3440"))
                setOnClickListener {
                    triggerKeyHaptic(this)
                    currentInputConnection?.commitText(emoji, 1)
                    MagicEmojiCatalog.recordEmojiUsed(applicationContext, emoji)
                }
            }
            currentRow?.addView(
                emojiTv,
                LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                    setMargins(dp(1.5f), dp(1f), dp(1.5f), dp(1f))
                }
            )
        }
    }

    private fun updateSystemKeyboardKeys() {
        val container = keyboardContainerLayout ?: return
        if (alphaKeysContainer == null) {
            initPersistentKeyboardScaffold(container)
        }

        // 1. Cập nhật nút thanh công cụ tại chỗ (0 cấp phát)
        toolbarKbBtn?.background = if (!isClipboardMode && !isEmojiMode) toolbarKbActiveBg else toolbarKbInactiveBg
        toolbarClipBtn?.background = if (isClipboardMode) toolbarClipActiveBg else toolbarClipInactiveBg
        toolbarLangBtn?.apply {
            text = if (isEnglishMode) "🌐 EN" else "🌐 VN"
            setTextColor(if (isEnglishMode) Color.parseColor("#60A5FA") else Color.parseColor("#10B981"))
        }
        toolbarClearClipBtn?.visibility = if (isClipboardMode) View.VISIBLE else View.GONE

        // 2. Cập nhật Banner OTP & Tự điền tài khoản
        refreshOtpBannerOnly()
        refreshAutofillBannerOnly()

        // 3. Chuyển đổi hiển thị các vùng con bằng View.VISIBLE / View.GONE (Không removeAllViews!)
        alphaKeysContainer?.visibility = if (!isClipboardMode && !isEmojiMode && !isSymbolModeActive) View.VISIBLE else View.GONE

        if (isClipboardMode) {
            ensureClipboardContainer().visibility = View.VISIBLE
            refreshClipboardContent()
        } else {
            clipboardContainer?.visibility = View.GONE
        }

        if (isEmojiMode) {
            ensureEmojiContainer().visibility = View.VISIBLE
            refreshEmojiGridContent(forceRebuild = selectedEmojiCategoryIndex == 0)
        } else {
            emojiContainer?.visibility = View.GONE
        }

        if (!isClipboardMode && !isEmojiMode && isSymbolModeActive) {
            ensureSymbolContainer(page2 = false).visibility = if (!isSymbolPage2) View.VISIBLE else View.GONE
            ensureSymbolContainer(page2 = true).visibility = if (isSymbolPage2) View.VISIBLE else View.GONE
        } else {
            symbolPage1Container?.visibility = View.GONE
            symbolPage2Container?.visibility = View.GONE
        }

        updateShiftVisuals()
    }

    private fun dp(value: Float): Int {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, resources.displayMetrics).toInt()
    }

    private fun dp(value: Int): Int {
        return dp(value.toFloat())
    }

    companion object {
        fun openKeyboardSettings(context: Context) {
            try {
                val intent = android.content.Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS).apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (_: Throwable) {}
        }

        fun showInputMethodPicker(context: Context) {
            try {
                val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
                imm?.showInputMethodPicker()
            } catch (_: Throwable) {}
        }
    }
}
