package com.example.core.keyboard

import android.content.Context
import android.os.Build
import android.util.Base64
import android.view.inputmethod.EditorInfo
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.CopyOnWriteArrayList
import java.util.regex.Pattern
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/**
 * Trình Quản Lý Mật Khẩu & Tài Khoản Tự Động Thông Minh Chuẩn Google (Magic Google-Smart Password Manager):
 * - Tự động 100%: Tự phát hiện tài khoản & mật khẩu khi đăng nhập trên bất kỳ ứng dụng hoặc trang web nào.
 * - Không cần lưu thủ công: Tự động ghi nhớ và cập nhật mật khẩu mới khi người dùng đăng nhập thành công.
 * - Mã hóa cục bộ an toàn bằng AES-256 (khóa sinh theo phần cứng thiết bị), tuyệt đối không gửi ra ngoài.
 * - Thanh gợi ý điền thông minh 1-chạm (như Google Autofill / Gboard):
 *   + Ở ô tài khoản/email/SĐT -> Nổi chip gợi ý [👤 Email/User] để điền 1-chạm.
 *   + Ở ô mật khẩu -> Tự động nhận diện tài khoản tương ứng và nổi chip [🔑 Điền mật khẩu (••••••••)] điền tức thì.
 */
object MagicAccountManager {

    private const val PREFS_NAME = "magic_saved_accounts_v1"
    private const val KEY_ACCOUNTS_JSON = "saved_accounts_list"
    private const val MAX_SAVED_ACCOUNTS = 50

    data class SavedAccount(
        val identifier: String,
        val passwordEncrypted: String = "",
        val label: String = "",
        val packageName: String = "",
        val lastUsedMs: Long = System.currentTimeMillis(),
        val usageCount: Int = 1
    ) {
        fun hasPassword(): Boolean = passwordEncrypted.isNotBlank()
    }

    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    private val emailPattern = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")
    private val phonePattern = Pattern.compile("^(?:\\+?84|0)(?:3|5|7|8|9)[0-9]{8}$")
    private val usernamePattern = Pattern.compile("^[A-Za-z0-9_.-]{3,40}$")

    fun addChangeListener(listener: () -> Unit) {
        if (!listeners.contains(listener)) {
            listeners.add(listener)
        }
    }

    fun removeChangeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    private fun notifyChanged() {
        for (l in listeners) {
            try {
                l.invoke()
            } catch (_: Throwable) {}
        }
    }

    private fun getSecretKey(context: Context): SecretKeySpec {
        val deviceId = try {
            android.provider.Settings.Secure.getString(
                context.contentResolver,
                android.provider.Settings.Secure.ANDROID_ID
            )
        } catch (_: Throwable) { null } ?: "magictune_keystore_seed_2026"
        val md = MessageDigest.getInstance("SHA-256")
        val keyBytes = md.digest((deviceId + "_magictune_smart_pwd_v2").toByteArray(Charsets.UTF_8))
        return SecretKeySpec(keyBytes, "AES")
    }

    fun encryptPassword(context: Context, plain: String): String {
        if (plain.isBlank()) return ""
        return try {
            // AES/GCM (mỗi bản ghi IV ngẫu nhiên) thay cho ECB — quyết định rà soát bảo mật
            val iv = ByteArray(12)
            java.security.SecureRandom().nextBytes(iv)
            val gcmSpec = javax.crypto.spec.GCMParameterSpec(128, iv)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getSecretKey(context), gcmSpec)
            val encrypted = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
            "gcm1:" + Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP)
        } catch (_: Throwable) {
            // Fallback cực kỳ hiếm gặp: giữ chuỗi cũ (không mã hóa) để không mất dữ liệu người dùng
            Base64.encodeToString(plain.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        }
    }

    @android.annotation.SuppressLint("GetInstance")
    fun decryptPassword(context: Context, encryptedBase64: String): String {
        if (encryptedBase64.isBlank()) return ""
        // Định dạng mới AES/GCM: "gcm1:<iv>:<ciphertext>"
        if (encryptedBase64.startsWith("gcm1:")) {
            return try {
                val parts = encryptedBase64.split(":")
                if (parts.size != 3) "" else {
                    val iv = Base64.decode(parts[1], Base64.NO_WRAP)
                    val data = Base64.decode(parts[2], Base64.NO_WRAP)
                    val gcmSpec = javax.crypto.spec.GCMParameterSpec(128, iv)
                    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    cipher.init(Cipher.DECRYPT_MODE, getSecretKey(context), gcmSpec)
                    String(cipher.doFinal(data), Charsets.UTF_8)
                }
            } catch (_: Throwable) { "" }
        }
        // Định dạng cũ AES/ECB (chỉ giải mã tương thích ngược cho bản ghi cũ; mã hóa mới luôn dùng AES/GCM)
        return try {
            val cipher = Cipher.getInstance("AES/ECB/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, getSecretKey(context))
            val decoded = Base64.decode(encryptedBase64, Base64.NO_WRAP)
            String(cipher.doFinal(decoded), Charsets.UTF_8)
        } catch (_: Throwable) {
            try {
                String(Base64.decode(encryptedBase64, Base64.NO_WRAP), Charsets.UTF_8)
            } catch (_: Throwable) {
                ""
            }
        }
    }

    /**
     * Lấy danh sách toàn bộ tài khoản và mật khẩu đã lưu, sắp xếp theo thứ tự thông minh:
     * Dùng nhiều nhất & Gần đây nhất lên đầu.
     */
    fun getAccounts(context: Context): List<SavedAccount> {
        val appCtx = context.applicationContext ?: context
        val prefs = appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_ACCOUNTS_JSON, "") ?: ""
        if (jsonStr.isBlank()) return emptyList()

        val list = mutableListOf<SavedAccount>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val id = obj.optString("identifier", "").trim()
                if (id.isNotBlank()) {
                    list.add(
                        SavedAccount(
                            identifier = id,
                            passwordEncrypted = obj.optString("pwd", ""),
                            label = obj.optString("label", ""),
                            packageName = obj.optString("pkg", ""),
                            lastUsedMs = obj.optLong("lastUsedMs", System.currentTimeMillis()),
                            usageCount = obj.optInt("usageCount", 1)
                        )
                    )
                }
            }
        } catch (_: Throwable) {}

        return list.sortedWith(
            compareByDescending<SavedAccount> { it.usageCount }
                .thenByDescending { it.lastUsedMs }
        )
    }

    private fun saveListInternal(context: Context, list: List<SavedAccount>) {
        val appCtx = context.applicationContext ?: context
        val prefs = appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val arr = JSONArray()
        for (item in list.take(MAX_SAVED_ACCOUNTS)) {
            val obj = JSONObject().apply {
                put("identifier", item.identifier)
                put("pwd", item.passwordEncrypted)
                put("label", item.label)
                put("pkg", item.packageName)
                put("lastUsedMs", item.lastUsedMs)
                put("usageCount", item.usageCount)
            }
            arr.put(obj)
        }
        prefs.edit().putString(KEY_ACCOUNTS_JSON, arr.toString()).apply()
        notifyChanged()
    }

    /**
     * Lưu tự động tài khoản & mật khẩu (Chuẩn Google Password Manager).
     */
    @Synchronized
    fun saveCredential(
        context: Context,
        identifier: String,
        plainPassword: String = "",
        packageName: String = "",
        label: String = ""
    ): Boolean {
        val cleanId = identifier.trim()
        if (cleanId.length < 3) return false

        val current = getAccounts(context).toMutableList()
        val existingIndex = current.indexOfFirst { it.identifier.equals(cleanId, ignoreCase = true) }

        val resolvedLabel = if (label.isNotBlank()) {
            label.trim()
        } else when {
            emailPattern.matcher(cleanId).matches() -> "Email"
            phonePattern.matcher(cleanId).matches() -> "SĐT"
            else -> "Tài khoản"
        }

        val encryptedPwd = if (plainPassword.isNotBlank()) {
            encryptPassword(context, plainPassword.trim())
        } else ""

        if (existingIndex >= 0) {
            val old = current[existingIndex]
            val finalPwd = if (encryptedPwd.isNotBlank()) encryptedPwd else old.passwordEncrypted
            val finalPkg = if (packageName.isNotBlank()) packageName else old.packageName
            current[existingIndex] = old.copy(
                passwordEncrypted = finalPwd,
                label = if (label.isNotBlank()) resolvedLabel else old.label,
                packageName = finalPkg,
                lastUsedMs = System.currentTimeMillis(),
                usageCount = old.usageCount + 1
            )
        } else {
            current.add(
                0,
                SavedAccount(
                    identifier = cleanId,
                    passwordEncrypted = encryptedPwd,
                    label = resolvedLabel,
                    packageName = packageName,
                    lastUsedMs = System.currentTimeMillis(),
                    usageCount = 1
                )
            )
        }

        saveListInternal(context, current)
        return true
    }

    /**
     * Tương thích ngược với hàm saveAccount cũ.
     */
    fun saveAccount(context: Context, identifier: String, label: String = ""): Boolean {
        return saveCredential(context, identifier, "", "", label)
    }

    @Synchronized
    fun recordAccountUsed(context: Context, identifier: String) {
        val cleanId = identifier.trim()
        val current = getAccounts(context).toMutableList()
        val index = current.indexOfFirst { it.identifier.equals(cleanId, ignoreCase = true) }
        if (index >= 0) {
            val old = current[index]
            current[index] = old.copy(
                lastUsedMs = System.currentTimeMillis(),
                usageCount = old.usageCount + 1
            )
            saveListInternal(context, current)
        } else {
            saveCredential(context, cleanId)
        }
    }

    @Synchronized
    fun deleteAccount(context: Context, identifier: String): Boolean {
        val cleanId = identifier.trim()
        val current = getAccounts(context).toMutableList()
        val removed = current.removeAll { it.identifier.equals(cleanId, ignoreCase = true) }
        if (removed) {
            saveListInternal(context, current)
        }
        return removed
    }

    /**
     * Tự động học & nhận diện tài khoản khi người dùng nhập trên bàn phím.
     */
    fun learnAccountFromInput(context: Context, text: String, packageName: String = ""): Boolean {
        val clean = text.trim()
        if (clean.length < 3 || clean.contains(" ")) return false

        if (emailPattern.matcher(clean).matches()) {
            return saveCredential(context, clean, "", packageName, "Email")
        }

        if (phonePattern.matcher(clean).matches()) {
            return saveCredential(context, clean, "", packageName, "SĐT")
        }

        if (usernamePattern.matcher(clean).matches() && clean.length in 4..30) {
            return saveCredential(context, clean, "", packageName, "Tài khoản")
        }

        return false
    }

    /**
     * Nhận diện thông minh ô Tên đăng nhập / Email / SĐT.
     */
    fun isLikelyAccountOrEmailField(info: EditorInfo?): Boolean {
        if (info == null) return false
        if (isPasswordField(info)) return false

        val inputType = info.inputType
        val inputClass = inputType and android.text.InputType.TYPE_MASK_CLASS
        val variation = inputType and android.text.InputType.TYPE_MASK_VARIATION

        if (variation == android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == android.text.InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
            variation == android.text.InputType.TYPE_TEXT_VARIATION_PERSON_NAME ||
            inputClass == android.text.InputType.TYPE_CLASS_PHONE
        ) {
            return true
        }

        val hintText = info.hintText?.toString()?.lowercase().orEmpty()
        val fieldName = info.fieldName?.lowercase().orEmpty()
        val combined = "$hintText $fieldName"

        val accountKeywords = listOf(
            "email", "tài khoản", "tai khoan", "username", "tên đăng nhập", "ten dang nhap",
            "số điện thoại", "so dien thoai", "sđt", "sdt", "phone", "login", "account",
            "đăng nhập", "dang nhap", "user", "id"
        )
        return accountKeywords.any { combined.contains(it) }
    }

    /**
     * Nhận diện thông minh ô Mật khẩu (Password Field).
     */
    fun isPasswordField(info: EditorInfo?): Boolean {
        if (info == null) return false

        val inputType = info.inputType
        val variation = inputType and android.text.InputType.TYPE_MASK_VARIATION

        if (variation == android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == android.text.InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            (inputType and android.text.InputType.TYPE_MASK_CLASS) == android.text.InputType.TYPE_CLASS_NUMBER &&
            (variation == 0x10 || variation == 0x80)
        ) {
            return true
        }

        val hintText = info.hintText?.toString()?.lowercase().orEmpty()
        val fieldName = info.fieldName?.lowercase().orEmpty()
        val combined = "$hintText $fieldName"

        if (combined.contains("otp") || combined.contains("mã") && combined.contains("xác thực")) {
            return false
        }

        val passKeywords = listOf(
            "password", "mật khẩu", "mat khau", "pass", "pin", "mã bảo mật", "ma bao mat", "passwd"
        )
        return passKeywords.any { combined.contains(it) }
    }
}
