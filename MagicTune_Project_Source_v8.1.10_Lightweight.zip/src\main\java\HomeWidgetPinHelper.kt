package com.example.core.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.compose.runtime.Immutable

@Immutable
data class MagicTuneWidgetDescriptor(
    val id: String,
    val title: String,
    val subtitle: String,
    val sizeBadge: String,
    val categoryBadge: String,
    val providerClass: Class<*>,
    val accentHex: Long
)

/**
 * Hỗ trợ ghim nhanh mọi Widget MagicTune trực tiếp lên Màn hình chính từ Tab Kho Ứng Dụng.
 */
object HomeWidgetPinHelper {

    const val ACTION_WIDGET_PINNED_FEEDBACK = "com.example.core.widget.ACTION_WIDGET_PINNED_FEEDBACK"
    const val EXTRA_WIDGET_TITLE = "extra_widget_title"
    @Volatile
    var lastPinnedFeedbackElapsedMs: Long = 0L

    val allWidgets: List<MagicTuneWidgetDescriptor> = listOf(
        MagicTuneWidgetDescriptor(
            id = "widget_battery",
            title = "Pin & Hạ Nhiệt Siêu Nhẹ",
            subtitle = "Bản 3×2 tối ưu ngang 2×2: % Pin, công suất W, xả Sáng/Tắt màn, nhiệt độ & 2 nút Làm mới / Hạ nhiệt.",
            sizeBadge = "3×2",
            categoryBadge = "Năng Lượng",
            providerClass = MagicTuneBatteryWidgetProvider::class.java,
            accentHex = 0xFF10B981
        ),
        MagicTuneWidgetDescriptor(
            id = "widget_battery_simple_2x2",
            title = "Pin Cơ Bản Tối Giản",
            subtitle = "Gọn nhẹ 2×2 đủ màu: % Pin lớn, nút ❄️ hạ nhiệt nhanh, vòng tròn pin Bluetooth & tốc độ xả.",
            sizeBadge = "2×2",
            categoryBadge = "Đơn Giản",
            providerClass = MagicTuneSimpleBatteryWidgetProvider::class.java,
            accentHex = 0xFF34D399
        ),
        MagicTuneWidgetDescriptor(
            id = "widget_memory",
            title = "RAM, ROM & Dọn Sạch 1-Chạm",
            subtitle = "Theo dõi RAM khả dụng, dung lượng bộ nhớ ROM & giải phóng tiến trình ngay ngoài MH chính.",
            sizeBadge = "4×1",
            categoryBadge = "Bộ Nhớ",
            providerClass = MagicTuneMemoryWidgetProvider::class.java,
            accentHex = 0xFF06B6D4
        ),
        MagicTuneWidgetDescriptor(
            id = "widget_weather_calendar",
            title = "Đồng Hồ, Thời Tiết & Lịch 7 Ngày / 24H",
            subtitle = "Mặc định giao diện Đồng hồ số to & thời tiết trực tiếp, bấm nút để sang giao diện Dự báo 24H & lịch 7 ngày.",
            sizeBadge = "4×2",
            categoryBadge = "Thời Tiết",
            providerClass = MagicTuneCalendarWeatherWidgetProvider::class.java,
            accentHex = 0xFF38BDF8
        ),
        MagicTuneWidgetDescriptor(
            id = "widget_perpetual_calendar",
            title = "Lịch Vạn Niên Âm - Dương",
            subtitle = "Quyển lịch tháng đầy đủ ngày Dương & Âm, Can Chi, chuyển tháng trực tiếp ngoài màn hình.",
            sizeBadge = "4×3",
            categoryBadge = "Lịch Việt",
            providerClass = MagicTunePerpetualCalendarWidgetProvider::class.java,
            accentHex = 0xFFF59E0B
        ),
        MagicTuneWidgetDescriptor(
            id = "widget_app_search",
            title = "Thanh Tìm Kiếm App Nhanh",
            subtitle = "Tìm ứng dụng, viết/vẽ chữ mở app & tìm Google tức thì trực tiếp từ màn hình chính.",
            sizeBadge = "4×1",
            categoryBadge = "Tìm Kiếm",
            providerClass = MagicTuneAppSearchWidgetProvider::class.java,
            accentHex = 0xFFA855F7
        ),
        MagicTuneWidgetDescriptor(
            id = "widget_printer",
            title = "Mở Nhanh Máy In Nhiệt K80",
            subtitle = "Lối tắt 1 chạm mở thẳng trạm in đơn Shopee / TikTok LAN, Wi-Fi & Bluetooth.",
            sizeBadge = "2×1",
            categoryBadge = "In Ấn K80",
            providerClass = MagicTunePrinterWidgetProvider::class.java,
            accentHex = 0xFFF43F5E
        )
    )

    fun countInstalledWidgets(context: Context): Map<String, Int> {
        val result = LinkedHashMap<String, Int>(allWidgets.size)
        val awm = try {
            AppWidgetManager.getInstance(context.applicationContext)
        } catch (_: Throwable) {
            null
        }
        for (descriptor in allWidgets) {
            val count = try {
                awm?.getAppWidgetIds(ComponentName(context.applicationContext, descriptor.providerClass))?.size ?: 0
            } catch (_: Throwable) {
                0
            }
            result[descriptor.id] = count
        }
        return result
    }

    fun requestPinWidget(context: Context, descriptor: MagicTuneWidgetDescriptor): Boolean {
        return try {
            val awm = AppWidgetManager.getInstance(context.applicationContext)
            val provider = ComponentName(context.applicationContext, descriptor.providerClass)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && awm.isRequestPinAppWidgetSupported) {
                val callbackIntent = Intent(context.applicationContext, WidgetPinnedFeedbackReceiver::class.java).apply {
                    action = ACTION_WIDGET_PINNED_FEEDBACK
                    putExtra(EXTRA_WIDGET_TITLE, descriptor.title)
                }
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                val successCallback = PendingIntent.getBroadcast(
                    context.applicationContext,
                    descriptor.id.hashCode(),
                    callbackIntent,
                    flags
                )
                val accepted = awm.requestPinAppWidget(provider, null, successCallback)
                if (accepted) {
                    Toast.makeText(
                        context,
                        "✨ Đã gửi yêu cầu thêm \"${descriptor.title}\" lên Màn hình chính! Bấm Thêm/OK nếu hệ thống hỏi.",
                        Toast.LENGTH_LONG
                    ).show()
                    return true
                }
            }
            Toast.makeText(
                context,
                "Nhấn giữ khoảng trống Màn hình chính -> Tiện ích (Widgets) -> chọn MagicTune -> \"${descriptor.title}\".",
                Toast.LENGTH_LONG
            ).show()
            false
        } catch (_: Throwable) {
            Toast.makeText(
                context,
                "Nhấn giữ Màn hình chính -> Tiện ích (Widgets) -> chọn \"${descriptor.title}\".",
                Toast.LENGTH_LONG
            ).show()
            false
        }
    }

    class WidgetPinnedFeedbackReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            lastPinnedFeedbackElapsedMs = android.os.SystemClock.elapsedRealtime()
            val title = intent.getStringExtra(EXTRA_WIDGET_TITLE).orEmpty().ifBlank { "Widget MagicTune" }
            Toast.makeText(
                context,
                "✅ Đã thêm \"$title\" lên Màn hình chính thành công!",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
