package com.example.core.shell

import android.app.Application
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], application = Application::class)
class UiAutomatorSwitchHelperTest {

    @Test
    fun parseDumpsysNotificationChannels_classifiesImportancesAccurately() {
        val sampleDumpsys = """
            AppSettings: com.google.android.gm
              NotificationChannel{mId='mail', mImportance=4}
            AppSettings: com.facebook.katana
              NotificationChannel{mId='push', mImportance=2}
              NotificationChannel{mId='feed', mImportance=3}
        """.trimIndent()

        val parsed = UiAutomatorSwitchHelper.parseDumpsysNotificationChannels(
            sampleDumpsys,
            setOf("com.google.android.gm", "com.facebook.katana", "com.zing.zalo")
        )

        val gmail = parsed["com.google.android.gm"]
        assertNotNull(gmail)
        assertTrue(gmail!!.foundInDumpsys)
        assertTrue(gmail.hasHighBannerChannel)
        assertFalse(gmail.hasLowOrGentleChannel)
        assertFalse(gmail.needsGentleOrBannerFix)

        val fb = parsed["com.facebook.katana"]
        assertNotNull(fb)
        assertTrue(fb!!.hasLowOrGentleChannel)
        assertTrue(fb.hasDefaultNoBannerChannel)
        assertFalse(fb.hasHighBannerChannel)
        assertTrue(fb.needsGentleOrBannerFix)

        assertNull(parsed["com.zing.zalo"])
    }

    @Test
    fun parseUiNodes_andFindSwitchAndChannelRows_parsesHierarchyCorrectly() {
        val xml = """
            <?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
            <hierarchy rotation="0">
              <node text="" class="android.widget.LinearLayout" clickable="true" enabled="true" checkable="false" checked="false" bounds="[0,200][1080,340]">
                <node text="Thông báo nhẹ nhàng" class="android.widget.TextView" clickable="false" enabled="true" checkable="false" checked="false" bounds="[48,230][700,310]" />
                <node text="" class="android.widget.Switch" clickable="true" enabled="true" checkable="true" checked="true" bounds="[900,235][1032,305]" />
              </node>
              <node text="" class="android.widget.LinearLayout" clickable="true" enabled="true" checkable="false" checked="false" bounds="[0,360][1080,500]">
                <node text="Tin nhắn quan trọng" class="android.widget.TextView" clickable="false" enabled="true" checkable="false" checked="false" bounds="[48,390][700,470]" />
              </node>
            </hierarchy>
        """.trimIndent()

        val nodes = UiAutomatorSwitchHelper.parseUiNodes(xml)
        assertEquals(5, nodes.size)

        val gentleMatch = UiAutomatorSwitchHelper.findSwitchForLabel(
            nodes,
            positiveKeywords = listOf("nhẹ nhàng", "gentle")
        )
        assertNotNull(gentleMatch)
        assertTrue(gentleMatch!!.isChecked)
        assertEquals(966, gentleMatch.tapX)
        assertEquals(270, gentleMatch.tapY)

        val channelRows = UiAutomatorSwitchHelper.findClickableChannelRows(nodes)
        assertTrue(channelRows.any { it.text == "Tin nhắn quan trọng" })
        assertFalse(channelRows.any { it.text == "Thông báo nhẹ nhàng" })
    }
}
