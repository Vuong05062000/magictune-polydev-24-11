package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.license.LicenseManager
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Immutable
data class ProGrantReceiptData(
    val targetDeviceId: String,
    val targetEmail: String = "",
    val isAccountPro: Boolean,
    val generatedKey: String,
    val reasonNote: String = "",
    val bankTransCode: String = "",
    val cloudSyncMessage: String = "Đã đồng bộ thành công lên Cloud!",
    val timestampMs: Long = System.currentTimeMillis()
) {
    fun buildCustomerReplyText(): String {
        val tierTitle = if (isAccountPro) "👑 PRO TÀI KHOẢN (Hỗ trợ đổi máy vĩnh viễn)" else "📱 PRO THIẾT BỊ (Cố định vĩnh viễn)"
        val targetLine = buildString {
            if (targetDeviceId.isNotBlank()) append("• Mã thiết bị: $targetDeviceId")
            if (targetEmail.contains("@")) {
                if (isNotEmpty()) append("\n")
                append("• Email Pro: $targetEmail")
            }
        }
        return buildString {
            appendLine("🎉 MagicTune Tool đã kích hoạt thành công gói $tierTitle cho bạn!")
            if (targetLine.isNotBlank()) appendLine(targetLine)
            if (generatedKey.isNotBlank()) appendLine("• Mã Key dự phòng vĩnh viễn: $generatedKey")
            if (bankTransCode.isNotBlank()) appendLine("• Mã đối soát: $bankTransCode")
            append("👉 Bạn chỉ cần mở lại app (hoặc vào mục Tài Khoản Pro -> Bấm 'Kiểm tra & Khôi phục Pro' / Dán mã Key trên) là dùng full tính năng ngay ạ!")
        }
    }
}

private fun copyPlainText(context: Context, label: String, text: String, toastMsg: String) {
    try {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText(label, text))
            Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
        }
    } catch (_: Throwable) {}
}

@Composable
fun ProGrantReceiptDialog(
    data: ProGrantReceiptData,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val accent = if (data.isAccountPro) MagicAmber else MagicEmerald
    val accentLight = if (data.isAccountPro) MagicAmberLight else MagicEmeraldLight
    val timeLabel = remember(data.timestampMs) {
        SimpleDateFormat("HH:mm:ss dd/MM/yyyy", Locale.getDefault()).format(Date(data.timestampMs))
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
                .widthIn(max = 540.dp),
            shape = RoundedCornerShape(18.dp),
            color = MagicSurfaceDark,
            border = BorderStroke(1.5.dp, accent.copy(alpha = 0.75f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(accent.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = "Cấp Pro thành công",
                                tint = accentLight,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "BIÊN NHẬN CẤP PRO CHUẨN CLOUD",
                                color = accentLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "🕒 $timeLabel",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Đóng", tint = TextSecondary)
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent.copy(alpha = 0.14f))
                        .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = if (data.isAccountPro) "👑 GÓI PRO TÀI KHOẢN (ĐỔI MÁY VĨNH VIỄN)" else "📱 GÓI PRO THIẾT BỊ (GẮN PHẦN CỨNG)",
                            color = accentLight,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Black
                        )
                        if (data.targetDeviceId.isNotBlank()) {
                            Text("• Device ID: ${data.targetDeviceId}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        if (data.targetEmail.isNotBlank()) {
                            Text("• Email Google: ${data.targetEmail}", color = MagicCyanLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        if (data.bankTransCode.isNotBlank()) {
                            Text("• Mã GD / Ngân hàng: ${data.bankTransCode}", color = TextSecondary, fontSize = 10.5.sp)
                        }
                        if (data.reasonNote.isNotBlank()) {
                            Text("• Ghi chú duyệt: ${data.reasonNote}", color = TextSecondary, fontSize = 10.5.sp)
                        }
                        Text(
                            text = "✅ ${data.cloudSyncMessage}",
                            color = MagicEmeraldLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                if (data.generatedKey.isNotBlank()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.65f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("🔑 MÃ KEY BẢN QUYỀN SHA-256", color = TextMuted, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    text = data.generatedKey,
                                    color = MagicCyanLight,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Button(
                                onClick = {
                                    copyPlainText(context, "Pro Key", data.generatedKey, "📋 Đã copy mã Key: ${data.generatedKey}")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                                modifier = Modifier
                                    .defaultMinSize(minHeight = 36.dp)
                                    .testTag("receipt_copy_key_btn"),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Copy Key", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.sp)
                            }
                        }
                    }
                }

                val replyMsg = remember(data) { data.buildCustomerReplyText() }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF0B1220))
                        .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("💬 Tin nhắn mẫu gửi khách (Zalo / Messenger / Telegram):", color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(replyMsg, color = TextSecondary, fontSize = 10.5.sp, lineHeight = 14.sp)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(0.7f)
                            .defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MagicBorder)
                    ) {
                        Text("Đóng", color = TextSecondary, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = {
                            copyPlainText(context, "Tin nhắn kích hoạt Pro", replyMsg, "✅ Đã copy tin nhắn hướng dẫn gửi khách!")
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = accent),
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(1.4f)
                            .defaultMinSize(minHeight = 36.dp)
                            .testTag("receipt_copy_customer_msg_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Copy Tin Nhắn Trả Khách", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminBatchGrantDialog(
    onDismiss: () -> Unit,
    onBatchComplete: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var rawTargetsInput by remember { mutableStateOf("") }
    var reasonInput by remember { mutableStateOf("CK Ngân hàng hợp lệ") }
    var grantAccountPro by remember { mutableStateOf(false) }
    var isRunning by remember { mutableStateOf(false) }
    var reportLines by remember { mutableStateOf<List<String>>(emptyList()) }
    var generatedKeysSummary by remember { mutableStateOf("") }

    Dialog(
        onDismissRequest = { if (!isRunning) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
                .widthIn(max = 580.dp),
            shape = RoundedCornerShape(18.dp),
            color = MagicSurfaceDark,
            border = BorderStroke(1.4.dp, MagicAmber.copy(alpha = 0.7f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "⚡ CẤP PRO HÀNG LOẠT (BATCH GRANT)",
                        color = MagicAmberLight,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black
                    )
                    IconButton(onClick = { if (!isRunning) onDismiss() }) {
                        Icon(Icons.Default.Close, contentDescription = "Đóng", tint = TextSecondary)
                    }
                }

                Text(
                    text = "Nhập nhiều Device ID (MT-...) hoặc Email Google (mỗi dòng 1 mục hoặc ngăn cách bằng dấu phẩy). Hệ thống sẽ tạo Key SHA-256 chuẩn & đồng bộ Cloud song song.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !grantAccountPro,
                        onClick = { grantAccountPro = false },
                        label = { Text("📱 Pro Thiết Bị", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MagicEmerald.copy(alpha = 0.3f),
                            selectedLabelColor = MagicEmeraldLight
                        )
                    )
                    FilterChip(
                        selected = grantAccountPro,
                        onClick = { grantAccountPro = true },
                        label = { Text("👑 Pro Tài Khoản (Đổi máy)", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MagicAmber.copy(alpha = 0.3f),
                            selectedLabelColor = MagicAmberLight
                        )
                    )
                }

                OutlinedTextField(
                    value = rawTargetsInput,
                    onValueChange = { rawTargetsInput = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 110.dp),
                    label = { Text("Danh sách Device ID hoặc Email", fontSize = 11.sp) },
                    placeholder = { Text("MT-7E6BB54F87617547\nkhachhang@gmail.com", fontSize = 11.sp) },
                    maxLines = 8,
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = reasonInput,
                    onValueChange = { reasonInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Lý do / Mã giao dịch (tùy chọn)", fontSize = 11.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("CK VCB 100k", "CK MB 50k", "Bảo hành đổi máy", "Khách VIP").forEach { preset ->
                        AssistChip(
                            onClick = { reasonInput = preset },
                            label = { Text(preset, fontSize = 10.sp) }
                        )
                    }
                }

                if (reportLines.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0A1120))
                            .border(1.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("📋 KẾT QUẢ XỬ LÝ:", color = MagicEmeraldLight, fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                            reportLines.forEach { line ->
                                Text(line, color = Color.White, fontSize = 10.5.sp, fontFamily = FontFamily.Monospace)
                            }
                            if (generatedKeysSummary.isNotBlank()) {
                                Spacer(Modifier.height(4.dp))
                                OutlinedButton(
                                    onClick = { copyPlainText(context, "Batch Pro Keys", generatedKeysSummary, "✅ Đã copy toàn bộ kết quả & Key!") },
                                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                                    border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.7f))
                                ) {
                                    Text("📋 Copy Toàn Bộ Mã Key", color = MagicCyanLight, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        enabled = !isRunning,
                        modifier = Modifier.fillMaxHeight().weight(0.7f).defaultMinSize(minHeight = 36.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Đóng", color = TextSecondary, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        enabled = !isRunning && rawTargetsInput.isNotBlank(),
                        onClick = {
                            val items = rawTargetsInput
                                .split('\n', ',', ';')
                                .map { it.trim() }
                                .filter { it.length >= 4 }
                                .distinct()
                            if (items.isEmpty()) {
                                Toast.makeText(context, "Vui lòng nhập ít nhất 1 Device ID hoặc Email hợp lệ!", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            isRunning = true
                            reportLines = listOf("⏳ Đang xử lý ${items.size} mục tiêu...")
                            scope.launch {
                                val outLines = mutableListOf<String>()
                                val keySummary = StringBuilder()
                                val cleanNote = reasonInput.trim().ifBlank { "ADMIN_BATCH_GRANT" }
                                for (target in items) {
                                    val isEmail = target.contains("@")
                                    if (isEmail && !grantAccountPro) {
                                        outLines.add("⚠️ $target -> Bỏ qua (Email chỉ cấp Pro Tài Khoản)")
                                        continue
                                    }
                                    val okAndKey = kotlinx.coroutines.suspendCancellableCoroutine<Pair<Boolean, String>> { cont ->
                                        LicenseManager.adminGrantTierForUserOrDevice(
                                            userId = "",
                                            deviceId = if (isEmail) "" else target.uppercase(),
                                            ownerEmail = if (isEmail) target.lowercase() else "",
                                            grantAccountPro = grantAccountPro,
                                            context = context,
                                            noteOrReason = cleanNote
                                        ) { ok, msg ->
                                            val computedKey = when {
                                                grantAccountPro && isEmail -> LicenseManager.generateAccountProKeyForEmail(target)
                                                grantAccountPro -> LicenseManager.generateAccountProLicenseKeyForDevice(target.uppercase())
                                                else -> LicenseManager.generateLicenseKeyForDevice(target.uppercase())
                                            }
                                            if (cont.isActive) {
                                                cont.resumeWith(Result.success(ok to if (ok) computedKey else msg))
                                            }
                                        }
                                    }
                                    if (okAndKey.first) {
                                        outLines.add("✅ $target -> ${okAndKey.second}")
                                        keySummary.appendLine("$target | ${okAndKey.second}")
                                    } else {
                                        outLines.add("❌ $target -> ${okAndKey.second}")
                                    }
                                }
                                reportLines = outLines
                                generatedKeysSummary = keySummary.toString().trim()
                                isRunning = false
                                onBatchComplete()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (grantAccountPro) MagicAmber else MagicEmerald),
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(1.4f)
                            .defaultMinSize(minHeight = 36.dp)
                            .testTag("batch_grant_execute_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isRunning) {
                            CircularProgressIndicator(color = Color(0xFF020617), strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                        }
                        Text(
                            text = if (isRunning) "Đang cấp Cloud..." else "⚡ Thực Thi Cấp Hàng Loạt",
                            color = Color(0xFF020617),
                            fontWeight = FontWeight.Black,
                            fontSize = 11.5.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AutoAdminBankTesterDialog(
    onDismiss: () -> Unit,
    onExecuteRealGrant: (deviceId: String, grantAccountPro: Boolean, bankTrans: String) -> Unit
) {
    val context = LocalContext.current
    var selectedSource by remember { mutableStateOf("com.mbmobile") }
    var isSmsMode by remember { mutableStateOf(false) }
    var sampleBody by remember { mutableStateOf("TK 0912xxx345 +100,000VND luc 14:35. SD: 15,200,000VND. ND: TKPRO MT-7E6BB54F87617547") }
    var dryRunResult by remember { mutableStateOf<LicenseManager.AutoAdminDryRunResult?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
                .widthIn(max = 580.dp),
            shape = RoundedCornerShape(18.dp),
            color = MagicSurfaceDark,
            border = BorderStroke(1.4.dp, MagicCyan.copy(alpha = 0.7f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🧪 TEST BỘ LỌC AUTO-ADMIN 7 LỚP",
                        color = MagicCyanLight,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Đóng", tint = TextSecondary)
                    }
                }

                Text(
                    text = "Kiểm tra thử cách hệ thống phân tích thông báo Ngân hàng / SMS để tránh duyệt nhầm hoặc bỏ sót khách. (Chế độ Dry-Run an toàn, không ghi dữ liệu thật trừ khi bạn bấm Duyệt).",
                    color = TextSecondary,
                    fontSize = 10.5.sp
                )

                Text("1. Chọn mẫu thử nhanh:", color = MagicAmberLight, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AssistChip(
                        onClick = {
                            selectedSource = "com.mbmobile"; isSmsMode = false
                            sampleBody = "TK 0912xxx345 +100,000VND. SD: 10,000,000VND. ND: TKPRO MT-7E6BB54F87617547"
                            dryRunResult = null
                        },
                        label = { Text("✅ MB +100k Pro TK", fontSize = 10.sp) }
                    )
                    AssistChip(
                        onClick = {
                            selectedSource = "com.VCB"; isSmsMode = false
                            sampleBody = "So du TK VCB +50,000 VND. ND: MT-776A6C0779C6577B UPPRO"
                            dryRunResult = null
                        },
                        label = { Text("✅ VCB +50k", fontSize = 10.sp) }
                    )
                    AssistChip(
                        onClick = {
                            selectedSource = "com.mbmobile"; isSmsMode = false
                            sampleBody = "TK 0912xxx +1,000VND. ND: +100,000VND MT-7E6BB54F87617547"
                            dryRunResult = null
                        },
                        label = { Text("🚨 Bẫy 1k ghi +100k", fontSize = 10.sp) }
                    )
                    AssistChip(
                        onClick = {
                            selectedSource = "com.zing.zalo"; isSmsMode = false
                            sampleBody = "TK +100,000VND ND: TKPRO MT-7E6BB54F87617547"
                            dryRunResult = null
                        },
                        label = { Text("🚨 Giả mạo Zalo", fontSize = 10.sp) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val sources = listOf(
                        Triple("MB App", "com.mbmobile", false),
                        Triple("VCB App", "com.VCB", false),
                        Triple("SMS MBBANK", "MBBANK", true),
                        Triple("Zalo (Chặn)", "com.zing.zalo", false)
                    )
                    sources.forEach { (label, pkg, sms) ->
                        FilterChip(
                            selected = selectedSource == pkg && isSmsMode == sms,
                            onClick = { selectedSource = pkg; isSmsMode = sms; dryRunResult = null },
                            label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }

                OutlinedTextField(
                    value = sampleBody,
                    onValueChange = { sampleBody = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Nội dung thông báo Ngân hàng / SMS", fontSize = 11.sp) },
                    minLines = 3,
                    maxLines = 5,
                    shape = RoundedCornerShape(10.dp)
                )

                Button(
                    onClick = {
                        dryRunResult = LicenseManager.dryRunTestBankNotification(
                            context = context,
                            rawBody = sampleBody,
                            bankSourcePackageOrBrand = selectedSource,
                            isSms = isSmsMode
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 36.dp)
                        .testTag("run_dry_test_auto_admin_btn"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Science, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Chạy Phân Tích 7 Lớp Ngay", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 12.sp)
                }

                dryRunResult?.let { res ->
                    val statusColor = if (res.passedAllChecks) MagicEmeraldLight else MagicRoseLight
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1120)),
                        border = BorderStroke(1.2.dp, statusColor.copy(alpha = 0.65f))
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Text(
                                text = res.summaryText,
                                color = Color.White,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                            if (res.passedAllChecks && res.primaryDeviceId.isNotBlank()) {
                                val fmtAmt = NumberFormat.getInstance(Locale.forLanguageTag("vi-VN")).format(res.layer3AmountVnd)
                                val isAcc = res.recommendedTier == "ACCOUNT_PRO"
                                Button(
                                    onClick = {
                                        onExecuteRealGrant(
                                            res.primaryDeviceId,
                                            isAcc,
                                            "+${fmtAmt}đ ($selectedSource)"
                                        )
                                        onDismiss()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = if (isAcc) MagicAmber else MagicEmerald),
                                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 36.dp),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = "⚡ Duyệt Thật Cho ${res.primaryDeviceId} (${if (isAcc) "👑 Pro TK" else "📱 Pro Máy"})",
                                        color = Color(0xFF020617),
                                        fontWeight = FontWeight.Black,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
