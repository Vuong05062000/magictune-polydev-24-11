package com.example.data

import android.app.ActivityManager
import android.bluetooth.BluetoothManager
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.nfc.NfcAdapter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.view.Display
import com.example.core.shell.ShellEngine
import com.example.core.shell.ShellMode
import com.example.core.shell.ShellResult
import com.example.core.license.LicenseManager
import com.example.core.auth.FirebaseAuthManager
import com.example.core.service.AutoWakeupPatrolManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

class MagicTuneRepository(
    private val context: Context,
    val shellEngine: ShellEngine
) {
    private val db: FirebaseFirestore? by lazy {
        try {
            val dbId = try {
                context.getString(com.example.R.string.firestore_database_id)
            } catch (_: Throwable) { "" }
            if (dbId.isNotBlank() && dbId != "(default)" && dbId != "default") {
                FirebaseFirestore.getInstance(dbId)
            } else {
                FirebaseFirestore.getInstance()
            }
        } catch (e: Throwable) {
            android.util.Log.w("MagicTuneRepository", "FirebaseFirestore fallback: ${e.message}")
            try {
                FirebaseFirestore.getInstance()
            } catch (_: Throwable) {
                null
            }
        }
    }
    private val deviceId = LicenseManager.getDeviceId(context).uppercase()
    // Secondary constructor for backward compatibility in tests
    constructor(shellEngine: ShellEngine) : this(
        context = extractContextFromEngine(shellEngine),
        shellEngine = shellEngine
    )

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private fun formatNow(): String = synchronized(timeFormat) {
        timeFormat.format(Date())
    }

    /**
     * Fix lint NewApi: LocationManager.isLocationEnabled chỉ có từ API 28.
     * Trên Android 7/8 (API 24/25) fallback kiểm tra GPS / NETWORK provider.
     */
    private fun isLocationEnabledCompat(locManager: LocationManager?): Boolean {
        if (locManager == null) return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return try { locManager.isLocationEnabled } catch (_: Throwable) { false }
        }
        return try {
            (locManager.isProviderEnabledSafe(android.location.LocationManager.GPS_PROVIDER) ||
                locManager.isProviderEnabledSafe(android.location.LocationManager.NETWORK_PROVIDER))
        } catch (_: Throwable) {
            false
        }
    }

    private fun LocationManager.isProviderEnabledSafe(provider: String): Boolean =
        try { isProviderEnabled(provider) } catch (_: Throwable) { false }

    private val repoScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + Dispatchers.Default
    )

    private val _logs = MutableStateFlow<List<LogItem>>(emptyList())
    val logs: StateFlow<List<LogItem>> = _logs

    private val _errorLogCount = MutableStateFlow(0)
    val errorLogCount: StateFlow<Int> = _errorLogCount

    private val logRingBuffer = java.util.ArrayDeque<LogItem>(320)
    private var logRevision: Long = 0L
    @Volatile
    private var logFlushScheduled: Boolean = false

    private val _deviceInfo = MutableStateFlow(DeviceInfo())
    val deviceInfo: StateFlow<DeviceInfo> = _deviceInfo

    private val _setupStatus = MutableStateFlow(NewDeviceSetupStatus())
    val setupStatus: StateFlow<NewDeviceSetupStatus> = _setupStatus

    private val _shizukuInfo = MutableStateFlow(ShizukuInfo())
    val shizukuInfo: StateFlow<ShizukuInfo> = _shizukuInfo

    private val _appsList = MutableStateFlow<List<DebloatApp>>(emptyList())
    val appsList: StateFlow<List<DebloatApp>> = _appsList

    private val _diagnosticScan = MutableStateFlow(DiagnosticScanResult())
    val diagnosticScan: StateFlow<DiagnosticScanResult> = _diagnosticScan

    private val _floatingWindowState = MutableStateFlow(FloatingMiniWindowState())
    val floatingWindowState: StateFlow<FloatingMiniWindowState> = _floatingWindowState

    private val _tuneStatus = MutableStateFlow(TuneStatus())
    val tuneStatus: StateFlow<TuneStatus> = _tuneStatus

    fun saveSyncData(tuneStatus: TuneStatus, appsList: List<DebloatApp>) {
        val firestore = db ?: return
        val frozenPackages = appsList.filter { it.isFrozen }.map { it.packageName }
        val data = mapOf(
            "tuneStatus" to tuneStatus,
            "frozenPackages" to frozenPackages,
            "lastSyncedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
        )
        try {
            firestore.collection("user_data").document(deviceId).set(data, SetOptions.merge())
        } catch (_: Throwable) {}
    }

    @Volatile
    private var lastSyncLoadMs: Long = 0L
    private var cachedSyncStatus: TuneStatus? = null
    private var cachedSyncFrozen: List<String>? = null

    fun loadSyncData(forceRefresh: Boolean = false, onLoaded: (TuneStatus?, List<String>?) -> Unit) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (!forceRefresh && lastSyncLoadMs > 0L && (now - lastSyncLoadMs < 5 * 60_000L)) {
            onLoaded(cachedSyncStatus, cachedSyncFrozen)
            return
        }
        val firestore = db ?: return
        try {
            firestore.collection("user_data").document(deviceId).get().addOnSuccessListener { doc ->
                if (doc.exists()) {
                    val status = doc.toObject(TuneStatus::class.java)
                    @Suppress("UNCHECKED_CAST")
                    val frozen = (doc.get("frozenPackages") as? List<*>)?.filterIsInstance<String>()
                    cachedSyncStatus = status
                    cachedSyncFrozen = frozen
                    lastSyncLoadMs = android.os.SystemClock.elapsedRealtime()
                    onLoaded(status, frozen)
                }
            }
        } catch (_: Throwable) {}
    }

    // Danh sách các gói CỐT LÕI HỆ THỐNG TUYỆT ĐỐI KHÔNG HIỂN THỊ / KHÔNG ĐƯỢC PHÉP GỠ (Bảo vệ ROM 100%, chống treo logo/bootloop)
    val CRITICAL_ROM_PACKAGES = setOf(
        "android",
        "com.android.systemui",
        "com.android.settings",
        "com.android.phone",
        "com.android.server.telecom",
        "com.android.keychain",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.android.shell",
        "com.android.bluetooth",
        "com.android.networkstack",
        "com.android.networkstack.inprocess",
        "com.android.networkstack.tethering.inprocess",
        "com.android.providers.settings",
        "com.android.providers.telephony",
        "com.android.providers.media",
        "com.android.providers.contacts",
        "com.android.providers.calendar",
        "com.android.providers.downloads",
        "com.android.providers.userdictionary",
        "com.android.se",
        "com.android.externalstorage",
        "com.android.mtp",
        "com.android.vpndialogs",
        "com.google.android.webview",
        "com.android.webview",
        "com.android.captiveportallogin",
        "com.android.inputdevices",
        "com.android.bms",
        "com.android.cts.priv.ctsshim",
        "com.android.cts.ctsshim",
        // Quản lý hệ thống & Điều phối Pin/Nhiệt gốc của máy (Cộng sinh 100% như người nhà, không bao giờ gỡ/tắt)
        "com.hihonor.systemmanager",
        "com.huawei.systemmanager",
        "com.hihonor.powergenius",
        "com.huawei.powergenie",
        "com.hihonor.iaware",
        "com.huawei.iaware",
        "com.hihonor.settings",
        "com.huawei.settings",
        "com.hihonor.android.launcher",
        "com.huawei.android.launcher",
        "com.miui.securitycenter",
        "com.miui.powerkeeper",
        "com.coloros.safecenter",
        "com.oplus.safecenter",
        "com.vivo.abe",
        "com.iqoo.secure",
        "com.samsung.android.lool"
    )

    // Các gói chẩn đoán/hệ thống được Honor bảo vệ chặt khiến `cmd appops set` có thể treo >25s (Timeout Exit 124)
    private val PROTECTED_HANGING_APPOPS_PACKAGES = setOf(
        "com.hihonor.detectrepair",
        "com.huawei.detectrepair"
    )

    private fun safeAppOpsCmd(pkg: String, op: String, mode: String = "allow", includeUid: Boolean = false): String {
        if (pkg in PROTECTED_HANGING_APPOPS_PACKAGES) return "true"
        if (mode != "allow" && mode != "default" &&
            com.example.core.widget.BackgroundDrainInspector.isSystemFamilyOrManagerApp(pkg)
        ) {
            return "true"
        }
        return shellEngine.buildSafeAppOpsCmd(pkg, op, mode, includeUid)
    }

    private val excludedHighDrainNotifPackages = setOf(
        "com.facebook.katana"
    )

    private val coreMetaNotificationPackages = listOf(
        "com.facebook.orca",
        "com.instagram.android",
        "com.instagram.barcelona",
        "com.whatsapp",
        "com.whatsapp.w4b"
    )

    private fun filterInstalledSafePackages(pkgs: List<String>): List<String> {
        return pkgs.asSequence()
            .map { it.trim() }
            .filter { it.isNotBlank() && it !in PROTECTED_HANGING_APPOPS_PACKAGES }
            .distinct()
            .filter { it == context.packageName || isPackageInstalledFast(it) }
            .toList()
    }

    val knownDebloatApps = listOf(
        // CẤP 1: RÁC AN TOÀN (Safe Bloatware - Gỡ thoải mái 100% không ảnh hưởng gì tới Quản lý hệ thống)
        DebloatApp("com.hihonor.video", "Honor Video", "Trình phát video nội địa, chứa nhiều quảng cáo tiếng Trung (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.gamecenter", "Trung tâm trò chơi", "Gây phiền nhiễu thông báo game tiếng Trung (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.search", "Honor Search", "Tìm kiếm vuốt xuống từ màn hình chính, gây giật lag (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.browser", "Trình duyệt Honor", "Trình duyệt mặc định nội địa TQ, nên dùng Chrome (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.magazinesettings", "Tạp chí màn hình khóa", "Tự tải ảnh nền 4K từ TQ, hao pin & dữ liệu ngầm (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.music", "Honor Music", "App nghe nhạc bản quyền Trung Quốc (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.reader", "Honor Reader", "Sách truyện tiếng Trung không có ích tại VN (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.mall", "Honor Mall", "Sàn mua sắm Honor nội địa TQ (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.live", "Honor Live", "Livestream bán hàng tiếng Trung chạy ngầm (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.vmall", "Honor Vmall", "Cửa hàng mua sắm Honor TQ chạy ngầm (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.phoneservice", "Honor Club & Thành viên", "Dịch vụ câu lạc bộ Honor TQ (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.findmyphone", "Tìm thiết bị Honor TQ", "Dịch vụ định vị nội địa TQ, nên dùng Google Find My (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.feedback", "Honor Feedback", "Phản hồi báo lỗi gửi dữ liệu về máy chủ TQ (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.hiai.engine", "HiAI Engine Service", "Nền tảng AI quảng cáo & gợi ý nội địa TQ (An toàn gỡ)", 1, isUserApp = false),

        // CẤP 2: CÂN NHẮC (Dịch vụ phụ trợ - Gỡ an toàn nhưng cân nhắc nếu có dùng tính năng này)
        DebloatApp("com.hihonor.hiboard", "Honor HiBoard", "Bảng tin vuốt trái màn hình chính tiếng Trung (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.appmarket", "Chợ Ứng dụng Honor", "Tự động cập nhật app VN đè sang tiếng Trung (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.assistant", "Trợ lý YOYO", "Trợ lý ảo YOYO tiếng Trung khi nhấn giữ thanh điều hướng (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.wallet", "Ví Honor Wallet", "Ví thanh toán Trung Quốc (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.health", "Honor Health", "App theo dõi sức khỏe nội địa TQ (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.cloud", "Honor Cloud", "Dịch vụ đám mây Honor TQ (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.tips", "Honor Tips", "Mẹo & hướng dẫn sử dụng máy Honor (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.notepad", "Ghi chú Honor", "Ứng dụng ghi chú mặc định của máy (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.compass", "La bàn Honor", "Công cụ la bàn tích hợp sẵn (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.calculator", "Máy tính Honor", "Công cụ tính toán mặc định của máy (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.soundrecorder", "Ghi âm Honor", "Công cụ ghi âm tích hợp sẵn (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.lens", "Honor Lens / AI Lens", "Quét mã QR và dịch văn bản hình ảnh (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.quicksearch", "Tìm kiếm nhanh", "Công cụ tìm kiếm trên thanh trạng thái (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.magicedge", "Magic Edge", "Cử chỉ thông minh vuốt viền màn hình (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.hwsuggestion", "Gợi ý thông minh YOYO", "Đề xuất thói quen sử dụng ứng dụng (Cân nhắc)", 2, isUserApp = false),

        // CẤP 3: CẢNH BÁO NGUY HIỂM CAO (Chỉ cho phép gỡ app gây trễ thông báo; khóa cứng các app bảo vệ ROM & không gây trễ thông báo)
        DebloatApp("com.hihonor.systemmanager", "Quản lý hệ thống (Phone Manager)", "CẤP 3: Giao diện Cài đặt Pin/Khởi chạy MagicOS • Khóa cứng chống gỡ/tắt APK để tránh lỗi ROM (MagicTune chỉ hạn chế appops ngầm an toàn)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.push", "Dịch vụ Push Honor", "CẤP 3: Dịch vụ Push Honor nội địa • Xung đột kênh FCM làm trễ tin nhắn (Cho phép gỡ/đóng băng)", 3, isUserApp = false, causesNotificationDelay = true),
        DebloatApp("com.hihonor.ouc", "Trình cập nhật MagicOS (FOTA)", "CẤP 3: Cập nhật hệ điều hành qua OTA • Tiến trình kiểm tra ngầm chiếm sóng & pin (Cho phép gỡ/đóng băng)", 3, isUserApp = false, causesNotificationDelay = true),
        DebloatApp("com.huawei.android.hwouc", "Trình cập nhật hệ thống cũ", "CẤP 3: Dịch vụ cập nhật OTA cũ còn sót lại • Chiếm sóng ngầm (Cho phép gỡ/đóng băng)", 3, isUserApp = false, causesNotificationDelay = true),
        DebloatApp("com.hihonor.id", "Tài khoản Honor ID", "CẤP 3: Đăng nhập đám mây Honor • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.android.totemweather", "Thời tiết Honor", "CẤP 3: Widget thời tiết màn hình • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.trustagent", "Honor TrustAgent", "CẤP 3: Mở khóa thông minh Bluetooth • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.android.instantshare", "Honor Share", "CẤP 3: Chia sẻ dữ liệu nhanh Wi-Fi Direct • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.airsharing", "Trình chiếu AirSharing", "CẤP 3: Chiếu màn hình không dây TV/PC • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.printservice", "Dịch vụ In ấn Honor", "CẤP 3: Kết nối & in tài liệu qua mạng • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.securitymanager", "Bảo mật nâng cao Honor", "CẤP 3: Quét virus tích hợp • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.photos", "Bộ sưu tập ảnh Honor", "CẤP 3: Xem ảnh/video mặc định • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.deskclock", "Đồng hồ & Báo thức Honor", "CẤP 3: Báo thức mặc định • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.contacts", "Danh bạ & Cuộc gọi Honor", "CẤP 3: Danh bạ mặc định • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.android.launcher", "Honor Launcher (Màn hình chính)", "CẤP 3: Giao diện Trang chủ mặc định • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false)
    )

    private val knownDebloatAppsMap: Map<String, DebloatApp> by lazy {
        knownDebloatApps.associateBy { it.packageName }
    }

    fun isAppCausingNotificationDelay(pkg: String): Boolean {
        val known = knownDebloatAppsMap[pkg]
        if (known != null) {
            return known.causesNotificationDelay
        }
        val lower = pkg.lowercase()
        return lower.contains("systemmanager") || lower.contains("push") ||
            lower.contains("ouc") || lower.contains("powergenie") ||
            lower.contains("powergenius") || lower.contains("iaware") ||
            lower.contains("battery") || lower.contains("powersaving") ||
            lower.contains("joyose") || lower.contains("powerkeeper") ||
            lower.contains("athena")
    }

    fun classifySystemApp(pkg: String, appLabel: String): Triple<Int, String, String> {
        val known = knownDebloatAppsMap[pkg]
        if (known != null) {
            return Triple(known.level, known.name, known.desc)
        }
        val lower = pkg.lowercase()
        val friendly = appLabel.ifBlank { pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() } }
        return when {
            lower.contains("ad") || lower.contains("analytic") || lower.contains("log") ||
                lower.contains("demo") || lower.contains("game") || lower.contains("video") ||
                lower.contains("music") || lower.contains("mall") || lower.contains("shop") ||
                lower.contains("news") || lower.contains("reader") || lower.contains("browser") ||
                lower.contains("market") || lower.contains("banner") || lower.contains("promo") ||
                lower.contains("live") || lower.contains("powergenie") || lower.contains("powergenius") -> {
                Triple(1, friendly, "Rác hệ thống thương mại/quảng cáo • An toàn gỡ bỏ 100%")
            }
            lower.contains("assistant") || lower.contains("cloud") || lower.contains("wallet") ||
                lower.contains("health") || lower.contains("hiboard") || lower.contains("tips") ||
                lower.contains("note") || lower.contains("recorder") || lower.contains("compass") ||
                lower.contains("lens") || lower.contains("theme") || lower.contains("weather") ||
                lower.contains("widget") || lower.contains("smart") || lower.contains("card") ||
                lower.contains("calculator") -> {
                Triple(2, friendly, "Dịch vụ phụ trợ hệ thống • Cân nhắc nhu cầu cá nhân trước khi gỡ")
            }
            else -> {
                val causesDelay = isAppCausingNotificationDelay(pkg)
                val desc = if (causesDelay) {
                    "CẤP 3: Quản lý pin & tiến trình • Có ảnh hưởng và gây chậm thông báo (Được phép gỡ/đóng băng)"
                } else {
                    "CẤP 3: Dịch vụ hệ thống chuyên sâu • Không gây trễ thông báo (Khóa cứng chống gỡ)"
                }
                Triple(3, friendly, desc)
            }
        }
    }

    val commonUserAppsCatalog = listOf(
        "com.zing.zalo" to ("Zalo" to "Ứng dụng nhắn tin & gọi điện tại Việt Nam (Cần ưu tiên thông báo & biểu ngữ)"),
        "com.facebook.katana" to ("Facebook" to "Mạng xã hội Facebook (Tự động bỏ qua fix thông báo để tránh ăn pin ngầm)"),
        "com.facebook.orca" to ("Messenger" to "Nhắn tin & gọi điện Meta Messenger (Cần chạy ngầm 24/24)"),
        "com.instagram.android" to ("Instagram" to "Mạng xã hội Meta Instagram (Giữ đầy đủ thông báo & tin nhắn Direct)"),
        "com.instagram.barcelona" to ("Threads" to "Mạng xã hội Meta Threads (Giữ đầy đủ thông báo tức thì)"),
        "com.whatsapp" to ("WhatsApp" to "Nhắn tin & gọi điện Meta WhatsApp (Cần chạy ngầm 24/24)"),
        "com.whatsapp.w4b" to ("WhatsApp Business" to "Nhắn tin doanh nghiệp Meta WhatsApp Business (Cần chạy ngầm 24/24)"),
        "com.google.android.gm" to ("Gmail" to "Thư điện tử Google Gmail (Cần phá gom cụm 0s để nhận mail tức thì)"),
        "org.telegram.messenger" to ("Telegram" to "Ứng dụng nhắn tin Telegram (Cần quyền chạy ngầm & biểu ngữ)"),
        "com.zhiliaoapp.musically" to ("TikTok" to "Ứng dụng video ngắn TikTok (Ứng dụng người dùng)"),
        "com.ss.android.ugc.trill" to ("TikTok" to "Ứng dụng video ngắn TikTok (Ứng dụng người dùng)"),
        "com.shopee.vn" to ("Shopee" to "Ứng dụng mua sắm Shopee Việt Nam (Ứng dụng người dùng)"),
        "com.vng.inputmethod.labankey" to ("Laban Key" to "Bàn phím gõ Tiếng Việt Laban Key (Ứng dụng người dùng)"),
        "com.lazada.android" to ("Lazada" to "Ứng dụng mua sắm Lazada Việt Nam (Ứng dụng người dùng)"),
        "com.mbmobile" to ("MB Bank" to "Ứng dụng tài chính MB Bank (Cần xác thực thanh toán tức thì)"),
        "com.VCB" to ("Vietcombank" to "Ứng dụng tài chính Vietcombank (Cần xác thực thanh toán tức thì)"),
        "vn.com.techcombank.bb.app" to ("Techcombank Mobile" to "Ứng dụng tài chính Techcombank (Cần xác thực thanh toán tức thì)")
    )

    private val commonUserAppsMap: Map<String, Pair<String, String>> by lazy {
        commonUserAppsCatalog.toMap()
    }

    private val cachedAppLabels = java.util.concurrent.ConcurrentHashMap<String, String>()

    private fun getCachedAppLabel(pm: android.content.pm.PackageManager, appInfo: ApplicationInfo): String {
        val pkg = appInfo.packageName ?: return ""
        cachedAppLabels[pkg]?.let { return it }
        if (cachedAppLabels.size > 200) {
            cachedAppLabels.clear()
        }
        val resolved = try {
            pm.getApplicationLabel(appInfo).toString().ifBlank { pkg }
        } catch (_: Exception) {
            pkg
        }
        cachedAppLabels[pkg] = resolved
        return resolved
    }

    init {
        loadSyncData { status, frozen ->
            if (status != null) _tuneStatus.value = status
            if (frozen != null) {
                _appsList.value = _appsList.value.map { app ->
                    if (frozen.contains(app.packageName)) app.copy(isFrozen = true) else app
                }
            }
        }
    }

    private fun hydrateAppsListFromRomIfEmpty() {
        if (_appsList.value.isNotEmpty()) return
        try {
            val raw = com.example.core.perf.DeviceMemoryStorageOptimizer.readFastSnapshotJson(
                context,
                "apps_list_snapshot_v1.json"
            ) ?: return
            val arr = org.json.JSONArray(raw)
            val list = ArrayList<DebloatApp>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                list.add(
                    DebloatApp(
                        packageName = o.optString("pkg"),
                        name = o.optString("name"),
                        desc = o.optString("desc"),
                        level = o.optInt("lvl"),
                        isInstalled = o.optBoolean("inst", true),
                        isFrozen = o.optBoolean("frz", false),
                        isUserApp = o.optBoolean("usr", false),
                        isFullNotificationFixed = o.optBoolean("notif", false),
                        isFullPermissionGranted = o.optBoolean("perm", false),
                        causesNotificationDelay = o.optBoolean("delay", false)
                    )
                )
            }
            if (list.isNotEmpty() && _appsList.value.isEmpty()) {
                _appsList.value = list
            }
        } catch (_: Throwable) {}
    }

    private fun saveAppsListToRomSnapshot(list: List<DebloatApp>) {
        try {
            val arr = org.json.JSONArray()
            for (app in list) {
                arr.put(
                    org.json.JSONObject().apply {
                        put("pkg", app.packageName)
                        put("name", app.name)
                        put("desc", app.desc)
                        put("lvl", app.level)
                        put("inst", app.isInstalled)
                        put("frz", app.isFrozen)
                        put("usr", app.isUserApp)
                        put("notif", app.isFullNotificationFixed)
                        put("perm", app.isFullPermissionGranted)
                        put("delay", app.causesNotificationDelay)
                    }
                )
            }
            com.example.core.perf.DeviceMemoryStorageOptimizer.writeFastSnapshotJson(
                context,
                "apps_list_snapshot_v1.json",
                arr.toString()
            )
        } catch (_: Throwable) {}
    }

    /**
     * Nạp ngay lập tức danh sách ứng dụng người dùng VÀ ứng dụng hệ thống Cấp 1, 2, 3 từ PackageManager & từ điển knownDebloatApps
     * khi người dùng mở Tab Quản Lý Ứng Dụng, bảo đảm 100% hiển thị đầy đủ ngay cả khi CHƯA KẾT NỐI ADB.
     */
    fun loadUserAppsImmediately() {
        hydrateAppsListFromRomIfEmpty()
        try {
            val pm = context.packageManager
            val combined = LinkedHashMap<String, DebloatApp>()

            // 1. Nạp app người dùng đã cài đặt (fallback an toàn nếu một phương thức bị lỗi)
            val installedApps = try {
                pm.getInstalledApplications(0)
            } catch (_: Throwable) {
                try {
                    pm.getInstalledPackages(0).mapNotNull { it.applicationInfo }
                } catch (_: Throwable) {
                    emptyList()
                }
            }

            val installedStatus = HashMap<String, Boolean>(installedApps.size)
            for (appInfo in installedApps) {
                val pkg = appInfo.packageName ?: continue
                installedStatus[pkg] = appInfo.enabled
                if (pkg == context.packageName) continue
                val isSys = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                if (!isSys) {
                    val catalogEntry = commonUserAppsMap[pkg]
                    val label = catalogEntry?.first ?: getCachedAppLabel(pm, appInfo)
                    val isNotifOk = shellEngine.isAppWhitelistedOrFixed(pkg) || shellEngine.isAppActuallyNotificationEnabled(pkg)
                    val isPermOk = shellEngine.isAppPermissionGranted(pkg) || shellEngine.isAppActuallyBackgroundWhitelisted(pkg)
                    combined[pkg] = DebloatApp(
                        packageName = pkg,
                        name = label,
                        desc = catalogEntry?.second ?: "Ứng dụng người dùng cài đặt • Có thể Gỡ cài đặt hoặc Cấp full quyền & Biểu ngữ",
                        level = 0,
                        isInstalled = true,
                        isFrozen = !appInfo.enabled,
                        isUserApp = true,
                        isFullNotificationFixed = isNotifOk,
                        isFullPermissionGranted = isPermOk
                    )
                }
            }

            // 2. Nạp các app hệ thống Cấp 1, Cấp 2, Cấp 3 từ knownDebloatApps vào danh sách ngay lập tức (O(1) map)
            for (sysApp in knownDebloatApps) {
                val pkg = sysApp.packageName
                if (CRITICAL_ROM_PACKAGES.contains(pkg)) continue
                val isEnabled = installedStatus[pkg]
                val hasInstalled = installedStatus.containsKey(pkg)
                val isDis = isEnabled == false || shellEngine.isPackageMarkedDisabled(pkg)
                val isUninstalled = shellEngine.isPackageMarkedUninstalled(pkg)
                val isInst = hasInstalled && !isUninstalled

                // Nếu gói có tồn tại trên máy hoặc đã được ghi nhận gỡ/tắt -> Đưa vào danh sách
                if (hasInstalled || isUninstalled || isDis) {
                    combined[pkg] = sysApp.copy(
                        isInstalled = isInst,
                        isFrozen = isDis,
                        isUserApp = false,
                        isFullNotificationFixed = shellEngine.isAppWhitelistedOrFixed(pkg),
                        isFullPermissionGranted = shellEngine.isAppPermissionGranted(pkg)
                    )
                }
            }
            installedStatus.clear()

            if (combined.isNotEmpty()) {
                _appsList.value = combined.values.sortedWith(
                    compareBy<DebloatApp> { app ->
                        when {
                            app.isUserApp && app.isInstalled && !app.isFrozen && (!app.isFullNotificationFixed || !app.isFullPermissionGranted) -> 0
                            !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 1 -> 1
                            app.isUserApp && app.isInstalled && !app.isFrozen -> 2
                            !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 2 -> 3
                            !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 3 -> 4
                            else -> 5
                        }
                    }.thenBy { it.name.lowercase() }
                )
            }
        } catch (_: Throwable) {}
    }

    @Volatile
    private var cachedCanViewRawLogs: Boolean = false

    @Volatile
    private var lastRawLogCheckMs: Long = 0L

    @Volatile
    private var lastSeenProVersionForLogs: Long = -1L

    private fun canUserViewRawLogsFast(): Boolean {
        val now = android.os.SystemClock.elapsedRealtime()
        val currentProVer = LicenseManager.proStateVersionFlow.value
        if (currentProVer == lastSeenProVersionForLogs && now - lastRawLogCheckMs < 2000L) {
            return cachedCanViewRawLogs
        }
        val isLiveAdmin = FirebaseAuthManager.getCurrentUser() != null &&
            (FirebaseAuthManager.isCurrentAdmin(context, null) || LicenseManager.isCurrentUserAdmin(context))
        val isProUserOrDevice = !LicenseManager.isAdminSimulateFreeMode(context) &&
            (LicenseManager.isProActivated(context) || LicenseManager.isAccountProActivated(context))
        val allowed = isLiveAdmin || isProUserOrDevice
        cachedCanViewRawLogs = allowed
        lastRawLogCheckMs = now
        lastSeenProVersionForLogs = currentProVer
        return allowed
    }

    /**
     * Lọc và che giấu các chuỗi lệnh Shell / ADB nhạy cảm đối với tài khoản chưa kích hoạt Pro:
     * - Admin, Người dùng Pro Tài Khoản và Máy Pro được xem toàn bộ chi tiết mã lệnh thô & kết quả thực thi.
     * - Với người dùng Free thông thường, chỉ hiển thị thông báo tiến trình tổng quát.
     */
    private fun sanitizeLogForUser(rawMessage: String, type: LogType): String {
        try {
            if (canUserViewRawLogsFast()) return rawMessage // Admin & Người dùng Pro / Máy Pro xem toàn bộ chi tiết dòng lệnh như Admin

            // Với người dùng Free, che các lệnh Shell thô và chi tiết lệnh
            if (type == LogType.COMMAND || rawMessage.startsWith("> ") || rawMessage.startsWith("$ ")) {
                return "⚡ Đang xử lý cấu hình hệ thống..."
            }
            if (rawMessage.startsWith("✅ OK: ") || rawMessage.startsWith("✅ [OK]: ")) {
                return "✅ Đã áp dụng thiết lập tối ưu thành công."
            }
            if (rawMessage.startsWith("✅ THÀNH CÔNG: ")) {
                return "✅ Đã hoàn tất cài đặt tối ưu hệ thống."
            }
            if (rawMessage.startsWith("❌ THẤT BẠI [") || rawMessage.startsWith("❌ LỆNH THẤT BẠI [")) {
                return "⚠️ Một mục cài đặt hệ thống không phản hồi hoặc đã được tối ưu trước đó."
            }
            // Che các câu lệnh chứa cú pháp kỹ thuật đặc thù
            if (rawMessage.contains("cmd ") || rawMessage.contains("settings put") ||
                rawMessage.contains("pm disable") || rawMessage.contains("service call") ||
                rawMessage.contains("setprop") || rawMessage.contains("device_config")) {
                return "⚙️ Đang đồng bộ hóa dịch vụ chuyên sâu..."
            }
        } catch (_: Throwable) {}
        return rawMessage
    }

    fun log(message: String, type: LogType = LogType.INFO) {
        val sanitized = sanitizeLogForUser(message, type)
        val item = LogItem(sanitized, type, formatNow())
        var scheduleFlush = false
        synchronized(logRingBuffer) {
            logRingBuffer.addLast(item)
            while (logRingBuffer.size > 300) {
                logRingBuffer.removeFirst()
            }
            logRevision++
            if (!logFlushScheduled) {
                logFlushScheduled = true
                scheduleFlush = true
            }
        }
        if (scheduleFlush) {
            repoScope.launch {
                delay(80L)
                val snapshot: List<LogItem>
                val errCount: Int
                synchronized(logRingBuffer) {
                    logFlushScheduled = false
                    snapshot = logRingBuffer.toList()
                    errCount = snapshot.count { it.type == LogType.ERROR }
                }
                _logs.value = snapshot
                _errorLogCount.value = errCount
            }
        }
    }

    fun clearLogs() {
        synchronized(logRingBuffer) {
            logRingBuffer.clear()
            logRevision++
            logFlushScheduled = false
        }
        _logs.value = emptyList()
        _errorLogCount.value = 0
    }

    /**
     * Executes a single shell command or a semicolon-separated command string.
     * Splits multiple commands so each command's exit code and stderr are verified individually.
     */
    suspend fun runShell(cmd: String, showLog: Boolean = true, isBackground: Boolean = !showLog): String = withContext(Dispatchers.IO) {
        val subCommands = splitShellCommands(cmd)
        if (subCommands.size <= 1) {
            if (showLog) log("> $cmd", LogType.COMMAND)
            val res = shellEngine.execute(cmd, isBackground = isBackground)
            if (showLog) {
                if (res.isSuccess) {
                    val outMsg = if (res.output.isNotBlank()) "✅ OK: ${res.output.take(300)}" else "✅ OK: $cmd"
                    log(outMsg, LogType.SUCCESS)
                } else {
                    log("❌ THẤT BẠI [$cmd]: ${res.errorReason}", LogType.ERROR)
                    val errOut = res.combinedOutput.ifBlank { res.errorReason }
                    if (shellEngine.state.value.isAdbReady && !LicenseManager.isConnectionRelatedAdbError(cmd, errOut, "RUN_SHELL")) {
                        LicenseManager.saveAdminAdbErrorLog(
                            context = context,
                            command = cmd,
                            exitCode = res.exitCode,
                            errorOutput = errOut,
                            connectionMode = res.modeUsed.name,
                            featureSource = "RUN_SHELL"
                        )
                    }
                }
            }
            // Khi showLog = false (đọc thông số ngầm), tuyệt đối KHÔNG trả về chuỗi lỗi res.error để tránh hiển thị nhầm lên thẻ thông tin máy!
            return@withContext if (res.isSuccess) {
                res.output.takeIf { !it.contains("Lỗi kết nối", ignoreCase = true) } ?: ""
            } else {
                if (showLog) res.output.ifBlank { res.error } else ""
            }
        } else {
            val outputs = mutableListOf<String>()
            for (single in subCommands) {
                if (showLog) log("> $single", LogType.COMMAND)
                val res = shellEngine.execute(single, isBackground = isBackground)
                if (showLog) {
                    if (res.isSuccess) {
                        val outMsg = if (res.output.isNotBlank()) "✅ OK: ${res.output.take(200)}" else "✅ OK: $single"
                        log(outMsg, LogType.SUCCESS)
                    } else {
                        log("❌ THẤT BẠI [$single]: ${res.errorReason}", LogType.ERROR)
                        val errOut = res.combinedOutput.ifBlank { res.errorReason }
                        if (shellEngine.state.value.isAdbReady && !LicenseManager.isConnectionRelatedAdbError(single, errOut, "RUN_SHELL_MULTI")) {
                            LicenseManager.saveAdminAdbErrorLog(
                                context = context,
                                command = single,
                                exitCode = res.exitCode,
                                errorOutput = errOut,
                                connectionMode = res.modeUsed.name,
                                featureSource = "RUN_SHELL_MULTI"
                            )
                        }
                    }
                }
                if (res.isSuccess) {
                    outputs.add(res.output)
                } else if (showLog) {
                    outputs.add(res.output.ifBlank { res.error })
                }
            }
            return@withContext outputs.joinToString("\n")
        }
    }

    private val sysPropMemoryCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    @Volatile
    private var sysPropGetMethod: java.lang.reflect.Method? = null

    @Volatile
    private var sysPropReflectionInitialized = false

    /**
     * Đọc thuộc tính hệ thống (SystemProperties) siêu tốc trực tiếp qua vùng nhớ chia sẻ Android (0.01ms),
     * lưu bộ đệm vào RAM cả khi có giá trị lẫn khi khóa rỗng để tuyệt đối không tạo tiến trình con `getprop` gây nghẽn CPU.
     */
    private fun readSysPropFast(key: String, default: String = ""): String {
        sysPropMemoryCache[key]?.let { cached ->
            return cached.ifBlank { default }
        }
        try {
            if (!sysPropReflectionInitialized) {
                synchronized(this) {
                    if (!sysPropReflectionInitialized) {
                        val spClass = Class.forName("android.os.SystemProperties")
                        sysPropGetMethod = spClass.getMethod("get", String::class.java, String::class.java)
                        sysPropReflectionInitialized = true
                    }
                }
            }
            val method = sysPropGetMethod
            if (method != null) {
                val rawValue = (method.invoke(null, key, "") as? String)?.trim() ?: ""
                val cleanValue = if (
                    rawValue.isNotBlank() &&
                    !rawValue.equals("null", ignoreCase = true) &&
                    !rawValue.contains("Lỗi kết nối", ignoreCase = true)
                ) {
                    rawValue
                } else {
                    ""
                }
                sysPropMemoryCache[key] = cleanValue
                return cleanValue.ifBlank { default }
            }
        } catch (_: Throwable) {}

        sysPropMemoryCache[key] = ""
        return default
    }

    /**
     * Runs a batch of ADB commands, verifying each command individually and reporting exact
     * success/failure counts without ever showing a fake success summary.
     */
    suspend fun runVerifiedBatch(actionTitle: String, commands: List<String>, silent: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        val flatCommands = commands.flatMap { splitShellCommands(it) }.filter { it.isNotBlank() }
        var successCount = 0
        var failCount = 0
        val failedList = mutableListOf<String>()

        val isHighSpeedAdbLive = shellEngine.state.value.isAdbReady

        // Tối ưu hóa siêu tốc Turbo v2.5 khi Shizuku/ADB đang Live:
        // Chạy qua shellEngine.executeBatch (mỗi lô 25 lệnh chỉ tạo ĐÚNG 1 tiến trình Shizuku duy nhất),
        // vừa có kết quả riêng biệt từng lệnh vừa triệt tiêu 100% lỗi "Shizuku Binder không phản hồi"!
        if (isHighSpeedAdbLive && flatCommands.size >= 2) {
            val chunkSize = 80 // Split commands into chunks so ADB/Shizuku socket never freezes on huge batches (e.g. 4854 commands)
            val chunks = flatCommands.chunked(chunkSize)
            val modeLabel = if (shellEngine.state.value.isWirelessAdbConnected) "Direct WLAN ADB (UID 2000)" else "Shizuku (UID 2000)"
            if (!silent) {
                log("⚡ [Turbo v2.5] Đang thực thi ${flatCommands.size} lệnh qua ${chunks.size} đợt siêu tốc ($modeLabel)...", LogType.INFO)
            }

            for ((chunkIndex, chunk) in chunks.withIndex()) {
                if (!silent && chunks.size > 1) {
                    log("🔄 Đang xử lý đợt ${chunkIndex + 1}/${chunks.size} (${chunk.size} lệnh)...", LogType.INFO)
                }
                val batchResults = shellEngine.executeBatch(chunk)
                for (res in batchResults) {
                    val cmd = res.command
                    if (res.isSuccess) {
                        successCount++
                        if (!silent) {
                            val detail = if (res.output.isNotBlank()) " -> ${res.output.take(120)}" else ""
                            log("✅ [OK]: $cmd$detail", LogType.SUCCESS)
                        }
                    } else {
                        failCount++
                        failedList.add(cmd)
                        if (!silent) {
                            log("❌ LỆNH THẤT BẠI [$cmd]: ${res.errorReason}", LogType.ERROR)
                        }
                        val errOut = res.combinedOutput.ifBlank { res.errorReason }
                        if (shellEngine.state.value.isAdbReady && !LicenseManager.isConnectionRelatedAdbError(cmd, errOut, "BATCH: $actionTitle")) {
                            LicenseManager.saveAdminAdbErrorLog(
                                context = context,
                                command = cmd,
                                exitCode = res.exitCode,
                                errorOutput = errOut,
                                connectionMode = res.modeUsed.name,
                                featureSource = "BATCH: $actionTitle"
                            )
                        }
                    }
                }
                if (chunkIndex < chunks.size - 1) {
                    kotlinx.coroutines.delay(50L) // Tiny pause between chunks to let system ADB socket process smoothly
                }
            }
        } else {
            for ((idx, cmd) in flatCommands.withIndex()) {
                if (!silent) {
                    log("> $cmd", LogType.COMMAND)
                }
                val res: ShellResult = shellEngine.execute(cmd)
                if (res.isSuccess) {
                    successCount++
                    if (!silent) {
                        val detail = if (res.output.isNotBlank()) " -> ${res.output.take(140)}" else ""
                        log("✅ THÀNH CÔNG: $cmd$detail", LogType.SUCCESS)
                    }
                } else {
                    failCount++
                    failedList.add(cmd)
                    val errOut = res.combinedOutput.ifBlank { res.errorReason }
                    val isNoAdbError = !shellEngine.state.value.isAdbReady && (
                        errOut.contains("Chưa kết nối Shizuku / WLAN ADB", ignoreCase = true) ||
                            errOut.contains("Direct ADB chưa được kết nối", ignoreCase = true)
                        )
                    if (isNoAdbError) {
                        val remainingCount = flatCommands.size - idx
                        failCount = flatCommands.size - successCount
                        if (!silent) {
                            log(
                                "⚠️ Chưa kết nối Gỡ lỗi WLAN / Shizuku — đã dừng nhanh ($remainingCount lệnh yêu cầu quyền hệ thống cần kết nối Gỡ lỗi Wi-Fi trước).",
                                LogType.ERROR
                            )
                        }
                        break
                    }
                    if (!silent) {
                        log("❌ LỆNH THẤT BẠI [$cmd]: ${res.errorReason}", LogType.ERROR)
                    }
                    if (shellEngine.state.value.isAdbReady && !LicenseManager.isConnectionRelatedAdbError(cmd, errOut, "ACTION: $actionTitle")) {
                        LicenseManager.saveAdminAdbErrorLog(
                            context = context,
                            command = cmd,
                            exitCode = res.exitCode,
                            errorOutput = errOut,
                            connectionMode = res.modeUsed.name,
                            featureSource = "ACTION: $actionTitle"
                        )
                    }
                }
            }
        }

        val total = flatCommands.size
        return@withContext when {
            failCount == 0 && total > 0 -> {
                if (!silent) {
                    log("🎉 HOÀN TẤT THÀNH CÔNG 100% ($successCount/$total lệnh): $actionTitle", LogType.SUCCESS)
                }
                true
            }
            successCount > 0 && failCount > 0 -> {
                if (!silent) {
                    val isShizukuActive = shellEngine.state.value.mode == ShellMode.SHIZUKU &&
                        shellEngine.state.value.isShizukuRunning &&
                        shellEngine.state.value.isShizukuPermissionGranted
                    val adviseWeb = if (isShizukuActive) " 👉 Hãy truy cập https://magictunehonor.ai.studio để dùng WebADB hoặc xem hướng dẫn fix chuyên sâu cho Honor!" else " 👉 Hãy kết nối WLAN / Shizuku hoặc truy cập https://magictunehonor.ai.studio."
                    log(
                        "⚠️ KẾT QUẢ THỰC TẾ [$actionTitle]: Thành công $successCount/$total lệnh, THẤT BẠI $failCount lệnh! (Xem chi tiết lỗi đỏ ❌ ở trên).$adviseWeb",
                        LogType.ERROR
                    )
                }
                false
            }
            else -> {
                if (!silent) {
                    val isShizukuActive = shellEngine.state.value.mode == ShellMode.SHIZUKU &&
                        shellEngine.state.value.isShizukuRunning &&
                        shellEngine.state.value.isShizukuPermissionGranted
                    val msg = if (isShizukuActive) {
                        "❌ THẤT BẠI ($failCount/$total lệnh bị từ chối): '$actionTitle' gặp lỗi quyền trên MagicOS dù đã có Shizuku! 👉 Bạn hãy mở website tiện ích https://magictunehonor.ai.studio để chạy công cụ gỡ lỗi chuyên sâu hoặc kết nối WebADB."
                    } else {
                        "❌ THẤT BẠI ($failCount/$total lệnh bị từ chối): '$actionTitle' không thể áp dụng do chưa kết nối Gỡ lỗi Wi-Fi (WLAN ADB)! 👉 Vui lòng mở tab Kết Nối để ghép nối trực tiếp bằng mã 6 số."
                    }
                    log(msg, LogType.ERROR)
                }
                false
            }
        }
    }

    private fun splitShellCommands(raw: String): List<String> {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return emptyList()
        // Giữ nguyên các khối điều khiển POSIX shell (`if...fi`, `for...done`, `while...done`, `case...esac`, `sh -c`, `{ ...; }`)
        // để tránh băm nhỏ `if echo ...; then ...; fi` thành các mảnh lệnh gãy cú pháp!
        if (Regex("(^|[;\\s])(if|then|elif|else|fi|for|do|done|while|until|case|esac)\\b").containsMatchIn(trimmed) ||
            trimmed.startsWith("sh -c") ||
            trimmed.startsWith("{")
        ) {
            return listOf(trimmed)
        }

        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inDoubleQuotes = false
        var inSingleQuotes = false
        var escaped = false
        var parenDepth = 0
        var braceDepth = 0
        for (ch in trimmed) {
            if (escaped) {
                current.append(ch)
                escaped = false
                continue
            }
            when {
                ch == '\\' && !inSingleQuotes -> {
                    escaped = true
                    current.append(ch)
                }
                ch == '\'' && !inDoubleQuotes -> {
                    inSingleQuotes = !inSingleQuotes
                    current.append(ch)
                }
                ch == '"' && !inSingleQuotes -> {
                    inDoubleQuotes = !inDoubleQuotes
                    current.append(ch)
                }
                ch == '(' && !inSingleQuotes && !inDoubleQuotes -> {
                    parenDepth++
                    current.append(ch)
                }
                ch == ')' && !inSingleQuotes && !inDoubleQuotes && parenDepth > 0 -> {
                    parenDepth--
                    current.append(ch)
                }
                ch == '{' && !inSingleQuotes && !inDoubleQuotes -> {
                    braceDepth++
                    current.append(ch)
                }
                ch == '}' && !inSingleQuotes && !inDoubleQuotes && braceDepth > 0 -> {
                    braceDepth--
                    current.append(ch)
                }
                ch == ';' && !inDoubleQuotes && !inSingleQuotes && parenDepth == 0 && braceDepth == 0 -> {
                    val built = current.toString().trim()
                    if (built.isNotEmpty()) result.add(built)
                    current.clear()
                }
                else -> current.append(ch)
            }
        }
        val last = current.toString().trim()
        if (last.isNotEmpty()) result.add(last)
        return result
    }

    private data class StaticHardwareSpecs(
        val manufacturer: String,
        val brand: String,
        val model: String,
        val deviceCodename: String,
        val board: String,
        val androidVer: String,
        val sdkInt: Int,
        val securityPatch: String,
        val displayId: String,
        val kernelVer: String,
        val abi: String,
        val socName: String,
        val cpuCoresText: String,
        val cpuFreqText: String,
        val gpuName: String,
        val sensorCount: Int,
        val capturedWithAdb: Boolean
    )

    @Volatile
    private var cachedStaticSpecs: StaticHardwareSpecs? = null

    @Volatile
    private var cachedBatteryCycleCount: String? = null

    @Volatile
    private var sessionPeakChargingWatts: Double = 0.0

    @Volatile
    private var lastBatteryCycleShellCheckMs: Long = 0L

    @Volatile
    private var cachedCycleSysfsUnavailable: Boolean = false

    @Volatile
    private var cachedTotalRamGb: Double = -1.0

    private val deviceInfoRefreshMutex = kotlinx.coroutines.sync.Mutex()

    @Volatile
    private var lastDeviceInfoRefreshElapsedMs: Long = 0L

    private fun loadPersistedStaticSpecsIfValid(): StaticHardwareSpecs? {
        return try {
            val hwPrefs = context.getSharedPreferences("magictune_hw_cache_prefs", Context.MODE_PRIVATE)
            if (hwPrefs.getString("hw_fingerprint", "") != Build.FINGERPRINT) return null
            val model = hwPrefs.getString("hw_model", "") ?: ""
            val soc = hwPrefs.getString("hw_soc", "") ?: ""
            val gpu = hwPrefs.getString("hw_gpu", "") ?: ""
            if (model.isBlank() || soc.isBlank() || gpu.isBlank()) return null
            StaticHardwareSpecs(
                manufacturer = hwPrefs.getString("hw_manufacturer", Build.MANUFACTURER) ?: Build.MANUFACTURER,
                brand = hwPrefs.getString("hw_brand", Build.BRAND) ?: Build.BRAND,
                model = model,
                deviceCodename = hwPrefs.getString("hw_codename", Build.DEVICE) ?: Build.DEVICE,
                board = hwPrefs.getString("hw_board", Build.BOARD) ?: Build.BOARD,
                androidVer = hwPrefs.getString("hw_android_ver", Build.VERSION.RELEASE) ?: Build.VERSION.RELEASE,
                sdkInt = Build.VERSION.SDK_INT,
                securityPatch = hwPrefs.getString("hw_sec_patch", "N/A") ?: "N/A",
                displayId = hwPrefs.getString("hw_display_id", Build.DISPLAY) ?: Build.DISPLAY,
                kernelVer = hwPrefs.getString("hw_kernel", "Linux") ?: "Linux",
                abi = hwPrefs.getString("hw_abi", "") ?: "",
                socName = soc,
                cpuCoresText = hwPrefs.getString("hw_cpu_cores", "") ?: "",
                cpuFreqText = hwPrefs.getString("hw_cpu_freq", "") ?: "",
                gpuName = gpu,
                sensorCount = hwPrefs.getInt("hw_sensor_count", 0),
                capturedWithAdb = false
            )
        } catch (_: Throwable) {
            null
        }
    }

    private fun savePersistedStaticSpecs(specs: StaticHardwareSpecs) {
        try {
            context.getSharedPreferences("magictune_hw_cache_prefs", Context.MODE_PRIVATE).edit()
                .putString("hw_fingerprint", Build.FINGERPRINT)
                .putString("hw_manufacturer", specs.manufacturer)
                .putString("hw_brand", specs.brand)
                .putString("hw_model", specs.model)
                .putString("hw_codename", specs.deviceCodename)
                .putString("hw_board", specs.board)
                .putString("hw_android_ver", specs.androidVer)
                .putString("hw_sec_patch", specs.securityPatch)
                .putString("hw_display_id", specs.displayId)
                .putString("hw_kernel", specs.kernelVer)
                .putString("hw_abi", specs.abi)
                .putString("hw_soc", specs.socName)
                .putString("hw_cpu_cores", specs.cpuCoresText)
                .putString("hw_cpu_freq", specs.cpuFreqText)
                .putString("hw_gpu", specs.gpuName)
                .putInt("hw_sensor_count", specs.sensorCount)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun getOrLoadStaticSpecs(): StaticHardwareSpecs {
        cachedStaticSpecs?.let { existing ->
            if (!existing.model.contains("Lỗi kết nối", ignoreCase = true) &&
                !existing.socName.contains("Lỗi kết nối", ignoreCase = true) &&
                !existing.gpuName.contains("Lỗi kết nối", ignoreCase = true)
            ) {
                return existing
            }
        }
        loadPersistedStaticSpecsIfValid()?.let { diskCached ->
            cachedStaticSpecs = diskCached
            return diskCached
        }

        val manufacturer = try {
            Build.MANUFACTURER.ifBlank { readSysPropFast("ro.product.manufacturer", "HONOR") }.ifBlank { "HONOR" }
        } catch (_: Throwable) { "HONOR" }
        val brand = try { Build.BRAND.ifBlank { manufacturer }.uppercase() } catch (_: Throwable) { manufacturer.uppercase() }
        val rawModel = try {
            Build.MODEL.ifBlank { readSysPropFast("ro.product.model", "Honor Device") }.ifBlank { "Honor Device" }
        } catch (_: Throwable) { "Honor Device" }
        val marketName = readSysPropFast("ro.config.marketing_name", "").trim()
        val customName = try {
            Settings.Global.getString(context.contentResolver, "device_name")?.takeIf { it.isNotBlank() && it != "null" && !it.contains("Lỗi kết nối", true) }
                ?: Settings.Secure.getString(context.contentResolver, "bluetooth_name")?.takeIf { it.isNotBlank() && it != "null" && !it.contains("Lỗi kết nối", true) }
        } catch (_: Throwable) { null }

        val model = when {
            marketName.isNotBlank() && !marketName.equals("null", ignoreCase = true) -> {
                val clean = if (marketName.startsWith("荣耀")) "Honor " + marketName.removePrefix("荣耀").trim() else marketName
                if (customName != null && customName.contains(clean, ignoreCase = true)) customName else clean
            }
            !customName.isNullOrBlank() -> customName
            rawModel.equals("PPG-AN00", ignoreCase = true) -> "Honor GT Pro"
            else -> rawModel
        }
        val deviceCodename = Build.DEVICE.ifBlank { Build.PRODUCT }.ifBlank { "Unknown" }
        val board = "${Build.BOARD} (${Build.HARDWARE})"
        val sdkInt = Build.VERSION.SDK_INT
        val androidVer = Build.VERSION.SDK_INT.let { sdk ->
            Build.VERSION.RELEASE.ifBlank {
                when {
                    sdk >= 37 -> "17"
                    sdk == 36 -> "16"
                    else -> "15"
                }
            }
        }
        val securityPatch = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Build.VERSION.SECURITY_PATCH.ifBlank { "N/A" }
        } else "N/A"
        val rawMagicProp = listOf(
            "ro.build.version.magic",
            "ro.build.version.magic.display",
            "ro.build.magic.version",
            "ro.hn.build.version.magic",
            "ro.honor.build.version.magic",
            "ro.magic.version.display",
            "ro.comp.real_os_version",
            "ro.build.display.id"
        ).firstNotNullOfOrNull { key ->
            readSysPropFast(key, "").trim().takeIf { it.isNotBlank() && !it.equals("unknown", true) }
        } ?: Build.DISPLAY.ifBlank { "MagicOS" }
        val displayId = if (rawMagicProp.startsWith("MagicOS", ignoreCase = true) || rawMagicProp.contains("MagicOS", ignoreCase = true)) {
            rawMagicProp
        } else if (rawMagicProp.matches(Regex("^\\d+(\\.\\d+)*$"))) {
            "MagicOS $rawMagicProp"
        } else {
            rawMagicProp.ifBlank { "MagicOS" }
        }
        val kernelVer = try { System.getProperty("os.version") ?: "Linux" } catch (_: Throwable) { "Linux" }
        val abi = try { Build.SUPPORTED_ABIS.joinToString(", ") } catch (_: Throwable) { "arm64-v8a" }

        val socFromBuild = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try { Build.SOC_MODEL.takeIf { it != Build.UNKNOWN && it.isNotBlank() } } catch (_: Throwable) { null }
        } else null
        val socProp = readSysPropFast("ro.board.platform", Build.HARDWARE).trim()
        val cpuHardware = readCpuHardwareName()
        val socName = listOfNotNull(socFromBuild, cpuHardware, socProp.takeIf { it.isNotBlank() })
            .distinct()
            .joinToString(" • ")
            .ifBlank { Build.HARDWARE }

        val cores = try { Runtime.getRuntime().availableProcessors().coerceAtLeast(1) } catch (_: Throwable) { 8 }
        val maxFreqGhz = readMaxCpuFreqGhz()
        val cpuCoresText = "$cores nhân xử lý"
        val cpuFreqText = if (maxFreqGhz.isNotBlank()) "Xung tối đa $maxFreqGhz" else abi

        val gpuProp = readSysPropFast("ro.hardware.egl", "").trim()
        val gpuName = if (gpuProp.isNotBlank()) "GPU $gpuProp (${socProp.ifBlank { Build.HARDWARE }})" else "Adreno / Mali (${socProp.ifBlank { Build.HARDWARE }})"

        val sensorCount = try {
            val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
            sm?.getSensorList(Sensor.TYPE_ALL)?.size ?: 0
        } catch (_: Throwable) { 0 }

        return StaticHardwareSpecs(
            manufacturer = manufacturer,
            brand = brand,
            model = model,
            deviceCodename = deviceCodename,
            board = board,
            androidVer = androidVer,
            sdkInt = sdkInt,
            securityPatch = securityPatch,
            displayId = displayId,
            kernelVer = kernelVer,
            abi = abi,
            socName = socName,
            cpuCoresText = cpuCoresText,
            cpuFreqText = cpuFreqText,
            gpuName = gpuName,
            sensorCount = sensorCount,
            capturedWithAdb = false
        ).also {
            cachedStaticSpecs = it
            savePersistedStaticSpecs(it)
        }
    }

    // -------------------------------------------------------------
    // ĐỌC ĐẦY ĐỦ PHẦN CỨNG & TRẠNG THÁI BẬT/TẮT TÍNH NĂNG REALTIME
    // -------------------------------------------------------------
    suspend fun refreshDeviceInfo(force: Boolean = false) = withContext(Dispatchers.IO) {
        deviceInfoRefreshMutex.lock()
        try {
            val nowElapsed = SystemClock.elapsedRealtime()
            if (!force && lastDeviceInfoRefreshElapsedMs > 0L && (nowElapsed - lastDeviceInfoRefreshElapsedMs) < 6_000L) {
                refreshTuneStatus()
                refreshFloatingPermissionsState()
                return@withContext
            }
            val specs = getOrLoadStaticSpecs()
        val manufacturer = specs.manufacturer
        val brand = specs.brand
        val model = specs.model
        val deviceCodename = specs.deviceCodename
        val board = specs.board
        val androidVer = specs.androidVer
        val sdkInt = specs.sdkInt
        val securityPatch = specs.securityPatch
        val displayId = specs.displayId
        val kernelVer = specs.kernelVer
        val abi = specs.abi
        val socName = specs.socName
        val cpuCoresText = specs.cpuCoresText
        val cpuFreqText = specs.cpuFreqText
        val gpuName = specs.gpuName

        var ramString = "N/A"
        var ramPercent = 0f
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (am != null) {
                val memInfo = ActivityManager.MemoryInfo()
                am.getMemoryInfo(memInfo)
                val totalGb = memInfo.totalMem.toDouble() / (1024.0 * 1024.0 * 1024.0)
                val availGb = memInfo.availMem.toDouble() / (1024.0 * 1024.0 * 1024.0)
                val usedGb = (totalGb - availGb).coerceAtLeast(0.0)
                ramPercent = if (totalGb > 0) ((usedGb / totalGb) * 100.0).toFloat().coerceIn(0f, 100f) else 0f
                ramString = String.format(
                    Locale.US,
                    "Đang dùng %.1f GB / %.1f GB (Trống %.1f GB • %.0f%%)",
                    usedGb,
                    totalGb,
                    availGb,
                    ramPercent
                )
            }
        } catch (_: Throwable) {}

        var storageString = "N/A"
        var storagePercent = 0f
        try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val totalBytes = stat.blockSizeLong * stat.blockCountLong
            val availBytes = stat.blockSizeLong * stat.availableBlocksLong
            val usedBytes = (totalBytes - availBytes).coerceAtLeast(0L)
            val totalGb = totalBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            val availGb = availBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            val usedGb = usedBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            storagePercent = if (totalGb > 0) ((usedGb / totalGb) * 100.0).toFloat().coerceIn(0f, 100f) else 0f
            storageString = String.format(
                Locale.US,
                "Đã dùng %.1f GB / %.1f GB (Trống %.1f GB • %.0f%%)",
                usedGb,
                totalGb,
                availGb,
                storagePercent
            )
        } catch (_: Throwable) {}

        var batLevel = 100
        var batStatusText = "Đang hoạt động"
        var batTempText = "N/A"
        var batVoltText = "N/A"
        var batTechText = "Li-poly"
        var batHealthText = "Tốt"
        var batCycleCountText = "N/A"
        try {
            val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (batteryIntent != null) {
                val level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                if (level >= 0 && scale > 0) {
                    batLevel = (level * 100) / scale
                }
                val status = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val plugged = batteryIntent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
                val plugType = when (plugged) {
                    BatteryManager.BATTERY_PLUGGED_AC -> "Sạc nguồn AC"
                    BatteryManager.BATTERY_PLUGGED_USB -> "Cáp USB"
                    BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Sạc không dây"
                    else -> ""
                }
                batStatusText = when (status) {
                    BatteryManager.BATTERY_STATUS_CHARGING -> "⚡ Đang sạc ($plugType)"
                    BatteryManager.BATTERY_STATUS_FULL -> "✅ Đã sạc đầy 100%"
                    BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Không sạc"
                    else -> "Đang dùng pin"
                }
                val tempTenths = batteryIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
                if (tempTenths > 0) {
                    batTempText = String.format(Locale.US, "%.1f°C", tempTenths / 10.0f)
                }
                val voltage = batteryIntent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
                if (voltage > 0) {
                    batVoltText = "${voltage} mV"
                }
                batTechText = batteryIntent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Li-poly"
                val health = batteryIntent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_GOOD)
                batHealthText = when (health) {
                    BatteryManager.BATTERY_HEALTH_GOOD -> "Tốt (Good)"
                    BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Quá nhiệt!"
                    BatteryManager.BATTERY_HEALTH_DEAD -> "Chai pin"
                    BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Quá áp"
                    else -> "Bình thường"
                }

                // Đọc số chu kỳ sạc (Battery Cycle Count) tương tự DevCheck / Android 14+ BatteryManager
                var cycleCount = -1
                if (Build.VERSION.SDK_INT >= 34) { // Android 14+
                    cycleCount = batteryIntent.getIntExtra("android.os.extra.CYCLE_COUNT", -1)
                    if (cycleCount < 0) {
                        try {
                            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
                            if (bm != null) {
                                // 7 là hằng số BatteryManager.BATTERY_PROPERTY_CYCLE_COUNT giới thiệu từ API 34
                                cycleCount = bm.getIntProperty(7)
                            }
                        } catch (_: Throwable) {}
                    }
                }
                if (cycleCount > 0) {
                    batCycleCountText = "$cycleCount chu kỳ"
                }
            }
        } catch (_: Throwable) {}

        // Fallback: Đọc trực tiếp file sysfs 1 lần duy nhất (ghi nhớ nếu bị SELinux từ chối để không mở lặp gây nóng máy)
        if (batCycleCountText == "N/A") {
            val cachedCycle = cachedBatteryCycleCount
            if (cachedCycle != null) {
                batCycleCountText = cachedCycle
            } else if (!cachedCycleSysfsUnavailable) {
                var parsedCycle: Int? = null
                for (sysPath in listOf("/sys/class/power_supply/bk_battery/cycle_count", "/sys/class/power_supply/battery/cycle_count")) {
                    try {
                        val f = File(sysPath)
                        if (f.exists() && f.canRead()) {
                            val v = f.readText().trim().toIntOrNull()
                            if (v != null && v > 0) {
                                parsedCycle = v
                                break
                            }
                        }
                    } catch (_: Throwable) {}
                }
                val nowMs = SystemClock.elapsedRealtime()
                if (parsedCycle == null && shellEngine.state.value.isAdbReady && (nowMs - lastBatteryCycleShellCheckMs > 600_000L || lastBatteryCycleShellCheckMs == 0L)) {
                    lastBatteryCycleShellCheckMs = nowMs
                    try {
                        val cycleSysfs = runShell("cat /sys/class/power_supply/bk_battery/cycle_count 2>/dev/null || cat /sys/class/power_supply/battery/cycle_count 2>/dev/null", false).trim()
                        val v = cycleSysfs.lineSequence().firstOrNull()?.trim()?.toIntOrNull()
                        if (v != null && v > 0) {
                            parsedCycle = v
                        }
                    } catch (_: Throwable) {}
                }
                if (parsedCycle != null && parsedCycle > 0) {
                    val formatted = "$parsedCycle chu kỳ"
                    cachedBatteryCycleCount = formatted
                    batCycleCountText = formatted
                } else {
                    cachedCycleSysfsUnavailable = true
                }
            }
        }

        var screenText = "Unknown"
        var refreshText = "60Hz"
        try {
            val dm = context.resources.displayMetrics
            screenText = "${dm.widthPixels}x${dm.heightPixels} px (${dm.densityDpi} dpi)"
            val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
            val defaultDisplay = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)
            if (defaultDisplay != null) {
                val liveHz = kotlin.math.round(defaultDisplay.refreshRate).toInt().coerceAtLeast(60)
                val persistedHz = shellEngine.getPersistedSetting("system", "user_refresh_rate")?.toIntOrNull()
                val maxHz = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    defaultDisplay.supportedModes.maxOfOrNull { kotlin.math.round(it.refreshRate).toInt() } ?: liveHz
                } else liveHz
                val effectiveHz = when {
                    persistedHz != null && persistedHz in 60..maxHz -> persistedHz
                    else -> liveHz
                }
                refreshText = "${effectiveHz}Hz (Tối đa ${maxHz}Hz)"
            }
        } catch (_: Throwable) {}

        val sensorCount = specs.sensorCount

        val elapsedMillis = SystemClock.elapsedRealtime()
        val hours = elapsedMillis / (1000 * 60 * 60)
        val minutes = (elapsedMillis / (1000 * 60)) % 60
        val uptimeText = "${hours}h ${minutes}p"

        var maxChargingWattsText = "N/A"
        var timeToFullText = "N/A"
        try {
            val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            if (batteryIntent != null && bm != null) {
                val voltageMv = batteryIntent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
                val currentNowUa = try { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) } catch (_: Throwable) { 0 }
                if (voltageMv > 0 && currentNowUa > 0) {
                    val watts = (voltageMv.toDouble() / 1000.0) * (currentNowUa.toDouble() / 1_000_000.0)
                    if (watts > 0.5 && watts > sessionPeakChargingWatts) {
                        sessionPeakChargingWatts = watts
                    }
                }
                if (sessionPeakChargingWatts > 0.1) {
                    maxChargingWattsText = String.format(Locale.US, "%.1fW (Max)", sessionPeakChargingWatts)
                }

                if (Build.VERSION.SDK_INT >= 28) {
                    val timeRemainingMs = bm.computeChargeTimeRemaining()
                    if (timeRemainingMs > 0) {
                        val mins = timeRemainingMs / 60_000L
                        timeToFullText = "$mins phút đến đầy"
                    } else if (batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_CHARGING) {
                        timeToFullText = "Đang tính..."
                    } else {
                        timeToFullText = "Đã rút sạc / Sẵn sàng"
                    }
                }
            }
        } catch (_: Throwable) {}

        val features = readPhoneFeatureStates()
        val smartCapUnlocked = shellEngine.getPersistedSetting("system", "smart_battery_capacity_switch") == "0" ||
            shellEngine.getPersistedSetting("secure", "smart_battery_capacity_switch") == "0" ||
            shellEngine.getPersistedSetting("secure", "magictune_battery_cap_unlocked") == "1"
        val customLimitPct = shellEngine.getPersistedSetting("system", "custom_charge_limit")?.toIntOrNull()
            ?: shellEngine.getPersistedSetting("secure", "magictune_charge_limit_pct")?.toIntOrNull()
            ?: 97
        val batCapStatusText = if (smartCapUnlocked) {
            if (customLimitPct in 90..99) {
                "🔓 Mở khóa $customLimitPct% (Đệm an toàn ${100 - customLimitPct}%)"
            } else {
                "🔓 Đã mở 100% dung lượng thực"
            }
        } else {
            "🔒 Khóa thông minh Honor (~80-85%)"
        }

        val nextDeviceInfo = DeviceInfo(
            model = model,
            manufacturer = manufacturer,
            brand = brand,
            deviceCodename = deviceCodename,
            board = board,
            version = "Android $androidVer (API $sdkInt)",
            sdkInt = sdkInt,
            securityPatch = securityPatch,
            magicOS = displayId,
            kernel = kernelVer,
            soc = socName,
            cpuCores = cpuCoresText,
            cpuFreq = cpuFreqText,
            abi = abi,
            gpu = gpuName,
            ram = ramString,
            ramUsedPercent = ramPercent,
            storage = storageString,
            storageUsedPercent = storagePercent,
            batteryLevel = batLevel,
            batteryStatus = batStatusText,
            batteryVoltage = batVoltText,
            batteryTech = batTechText,
            batteryHealth = batHealthText,
            batteryCycleCount = batCycleCountText,
            batteryMaxChargingWatts = maxChargingWattsText,
            batteryTimeToFullMinutes = timeToFullText,
            batteryCapacityStatus = batCapStatusText,
            isSmartBatteryCapacityUnlocked = smartCapUnlocked,
            temp = batTempText,
            screen = screenText,
            refreshRate = refreshText,
            sensorCount = sensorCount,
            uptime = uptimeText,
            serial = when (shellEngine.state.value.mode) {
                ShellMode.SHIZUKU -> "SHIZUKU_UID_2000"
                ShellMode.WIRELESS_ADB -> "WLAN_127.0.0.1:${shellEngine.state.value.wirelessAdbPort}"
                ShellMode.ROOT -> "ROOT_SU_UID_0"
                else -> if (shellEngine.state.value.hasPersistentGrant) "PERSISTENT_FIX_ACTIVE" else "LOCAL_SHELL"
            },
            features = features
        )
        if (_deviceInfo.value != nextDeviceInfo) {
            _deviceInfo.value = nextDeviceInfo
        }
        lastDeviceInfoRefreshElapsedMs = SystemClock.elapsedRealtime()
        refreshTuneStatus()
        refreshFloatingPermissionsState()
        } catch (_: Throwable) {
        } finally {
            deviceInfoRefreshMutex.unlock()
        }
    }

    private fun readPhoneFeatureStates(): List<PhoneFeatureItem> {
        val cr = context.contentResolver
        val list = mutableListOf<PhoneFeatureItem>()

        // 1. Wi-Fi
        val wifiEnabled = try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            wm?.isWifiEnabled ?: (Settings.Global.getInt(cr, Settings.Global.WIFI_ON, 0) == 1)
        } catch (_: Throwable) {
            try { Settings.Global.getInt(cr, Settings.Global.WIFI_ON, 0) == 1 } catch (_: Throwable) { false }
        }
        list.add(
            PhoneFeatureItem(
                id = "wifi",
                name = "Wi-Fi",
                isEnabled = wifiEnabled,
                statusText = if (wifiEnabled) "ĐANG BẬT" else "ĐANG TẮT",
                detail = if (wifiEnabled) "Kết nối mạng không dây đang mở" else "Đã tắt kết nối Wi-Fi"
            )
        )

        // 2. Bluetooth
        val btEnabled = try {
            val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            val adapter = bm?.adapter
            adapter?.isEnabled ?: (Settings.Global.getInt(cr, Settings.Global.BLUETOOTH_ON, 0) == 1)
        } catch (_: Throwable) {
            try { Settings.Global.getInt(cr, Settings.Global.BLUETOOTH_ON, 0) == 1 } catch (_: Throwable) { false }
        }
        list.add(
            PhoneFeatureItem(
                id = "bluetooth",
                name = "Bluetooth",
                isEnabled = btEnabled,
                statusText = if (btEnabled) "ĐANG BẬT" else "ĐANG TẮT",
                detail = if (btEnabled) "Sẵn sàng kết nối tai nghe / phụ kiện" else "Bluetooth đang tắt"
            )
        )

        // 3. Mạng Di Động (Mobile Data 4G/5G)
        val mobileDataEnabled = try {
            val setting = Settings.Global.getInt(cr, "mobile_data", -1)
            if (setting != -1) {
                setting == 1
            } else {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                val net = cm?.activeNetwork
                val caps = cm?.getNetworkCapabilities(net)
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
            }
        } catch (_: Throwable) { false }
        list.add(
            PhoneFeatureItem(
                id = "mobile_data",
                name = "Dữ Liệu Di Động (4G/5G)",
                isEnabled = mobileDataEnabled,
                statusText = if (mobileDataEnabled) "ĐANG BẬT" else "ĐANG TẮT",
                detail = if (mobileDataEnabled) "Dữ liệu SIM đang bật" else "Dữ liệu SIM đang tắt"
            )
        )

        // 4. Định vị GPS (Location) - Ưu tiên đọc trạng thái phần cứng thực tế từ LocationManager / Settings.Secure
        val gpsEnabled = try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && lm != null) {
                lm.isLocationEnabled
            } else {
                @Suppress("DEPRECATION")
                Settings.Secure.getInt(cr, Settings.Secure.LOCATION_MODE, 0) != 0
            }
        } catch (_: Throwable) {
            shellEngine.getPersistedSetting("secure", "location_mode")?.let { it != "0" } ?: false
        }
        list.add(
            PhoneFeatureItem(
                id = "gps",
                name = "Định Vị GPS",
                isEnabled = gpsEnabled,
                statusText = if (gpsEnabled) "ĐANG BẬT" else "ĐANG TẮT",
                detail = if (gpsEnabled) "Định vị bản đồ đang hoạt động" else "Đã tắt vị trí GPS"
            )
        )

        // 5. NFC
        val nfcAdapter = try { NfcAdapter.getDefaultAdapter(context) } catch (_: Throwable) { null }
        val nfcEnabled = try { nfcAdapter?.isEnabled == true } catch (_: Throwable) { false }
        val nfcStatus = when {
            nfcAdapter == null -> "KHÔNG HỖ TRỢ"
            nfcEnabled -> "ĐANG BẬT"
            else -> "ĐANG TẮT"
        }
        list.add(
            PhoneFeatureItem(
                id = "nfc",
                name = "NFC (Chạm Thanh Toán / CCCD)",
                isEnabled = nfcEnabled,
                statusText = nfcStatus,
                detail = if (nfcAdapter == null) "Máy không có chip NFC" else if (nfcEnabled) "Quét CCCD / Google Pay sẵn sàng" else "NFC đang tắt"
            )
        )

        // 6. Xoay màn hình tự động
        val autoRotate = try {
            Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
        } catch (_: Throwable) { false }
        list.add(
            PhoneFeatureItem(
                id = "auto_rotate",
                name = "Tự Động Xoay Màn Hình",
                isEnabled = autoRotate,
                statusText = if (autoRotate) "ĐANG BẬT" else "ĐANG TẮT (Khóa xoay)",
                detail = if (autoRotate) "Tự xoay theo cảm biến góc nghiêng" else "Đang khóa xoay dọc"
            )
        )

        // 7. Chế độ tối (Dark Mode) - Đọc trực tiếp từ Configuration / Settings.Secure thực tế trên máy
        val darkMode = try {
            val mask = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
            if (mask == Configuration.UI_MODE_NIGHT_YES) {
                true
            } else {
                val nightSetting = Settings.Secure.getInt(cr, "ui_night_mode", -1)
                if (nightSetting != -1) nightSetting == 2 else false
            }
        } catch (_: Throwable) { false }
        list.add(
            PhoneFeatureItem(
                id = "dark_mode",
                name = "Giao Diện Tối (Dark Mode)",
                isEnabled = darkMode,
                statusText = if (darkMode) "ĐANG BẬT" else "ĐANG TẮT (Nền sáng)",
                detail = if (darkMode) "Đang bật chế độ nền tối OLED" else "Đang dùng giao diện sáng"
            )
        )

        // 8. Chặn Quảng Cáo DNS (AdBlocker Pro)
        val dnsMode = shellEngine.getPersistedSetting("global", "private_dns_mode")
            ?: try { Settings.Global.getString(cr, "private_dns_mode") } catch (_: Throwable) { null }
        val dnsHost = shellEngine.getPersistedSetting("global", "private_dns_specifier")
            ?: try { Settings.Global.getString(cr, "private_dns_specifier") } catch (_: Throwable) { null }
        val adBlockActive = dnsMode == "hostname" && !dnsHost.isNullOrBlank()
        list.add(
            PhoneFeatureItem(
                id = "adblocker_dns",
                name = "Chặn Quảng Cáo (Private DNS)",
                isEnabled = adBlockActive,
                statusText = if (adBlockActive) "ĐANG BẬT" else "ĐANG TẮT",
                detail = if (adBlockActive) "DNS: $dnsHost" else "Chưa bật lọc quảng cáo DNS"
            )
        )

        // 9. Công tắc nhấn thanh điều hướng đánh thức YOYO
        val yoyoDisabled = shellEngine.getPersistedSetting("secure", "navigation_bar_wakeup_yoyo") == "0" ||
            shellEngine.getPersistedSetting("secure", "yoyo_navigation_bar_wakeup") == "0" ||
            shellEngine.isPackageMarkedDisabled("com.hihonor.assistant")
        list.add(
            PhoneFeatureItem(
                id = "yoyo_nav_wake",
                name = "Chặn Đánh Thức YOYO Thanh Điều Hướng",
                isEnabled = yoyoDisabled,
                statusText = if (yoyoDisabled) "ĐÃ TẮT GỌI YOYO" else "CHƯA TẮT",
                detail = if (yoyoDisabled) "Nhấn giữ thanh điều hướng không còn bật YOYO" else "Nhấn giữ thanh điều hướng có thể gọi YOYO"
            )
        )

        // 10. Chặn Chợ App Honor Tự Cập Nhật (Giữ nguyên Cập nhật MagicOS OUC/HOTA)
        val updateBlocked = shellEngine.getPersistedSetting("global", "auto_update_app") == "0"
        list.add(
            PhoneFeatureItem(
                id = "block_update",
                name = "Chặn Chợ App Honor Tự Cập Nhật",
                isEnabled = updateBlocked,
                statusText = if (updateBlocked) "ĐÃ CHẶN CHỢ HONOR" else "CHƯA CHẶN",
                detail = if (updateBlocked) "Chỉ chặn Chợ Honor cài đè app Trung (Trang Cập nhật MagicOS vẫn mở 100%)" else "Chợ Honor có thể tự cập nhật đè app"
            )
        )

        // 11. Đồng bộ Tự động (Auto-Sync)
        val autoSync = try { ContentResolver.getMasterSyncAutomatically() } catch (_: Throwable) { true }
        list.add(
            PhoneFeatureItem(
                id = "auto_sync",
                name = "Đồng Bộ Tài Khoản (Auto-Sync)",
                isEnabled = autoSync,
                statusText = if (autoSync) "ĐANG BẬT" else "ĐANG TẮT",
                detail = if (autoSync) "Gmail & Danh bạ tự động đồng bộ" else "Tự động đồng bộ đang tắt"
            )
        )

        // 12. Gỡ lỗi USB / Gỡ lỗi Wi-Fi (ADB)
        val devOn = try { Settings.Global.getInt(cr, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1 } catch (_: Exception) { false }
        val usbAdb = devOn && try { Settings.Global.getInt(cr, Settings.Global.ADB_ENABLED, 0) == 1 } catch (_: Exception) { false }
        val wifiAdb = devOn && (try { Settings.Global.getInt(cr, "adb_wifi_enabled", 0) == 1 } catch (_: Exception) { false } ||
            shellEngine.state.value.isWirelessAdbConnected)
        val anyAdb = usbAdb || wifiAdb || shellEngine.state.value.isAdbReady
        list.add(
            PhoneFeatureItem(
                id = "adb_debug",
                name = "Trạng Thái Gỡ Lỗi & Duy Trì Fix",
                isEnabled = anyAdb,
                statusText = when {
                    shellEngine.state.value.isWirelessAdbConnected -> "WLAN: ĐANG KẾT NỐI"
                    shellEngine.state.value.isShizukuRunning && shellEngine.state.value.isShizukuPermissionGranted -> "SHIZUKU: ĐANG KẾT NỐI"
                    shellEngine.state.value.hasPersistentGrant -> "GIỮ FIX KHI TẮT WLAN"
                    else -> "CHƯA KẾT NỐI"
                },
                detail = when {
                    shellEngine.state.value.isShizukuRunning && shellEngine.state.value.isShizukuPermissionGranted -> "Shizuku UID 2000 đang hoạt động"
                    shellEngine.state.value.isWirelessAdbConnected -> "Gỡ lỗi qua WLAN cổng ${shellEngine.state.value.wirelessAdbPort} đang kết nối"
                    shellEngine.state.value.hasPersistentGrant -> "Đã ngắt WLAN nhưng giữ nguyên 100% các mục đã Fix"
                    else -> "Bấm nút WLAN trên thanh tiêu đề để kết nối"
                }
            )
        )

        return list
    }

    fun refreshTuneStatus() {
        val cr = context.contentResolver
        val dnsMode = shellEngine.getPersistedSetting("global", "private_dns_mode")
            ?: try { Settings.Global.getString(cr, "private_dns_mode") } catch (_: Exception) { null }
        val dnsHost = shellEngine.getPersistedSetting("global", "private_dns_specifier")
            ?: try { Settings.Global.getString(cr, "private_dns_specifier") } catch (_: Exception) { null }
        val adBlockEnabled = dnsMode == "hostname" && !dnsHost.isNullOrBlank()

        val yoyoDisabled = shellEngine.getPersistedSetting("secure", "navigation_bar_wakeup_yoyo") == "0" ||
            shellEngine.getPersistedSetting("secure", "yoyo_navigation_bar_wakeup") == "0" ||
            shellEngine.isPackageMarkedDisabled("com.hihonor.assistant")
        val navHidden = shellEngine.getPersistedSetting("secure", "hide_navigation_bar") == "1"
        val updateBlocked = shellEngine.getPersistedSetting("global", "auto_update_app") == "0"
        val audioFixed = shellEngine.getPersistedSetting("global", "bluetooth_absolute_volume") == "0"
        val screenshotUnlocked = shellEngine.getPersistedSetting("global", "block_screen_capture") == "0"
        val androidAutoFixed = shellEngine.getPersistedSetting("secure", "gearhead_fixed") == "1" ||
            shellEngine.isAppWhitelistedOrFixed("com.google.android.projection.gearhead")
        val googleAssistantWake = shellEngine.getPersistedSetting("secure", "google_assistant_wake") == "1" ||
            (shellEngine.getPersistedSetting("secure", "assistant")?.contains("google") == true &&
             shellEngine.getPersistedSetting("secure", "assist_long_press_home_enabled") == "1")
        val honorSearchDisabled = shellEngine.isPackageMarkedDisabled("com.hihonor.search") ||
            shellEngine.getPersistedSetting("secure", "honor_search_disabled") == "1"
        val fontBold = shellEngine.getPersistedSetting("system", "font_scale") == "1.15"
        val darkOled = shellEngine.getPersistedSetting("secure", "ui_night_mode") == "2"
        val kvPrefs = context.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
        val configuredHz = kvPrefs.getInt("magictune_configured_refresh_rate", 0)
        val peakHz = shellEngine.getPersistedSetting("system", "peak_refresh_rate")?.toFloatOrNull()?.toInt() ?: 0
        val userHz = shellEngine.getPersistedSetting("system", "user_refresh_rate")?.toIntOrNull() ?: 0
        val honorHz = shellEngine.getPersistedSetting("system", "honor_screen_refresh_rate")?.toIntOrNull() ?: 0
        val hz = when {
            configuredHz in 60..144 -> configuredHz
            peakHz in 60..144 -> peakHz
            honorHz in 60..144 -> honorHz
            userHz in 60..144 -> userHz
            else -> 120
        }
        val anim = shellEngine.getPersistedSetting("global", "window_animation_scale")?.toFloatOrNull() ?: 1.0f

        val navModMode = shellEngine.getPersistedSetting("secure", "magictune_nav_mod_mode") ?: "CIRCLE_TO_SEARCH"
        val circleToSearch = navModMode == "CIRCLE_TO_SEARCH" || navModMode == "MAGIC_LIVE" ||
            shellEngine.getPersistedSetting("secure", "contextual_search_enabled") == "1"
        val magic_liveVoice = navModMode == "MAGIC_LIVE" ||
            (googleAssistantWake && !circleToSearch && navModMode != "DEFAULT" && navModMode != "DISABLED")

        val devStealth = shellEngine.getPersistedSetting("global", "magictune_dev_stealth") == "1" ||
            (shellEngine.getPersistedSetting("global", "development_settings_enabled") == "0" && shellEngine.state.value.isAdbReady)
        val restrictedUnlocked = shellEngine.getPersistedSetting("secure", "magictune_restricted_storage_unlocked") == "1"
        val dataCount = shellEngine.getPersistedSetting("secure", "magictune_data_folders_count")?.toIntOrNull() ?: 0
        val obbCount = shellEngine.getPersistedSetting("secure", "magictune_obb_folders_count")?.toIntOrNull() ?: 0
        val storageSummary = shellEngine.getPersistedSetting("secure", "magictune_restricted_storage_summary")
            ?: if (restrictedUnlocked) "Đã mở khóa truy cập trực tiếp Android/data ($dataCount app) & Android/obb ($obbCount gói)"
            else "Sẵn sàng mở khóa & đọc/ghi/giải nén trực tiếp Android/data & Android/obb"
        val camBlocked = shellEngine.getPersistedSetting("secure", "magictune_cam_blocked") == "1"
        val micBlocked = shellEngine.getPersistedSetting("secure", "magictune_mic_blocked") == "1"
        val locBlocked = shellEngine.getPersistedSetting("secure", "magictune_loc_blocked") == "1"
        val clipProtected = shellEngine.getPersistedSetting("secure", "magictune_clip_protected") == "1"
        val gestureEnhanced = shellEngine.getPersistedSetting("secure", "gesture_nav_sensitivity") == "2" ||
            shellEngine.getPersistedSetting("secure", "touch_response_time") == "0"
        val fingerprintBoosted = shellEngine.getPersistedSetting("secure", "screen_protector_mode") == "1" ||
            shellEngine.getPersistedSetting("system", "touch_screen_film_switch") == "1" ||
            shellEngine.getPersistedSetting("system", "glove_file_status") == "1" ||
            shellEngine.getPersistedSetting("secure", "high_touch_sensitivity_enable") == "1"
        val wifiSpeedBoosted = shellEngine.getPersistedSetting("global", "wifi_scan_always_enabled") == "0" &&
            shellEngine.getPersistedSetting("global", "wifi_scan_throttle_enabled") == "1"
        val dualWifiBoosted = shellEngine.getPersistedSetting("system", "dual_wifi_state") == "1" ||
            shellEngine.getPersistedSetting("system", "link_turbo_enable") == "1" ||
            shellEngine.getPersistedSetting("global", "wifi_boost_enable") == "1"
        val alwaysOnBatterySaved = shellEngine.getPersistedSetting("global", "mobile_data_always_on") == "0" &&
            shellEngine.getPersistedSetting("global", "ble_scan_always_enabled") == "0"
        val vcCoolingActive = com.example.core.perf.SafeThermalRelief.isEnabled(context)
        val magicosSmoothnessActive = shellEngine.getPersistedSetting("secure", "touch_response_time") == "0" &&
            shellEngine.getPersistedSetting("global", "window_animation_scale") == "0.5" &&
            shellEngine.getPersistedSetting("secure", "gesture_nav_sensitivity") == "2"
        val magicosBatteryEngineActive = shellEngine.getPersistedSetting("global", "device_idle_constants")?.contains("quick_doze_delay_to=5000") == true ||
            (shellEngine.getPersistedSetting("global", "mobile_data_always_on") == "0" &&
             shellEngine.getPersistedSetting("secure", "ui_night_mode") == "2" &&
             shellEngine.getPersistedSetting("global", "app_standby_enabled") == "1")
        val activeMacro = shellEngine.getPersistedSetting("secure", "magictune_active_macro") ?: "Mặc định"

        val isSuplGoogle = shellEngine.getPersistedSetting("global", "supl_host")?.contains("google") == true
        val isHonorGpsFixedPersisted = shellEngine.getPersistedSetting("secure", "honor_gps_fixed") == "1"
        val isAmapDisabled = shellEngine.isPackageMarkedDisabled("com.hihonor.amap") || shellEngine.isPackageMarkedDisabled("com.amap.android.ams")
        val gpsFixed = isSuplGoogle || isHonorGpsFixedPersisted || isAmapDisabled
        val smartCapUnlocked = shellEngine.getPersistedSetting("system", "smart_battery_capacity_switch") == "0" ||
            shellEngine.getPersistedSetting("secure", "smart_battery_capacity_switch") == "0" ||
            shellEngine.getPersistedSetting("secure", "magictune_battery_cap_unlocked") == "1"
        val chargeLimitPct = shellEngine.getPersistedSetting("system", "custom_charge_limit")?.toIntOrNull()
            ?: shellEngine.getPersistedSetting("secure", "magictune_charge_limit_pct")?.toIntOrNull()
            ?: 97

        val refreshLocked = kvPrefs.getBoolean("magictune_refresh_lock_active", false)
        val lockedHzVal = kvPrefs.getInt("magictune_locked_refresh_rate", 120)
        val resLocked = kvPrefs.getBoolean("magictune_resolution_lock_active", false)
        val rawResMode = kvPrefs.getString("magictune_resolution_lock_mode", "MAX_NATIVE") ?: "MAX_NATIVE"
        val lockedResMode = if (rawResMode == "HD") "MAX_NATIVE" else rawResMode

        _tuneStatus.value = TuneStatus(
            isAdBlockerEnabled = adBlockEnabled,
            activeDnsHost = if (adBlockEnabled) (dnsHost ?: "dns.adguard-dns.com") else "Tự động (Chưa bật chặn QC)",
            isYoyoWakeDisabled = yoyoDisabled,
            isNavBarHidden = navHidden,
            isAppMarketUpdateBlocked = updateBlocked,
            isAudio48kFixed = audioFixed,
            isScreenshotUnlocked = screenshotUnlocked,
            isFontBoldLarge = fontBold,
            isDarkModeOled = darkOled,
            isAndroidAutoFixed = androidAutoFixed,
            isGoogleAssistantWakeEnabled = googleAssistantWake || circleToSearch || magic_liveVoice,
            isCircleToSearchEnabled = circleToSearch,
            isMagicLiveEnabled = magic_liveVoice,
            activeNavModMode = navModMode,
            currentRefreshRate = hz,
            currentAnimationScale = anim,
            isHonorSearchDisabled = honorSearchDisabled,
            isDevModeStealthActive = devStealth,
            isRestrictedStorageUnlocked = restrictedUnlocked,
            restrictedDataFoldersCount = dataCount,
            restrictedObbFoldersCount = obbCount,
            restrictedStorageSummary = storageSummary,
            isCameraPrivacyBlocked = camBlocked,
            isMicPrivacyBlocked = micBlocked,
            isLocationPrivacyBlocked = locBlocked,
            isClipboardPrivacyActive = clipProtected,
            isGestureSensitivityEnhanced = gestureEnhanced,
            isFingerprintBoosted = fingerprintBoosted,
            isWifiSpeedBoosted = wifiSpeedBoosted,
            isDualWifiBoosted = dualWifiBoosted,
            isAlwaysOnNetworkBatterySaved = alwaysOnBatterySaved,
            isVcCoolingActive = vcCoolingActive,
            isIosFluidSmoothnessActive = magicosSmoothnessActive,
            isIosBatteryEngineActive = magicosBatteryEngineActive,
            isSmartBatteryCapacityUnlocked = smartCapUnlocked,
            honorBatteryChargeLimitPercent = chargeLimitPct,
            activeAutomationMacro = activeMacro,
            isGoogleAppInstalled = true,
            isMagicLiveAppInstalled = true,
            isOverlayPermissionGranted = true,
            isHonorGpsFixed = gpsFixed,
            isRefreshRateLocked = refreshLocked,
            lockedRefreshRate = lockedHzVal,
            isResolutionLocked = resLocked,
            lockedResolutionMode = lockedResMode
        )
    }

    fun refreshFloatingPermissionsState() {
        val current = _floatingWindowState.value
        _floatingWindowState.value = current.copy(
            hasOverlayPermission = shellEngine.hasOverlayPermission(),
            hasControlPermission = shellEngine.hasControlPermission()
        )
    }

    private fun readCpuHardwareName(): String? {
        return try {
            val file = File("/proc/cpuinfo")
            if (!file.exists()) return null
            file.useLines { lines ->
                for (line in lines) {
                    if (line.startsWith("Hardware", ignoreCase = true) ||
                        line.startsWith("model name", ignoreCase = true)
                    ) {
                        val parts = line.split(":")
                        if (parts.size >= 2) {
                            return@useLines parts[1].trim()
                        }
                    }
                }
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun readMaxCpuFreqGhz(): String {
        return try {
            val cores = Runtime.getRuntime().availableProcessors()
            var maxKhz = 0L
            for (i in 0 until cores) {
                val f = File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq")
                if (f.exists()) {
                    val khz = f.readText().trim().toLongOrNull() ?: 0L
                    if (khz > maxKhz) maxKhz = khz
                }
            }
            if (maxKhz > 0) {
                String.format(Locale.US, "%.2f GHz", maxKhz / 1_000_000.0)
            } else ""
        } catch (_: Exception) {
            ""
        }
    }

    suspend fun refreshSetupStatus() = withContext(Dispatchers.IO) {
        val cr = context.contentResolver
        val pm = context.packageManager

        val requiredSettings = listOf(
            "system" to "system_locales",
            "system" to "time_12_24",
            "secure" to "google_service_switch",
            "system" to "min_match",
            "global" to "captive_portal_https_url",
            "system" to "hw_volte_user_switch",
            "system" to "use_default_notification_sound",
            "global" to "auto_update_app",
            "secure" to "navigation_bar_wakeup_yoyo",
            "secure" to "location_mode",
            "secure" to "hiboard_switch",
            "system" to "iaware_switch",
            "secure" to "yoyo_navigation_bar_wakeup",
            "global" to "supl_host"
        )

        val resolvedMap = HashMap<String, String>()
        val missingForShell = mutableListOf<Pair<String, String>>()

        for ((ns, key) in requiredSettings) {
            val mapKey = "$ns:$key"
            val fromCr = try {
                when (ns) {
                    "system" -> Settings.System.getString(cr, key)
                    "secure" -> Settings.Secure.getString(cr, key)
                    "global" -> Settings.Global.getString(cr, key)
                    else -> null
                }
            } catch (_: Exception) { null }

            if (!fromCr.isNullOrBlank() && fromCr != "null") {
                resolvedMap[mapKey] = fromCr.trim()
            } else {
                val persisted = shellEngine.getPersistedSetting(ns, key)?.takeIf { it.isNotBlank() && it != "null" }
                if (persisted != null) {
                    resolvedMap[mapKey] = persisted.trim()
                } else {
                    missingForShell.add(ns to key)
                }
            }
        }

        if (missingForShell.isNotEmpty() && shellEngine.state.value.isAdbReady) {
            val batchCmd = missingForShell.joinToString("; ") { (ns, key) ->
                "echo -n '__MT_${ns}_${key}='; settings get $ns $key 2>/dev/null"
            }
            val batchOut = runShell(batchCmd, false)
            for (line in batchOut.lineSequence()) {
                val trimmed = line.trim()
                if (trimmed.startsWith("__MT_") && trimmed.contains("=")) {
                    val rawKey = trimmed.substringAfter("__MT_").substringBefore("=")
                    val value = trimmed.substringAfter("=").trim()
                    val ns = rawKey.substringBefore("_")
                    val key = rawKey.substringAfter("_")
                    if (value.isNotBlank() && value != "null") {
                        resolvedMap["$ns:$key"] = value
                    }
                }
            }
        }

        fun readSettingFast(namespace: String, key: String): String {
            return resolvedMap["$namespace:$key"] ?: ""
        }

        fun isPkgInstalledFast(pkg: String): Boolean {
            if (shellEngine.isPackageMarkedUninstalled(pkg)) return false
            return try {
                pm.getPackageInfo(pkg, 0)
                true
            } catch (_: Exception) {
                false
            }
        }

        fun isPkgEnabledFast(pkg: String): Boolean {
            if (shellEngine.isPackageMarkedDisabled(pkg)) return false
            return try {
                pm.getApplicationInfo(pkg, 0).enabled
            } catch (_: Exception) {
                false
            }
        }

        val locale = readSettingFast("system", "system_locales")
        val tz = java.util.TimeZone.getDefault().id.ifBlank { readSysPropFast("persist.sys.timezone", "Asia/Ho_Chi_Minh") }
        val time24 = readSettingFast("system", "time_12_24")
        val gms = readSettingFast("secure", "google_service_switch")
        val minMatch = readSettingFast("system", "min_match")
        val captiveUrl = readSettingFast("global", "captive_portal_https_url")
        val volte = readSettingFast("system", "hw_volte_user_switch")
        val useDefaultSound = readSettingFast("system", "use_default_notification_sound")
        val autoUpdate = readSettingFast("global", "auto_update_app")
        val yoyoWake = readSettingFast("secure", "navigation_bar_wakeup_yoyo")

        val isViLocale = locale.contains("vi", ignoreCase = true) || Locale.getDefault().language == "vi"
        val isViTz = tz.contains("Ho_Chi_Minh", ignoreCase = true) ||
            tz.contains("Saigon", ignoreCase = true)
        val hasGms = isPkgEnabledFast("com.google.android.gms") &&
            (gms.isBlank() || gms == "1")
        val hasPlay = isPkgEnabledFast("com.android.vending")
        val hasLaban = isPkgInstalledFast("com.vng.inputmethod.labankey")
        val hasGboard = isPkgInstalledFast("com.google.android.inputmethod.latin")
        val enabledInputMethods = try {
            Settings.Secure.getString(cr, Settings.Secure.ENABLED_INPUT_METHODS).orEmpty()
        } catch (_: Exception) { "" }
        val defaultInputMethod = try {
            Settings.Secure.getString(cr, Settings.Secure.DEFAULT_INPUT_METHOD).orEmpty()
        } catch (_: Exception) { "" }
        val labanEnabled = enabledInputMethods.contains("com.vng.inputmethod.labankey")
        val gboardEnabled = enabledInputMethods.contains("com.google.android.inputmethod.latin")
        val vietnameseKeyboardDefault =
            (defaultInputMethod.contains("com.vng.inputmethod.labankey") && labanEnabled) ||
                (defaultInputMethod.contains("com.google.android.inputmethod.latin") && gboardEnabled)
        val callerIdOk = minMatch == "7"
        val captiveOk = captiveUrl.contains("gstatic") || captiveUrl.contains("google")
        val volteOk = volte == "1"
        val suplSetting = readSettingFast("global", "supl_host")
            .ifBlank { shellEngine.getPersistedSetting("global", "supl_host") ?: "" }
        val locModeSetting = readSettingFast("secure", "location_mode")
            .ifBlank { shellEngine.getPersistedSetting("secure", "location_mode") ?: "" }
        val locManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        // LocationManager.isLocationEnabled chỉ có từ API 28 (Android 9) — fallback qua providers cho Android 7/8
        val isLocEnabled = (isLocationEnabledCompat(locManager)) ||
            locModeSetting in listOf("1", "2", "3") ||
            shellEngine.getPersistedSetting("secure", "location_mode") in listOf("1", "2", "3")
        val isSuplGoogle = suplSetting == "supl.google.com" || suplSetting.contains("google") ||
            shellEngine.getPersistedSetting("global", "supl_host")?.contains("google") == true
        val isHonorGpsFixedPersisted = shellEngine.getPersistedSetting("secure", "honor_gps_fixed") == "1"
        val isAmapDisabled = shellEngine.isPackageMarkedDisabled("com.amap.android.ams")
        val gpsOk = (isSuplGoogle || isHonorGpsFixedPersisted || isAmapDisabled) && isLocEnabled
        val noChinaFeeds = readSettingFast("secure", "hiboard_switch") == "0" ||
            shellEngine.isPackageMarkedDisabled("com.hihonor.hiboard")
        val noAutoUpdate = autoUpdate == "0"
        val noPowerGenius = shellEngine.getPersistedSetting("secure", "magictune_system_harmony_registered") == "1" ||
            shellEngine.getPersistedSetting("secure", "magictune_wlan_activated_forever") == "1" ||
            shellEngine.isAppPermissionGranted(context.packageName) ||
            shellEngine.isPackageMarkedDisabled("com.hihonor.powergenius")
        val customSound = useDefaultSound == "0"
        val yoyoWakeOff = yoyoWake == "0" ||
            readSettingFast("secure", "yoyo_navigation_bar_wakeup") == "0"

        var score = 0
        if (isViLocale && isViTz && (time24 == "24" || android.text.format.DateFormat.is24HourFormat(context))) score++
        if (hasGms && hasPlay) score++
        if (vietnameseKeyboardDefault) score++
        if (callerIdOk && captiveOk) score++
        if (noChinaFeeds) score++
        if (noAutoUpdate) score++
        if (noPowerGenius) score++
        if (customSound) score++
        if (gpsOk) score++

        _setupStatus.value = NewDeviceSetupStatus(
            isVietnameseLocale = isViLocale,
            currentLocale = if (locale.isNotBlank() && locale != "null") locale else Locale.getDefault().toLanguageTag(),
            isVietnamTimezone = isViTz,
            currentTimezone = if (tz.isNotBlank() && tz != "null") tz else "Không xác định",
            is24HourFormat = time24 == "24" || android.text.format.DateFormat.is24HourFormat(context),
            gmsEnabled = hasGms,
            playStoreInstalled = hasPlay,
            labanKeyInstalled = hasLaban,
            gboardInstalled = hasGboard,
            labanKeyEnabled = labanEnabled,
            gboardEnabled = gboardEnabled,
            vietnameseKeyboardDefault = vietnameseKeyboardDefault,
            callerId84Fixed = callerIdOk,
            captivePortalGlobal = captiveOk,
            volte5gUnlocked = volteOk,
            chineseUiCleaned = noChinaFeeds,
            honorMarketUpdateBlocked = noAutoUpdate,
            powerGeniusRemoved = noPowerGenius,
            customAppSoundsEnabled = customSound,
            yoyoNavWakeDisabled = yoyoWakeOff,
            gpsOptimized = gpsOk,
            readyScore = score
        )
        refreshTuneStatus()
    }

    suspend fun refreshShizukuInfo() = withContext(Dispatchers.IO) {
        val installed = shellEngine.isShizukuInstalled()
        val running = shellEngine.state.value.isShizukuRunning
        val granted = shellEngine.state.value.isShizukuPermissionGranted
        val isReady = shellEngine.state.value.isAdbReady

        var phantomMax = shellEngine.getPersistedSetting("global", "max_phantom_processes") ?: ""
        var chargingOnly = try {
            Settings.Global.getString(context.contentResolver, "adb_charging_only") ?: ""
        } catch (_: Exception) { "" }

        if (isReady && (phantomMax.isBlank() || chargingOnly.isBlank())) {
            val combined = runShell(
                "device_config get activity_manager max_phantom_processes 2>/dev/null; echo '---MT_SEP---'; settings get global adb_charging_only 2>/dev/null",
                false
            )
            val parts = combined.split("---MT_SEP---")
            if (parts.isNotEmpty() && phantomMax.isBlank()) {
                phantomMax = parts[0].trim()
            }
            if (parts.size >= 2 && chargingOnly.isBlank()) {
                chargingOnly = parts[1].trim()
            }
        }

        val adbWifiOn = shellEngine.state.value.isAdbWifiEnabled
        val dynamicVer = if (running) {
            try {
                val v = rikka.shizuku.Shizuku.getVersion()
                "API v$v"
            } catch (_: Exception) {
                "13.5+"
            }
        } else "13.5+"

        _shizukuInfo.value = ShizukuInfo(
            isInstalled = installed,
            isRunning = running,
            isPermissionGranted = granted,
            isAdbWifiEnabled = adbWifiOn,
            isShizukuSeveredFromAdb = false,
            version = dynamicVer,
            serverPid = if (running && granted) "UID 2000" else if (running) "Chờ cấp quyền" else if (shellEngine.state.value.isWirelessAdbConnected) "WLAN ADB" else "Chưa chạy",
            phantomKillerDisabled = phantomMax == "2147483647",
            usbChargingOnlyEnabled = chargingOnly == "1"
        )
    }

    /**
     * Loads BOTH User-Installed Apps (Ứng dụng người dùng) AND System/Honor Debloat Apps
     * so the user can view, manage, uninstall, freeze, or grant full permissions to User Apps as well as System Apps.
     * Protects critical ROM packages while classifying removable system apps into Levels 1, 2, and 3.
     */
    @Volatile
    private var lastAppsRefreshMs: Long = 0L

    private fun parsePackageLinesToSet(raw: String): HashSet<String> {
        if (raw.isBlank()) return HashSet()
        val set = HashSet<String>(128)
        for (line in raw.lineSequence()) {
            val cleaned = line.removePrefix("package:").trim()
            if (cleaned.isNotEmpty() && cleaned != context.packageName) {
                set.add(cleaned)
            }
        }
        return set
    }

    suspend fun refreshAppsList(force: Boolean = false) = withContext(Dispatchers.IO) {
        val nowMs = SystemClock.elapsedRealtime()
        if (!force && _appsList.value.isNotEmpty() && (nowMs - lastAppsRefreshMs) < 60_000L) {
            return@withContext
        }
        lastAppsRefreshMs = nowMs

        val isAdb = shellEngine.state.value.isAdbReady
        var thirdPartySet: HashSet<String> = HashSet()
        var disabledSet: HashSet<String> = HashSet()
        var systemSet: HashSet<String> = HashSet()

        if (isAdb) {
            val batchedPm = runShell(
                "pm list packages -3 --user 0 2>/dev/null; echo '---MT_DIS---'; pm list packages -d --user 0 2>/dev/null; echo '---MT_SYS---'; pm list packages -s --user 0 2>/dev/null",
                false
            )
            val s1 = batchedPm.split("---MT_DIS---")
            thirdPartySet = parsePackageLinesToSet(s1.getOrNull(0).orEmpty())
            val s2 = s1.getOrNull(1).orEmpty().split("---MT_SYS---")
            disabledSet = parsePackageLinesToSet(s2.getOrNull(0).orEmpty())
            systemSet = parsePackageLinesToSet(s2.getOrNull(1).orEmpty())
        }

        val combinedMap = LinkedHashMap<String, DebloatApp>()
        val installedStatus = HashMap<String, Boolean>(256)
        val pm = context.packageManager

        // 1. NẠP APP NGƯỜI DÙNG: Quét trực tiếp PackageManager (hoạt động 100% không phụ thuộc ADB)
        try {
            val installedApps = try {
                pm.getInstalledApplications(0)
            } catch (_: Throwable) {
                try {
                    pm.getInstalledPackages(0).mapNotNull { it.applicationInfo }
                } catch (_: Throwable) {
                    emptyList()
                }
            }

            for (appInfo in installedApps) {
                val pkg = appInfo.packageName ?: continue
                installedStatus[pkg] = appInfo.enabled
                if (pkg == context.packageName) continue

                val isSys = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0

                val isUser = if (isAdb && thirdPartySet.isNotEmpty()) {
                    !isSys || thirdPartySet.contains(pkg)
                } else {
                    !isSys
                }

                val label = getCachedAppLabel(pm, appInfo)

                val isDis = !appInfo.enabled || (isAdb && (disabledSet.contains(pkg) || shellEngine.isPackageMarkedDisabled(pkg)))
                val isUninstalled = isAdb && shellEngine.isPackageMarkedUninstalled(pkg)

                if (isUser) {
                    val catalogEntry = commonUserAppsMap[pkg]
                    val isNotifOk = shellEngine.isAppWhitelistedOrFixed(pkg) || shellEngine.isAppActuallyNotificationEnabled(pkg)
                    val isPermOk = shellEngine.isAppPermissionGranted(pkg) || shellEngine.isAppActuallyBackgroundWhitelisted(pkg)

                    combinedMap[pkg] = DebloatApp(
                        packageName = pkg,
                        name = catalogEntry?.first ?: label,
                        desc = catalogEntry?.second ?: "Ứng dụng người dùng cài đặt • Có thể Gỡ cài đặt hoặc Cấp full quyền & Biểu ngữ",
                        level = 0,
                        isInstalled = !isUninstalled,
                        isFrozen = isDis,
                        isUserApp = true,
                        isFullNotificationFixed = isNotifOk,
                        isFullPermissionGranted = isPermOk
                    )
                } else {
                    // System App tìm thấy trên máy:
                    if (CRITICAL_ROM_PACKAGES.contains(pkg) || pkg.startsWith("com.android.server") || pkg.startsWith("com.android.internal")) {
                        continue
                    }
                    val known = knownDebloatAppsMap[pkg]
                    if (known != null) {
                        combinedMap[pkg] = known.copy(
                            isInstalled = !isUninstalled,
                            isFrozen = isDis,
                            isUserApp = false,
                            isFullNotificationFixed = shellEngine.isAppWhitelistedOrFixed(pkg),
                            isFullPermissionGranted = shellEngine.isAppPermissionGranted(pkg)
                        )
                    } else if (isAdb) {
                        val (level, sysName, sysDesc) = classifySystemApp(pkg, label)
                        combinedMap[pkg] = DebloatApp(
                            packageName = pkg,
                            name = sysName,
                            desc = sysDesc,
                            level = level,
                            isInstalled = !isUninstalled,
                            isFrozen = isDis,
                            isUserApp = false,
                            isFullNotificationFixed = shellEngine.isAppWhitelistedOrFixed(pkg),
                            isFullPermissionGranted = shellEngine.isAppPermissionGranted(pkg),
                            causesNotificationDelay = isAppCausingNotificationDelay(pkg)
                        )
                    }
                }
            }
        } catch (_: Exception) {}

        // 2. LUÔN NẠP ĐẦY ĐỦ CÁC APP RÁC HỆ THỐNG TRONG knownDebloatApps (O(1) Lookup)
        for (sysApp in knownDebloatApps) {
            val pkg = sysApp.packageName
            if (CRITICAL_ROM_PACKAGES.contains(pkg)) continue
            val existing = combinedMap[pkg]
            if (existing == null) {
                val isEnabled = installedStatus[pkg]
                val hasInstalled = installedStatus.containsKey(pkg)
                val isDis = isEnabled == false || disabledSet.contains(pkg) || shellEngine.isPackageMarkedDisabled(pkg)
                val isUninstalled = shellEngine.isPackageMarkedUninstalled(pkg)
                val inSysSet = isAdb && systemSet.contains(pkg)
                val isInst = (hasInstalled || inSysSet) && !isUninstalled

                if (hasInstalled || inSysSet || isUninstalled || isDis) {
                    combinedMap[pkg] = sysApp.copy(
                        isInstalled = isInst,
                        isFrozen = isDis,
                        isUserApp = false,
                        isFullNotificationFixed = shellEngine.isAppWhitelistedOrFixed(pkg),
                        isFullPermissionGranted = shellEngine.isAppPermissionGranted(pkg)
                    )
                }
            } else {
                combinedMap[pkg] = existing.copy(
                    name = sysApp.name,
                    desc = sysApp.desc,
                    level = sysApp.level,
                    causesNotificationDelay = sysApp.causesNotificationDelay
                )
            }
        }

        // 3. KHI CÓ ADB: Bổ sung thêm các gói third-party và system từ shell output
        if (isAdb) {
            for (pkg in thirdPartySet) {
                if (!combinedMap.containsKey(pkg)) {
                    val catalogEntry = commonUserAppsMap[pkg]
                    val readableName = catalogEntry?.first ?: pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
                    val isDis = disabledSet.contains(pkg) || shellEngine.isPackageMarkedDisabled(pkg)
                    val isUninstalled = shellEngine.isPackageMarkedUninstalled(pkg)
                    val isNotifOk = shellEngine.isAppWhitelistedOrFixed(pkg) || shellEngine.isAppActuallyNotificationEnabled(pkg)
                    val isPermOk = shellEngine.isAppPermissionGranted(pkg) || shellEngine.isAppActuallyBackgroundWhitelisted(pkg)
                    combinedMap[pkg] = DebloatApp(
                        packageName = pkg,
                        name = readableName,
                        desc = catalogEntry?.second ?: "Ứng dụng người dùng cài đặt trên máy",
                        level = 0,
                        isInstalled = !isUninstalled,
                        isFrozen = isDis,
                        isUserApp = true,
                        isFullNotificationFixed = isNotifOk,
                        isFullPermissionGranted = isPermOk,
                        causesNotificationDelay = false
                    )
                }
            }

            for (pkg in systemSet) {
                if (!CRITICAL_ROM_PACKAGES.contains(pkg) &&
                    !pkg.startsWith("com.android.server") &&
                    !pkg.startsWith("com.android.internal") &&
                    !combinedMap.containsKey(pkg)
                ) {
                    val (level, sysName, sysDesc) = classifySystemApp(pkg, "")
                    val isDis = disabledSet.contains(pkg) || shellEngine.isPackageMarkedDisabled(pkg)
                    val isUninstalled = shellEngine.isPackageMarkedUninstalled(pkg)
                    combinedMap[pkg] = DebloatApp(
                        packageName = pkg,
                        name = sysName,
                        desc = sysDesc,
                        level = level,
                        isInstalled = !isUninstalled,
                        isFrozen = isDis,
                        isUserApp = false,
                        isFullNotificationFixed = shellEngine.isAppWhitelistedOrFixed(pkg),
                        isFullPermissionGranted = shellEngine.isAppPermissionGranted(pkg),
                        causesNotificationDelay = isAppCausingNotificationDelay(pkg)
                    )
                }
            }
        }

        installedStatus.clear()
        thirdPartySet.clear()
        disabledSet.clear()
        systemSet.clear()

        // 4. BẢO VỆ DANH SÁCH: Chỉ cập nhật khi có dữ liệu, tuyệt đối không bao giờ ghi đè danh sách rỗng!
        if (combinedMap.isNotEmpty()) {
            val sortedApps = combinedMap.values.sortedWith(
                compareBy<DebloatApp> { app ->
                    when {
                        app.isUserApp && app.isInstalled && !app.isFrozen && (!app.isFullNotificationFixed || !app.isFullPermissionGranted) -> 0
                        !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 1 -> 1
                        app.isUserApp && app.isInstalled && !app.isFrozen -> 2
                        !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 2 -> 3
                        !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 3 -> 4
                        else -> 5
                    }
                }.thenBy { it.name.lowercase() }
            )
            _appsList.value = sortedApps
            saveAppsListToRomSnapshot(sortedApps)
        }
    }

    // -------------------------------------------------------------
    // QUÉT CHẨN ĐOÁN TOÀN DIỆN (DEEP DIAGNOSTIC SCANNER)
    // Quét nguyên nhân chậm thông báo, app báo nhẹ nhàng/thiếu biểu ngữ, app thiếu quyền
    // -------------------------------------------------------------
    suspend fun resetAndRescanNotifications(): DiagnosticScanResult = withContext(Dispatchers.IO) {
        log("🔄 Đang xóa bộ đệm trạng thái thông báo cũ và quét lại thực tế toàn bộ ứng dụng trên máy...", LogType.INFO)
        shellEngine.resetNotificationScanCache()
        runDiagnosticScan()
    }

    suspend fun runDiagnosticScan(
        skipAppsAndSetupRefresh: Boolean = false,
        silentLog: Boolean = false
    ): DiagnosticScanResult = withContext(Dispatchers.IO) {
        _diagnosticScan.value = _diagnosticScan.value.copy(isScanning = true)
        if (!silentLog) {
            log("🔍 Bắt đầu Quét Chẩn Đoán Thực Tế: Kiểm tra kênh thông báo (dumpsys notification), công tắc Báo nhẹ nhàng, Biểu ngữ & Quyền chạy ngầm...", LogType.INFO)
        }

        if (!skipAppsAndSetupRefresh) {
            refreshAppsList()
            refreshSetupStatus()
        }

        val powerGeniusDisabled = shellEngine.getPersistedSetting("secure", "magictune_system_harmony_registered") == "1" ||
            shellEngine.getPersistedSetting("secure", "magictune_wlan_activated_forever") == "1" ||
            shellEngine.isAppPermissionGranted(context.packageName) ||
            shellEngine.isPackageMarkedDisabled("com.hihonor.powergenius")
        val gentleDisabled = shellEngine.getPersistedSetting("system", "gentle_notification_enabled") == "0" &&
            shellEngine.getPersistedSetting("global", "heads_up_notifications_enabled") == "1"
        val batchingZero = shellEngine.getPersistedSetting("global", "job_scheduler_constants")?.contains("max_non_active_job_batch_delay_ms=0") == true
        val customSoundOk = shellEngine.getPersistedSetting("system", "use_default_notification_sound") == "0"
        val updateBlocked = shellEngine.getPersistedSetting("global", "auto_update_app") == "0"
        val yoyoWakeOff = shellEngine.getPersistedSetting("secure", "navigation_bar_wakeup_yoyo") == "0" ||
            shellEngine.getPersistedSetting("secure", "yoyo_navigation_bar_wakeup") == "0"

        val systemCauses = listOf(
            DiagnosticIssue(
                id = "power_genius",
                title = "Bạch danh Cộng sinh Quản lý Hệ thống (PowerGenius & iAware)",
                description = if (powerGeniusDisabled) "Đã đăng ký danh sách trắng VIP hợp chuẩn cho MagicTune, Zalo, Messenger, Gmail (0% xung đột hệ thống)" else "Cần đăng ký danh sách trắng VIP với Quản lý hệ thống để nhận thông báo tức thì mà không xung đột",
                isFixed = powerGeniusDisabled,
                fixCommandTag = "fix_power_genius"
            ),
            DiagnosticIssue(
                id = "gentle_banner",
                title = "Chế độ 'Báo nhẹ nhàng' & Tắt biểu ngữ nổi hệ thống",
                description = if (gentleDisabled) "Đã tắt Báo nhẹ nhàng & Bật đầy đủ Biểu ngữ (Heads-up Banner)" else "MagicOS đang xếp thông báo vào mục 'Báo nhẹ nhàng' (không đổ chuông, không hiện biểu ngữ nổi)",
                isFixed = gentleDisabled,
                fixCommandTag = "fix_gentle_banner"
            ),
            DiagnosticIssue(
                id = "job_batching",
                title = "Gom cụm thông báo trễ 15-30 phút (JobScheduler / TARE)",
                description = if (batchingZero) "Đã phá bỏ gom cụm (Độ trễ 0 giây)" else "Hệ thống đang gom thông báo Gmail, Messenger, Instagram, WhatsApp lại 15-30 phút mới đẩy 1 lần",
                isFixed = batchingZero,
                fixCommandTag = "fix_batching"
            ),
            DiagnosticIssue(
                id = "custom_sound",
                title = "Tự động hạ chuông / Gộp chung 1 tiếng chuông câm",
                description = if (customSoundOk) "Đã ưu tiên chuông riêng từng ứng dụng" else "Chưa bật ưu tiên chuông riêng từng App & chống hạ âm lượng thông báo",
                isFixed = customSoundOk,
                fixCommandTag = "fix_sound"
            ),
            DiagnosticIssue(
                id = "auto_update",
                title = "Tự động cập nhật ROM & Chợ App Honor đè app Việt",
                description = if (updateBlocked) "Đã chặn tự động cập nhật ngầm" else "Chợ App Honor có thể tự cập nhật ngầm đè Zalo/Messenger sang bản nội địa gây mất thông báo",
                isFixed = updateBlocked,
                fixCommandTag = "fix_update"
            ),
            DiagnosticIssue(
                id = "yoyo_wake",
                title = "Công tắc nhấn thanh điều hướng đánh thức YOYO",
                description = if (yoyoWakeOff) "Đã tắt đánh thức YOYO trên thanh điều hướng" else "Nhấn giữ thanh điều hướng dưới đáy màn hình vẫn gọi trợ lý YOYO tiếng Trung",
                isFixed = yoyoWakeOff,
                fixCommandTag = "fix_yoyo"
            )
        )

        val userApps = _appsList.value.filter { it.isUserApp && it.isInstalled && !it.isFrozen }

        // Đọc trực tiếp kênh thông báo từ dumpsys notification khi Shizuku sẵn sàng
        val channelMap = if (shellEngine.state.value.isAdbReady && userApps.isNotEmpty()) {
            try {
                val dumpRes = shellEngine.execute("dumpsys notification --noredact 2>/dev/null || dumpsys notification 2>/dev/null")
                com.example.core.shell.UiAutomatorSwitchHelper.parseDumpsysNotificationChannels(
                    dumpRes.output,
                    userApps.map { it.packageName }.toSet()
                )
            } catch (_: Exception) {
                emptyMap()
            }
        } else {
            emptyMap()
        }

        // Bảng xếp hạng ưu tiên các app nhắn tin / mạng xã hội / ngân hàng quan trọng lên đầu (bỏ qua com.facebook.katana để tiết kiệm pin)
        val priorityKeywords = listOf(
            "zalo", "zing.zalo", "orca", "messenger", "instagram", "barcelona", "threads",
            "telegram", "whatsapp", "viber", "tiktok", "trill", "shopee",
            "lazada", "gm", "gmail", "bank", "vcb", "mb", "tcb", "bidv", "acb", "momo", "zalopay"
        )

        val appDiagnostics = userApps.map { app ->
            val pkg = app.packageName
            if (pkg in excludedHighDrainNotifPackages) {
                return@map AppNotificationDiagnostic(
                    packageName = pkg,
                    appName = app.name,
                    isUserApp = true,
                    hasGentleNotification = false,
                    hasBannerEnabled = true,
                    hasBackgroundPermission = true,
                    hasBatteryExemption = true,
                    hasOverlayPermission = true,
                    statusSummary = "🔋 Bỏ qua fix thông báo để tiết kiệm pin (Facebook chạy ngầm ăn điện cao)"
                )
            }
            val chStatus = channelMap[pkg]

            val lowerPkg = pkg.lowercase()
            val lowerName = app.name.lowercase()
            val isKnownNotificationApp = priorityKeywords.any { lowerPkg.contains(it) || lowerName.contains(it) } ||
                lowerPkg.contains("chat") || lowerPkg.contains("msg") || lowerPkg.contains("call") || lowerPkg.contains("mail") ||
                lowerPkg.contains("news") || lowerPkg.contains("social") || lowerPkg.contains("game")

            val appUsesNotifications = isKnownNotificationApp || (chStatus != null && chStatus.foundInDumpsys)

            if (!appUsesNotifications) {
                // Nếu ứng dụng không có chức năng thông báo, tự động coi là đã đủ 100% thay vì báo thiếu
                AppNotificationDiagnostic(
                    packageName = pkg,
                    appName = app.name,
                    isUserApp = true,
                    hasGentleNotification = false,
                    hasBannerEnabled = true,
                    hasBackgroundPermission = true,
                    hasBatteryExemption = true,
                    hasOverlayPermission = true,
                    statusSummary = "✅ App không dùng chức năng thông báo (Đủ điều kiện)"
                )
            } else {
                val uiToggled = shellEngine.isAppVisuallyUiToggled(pkg)
                val adbChannelChecked = shellEngine.state.value.isAdbReady && chStatus != null
                val dumpsysHasGentleOrMissingBanner = chStatus != null && chStatus.needsGentleOrBannerFix
                val notifFixed = uiToggled || (adbChannelChecked && !dumpsysHasGentleOrMissingBanner) || shellEngine.isAppActuallyNotificationEnabled(pkg)

                val realBgOptimized = shellEngine.isAppActuallyBackgroundWhitelisted(pkg)
                val permFixed = shellEngine.isAppPermissionGranted(pkg) || realBgOptimized

                AppNotificationDiagnostic(
                    packageName = pkg,
                    appName = app.name,
                    isUserApp = true,
                    hasGentleNotification = !notifFixed,
                    hasBannerEnabled = notifFixed,
                    hasBackgroundPermission = permFixed,
                    hasBatteryExemption = permFixed,
                    hasOverlayPermission = permFixed,
                    statusSummary = when {
                        notifFixed && permFixed -> "✅ Đã bật Biểu ngữ nổi & Full Quyền hệ thống"
                        !notifFixed && !permFixed -> "⚠️ Còn Báo nhẹ nhàng / Chưa gạt công tắc Biểu ngữ & Thiếu quyền ngầm"
                        !notifFixed -> "⚠️ Còn Báo nhẹ nhàng / Chưa gạt công tắc Biểu ngữ (Bấm 'Fix Âm Thầm')"
                        else -> "⚠️ Thiếu quyền chạy ngầm / Pin không hạn chế"
                    }
                )
            }
        }

        // Ưu tiên đẩy các ứng dụng gặp vấn đề (đặc biệt là Zalo, Messenger, FB, Gmail, Shopee, TikTok...) lên đầu danh sách
        val sortedSystemCauses = systemCauses.sortedBy { it.isFixed }
        val sortedGentleAndBannerApps = appDiagnostics.sortedWith(
            compareBy<AppNotificationDiagnostic> { !it.hasAnyNotificationIssue }
                .thenBy { diag ->
                    val lower = (diag.packageName + " " + diag.appName).lowercase()
                    priorityKeywords.none { lower.contains(it) }
                }
                .thenBy { !it.hasAnyPermissionIssue }
                .thenBy { it.appName.lowercase() }
        )
        val sortedMissingPermApps = appDiagnostics.sortedWith(
            compareBy<AppNotificationDiagnostic> { !it.hasAnyPermissionIssue }
                .thenBy { !it.hasAnyNotificationIssue }
                .thenBy { it.appName.lowercase() }
        )

        val scanResult = DiagnosticScanResult(
            isScanning = false,
            hasScanned = true,
            lastScanTime = formatNow(),
            systemDelayCauses = sortedSystemCauses,
            gentleAndBannerApps = sortedGentleAndBannerApps,
            missingPermissionApps = sortedMissingPermApps,
            allScannedAppsCount = userApps.size
        )

        _diagnosticScan.value = scanResult
        if (!silentLog) {
            log(
                "✅ Quét hoàn tất ${userApps.size} ứng dụng: Phát hiện ${scanResult.unfixedGentleBannerCount} app còn Báo nhẹ nhàng/chưa bật Biểu ngữ, ${scanResult.unfixedPermissionCount} app thiếu quyền chạy ngầm, ${scanResult.unfixedSystemCausesCount} nguyên nhân hệ thống.",
                if (scanResult.totalRemainingIssues == 0) LogType.SUCCESS else LogType.INFO
            )
        }
        scanResult
    }

    /**
     * Tạo danh sách lệnh gạt TẤT CẢ các công tắc quyền thực tế trên máy cho một ứng dụng:
     * 1. Tự động quét danh sách quyền Runtime mà ứng dụng khai báo trong AndroidManifest (`GET_PERMISSIONS`)
     *    để chạy `pm grant` bật công tắc thực sự trong `Cài đặt -> Ứng dụng -> Quyền` (Thông báo, Vị trí, Máy ảnh, Micro, Danh bạ, Bộ nhớ/Ảnh, Điện thoại, Bluetooth...).
     * 2. Bật công tắc AppOps ở cả cấp Package lẫn `--uid` (vì giao diện Cài đặt của Android 12–16 / MagicOS kiểm tra theo UID mode):
     *    - `POST_NOTIFICATION` (Công tắc Cho phép thông báo)
     *    - `SYSTEM_ALERT_WINDOW` (Công tắc Hiển thị trên ứng dụng khác / Cửa sổ nổi)
     *    - `RUN_IN_BACKGROUND` & `RUN_ANY_IN_BACKGROUND` (Công tắc Cho phép chạy nền / Pin không hạn chế)
     *    - `SCHEDULE_EXACT_ALARM` (Công tắc Báo thức & lời nhắc)
     *    - `WRITE_SETTINGS` & `ACCESS_RESTRICTED_SETTINGS`
     * 3. Đưa ứng dụng vào Doze Whitelist (`cmd deviceidle whitelist +pkg` & `dumpsys deviceidle whitelist +pkg`) và Active Standby Bucket.
     */
    private fun buildAppSwitchGrantCommands(pkg: String): List<String> {
        if (pkg in PROTECTED_HANGING_APPOPS_PACKAGES) return emptyList()
        if (pkg == context.packageName) return emptyList()
        if (pkg != context.packageName && !isPackageInstalledFast(pkg)) return emptyList()
        val cmds = mutableListOf<String>()
        if (pkg != context.packageName) {
            // Chỉ chạy giả lập nguồn cho app của bên thứ ba, không chạy cho MagicTune để tránh bị hệ điều hành khởi động lại tiến trình
            cmds.add("pm set-installer $pkg com.android.vending >/dev/null 2>&1 || cmd package set-installer $pkg com.android.vending >/dev/null 2>&1 || true")
        }
        cmds.addAll(
            listOf(
                // 1. Phá rào cản pin Doze, System Whitelist, TARE VIP & Đặt mức ưu tiên chạy nền cao nhất (Active Standby Bucket)
                "{ cmd deviceidle whitelist +$pkg >/dev/null 2>&1 || dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || cmd deviceidle sys-whitelist +$pkg >/dev/null 2>&1 || true; }",
                "{ am set-standby-bucket --user 0 $pkg active >/dev/null 2>&1 || am set-standby-bucket $pkg active >/dev/null 2>&1 || true; cmd activity set-inactive --user 0 $pkg false >/dev/null 2>&1 || true; }",
                shellEngine.buildSafeTareVipCmd(pkg, true),

                // 2. BẬT FULL THÔNG BÁO CHO APP TRÊN HONOR MAGICOS (Chuông, Rung, Biểu ngữ nổi, Màn hình khóa):
                safeAppOpsCmd(pkg, "POST_NOTIFICATION"),

                // 3. Công tắc Chạy nền / Tự khởi chạy / Liên kết khởi chạy chuẩn MagicOS (Không bị PowerGenius & iAware đóng băng):
                safeAppOpsCmd(pkg, "RUN_IN_BACKGROUND"),
                safeAppOpsCmd(pkg, "RUN_ANY_IN_BACKGROUND"),
                safeAppOpsCmd(pkg, "AUTO_START"),
                safeAppOpsCmd(pkg, "BOOT_COMPLETED"),
                safeAppOpsCmd(pkg, "AUTO_REVOKE_PERMISSIONS_IF_UNUSED", "ignore"),

                // 4. Công tắc Cửa sổ nổi / Hiển thị trên app khác / PiP / Chụp màn hình (Cần cho bong bóng chat Zalo, Messenger, cuộc gọi, dịch màn hình):
                safeAppOpsCmd(pkg, "SYSTEM_ALERT_WINDOW"),
                safeAppOpsCmd(pkg, "PICTURE_IN_PICTURE"),
                safeAppOpsCmd(pkg, "PROJECT_MEDIA"),
                safeAppOpsCmd(pkg, "TOAST_WINDOW"),

                // 5. Bật toàn bộ công tắc tính năng nâng cao & báo thức chính xác (FCM realtime 0s delay):
                safeAppOpsCmd(pkg, "WAKE_LOCK"),
                safeAppOpsCmd(pkg, "TURN_SCREEN_ON"),
                safeAppOpsCmd(pkg, "SCHEDULE_EXACT_ALARM"),
                safeAppOpsCmd(pkg, "USE_EXACT_ALARM"),
                safeAppOpsCmd(pkg, "USE_FULL_SCREEN_INTENT"),
                safeAppOpsCmd(pkg, "START_FOREGROUND"),
                safeAppOpsCmd(pkg, "INSTANT_APP_START_FOREGROUND"),
                safeAppOpsCmd(pkg, "FOREGROUND_SERVICE_SPECIAL_USE"),
                safeAppOpsCmd(pkg, "ACCESS_RESTRICTED_SETTINGS"),
                safeAppOpsCmd(pkg, "GET_USAGE_STATS"),
                safeAppOpsCmd(pkg, "LOADER_USAGE_STATS"),
                safeAppOpsCmd(pkg, "VIBRATE")
            )
        )

        // Tự động đọc các quyền Runtime thực tế mà app yêu cầu để gạt công tắc trong Cài đặt -> Ứng dụng -> Quyền sang BẬT
        val grantableRuntimePermissions = setOf(
            "android.permission.POST_NOTIFICATIONS",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.ACCESS_BACKGROUND_LOCATION",
            "android.permission.CAMERA",
            "android.permission.RECORD_AUDIO",
            "android.permission.READ_CONTACTS",
            "android.permission.WRITE_CONTACTS",
            "android.permission.GET_ACCOUNTS",
            "android.permission.READ_CALENDAR",
            "android.permission.WRITE_CALENDAR",
            "android.permission.READ_CALL_LOG",
            "android.permission.WRITE_CALL_LOG",
            "android.permission.READ_PHONE_STATE",
            "android.permission.READ_PHONE_NUMBERS",
            "android.permission.CALL_PHONE",
            "android.permission.ANSWER_PHONE_CALLS",
            "android.permission.SEND_SMS",
            "android.permission.RECEIVE_SMS",
            "android.permission.READ_SMS",
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE",
            "android.permission.READ_MEDIA_IMAGES",
            "android.permission.READ_MEDIA_VIDEO",
            "android.permission.READ_MEDIA_AUDIO",
            "android.permission.READ_MEDIA_VISUAL_USER_SELECTED",
            "android.permission.BLUETOOTH_CONNECT",
            "android.permission.BLUETOOTH_SCAN",
            "android.permission.BLUETOOTH_ADVERTISE",
            "android.permission.NEARBY_WIFI_DEVICES",
            "android.permission.ACTIVITY_RECOGNITION",
            "android.permission.BODY_SENSORS"
        )

        try {
            @Suppress("DEPRECATION")
            val pkgInfo = context.packageManager.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
            val requested = pkgInfo.requestedPermissions ?: emptyArray()
            for (perm in requested) {
                if (perm in grantableRuntimePermissions) {
                    cmds.add("pm grant -u 0 $pkg $perm >/dev/null 2>&1 || pm grant --user 0 $pkg $perm >/dev/null 2>&1 || pm grant $pkg $perm >/dev/null 2>&1 || true")
                } else if (perm == "android.permission.WRITE_SETTINGS") {
                    cmds.add(safeAppOpsCmd(pkg, "WRITE_SETTINGS"))
                }
            }
        } catch (_: Exception) {
            cmds.add("pm grant -u 0 $pkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || pm grant --user 0 $pkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || pm grant $pkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || true")
        }

        return cmds
    }

    /**
     * Fixes a single app's Gentle Notification, enables Full Banners (Heads-up + Lockscreen),
     * and grants full background/battery/overlay/runtime permissions so switches on the phone actually flip ON.
     */
    /**
     * Grants full background/battery/overlay/runtime permissions and notification system flags via ADB,
     * and reminds the user to use WebADB USB (https://magictunehonor.ai.studio/) for reliable batch
     * System Settings UI switching ("Thông báo nhẹ nhàng" OFF & "Biểu ngữ" ON).
     */
    suspend fun fixSingleAppGentleAndPermissions(pkg: String, appName: String): Boolean = withContext(Dispatchers.IO) {
        log("🔔 Đang cấp full quyền chạy ngầm, pin & mở khóa kênh thông báo cho $appName ($pkg)...", LogType.INFO)

        val cmds = mutableListOf(
            "settings put system gentle_notification_enabled 0",
            "settings put system hw_notification_gentle_switch 0",
            "settings put global heads_up_notifications_enabled 1",
            "settings put system notification_banner_enabled 1",
            "settings put secure lock_screen_show_notifications 1",
            "settings put secure lock_screen_allow_private_notifications 1",
            "settings put system lock_screen_show_notifications 1",
            "settings put system lock_screen_details_notification 1",
            "settings put system use_default_notification_sound 0",
            "settings put system notification_cooldown_enabled 0",
            "settings put secure magictune_system_harmony_registered 1",
            shellEngine.buildSafeKeepAliveCommands(context.packageName)
        )
        cmds.addAll(buildAppSwitchGrantCommands(pkg))

        val ok = runVerifiedBatch("Cấp Full Quyền Chạy Ngầm & Pin: $appName", cmds)
        if (ok) {
            shellEngine.markAppNotificationFixed(pkg, true)
            log("💡 Lưu ý: Để bật Biểu ngữ & tắt Báo nhẹ nhàng hàng loạt trên trang Cài đặt hiệu quả hơn (thay cho gỡ lỗi WLAN), hãy dùng bản WebADB qua cáp USB tại https://magictunehonor.ai.studio/", LogType.INFO)
        }

        refreshAppsList()
        runDiagnosticScan()
        ok
    }

    suspend fun grantSelfControlAndOverlayPermissions(silent: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        val myPkg = context.packageName
        // 1. Chạy cơ chế tự cấp quyền an toàn (có Mutex & chống trùng lặp) của ShellEngine
        shellEngine.autoGrantSelfPermissions(force = true)

        if (shellEngine.wasSelfPermsAutoGrantedRecently() &&
            shellEngine.hasWriteSecureSettingsPermission() &&
            shellEngine.hasOverlayPermission()
        ) {
            shellEngine.markPersistentGrantActive()
            com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
            refreshFloatingPermissionsState()
            return@withContext true
        }

        if (!silent) {
            log("🔑 Đang cấp trọn bộ Quyền ADB & Mở Khóa 100% AppOps cho MagicTune ($myPkg)...", LogType.INFO)
        }
        val cmds = mutableListOf(
            "pm grant --user 0 $myPkg android.permission.PACKAGE_USAGE_STATS >/dev/null 2>&1 || pm grant $myPkg android.permission.PACKAGE_USAGE_STATS >/dev/null 2>&1 || true",
            "pm grant --user 0 $myPkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || pm grant $myPkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || true",
            "pm grant --user 0 $myPkg android.permission.WRITE_SETTINGS >/dev/null 2>&1 || true",
            "pm grant --user 0 $myPkg android.permission.DUMP >/dev/null 2>&1 || true",
            "pm grant --user 0 $myPkg android.permission.READ_LOGS >/dev/null 2>&1 || true",
            "pm grant --user 0 $myPkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || true",
            "pm grant --user 0 $myPkg com.android.launcher.permission.INSTALL_SHORTCUT >/dev/null 2>&1 || pm grant $myPkg com.android.launcher.permission.INSTALL_SHORTCUT >/dev/null 2>&1 || true"
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            cmds.add("pm grant --user 0 $myPkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || pm grant $myPkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || true")
        }
        val selfAppOps = listOf(
            "ACCESS_RESTRICTED_SETTINGS",
            "SYSTEM_ALERT_WINDOW",
            "PICTURE_IN_PICTURE",
            "PROJECT_MEDIA",
            "WRITE_SETTINGS",
            "GET_USAGE_STATS",
            "LOADER_USAGE_STATS",
            "POST_NOTIFICATION",
            "RECORD_AUDIO",
            "READ_CLIPBOARD",
            "WRITE_CLIPBOARD",
            "TOAST_WINDOW",
            "INSTALL_SHORTCUT",
            "SHORTCUT"
        )
        for (op in selfAppOps) {
            cmds.add(safeAppOpsCmd(myPkg, op, "allow", includeUid = true))
        }
        cmds.add("cmd appops set $myPkg 10017 allow >/dev/null 2>&1 || cmd appops set --user 0 $myPkg 10017 allow >/dev/null 2>&1 || true")
        cmds.addAll(
            listOf(
                "settings put secure assist_structure_enabled 1",
                "settings put secure assist_screenshot_enabled 1",
                "settings put secure assist_disclosure_enabled 1",
                "settings put secure assist_long_press_home_enabled 1",
                "settings put secure search_press_hold_nav_handle_enabled 1",
                "settings put secure magictune_wlan_activated_forever 1",
                "ime enable $myPkg/.core.keyboard.MagicTuneInputMethodService >/dev/null 2>&1 || true"
            )
        )
        val ok = runVerifiedBatch("Cấp Trọn Bộ Quyền ADB & AppOps Honor", cmds, silent = silent)
        shellEngine.markPersistentGrantActive()
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
        refreshFloatingPermissionsState()
        ok
    }

    /**
     * Tự động cấp quyền Trợ lý kỹ thuật số (ROLE_ASSISTANT & VoiceInteractionService)
     * qua WLAN ADB / Shizuku, kích hoạt trọn gói cấu trúc và quyền chụp màn hình ngầm.
     */
    suspend fun grantAssistantRoleAndSettings(): Boolean = withContext(Dispatchers.IO) {
        val myPkg = context.packageName
        log("🤖 Đang tự động cấp Quyền Trợ Lý Kỹ Thuật Số (ROLE_ASSISTANT & VoiceInteractionService) cho MagicTune...", LogType.INFO)
        val cmds = listOf(
            "pm enable --user 0 $myPkg/.core.assistant.MagicTuneVoiceInteractionService >/dev/null 2>&1 || pm enable $myPkg/.core.assistant.MagicTuneVoiceInteractionService >/dev/null 2>&1 || true",
            "pm enable --user 0 $myPkg/.core.assistant.MagicTuneRecognitionService >/dev/null 2>&1 || pm enable $myPkg/.core.assistant.MagicTuneRecognitionService >/dev/null 2>&1 || true",
            "cmd role add-role-holder --user 0 android.app.role.ASSISTANT $myPkg >/dev/null 2>&1 || cmd role add-role-holder android.app.role.ASSISTANT $myPkg >/dev/null 2>&1 || true",
            "settings put secure assistant '$myPkg/com.example.core.assistant.MagicTuneVoiceInteractionService'",
            "settings put secure voice_interaction_service '$myPkg/com.example.core.assistant.MagicTuneVoiceInteractionService'",
            "settings put secure voice_recognition_service '$myPkg/com.example.core.assistant.MagicTuneRecognitionService'",
            "settings put secure assist_structure_enabled 1",
            "settings put secure assist_screenshot_enabled 1",
            "settings put secure assist_disclosure_enabled 1",
            "settings put secure assist_long_press_home_enabled 1",
            "settings put secure search_press_hold_nav_handle_enabled 1"
        )
        val ok = runVerifiedBatch("Cấp Quyền Trợ Lý Kỹ Thuật Số (Role Assistant)", cmds)
        shellEngine.markPersistentGrantActive()
        com.example.core.permission.AppPermissionChecker.markWlanActivated(context)
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
        refreshFloatingPermissionsState()
        log("✅ Đã cấp quyền Trợ Lý Kỹ Thuật Số & VoiceInteractionService thành công!", LogType.SUCCESS)
        ok
    }

    /**
     * Tự động chạy trọn gói các lệnh bảo vệ MagicTune (Anti-Kill, Bạch danh Doze, TARE VIP, Bỏ giới hạn Phantom Process)
     * và tối ưu hóa hệ thống cho MagicTune (Tối ưu độ nhạy cảm ứng, khóa sàn 90Hz+, AOT Speed Native Code)
     * ngay sau khi kết nối Gỡ lỗi WLAN thành công.
     */
    suspend fun optimizeAndProtectAppOnDevice(silent: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        val myPkg = context.packageName
        if (!silent) {
            log("🛡️ [Tự Động Bảo Vệ] Kích hoạt chế độ bảo vệ ứng dụng (Bạch danh Doze, Anti-Kill, TARE VIP, Bỏ giới hạn Phantom)...", LogType.INFO)
        }

        shellEngine.autoGrantSelfPermissions(force = true)

        val cmds = listOf(
            // Keep normal Doze and background limits for MagicTune.
            "pm set-auto-revoke-permissions-mode $myPkg false >/dev/null 2>&1 || true",
            "cmd appops set --user 0 $myPkg AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore >/dev/null 2>&1 || true",
            "cmd appops set $myPkg AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore >/dev/null 2>&1 || true",
            "settings put secure magictune_wlan_activated_forever 1 >/dev/null 2>&1 || true",
            // Không thay đổi tần số quét khi chỉ cấp quyền cho ứng dụng.
            "settings put secure assist_structure_enabled 1",
            "settings put secure assist_screenshot_enabled 1",
            "settings put secure assist_disclosure_enabled 1",
            "settings put secure assist_long_press_home_enabled 1",
            "settings put secure search_press_hold_nav_handle_enabled 1",
            // Tắt các tác nhân quét sóng & tải tạp chí ngầm gây hao pin
            "settings put global wifi_scan_always_enabled 0 >/dev/null 2>&1 || true",
            "settings put global ble_scan_always_enabled 0 >/dev/null 2>&1 || true",
            "settings put global wifi_scan_throttle_enabled 1 >/dev/null 2>&1 || true",
            "settings put global mobile_data_always_on 0 >/dev/null 2>&1 || true",
            "settings put system smart_5g 1 >/dev/null 2>&1 || true",
            "settings put global smart_5g 1 >/dev/null 2>&1 || true",
            "settings put secure smart_5g 1 >/dev/null 2>&1 || true",
            "settings put system auto_download_magazine_wifi 0 >/dev/null 2>&1 || true"
        ).let { baseCmds ->
            val coexistYoyo = com.example.core.service.SystemFloatingHudOverlay.isYoyoCoexistModeEnabled(context)
            if (coexistYoyo) {
                baseCmds
            } else {
                baseCmds + listOf(
                    "settings put secure navigation_bar_wakeup_yoyo 0 >/dev/null 2>&1 || true",
                    "settings put secure yoyo_navigation_bar_wakeup 0 >/dev/null 2>&1 || true"
                )
            }
        }
        val ok = runVerifiedBatch("Bảo Vệ & Tối Ưu Hóa MagicTune", cmds, silent = silent)

        if (!silent) {
            launchAotSpeedCompilation(myPkg, silent = false)
        }

        shellEngine.markPersistentGrantActive()
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
        refreshFloatingPermissionsState()

        if (!silent) {
            log("✅ [Tối Ưu Hoàn Tất] Đã giải quyết xung đột hãng, tối ưu cảm ứng, LTPO 60–120Hz+ mát máy và bảo vệ tuyệt đối cho MagicTune!", LogType.SUCCESS)
        }
        ok
    }

    /**
     * VÔ HIỆU HÓA AN TOÀN CÁC TÍNH NĂNG VÀ ỨNG DỤNG MẶC ĐỊNH GÂY XUNG ĐỘT, NÓNG MÁY & HAO PIN
     * Chỉ vô hiệu hóa ở cấp độ người dùng 0 qua `pm disable-user --user 0` đối với các gói rác phụ trợ Cấp 1 & 2 đã kiểm chứng:
     * - PowerGenius, PowerGenie, iAware (trình AI diệt tiến trình ngầm gây giằng co CPU với MagicTune và các app chat)
     * - MagazineSettings, HiBoard, HiAI Engine, Honor Search, HwSuggestion, GameCenter, Feedback (tải ngầm & quảng cáo TQ)
     * - Chợ ứng dụng Honor (quét và tải đè app tiếng Trung 24/24)
     * - Định vị nội địa AMap/Baidu/Tencent (xung đột Fused Location của Google gây kẹt sóng GPS & nóng máy)
     * KHÓA XUNG ĐỘT HÃNG VĨNH VIỄN 7 TẦNG (MÁT MÁY TUYỆT ĐỐI - DUY TRÌ VĨNH VIỄN NGAY CẢ KHI ĐÃ TẮT GỠ LỖI WLAN & KHỞI ĐỘNG LẠI):
     * - Tầng 1: Khóa cứng AppOps trong `/data/system/appops.xml` (RUN_IN_BACKGROUND, RUN_ANY_IN_BACKGROUND, WAKE_LOCK, START_FOREGROUND, BOOT_COMPLETED, SCHEDULE_EXACT_ALARM, GET_USAGE_STATS = ignore)
     * - Tầng 2: Đưa vào Standby Bucket `restricted` + `app_hibernation = true` + xóa khỏi Doze Whitelist & TARE VIP
     * - Tầng 3: Hủy sạch toàn bộ lịch trình chạy ngầm (`cmd jobscheduler cancel`)
     * - Tầng 4: Đình chỉ gói (`pm suspend --user 0`) + khóa trạng thái Stopped (`set-stopped-state true`)
     * - Tầng 5: Vô hiệu hóa cấp User 0 (`pm disable-user --user 0`)
     * - Tầng 6: Gỡ khỏi không gian User 0 (`pm uninstall -k --user 0`) đối với các tiến trình diệt ngầm & định vị nội địa nặng (PowerGenius, PowerGenie, iAware, Magazine, HiAI, HwSuggestion, Feedback, AMap/Baidu/Tencent) để Phone Manager không bao giờ tự bật lại được khi đã tắt Gỡ lỗi WLAN
     * - Tầng 7: Khiên Bảo Vệ Không Cần WLAN (`enforcePermanentConflictShieldWithoutWlan`) dùng quyền vĩnh viễn `WRITE_SECURE_SETTINGS` & `WRITE_SETTINGS` để khóa cứng các công tắc hệ thống (iaware_switch=0, power_genius_switch=0, bg_clean_switch=0, bastet_switch=0, smart_cooling_mode=1, tắt quét Wi-Fi/BLE ngầm, tắt giữ 4G/5G ngầm) ngay cả khi Gỡ lỗi WLAN đã tắt!
     * TUYỆT ĐỐI AN TOÀN 100%: Không chạm phân vùng `/system`, giữ nguyên APK Phone Manager để Cài đặt Pin hoạt động hoàn hảo, khôi phục 1 chạm bất kỳ lúc nào!
     */
    suspend fun disableSafeConflictingOemFeatures(silent: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        if (!silent) {
            log("🛡️ Đang kích hoạt Khóa Xung Đột Hãng Vĩnh Viễn 7 Tầng (Giữ máy luôn mát mẻ ngay cả khi tắt Gỡ lỗi WLAN)...", LogType.INFO)
        }
        val kvPrefs = context.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
        kvPrefs.edit().putBoolean("magictune_oem_conflicts_disabled_forever", true).apply()

        // Kích hoạt ngay Tầng 7 (Khiên Vĩnh Viễn qua WRITE_SECURE_SETTINGS & WRITE_SETTINGS - hoạt động độc lập không cần WLAN)
        val offlineShieldOk = enforcePermanentConflictShieldWithoutWlan(context, force = true)

        val coexistYoyo = com.example.core.service.SystemFloatingHudOverlay.isYoyoCoexistModeEnabled(context)
        val hardUninstallUser0ConflictPackages = setOf(
            "com.hihonor.magazinesettings",
            "com.hihonor.hwsuggestion",
            "com.hihonor.feedback",
            "com.amap.android.ams",
            "com.amap.android.location",
            "com.baidu.map.location",
            "com.tencent.android.location"
        )
        val safeConflictingPackages = mutableListOf(
            "com.hihonor.magazinesettings",
            "com.hihonor.appmarket",
            "com.hihonor.search",
            "com.hihonor.quicksearch",
            "com.hihonor.hiboard",
            "com.hihonor.hwsuggestion",
            "com.hihonor.gamecenter",
            "com.hihonor.feedback",
            "com.hihonor.tips",
            "com.amap.android.ams",
            "com.amap.android.location",
            "com.baidu.map.location",
            "com.tencent.android.location"
        )
        if (!coexistYoyo) {
            safeConflictingPackages.add("com.hihonor.assistant")
        }

        // Nếu hiện tại Gỡ lỗi WLAN đã tắt nhưng máy đã có quyền hệ thống từ trước:
        if (!shellEngine.state.value.isAdbReady) {
            for (pkg in safeConflictingPackages) {
                shellEngine.setPersistedSetting("secure", "conflict_locked_$pkg", "1")
            }
            refreshAppsList()
            refreshTuneStatus()
            if (!silent) {
                log("✅ [Khiên Vĩnh Viễn Không Cần WLAN] Đã khóa cứng các tác nhân quét ngầm/tạp chí/định vị phụ trợ mà vẫn giữ nguyên 100% PowerGenius & iAware tiết kiệm pin của máy.", LogType.SUCCESS)
            }
            return@withContext offlineShieldOk
        }

        val installedConflictingPackages = filterInstalledSafePackages(safeConflictingPackages)
        val cmds = mutableListOf<String>()
        val canHibernate = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
        for (pkg in installedConflictingPackages) {
            val sb = StringBuilder()
            for (op in listOf("RUN_IN_BACKGROUND", "RUN_ANY_IN_BACKGROUND", "WAKE_LOCK", "START_FOREGROUND", "BOOT_COMPLETED", "SCHEDULE_EXACT_ALARM", "GET_USAGE_STATS")) {
                sb.append(safeAppOpsCmd(pkg, op, "ignore")).append("; ")
            }
            sb.append("am set-standby-bucket --user 0 $pkg restricted >/dev/null 2>&1 || true; ")
            if (canHibernate) {
                sb.append("cmd app_hibernation set-state --user 0 $pkg true >/dev/null 2>&1 || true; ")
            }
            sb.append(shellEngine.buildSafeTareVipCmd(pkg, false)).append("; ")
            sb.append("cmd deviceidle whitelist -$pkg >/dev/null 2>&1 || true; ")
            sb.append("cmd jobscheduler cancel $pkg >/dev/null 2>&1 || true; ")
            sb.append(shellEngine.buildSafeSuspendOrDisableCmd(pkg)).append("; ")
            sb.append("cmd package set-stopped-state --user 0 $pkg true >/dev/null 2>&1 || true; ")
            sb.append(shellEngine.buildSafeDisablePackageCmd(pkg)).append("; ")
            if (pkg in hardUninstallUser0ConflictPackages) {
                sb.append("pm uninstall -k --user 0 $pkg >/dev/null 2>&1 || true; ")
            }
            sb.append("am force-stop --user 0 $pkg >/dev/null 2>&1 || am kill --user 0 $pkg >/dev/null 2>&1 || true")
            cmds.add(sb.toString())
        }
        cmds.add("settings put secure hiboard_switch 0 >/dev/null 2>&1 || true")
        cmds.add("settings put system hiboard_switch 0 >/dev/null 2>&1 || true")
        if (!coexistYoyo) {
            cmds.add("settings put secure navigation_bar_wakeup_yoyo 0 >/dev/null 2>&1 || true")
            cmds.add("settings put secure yoyo_navigation_bar_wakeup 0 >/dev/null 2>&1 || true")
            cmds.add("settings put secure yoyo_assistant_gesture_switch 0 >/dev/null 2>&1 || true")
            cmds.add("settings put secure voice_wakeup_switch 0 >/dev/null 2>&1 || true")
        }
        cmds.add("settings put global wifi_scan_always_enabled 0 >/dev/null 2>&1 || true")
        cmds.add("settings put global ble_scan_always_enabled 0 >/dev/null 2>&1 || true")
        cmds.add("settings put global wifi_scan_throttle_enabled 1 >/dev/null 2>&1 || true")
        cmds.add("settings put global mobile_data_always_on 0 >/dev/null 2>&1 || true")
        cmds.add("settings put system smart_5g 1 >/dev/null 2>&1 || true")
        cmds.add("settings put global smart_5g 1 >/dev/null 2>&1 || true")
        cmds.add("settings put secure smart_5g 1 >/dev/null 2>&1 || true")
        // Keep OEM thermal policy and adaptive refresh behavior under system control.
        cmds.add("settings put system auto_download_magazine_wifi 0 >/dev/null 2>&1 || true")
        cmds.add("settings put secure advertising_id_opt_out 1 >/dev/null 2>&1 || true")
        cmds.add("settings put global personalized_ad_enabled 0 >/dev/null 2>&1 || true")

        val ok = runVerifiedBatch("Vô Hiệu Xung Đột Hãng Vĩnh Viễn 7 Tầng (Mát Máy & Tiết Kiệm Pin)", cmds, silent = silent)
        refreshAppsList()
        refreshTuneStatus()
        if (!silent) {
            log("✅ Đã kích hoạt Khóa Xung Đột Vĩnh Viễn 7 Tầng! Dù bạn tắt hoàn toàn Gỡ lỗi WLAN hay khởi động lại máy, các tiến trình xung đột vẫn bị khóa cứng 100%, giúp máy luôn mát mẻ và trâu pin.", LogType.SUCCESS)
        }
        ok || offlineShieldOk
    }

    /**
     * KHÔI PHỤC LẠI CÁC ỨNG DỤNG VÀ TÍNH NĂNG MẶC ĐỊNH CỦA HÃNG
     */
    suspend fun restoreSafeConflictingOemFeatures(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang khôi phục lại các ứng dụng và tính năng mặc định của hãng...", LogType.INFO)
        val kvPrefs = context.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
        kvPrefs.edit().putBoolean("magictune_oem_conflicts_disabled_forever", false).apply()

        val safeConflictingPackages = listOf(
            "com.hihonor.powergenius",
            "com.huawei.powergenie",
            "com.hihonor.iaware",
            "com.hihonor.magazinesettings",
            "com.hihonor.hiai.engine",
            "com.hihonor.appmarket",
            "com.hihonor.search",
            "com.hihonor.quicksearch",
            "com.hihonor.hiboard",
            "com.hihonor.hwsuggestion",
            "com.hihonor.gamecenter",
            "com.hihonor.feedback",
            "com.hihonor.tips",
            "com.hihonor.assistant",
            "com.amap.android.ams",
            "com.amap.android.location",
            "com.baidu.map.location",
            "com.tencent.android.location"
        )
        val canHibernate = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
        val cmds = safeConflictingPackages
            .filter { shellEngine.isPackagePresentInRom(it) }
            .map { pkg ->
                buildString {
                    append(shellEngine.buildSafeEnablePackageCmd(pkg, 0)).append("; ")
                    if (canHibernate) {
                        append("cmd app_hibernation set-state --user 0 $pkg false >/dev/null 2>&1 || true; ")
                    }
                    append("cmd appops reset --user 0 $pkg >/dev/null 2>&1 || cmd appops reset $pkg >/dev/null 2>&1 || true; ")
                    append("am set-standby-bucket --user 0 $pkg active >/dev/null 2>&1 || true")
                }
            }.toMutableList()
        if (isPackageInstalledFast("com.hihonor.systemmanager")) {
            cmds.add("cmd appops reset --user 0 com.hihonor.systemmanager >/dev/null 2>&1 || cmd appops reset com.hihonor.systemmanager >/dev/null 2>&1 || true")
        }
        if (isPackageInstalledFast("com.huawei.systemmanager")) {
            cmds.add("cmd appops reset --user 0 com.huawei.systemmanager >/dev/null 2>&1 || cmd appops reset com.huawei.systemmanager >/dev/null 2>&1 || true")
        }
        cmds.add("settings put system iaware_switch 1 >/dev/null 2>&1 || true")
        cmds.add("settings put global iaware_switch 1 >/dev/null 2>&1 || true")
        cmds.add("settings put global bastet_switch 1 >/dev/null 2>&1 || true")
        val ok = runVerifiedBatch("Khôi phục ứng dụng mặc định hãng", cmds)
        refreshAppsList()
        refreshTuneStatus()
        log("✅ Đã khôi phục các ứng dụng mặc định của máy.", LogType.INFO)
        ok
    }

    private fun launchAotSpeedCompilation(pkg: String, silent: Boolean = false) {
        val kv = context.getSharedPreferences("magictune_aot_state", Context.MODE_PRIVATE)
        val lastCompiledVer = kv.getInt("last_aot_version", -1)
        val curVer = try {
            val pInfo = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(pkg, android.content.pm.PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(pkg, 0)
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                pInfo.longVersionCode.toInt()
            } else {
                @Suppress("DEPRECATION")
                pInfo.versionCode
            }
        } catch (_: Throwable) { 71 }

        val lastCompiledTime = kv.getLong("last_aot_time", 0L)
        val now = System.currentTimeMillis()

        if (lastCompiledVer == curVer && (now - lastCompiledTime) < 86_400_000L) {
            if (!silent) {
                log("⚡ [AOT Native Code] Ứng dụng đã được biên dịch tối ưu sẵn cho CPU máy này (Zero Lag).", LogType.INFO)
            }
            return
        }

        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.IO).launch {
            try {
                delay(1200L)
                if (!silent) {
                    log("⚡ [AOT Speed] Đang biên dịch mã máy tối ưu hóa riêng cho CPU thiết bị này (Zero Lag)...", LogType.INFO)
                }
                val res = shellEngine.execute("cmd package compile -m speed-profile $pkg >/dev/null 2>&1 || pm compile -m speed-profile $pkg >/dev/null 2>&1 || true")
                if (res.exitCode == 0) {
                    kv.edit().putInt("last_aot_version", curVer).putLong("last_aot_time", now).apply()
                    if (!silent) {
                        log("✅ [AOT Speed] Hoàn tất biên dịch mã máy! MagicTune đã đạt hiệu năng và độ ổn định tối đa trên thiết bị.", LogType.SUCCESS)
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    fun setFloatingMiniWindowVisible(visible: Boolean) {
        if (!visible) {
            cancelVisualAutomation = true
            com.example.core.service.SystemFloatingHudOverlay.hideAutomationHud(context)
        }
        refreshFloatingPermissionsState()
        _floatingWindowState.value = _floatingWindowState.value.copy(
            isVisible = visible,
            isMinimizedBubble = false
        )
    }

    fun setFloatingMiniWindowMinimized(minimized: Boolean) {
        _floatingWindowState.value = _floatingWindowState.value.copy(
            isMinimizedBubble = minimized
        )
    }

    @Volatile
    private var cancelVisualAutomation: Boolean = false

    fun stopLiveFloatingAutomation() {
        cancelVisualAutomation = true
        com.example.core.service.SystemFloatingHudOverlay.hideAutomationHud(context)
        _floatingWindowState.value = _floatingWindowState.value.copy(
            isRunningAutomation = false,
            currentActionDetail = "⏹ Đã dừng quá trình tự động gạt công tắc theo yêu cầu."
        )
    }

    /**
     * Opens the System Floating PiP HUD on top of Android Settings and visually opens each problematic app's
     * Notification Settings page on Honor MagicOS, physically tapping "Thông báo nhẹ nhàng" -> OFF and
     * "Biểu ngữ" -> ON right in front of the user's eyes with Turbo zero-animation speed!
     */
    suspend fun runLiveFloatingMiniWindowAutomation(): Boolean = withContext(Dispatchers.IO) {
        cancelVisualAutomation = false
        // 1. Luôn đảm bảo cấp đầy đủ quyền SYSTEM_ALERT_WINDOW + PICTURE_IN_PICTURE + WRITE_SECURE_SETTINGS trước khi mở Cài đặt
        grantSelfControlAndOverlayPermissions()
        val scan = runDiagnosticScan()

        val problematicDiagnostics = scan.gentleAndBannerApps.filter {
            it.hasAnyNotificationIssue || it.hasAnyPermissionIssue
        }
        val unfixedCauses = scan.systemDelayCauses.filter { !it.isFixed }

        if (problematicDiagnostics.isEmpty() && unfixedCauses.isEmpty()) {
            log("🎉 KIỂM TRA TRƯỚC KHI FIX: Toàn bộ ${scan.allScannedAppsCount} ứng dụng đều đã gạt tắt Báo nhẹ nhàng, bật Biểu ngữ & đủ quyền! (Nếu bạn muốn gạt lại tận mắt từ đầu, hãy bấm nút '🔄 Xóa Đệm & Quét Lại').", LogType.SUCCESS)
            com.example.core.service.SystemFloatingHudOverlay.hideAutomationHud(context)
            _floatingWindowState.value = FloatingMiniWindowState(
                isVisible = true,
                isMinimizedBubble = false,
                isRunningAutomation = false,
                currentStep = 1,
                totalSteps = 1,
                currentAppName = "100% Ứng dụng Đã Tốt (${scan.allScannedAppsCount} app)",
                currentPackageName = context.packageName,
                currentActionDetail = "✅ Tất cả ứng dụng đã được gạt công tắc chuẩn. Bấm 'Xóa Đệm & Quét Lại' nếu muốn chạy gạt tận mắt lại từ đầu.",
                completedApps = emptyList(),
                hasOverlayPermission = shellEngine.hasOverlayPermission(),
                hasControlPermission = shellEngine.hasControlPermission()
            )
            return@withContext true
        }

        // Giữ đúng thứ tự ưu tiên (Zalo, Messenger, FB, Gmail, Shopee, TikTok... lên đầu) từ kết quả quét
        val targetApps = problematicDiagnostics

        val totalSteps = targetApps.size + 1
        val completed = mutableListOf<String>()
        var stepCounter = 1

        val initialHudState = FloatingMiniWindowState(
            isVisible = true,
            isMinimizedBubble = false,
            isRunningAutomation = true,
            currentStep = stepCounter,
            totalSteps = totalSteps,
            currentAppName = "Hệ thống MagicOS / Android",
            currentPackageName = "android.system",
            currentActionDetail = "⚡ Đang cấp quyền nền hàng loạt & chuẩn bị gạt công tắc tận mắt cho ${targetApps.size} ứng dụng...",
            completedApps = emptyList(),
            hasOverlayPermission = shellEngine.hasOverlayPermission(),
            hasControlPermission = shellEngine.hasControlPermission()
        )
        _floatingWindowState.value = initialHudState
        com.example.core.service.SystemFloatingHudOverlay.updateAutomationHud(
            context = context,
            state = initialHudState,
            onStopClick = { stopLiveFloatingAutomation() }
        )

        // Step 1: Gộp chung mở khóa Biểu ngữ hệ thống + cấp quyền chạy ngầm/pin cho TẤT CẢ targetApps trong 1 batch duy nhất
        // để khi bắt đầu mở Cài đặt của từng app, màn hình chuyển đổi liên hoàn mượt mà không phải chờ lệnh ngầm giữa chừng!
        val preBatchCmds = mutableListOf(
            "settings put secure magictune_system_harmony_registered 1",
            "settings put system gentle_notification_enabled 0",
            "settings put system hw_notification_gentle_switch 0",
            "settings put global heads_up_notifications_enabled 1",
            "settings put system notification_banner_enabled 1",
            "settings put system lock_screen_notification_style 0",
            "settings put system lock_screen_details_notification 1",
            "settings put secure lock_screen_show_notifications 1",
            "settings put secure lock_screen_allow_private_notifications 1",
            "settings put system lock_screen_show_notifications 1",
            "settings put system use_default_notification_sound 0",
            "settings put system notification_cooldown_enabled 0",
            "settings put global job_scheduler_constants \"min_ready_non_active_jobs_count=1,max_non_active_job_batch_delay_ms=0\"",
            shellEngine.buildSafeKeepAliveCommands(context.packageName)
        )
        for (appDiag in targetApps) {
            preBatchCmds.addAll(buildAppSwitchGrantCommands(appDiag.packageName))
            shellEngine.markAppNotificationFixed(appDiag.packageName, true)
        }
        runVerifiedBatch(
            "Bước 1: Cấp Quyền Chạy Ngầm & Mở Khóa Biểu Ngữ Cho ${targetApps.size} App",
            preBatchCmds
        )
        stepCounter++

        // Step 2..N: Mở trang Cài đặt thông báo của từng app (Zero-Animation) và tự động gạt công tắc tận mắt
        for (appDiag in targetApps) {
            if (cancelVisualAutomation) {
                log("⏹ Đã dừng quá trình tự động gạt công tắc tận mắt (Đã hoàn thành ${completed.size} app).", LogType.INFO)
                break
            }
            val pkg = appDiag.packageName
            val name = appDiag.appName

            val appStepState = _floatingWindowState.value.copy(
                currentStep = stepCounter,
                currentAppName = "$name (${completed.size + 1}/${targetApps.size})",
                currentPackageName = pkg,
                currentActionDetail = "👁️ Đang mở Cài đặt Thông báo của $name -> Tự gạt TẮT Báo nhẹ nhàng & BẬT Biểu ngữ..."
            )
            _floatingWindowState.value = appStepState
            com.example.core.service.SystemFloatingHudOverlay.updateAutomationHud(
                context = context,
                state = appStepState,
                onStopClick = { stopLiveFloatingAutomation() }
            )

            // Mở trực tiếp màn hình Cài đặt Thông báo của ứng dụng (không trễ hoạt ảnh) và dùng UIAutomator nén + Batched Tap gạt công tắc
            val uiReport = com.example.core.shell.UiAutomatorSwitchHelper.autoToggleAppNotificationScreen(
                shellEngine = shellEngine,
                pkg = pkg,
                appName = name,
                pressBackWhenDone = false,
                onProgressUpdate = { progressText ->
                    val progressState = _floatingWindowState.value.copy(
                        currentActionDetail = progressText
                    )
                    _floatingWindowState.value = progressState
                    com.example.core.service.SystemFloatingHudOverlay.updateAutomationHud(
                        context = context,
                        state = progressState,
                        onStopClick = { stopLiveFloatingAutomation() }
                    )
                },
                onLog = { msg -> log(msg, LogType.INFO) }
            )
            if (uiReport.openedSettingsOk) {
                shellEngine.markAppVisuallyUiToggled(pkg, true)
            }

            completed.add(name)
            _floatingWindowState.value = _floatingWindowState.value.copy(
                completedApps = completed.toList()
            )
            stepCounter++
        }

        // Ẩn cửa sổ nổi hệ thống và đưa người dùng quay lại giao diện MagicTune ngay lập tức
        com.example.core.service.SystemFloatingHudOverlay.hideAutomationHud(context)
        shellEngine.execute("am start --activity-clear-top --activity-single-top --activity-no-animation -n ${context.packageName}/com.example.MainActivity >/dev/null 2>&1 || true")

        _floatingWindowState.value = _floatingWindowState.value.copy(
            currentStep = totalSteps,
            currentAppName = "Bảo vệ Vĩnh Viễn",
            currentPackageName = context.packageName,
            currentActionDetail = "Đang cập nhật kết quả sau khi gạt công tắc tận mắt..."
        )
        refreshAppsList()
        refreshSetupStatus()
        refreshDeviceInfo()
        runDiagnosticScan()

        _floatingWindowState.value = _floatingWindowState.value.copy(
            isRunningAutomation = false,
            currentStep = totalSteps,
            currentAppName = "Hoàn tất (Đã tự động gạt ${completed.size} app)",
            currentActionDetail = "✅ Đã mở Cài đặt và tự động gạt tắt Báo nhẹ nhàng + bật Biểu ngữ tận mắt cho ${completed.size} ứng dụng!"
        )
        true
    }

    // -------------------------------------------------------------
    // 1-CHẠM SIÊU THIẾT LẬP 8-TRONG-1 TURBO v2.5 (SIÊU TỐC GỘP CỤM)
    // -------------------------------------------------------------
    suspend fun runOneClickSetupMaster(onlyPending: Boolean = true): Boolean = withContext(Dispatchers.IO) {
        refreshSetupStatus()
        val st = _setupStatus.value

        if (onlyPending && st.readyScore == 8) {
            log("🎉 TUYỆT VỜI: Tất cả 8/8 hạng mục đã được cấu hình hoàn hảo từ trước! Không cần chạy lại.", LogType.SUCCESS)
            return@withContext true
        }

        val modeLabel = if (onlyPending) "TURBO THÔNG MINH (CHỈ CHẠY CÁC MỤC CHƯA ĐẠT)" else "TOÀN DIỆN TẤT CẢ 8 HẠNG MỤC"
        log("⚡ [Turbo v2.5] BẮT ĐẦU SIÊU THIẾT LẬP $modeLabel...", LogType.INFO)

        val pkg = context.packageName
        val turboCmds = mutableListOf(
            // Tự cấp quyền nền tảng cho MagicTune ngay trong cùng 1 phiên
            "pm grant --user 0 $pkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || true",
            safeAppOpsCmd(pkg, "SYSTEM_ALERT_WINDOW", includeUid = true),
            safeAppOpsCmd(pkg, "GET_USAGE_STATS", includeUid = true),
            safeAppOpsCmd(pkg, "RUN_IN_BACKGROUND", includeUid = true),
            safeAppOpsCmd(pkg, "RUN_ANY_IN_BACKGROUND", includeUid = true),
            "dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true"
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            turboCmds.add("pm grant --user 0 $pkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || true")
        }

        // 1. Tiếng Việt & Múi giờ
        if (!onlyPending || !st.isVietnameseLocale || !st.isVietnamTimezone) {
            log("⚡ [1/8] Đưa cấu hình Tiếng Việt (vi-VN) & Giờ GMT+7 vào cụm Turbo...", LogType.INFO)
            turboCmds.addAll(
                listOf(
                    "settings put system system_locales vi-VN",
                    "settings put global auto_time 1",
                    "settings put system time_12_24 24",
                    "cmd locale set-locales vi-VN"
                )
            )
        } else {
            log("✓ [1/8] Tiếng Việt & Giờ GMT+7 đã đạt chuẩn (Bỏ qua)", LogType.INFO)
        }

        // 2. Google GMS & Đồng bộ
        if (!onlyPending || !st.gmsEnabled || !st.playStoreInstalled) {
            log("⚡ [2/8] Đưa cấu hình Bật Google GMS & Auto-Sync vào cụm Turbo...", LogType.INFO)
            try { ContentResolver.setMasterSyncAutomatically(true) } catch (_: Throwable) {}
            turboCmds.addAll(
                listOf(
                    "settings put secure google_service_switch 1",
                    "settings put global google_service_switch 1",
                    "settings put global auto_sync 1",
                    shellEngine.buildSafeMasterSyncCmd(true)
                )
            )
            if (shellEngine.isPackagePresentInRom("com.google.android.gms")) {
                turboCmds.add(shellEngine.buildSafeEnablePackageCmd("com.google.android.gms", 0))
                turboCmds.add("dumpsys deviceidle whitelist +com.google.android.gms >/dev/null 2>&1 || true")
                turboCmds.add("am set-standby-bucket --user 0 com.google.android.gms active >/dev/null 2>&1 || true")
            }
        } else {
            log("✓ [2/8] Google GMS & Đồng bộ danh bạ đã bật sẵn (Bỏ qua)", LogType.INFO)
        }

        // 3. Bàn phím Tiếng Việt & Khóa bàn phím Trung (chỉ chạy nếu bàn phím thực sự được cài trên máy)
        val hasLabanTurbo = isPackageInstalledFast("com.vng.inputmethod.labankey")
        val hasGboardTurbo = isPackageInstalledFast("com.google.android.inputmethod.latin")
        val baiduDisableCmd = if (isPackageInstalledFast("com.baidu.input_hihonor")) shellEngine.buildSafeDisablePackageCmd("com.baidu.input_hihonor") else null
        if (!onlyPending || !st.vietnameseKeyboardDefault) {
            when {
                hasLabanTurbo -> {
                    log("⚡ [3/8] Đưa cấu hình Laban Key & Đóng băng phím Baidu vào cụm Turbo...", LogType.INFO)
                    turboCmds.addAll(
                        listOfNotNull(
                            "dumpsys deviceidle whitelist +com.vng.inputmethod.labankey >/dev/null 2>&1 || true",
                            "ime enable com.vng.inputmethod.labankey/.LabanKey >/dev/null 2>&1 || true",
                            "ime set com.vng.inputmethod.labankey/.LabanKey >/dev/null 2>&1 || true",
                            baiduDisableCmd
                        )
                    )
                }
                hasGboardTurbo -> {
                    log("⚡ [3/8] Đưa cấu hình Gboard & Đóng băng phím Baidu vào cụm Turbo...", LogType.INFO)
                    turboCmds.addAll(
                        listOfNotNull(
                            "dumpsys deviceidle whitelist +com.google.android.inputmethod.latin >/dev/null 2>&1 || true",
                            "ime enable com.google.android.inputmethod.latin/com.android.inputmethod.latin.LatinIME >/dev/null 2>&1 || true",
                            "ime set com.google.android.inputmethod.latin/com.android.inputmethod.latin.LatinIME >/dev/null 2>&1 || true",
                            baiduDisableCmd
                        )
                    )
                }
                else -> {
                    log("ℹ️ [3/8] Máy chưa cài Laban Key hay Gboard -> Bỏ qua đổi bàn phím để tránh lỗi thiếu gói.", LogType.INFO)
                }
            }
        } else {
            log("✓ [3/8] Bàn phím Gõ Tiếng Việt đã sẵn sàng (Bỏ qua)", LogType.INFO)
        }

        // 4. Sửa danh bạ +84 & Chấm than Wi-Fi
        if (!onlyPending || !st.callerId84Fixed || !st.captivePortalGlobal) {
            log("⚡ [4/8] Đưa cấu hình Sửa Danh bạ +84, Xóa chấm than Wi-Fi & 5G/VoLTE vào cụm Turbo...", LogType.INFO)
            turboCmds.addAll(
                listOf(
                    "settings put system min_match 7",
                    "settings put global min_match 7",
                    "settings put global captive_portal_mode 1",
                    "settings put global captive_portal_https_url \"https://connectivitycheck.gstatic.com/generate_204\"",
                    "settings put global captive_portal_http_url \"http://connectivitycheck.gstatic.com/generate_204\"",
                    "settings put system hw_volte_user_switch 1",
                    "settings put global fiveg_user_switch 1"
                )
            )
        } else {
            log("✓ [4/8] Danh bạ +84 & Xóa chấm than Wi-Fi đã hoàn thành (Bỏ qua)", LogType.INFO)
        }

        // 5. Dọn sạch giao diện chữ Trung & Tắt YOYO
        if (!onlyPending || !st.chineseUiCleaned) {
            log("⚡ [5/8] Đưa cấu hình Dọn sạch HiBoard, Honor Search, Tạp chí khóa & YOYO vào cụm Turbo...", LogType.INFO)
            turboCmds.add("settings put secure hiboard_switch 0")
            turboCmds.add("settings put system hiboard_switch 0")
            for (uiPkg in listOf("com.hihonor.hiboard", "com.hihonor.search", "com.hihonor.magazinesettings")) {
                if (isPackageInstalledFast(uiPkg)) turboCmds.add(shellEngine.buildSafeDisablePackageCmd(uiPkg))
            }
            turboCmds.add("settings put system auto_download_magazine_wifi 0")
            if (!com.example.core.service.SystemFloatingHudOverlay.isYoyoCoexistModeEnabled(context)) {
                turboCmds.addAll(
                    listOf(
                        "settings put secure navigation_bar_wakeup_yoyo 0",
                        "settings put secure yoyo_navigation_bar_wakeup 0"
                    )
                )
            }
        } else {
            log("✓ [5/8] HiBoard & chữ Trung đã được dọn sạch (Bỏ qua)", LogType.INFO)
        }

        // 6. Định vị GPS độ nhạy cao & Đặc trị Timestamp Camera
        if (!onlyPending || !st.gpsOptimized) {
            log("⚡ [6/8] Đưa cấu hình GPS độ nhạy cao, A-GPS Google & Timestamp Camera vào cụm Turbo...", LogType.INFO)
            turboCmds.addAll(
                listOf(
                    "settings put secure location_mode 3",
                    "settings put secure location_providers_allowed +gps,+network",
                    "settings put global supl_host supl.google.com",
                    "settings put global supl_port 7275",
                    "settings put global assisted_gps_enabled 1",
                    "settings put global wifi_scan_throttle_enabled 1",
                    "settings put secure location_nlp_pkg com.google.android.gms",
                    "settings put global location_nlp_pkg com.google.android.gms",
                    "settings put secure google_location_accuracy_enabled 1"
                )
            )
            for (locPkg in listOf("com.amap.android.ams", "com.amap.android.location")) {
                if (isPackageInstalledFast(locPkg)) turboCmds.add(shellEngine.buildSafeDisablePackageCmd(locPkg))
            }
            if (isPackageInstalledFast("com.google.android.gms")) {
                turboCmds.add("dumpsys deviceidle whitelist +com.google.android.gms >/dev/null 2>&1 || true")
                turboCmds.add(safeAppOpsCmd("com.google.android.gms", "RUN_IN_BACKGROUND"))
                turboCmds.add(safeAppOpsCmd("com.google.android.gms", "FINE_LOCATION"))
                turboCmds.add(safeAppOpsCmd("com.google.android.gms", "COARSE_LOCATION"))
            }
            shellEngine.setPersistedSetting("global", "supl_host", "supl.google.com")
            shellEngine.setPersistedSetting("secure", "location_mode", "3")
            shellEngine.setPersistedSetting("secure", "honor_gps_fixed", "1")
        } else {
            log("✓ [6/8] Định vị GPS & Google Location đã tối ưu (Bỏ qua)", LogType.INFO)
        }

        // 7. Chặn Chợ App Honor tự cập nhật đè
        if (!onlyPending || !st.honorMarketUpdateBlocked) {
            log("⚡ [7/8] Đưa cấu hình Chặn Chợ App Honor tự cập nhật vào cụm Turbo...", LogType.INFO)
            turboCmds.add("settings put global auto_update_app 0")
            turboCmds.add("settings put secure auto_update_app 0")
            if (isPackageInstalledFast("com.hihonor.appmarket")) {
                turboCmds.add(safeAppOpsCmd("com.hihonor.appmarket", "REQUEST_INSTALL_PACKAGES", "ignore"))
                turboCmds.add(safeAppOpsCmd("com.hihonor.appmarket", "RUN_IN_BACKGROUND", "ignore"))
            }
        } else {
            log("✓ [7/8] Chặn Chợ Honor tự cập nhật đã hoàn thành (Bỏ qua)", LogType.INFO)
        }

        // 8. Bảo vệ Shizuku Bất Tử & Khóa đánh thức YOYO
        turboCmds.addAll(
            listOf(
                "device_config set_sync_disabled_for_tests persistent",
                "device_config put activity_manager max_phantom_processes 2147483647",
                "settings put global settings_enable_monitor_phantom_procs false",
                "settings put global adb_charging_only 0",
                "settings put secure adb_TakeEffectInChargingOnly 0",
                "settings put secure navigation_bar_wakeup_yoyo 0",
                "settings put secure yoyo_navigation_bar_wakeup 0",
                "settings put system navigation_bar_wakeup_yoyo 0"
            )
        )
        if (isPackageInstalledFast("moe.shizuku.privileged.api")) {
            turboCmds.add("dumpsys deviceidle whitelist +moe.shizuku.privileged.api >/dev/null 2>&1 || true")
            turboCmds.add(safeAppOpsCmd("moe.shizuku.privileged.api", "RUN_IN_BACKGROUND", includeUid = true))
            turboCmds.add(safeAppOpsCmd("moe.shizuku.privileged.api", "RUN_ANY_IN_BACKGROUND", includeUid = true))
        }

        var allOk = runVerifiedBatch("Siêu Thiết Lập 8-trong-1 Turbo v2.5", turboCmds)

        // Mở 100% Thông báo & Quyền cho các ứng dụng gặp vấn đề
        if (!onlyPending || !st.powerGeniusRemoved || !st.customAppSoundsEnabled) {
            val notifOk = optimizeAllApps()
            if (!notifOk) allOk = false
        } else {
            log("✓ [8/8] Thông báo, biểu ngữ & Doze pin đã đạt chuẩn (Bỏ qua)", LogType.INFO)
        }

        refreshSetupStatus()
        refreshDeviceInfo()
        runDiagnosticScan()
        if (allOk) {
            log("🎉 HOÀN TẤT SIÊU THIẾT LẬP TURBO v2.5 THÀNH CÔNG! Thiết bị đã đạt chuẩn Quốc Tế.", LogType.SUCCESS)
        } else {
            log("⚠️ KẾT THÚC THIẾT LẬP: Có mục chưa thành công (Đã báo chi tiết ở trên).", LogType.ERROR)
        }
        allOk
    }

    suspend fun setupVietnameseLanguage(): Boolean = withContext(Dispatchers.IO) {
        log("🌐 Đang thiết lập Tiếng Việt (vi-VN), Múi giờ Asia/Ho_Chi_Minh & 24h...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Tiếng Việt & Múi giờ GMT+7",
            listOf(
                "settings put system system_locales vi-VN",
                "settings put global auto_time 1",
                "settings put system time_12_24 24",
                "cmd locale set-locales vi-VN"
            )
        )
        refreshSetupStatus()
        ok
    }

    suspend fun setupGoogleAndSync(): Boolean = withContext(Dispatchers.IO) {
        log("📦 Đang bật Google GMS & Đồng bộ Danh bạ Google...", LogType.INFO)
        try { ContentResolver.setMasterSyncAutomatically(true) } catch (_: Throwable) {}
        val cmds = mutableListOf(
            "settings put secure google_service_switch 1",
            "settings put global google_service_switch 1",
            "settings put global auto_sync 1",
            shellEngine.buildSafeMasterSyncCmd(true)
        )
        if (shellEngine.isPackagePresentInRom("com.google.android.gms")) {
            cmds.add(shellEngine.buildSafeEnablePackageCmd("com.google.android.gms", 0))
            cmds.add("dumpsys deviceidle whitelist +com.google.android.gms >/dev/null 2>&1 || true")
            cmds.add("am set-standby-bucket --user 0 com.google.android.gms active >/dev/null 2>&1 || true")
        }
        val ok = runVerifiedBatch("Bật Google GMS & Đồng bộ Danh bạ", cmds)
        refreshSetupStatus()
        ok
    }

    suspend fun fixCallerIdAndWifi(): Boolean = withContext(Dispatchers.IO) {
        log("📶 Đang sửa Danh bạ +84, Xóa chấm than Wi-Fi & Mở 5G/VoLTE...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Fix Danh bạ +84, Wi-Fi & 5G/VoLTE",
            listOf(
                "settings put system min_match 7",
                "settings put global min_match 7",
                "settings put global captive_portal_mode 1",
                "settings put global captive_portal_https_url \"https://connectivitycheck.gstatic.com/generate_204\"",
                "settings put global captive_portal_http_url \"http://connectivitycheck.gstatic.com/generate_204\"",
                "settings put system hw_volte_user_switch 1",
                "settings put global fiveg_user_switch 1"
            )
        )
        refreshSetupStatus()
        ok
    }

    suspend fun cleanChineseUi(): Boolean = withContext(Dispatchers.IO) {
        log("🧹 Đang dọn sạch chữ Trung: HiBoard vuốt trái, Honor Search, Tạp chí khóa & Tắt YOYO thanh điều hướng...", LogType.INFO)
        val cmds = mutableListOf(
            "settings put secure hiboard_switch 0",
            "settings put system hiboard_switch 0",
            "settings put system auto_download_magazine_wifi 0",
            "settings put secure navigation_bar_wakeup_yoyo 0",
            "settings put secure yoyo_navigation_bar_wakeup 0"
        )
        for (uiPkg in listOf("com.hihonor.hiboard", "com.hihonor.search", "com.hihonor.magazinesettings")) {
            if (isPackageInstalledFast(uiPkg)) cmds.add(shellEngine.buildSafeDisablePackageCmd(uiPkg))
        }
        val ok = runVerifiedBatch("Dọn sạch chữ Trung (HiBoard, Search, Magazine, YOYO)", cmds)
        refreshSetupStatus()
        ok
    }

/**
     * Thay thế tìm kiếm mặc định Honor Search vuốt từ màn hình chính:
     * - Vô hiệu hóa ứng dụng tìm kiếm giật lag/quảng cáo của Honor (com.hihonor.search)
     * - Cấu hình mở trợ lý số / tìm kiếm Google hoặc các công cụ tìm kiếm chuẩn (Google / Gesture Search)
     */
    suspend fun replaceHonorSearch(disable: Boolean): Boolean = withContext(Dispatchers.IO) {
        val actionText = if (disable) "Tắt Honor Search & Chuyển sang tìm kiếm ứng dụng Google / Gesture Search" else "Khôi phục Honor Search gốc"
        log("🔍 Đang $actionText...", LogType.INFO)
        val cmds = if (disable) {
            listOfNotNull(
                if (isPackageInstalledFast("com.hihonor.search")) shellEngine.buildSafeDisablePackageCmd("com.hihonor.search") else null,
                "settings put secure honor_search_disabled 1",
                "settings put secure hiboard_search_switch 0",
                "settings put system hiboard_search_switch 0"
            )
        } else {
            listOfNotNull(
                if (shellEngine.isPackagePresentInRom("com.hihonor.search")) shellEngine.buildSafeEnablePackageCmd("com.hihonor.search", 0) else null,
                "settings put secure honor_search_disabled 0",
                "settings put secure hiboard_search_switch 1",
                "settings put system hiboard_search_switch 1"
            )
        }
        val ok = runVerifiedBatch(actionText, cmds)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun blockHonorMarket(): Boolean = withContext(Dispatchers.IO) {
        log("🔒 Đang chặn Chợ App Honor tự động cập nhật đè app tiếng Việt (Giữ nguyên Cập nhật MagicOS)...", LogType.INFO)
        val cmds = mutableListOf(
            "settings put global auto_update_app 0",
            "settings put secure auto_update_app 0"
        )
        if (isPackageInstalledFast("com.hihonor.appmarket")) {
            cmds.add(safeAppOpsCmd("com.hihonor.appmarket", "REQUEST_INSTALL_PACKAGES", "ignore"))
            cmds.add(safeAppOpsCmd("com.hihonor.appmarket", "RUN_IN_BACKGROUND", "ignore"))
        }
        if (shellEngine.isPackagePresentInRom("com.hihonor.ouc")) {
            cmds.add(shellEngine.buildSafeEnablePackageCmd("com.hihonor.ouc", 0))
        }
        if (shellEngine.isPackagePresentInRom("com.hihonor.android.hwouc")) {
            cmds.add(shellEngine.buildSafeEnablePackageCmd("com.hihonor.android.hwouc", 0))
        }
        val ok = runVerifiedBatch("Chặn Chợ App Honor Tự Cập Nhật", cmds)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun unblockHonorMarket(): Boolean = withContext(Dispatchers.IO) {
        log("🔓 Đang mở lại Tự Động Cập Nhật App trong Chợ Honor & Google Play...", LogType.INFO)
        val cmds = mutableListOf(
            "settings put global auto_update_app 1",
            "settings put secure auto_update_app 1"
        )
        if (shellEngine.isPackagePresentInRom("com.hihonor.appmarket")) {
            cmds.add(shellEngine.buildSafeEnablePackageCmd("com.hihonor.appmarket", 0))
            cmds.add("cmd appops reset --user 0 com.hihonor.appmarket >/dev/null 2>&1 || cmd appops reset com.hihonor.appmarket >/dev/null 2>&1 || true")
        }
        val ok = runVerifiedBatch("Mở lại Tự Động Cập Nhật App", cmds)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        refreshAppsList()
        ok
    }

    suspend fun applyThermalCooling(): Boolean = withContext(Dispatchers.IO) {
        val result = com.example.core.perf.SafeThermalRelief.enable(context)
        log(result.message, if (result.success) LogType.SUCCESS else LogType.ERROR)
        refreshTuneStatus()
        result.success
    }

    suspend fun setupKeyboard(): Boolean = withContext(Dispatchers.IO) {
        log("⌨️ Đang thiết lập bàn phím Tiếng Việt & đóng băng phím Trung...", LogType.INFO)
        val hasLabanKey = isPackageInstalledFast("com.vng.inputmethod.labankey")
        val hasGboard = isPackageInstalledFast("com.google.android.inputmethod.latin")
        val cmds = mutableListOf<String>()
        when {
            hasLabanKey -> {
                cmds.add("dumpsys deviceidle whitelist +com.vng.inputmethod.labankey >/dev/null 2>&1 || true")
                cmds.add("ime enable com.vng.inputmethod.labankey/.LabanKey")
                cmds.add("ime set com.vng.inputmethod.labankey/.LabanKey")
                cmds.add("pm disable-user --user 0 com.baidu.input_hihonor >/dev/null 2>&1 || true")
            }
            hasGboard -> {
                cmds.add("dumpsys deviceidle whitelist +com.google.android.inputmethod.latin >/dev/null 2>&1 || true")
                cmds.add("ime enable com.google.android.inputmethod.latin/com.android.inputmethod.latin.LatinIME")
                cmds.add("ime set com.google.android.inputmethod.latin/com.android.inputmethod.latin.LatinIME")
                cmds.add("pm disable-user --user 0 com.baidu.input_hihonor >/dev/null 2>&1 || true")
            }
            else -> {
                log("⚠️ Chưa cài Laban Key hay Gboard trên máy nên giữ lại bàn phím hệ thống để tránh mất bàn phím gõ chữ!", LogType.INFO)
                return@withContext false
            }
        }
        val ok = runVerifiedBatch("Thiết lập bàn phím Tiếng Việt", cmds)
        refreshSetupStatus()
        ok
    }

    suspend fun setupGpsVietnam(): Boolean = withContext(Dispatchers.IO) {
        log("📍 Bắt đầu Đặc Trị Định Vị GPS & Fix Triệt Để Timestamp Camera trên Honor (Đặc biệt cho Honor Magic 6 / Magic 7 - MagicOS 8.0 & 9.0)...", LogType.INFO)

        // Tự động dò tìm mọi phiên bản ứng dụng Timestamp Camera / Geotag Camera đang cài trên máy
        val knownTimestampPkgs = mutableSetOf(
            "com.jeyluta.timestampcamerafree",
            "com.jeyluta.timestampcamera",
            "com.jeyluta.timestampcamerapro",
            "com.jeyluta.timestampcameraenterprise",
            "com.darinsoft.timestampcamera",
            "com.camera.timestamp",
            "com.gpsmapcamera.geotagginglocationonphoto",
            "com.gpsmapcamera.gpsmaplocationonphoto",
            "com.app.geotagcamera",
            "com.timestampcamera.free",
            "com.jkfantasy.gpsmapcamera",
            "com.SimpleMobilePhotoResizer"
        )
        try {
            val pm = context.packageManager
            val installed = pm.getInstalledPackages(0)
            for (p in installed) {
                val pkgName = p.packageName ?: continue
                val lower = pkgName.lowercase()
                if (lower.contains("timestamp") || lower.contains("geotag") || lower.contains("gpsmap") || lower.contains("mapcamera")) {
                    knownTimestampPkgs.add(pkgName)
                }
            }
        } catch (_: Exception) {}

        val selfPkg = context.packageName
        val whitelistLocationThrottlePkgs = (listOf(
            selfPkg,
            "com.google.android.gms",
            "com.google.android.apps.maps",
            "com.grabtaxi.passenger",
            "com.beegroup.be"
        ) + knownTimestampPkgs).distinct().joinToString(",")

        // Danh sách toàn bộ các dịch vụ định vị nội địa Trung Quốc gây lệch tọa độ Mars GCJ-02 (500m-2km) & lưu chết vị trí cũ:
        // ĐẶC BIỆT TRÊN HONOR MAGIC 6 & MAGIC 7 (MagicOS 8.0 / 9.0): Gói định vị Cao Đức ngầm có tên là `com.amap.android.ams`!
        val chineseLocationPkgs = listOf(
            "com.amap.android.ams",
            "com.amap.android.location",
            "com.baidu.map.location",
            "com.baidu.location.fused",
            "com.tencent.android.location"
        )

        val commands = mutableListOf(
            // 0. Tự động cấp full quyền vị trí chính xác cho chính MagicTune để khóa nóng tọa độ thực WGS-84 cho toàn hệ thống
            "pm grant $selfPkg android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1 || true",
            "pm grant $selfPkg android.permission.ACCESS_COARSE_LOCATION >/dev/null 2>&1 || true",
            "cmd appops set $selfPkg FINE_LOCATION allow >/dev/null 2>&1 || true",
            "cmd appops set $selfPkg COARSE_LOCATION allow >/dev/null 2>&1 || true",
            "cmd appops set $selfPkg FINE_LOCATION_SOURCE allow >/dev/null 2>&1 || true",
            "cmd appops set $selfPkg MONITOR_HIGH_POWER_LOCATION allow >/dev/null 2>&1 || true",

            // 1. Xóa sạch dữ liệu cache tọa độ cũ (GCJ-02 / trạm phát sóng cũ) và VÔ HIỆU HÓA định vị Cao Đức `com.amap.android.ams` trên Honor Magic 6 & Magic 7
        )

        for (cnPkg in chineseLocationPkgs) {
            commands.add("pm clear $cnPkg >/dev/null 2>&1 || true")
            commands.add("cmd appops set $cnPkg FINE_LOCATION ignore >/dev/null 2>&1 || true")
            commands.add("cmd appops set $cnPkg COARSE_LOCATION ignore >/dev/null 2>&1 || true")
            commands.add("cmd appops set $cnPkg MONITOR_LOCATION ignore >/dev/null 2>&1 || true")
            commands.add("cmd appops set $cnPkg MONITOR_HIGH_POWER_LOCATION ignore >/dev/null 2>&1 || true")
            commands.add("cmd appops set $cnPkg RUN_IN_BACKGROUND ignore >/dev/null 2>&1 || true")
            commands.add("cmd appops set $cnPkg RUN_ANY_IN_BACKGROUND ignore >/dev/null 2>&1 || true")
            commands.add("am force-stop $cnPkg >/dev/null 2>&1 || true")
            commands.add("pm disable-user --user 0 $cnPkg >/dev/null 2>&1 || true")
        }

        commands.addAll(
            listOf(
                // 2. Làm mới LocationManagerService (Tắt -> Bật nhanh để xả sạch tọa độ LastKnownLocation bị kẹt trong RAM của MagicOS)
                "cmd location set-location-enabled false >/dev/null 2>&1 || true",
                "cmd location set-location-enabled true >/dev/null 2>&1 || true",
                "settings put secure location_mode 3",
                "settings put secure location_providers_allowed +gps,+network",

                // 3. Whitelist GPS đích danh cho Maps, GMS, Gọi xe & Timestamp Camera (KHÔNG tắt throttle toàn máy để tránh hao pin/nóng modem Wi-Fi/GPS 24/7)
                "settings delete global location_gnss_raw_meas_full_tracking >/dev/null 2>&1 || true",
                "settings delete global location_background_throttle_interval_ms >/dev/null 2>&1 || true",
                "settings delete global location_background_throttle_proximity_alert_interval_ms >/dev/null 2>&1 || true",
                "settings put global location_background_throttle_package_whitelist \"$whitelistLocationThrottlePkgs\"",
                "device_config delete location location_background_throttle_interval_ms >/dev/null 2>&1 || true",
                "device_config delete location min_location_request_interval_ms >/dev/null 2>&1 || true",
                "settings put global gnss_satellite_blocklist \"\"",
                "settings put secure location_changer 0",
                "settings put secure location_fuzzy_enabled 0",

                // 4. Ép hệ thống trỏ Network Location Provider (NLP) & Geocoder sang Google Play Services (Chuẩn tọa độ quốc tế WGS-84)
                // Lưu ý: Không ghi location_nlp_pkg / location_fuzzy_enabled vào namespace `system` vì Android 11-15 SettingsProvider sẽ từ chối
                "settings put secure location_nlp_pkg com.google.android.gms",
                "settings put global location_nlp_pkg com.google.android.gms",
                "settings put secure location_Global_nlp_pkg com.google.android.gms",
                "settings put global supl_host supl.google.com",
                "settings put global supl_port 7275",
                "settings put global assisted_gps_enabled 1",

                // 5. Giữ tiết kiệm pin quét Wi-Fi/BLE ngầm cho app rác, chỉ ưu tiên app định vị trong whitelist
                "settings put global wifi_scan_always_enabled 0",
                "settings put global ble_scan_always_enabled 0",
                "settings put global wifi_scan_throttle_enabled 1",

                // 6. Kích hoạt cờ Google Location Accuracy & Google Geocoder chính xác
                "settings put secure google_location_accuracy_enabled 1",
                "settings put secure google_location_accuracy 1",
                "settings put secure nlp_mode 1",

                // 7. Xóa sạch Cache vệ tinh & trạm phát sóng cũ (Khu B) và ép nạp lại lịch thiên văn vệ tinh XTRA mới nhất (Khu A)
                "cmd location send-extra-command gps delete_aiding_data >/dev/null 2>&1 || true",
                "cmd location send-extra-command gps force_xtra_injection >/dev/null 2>&1 || true",
                "cmd location send-extra-command gps force_time_injection >/dev/null 2>&1 || true",

                // 8. Cấp full quyền Android 14/15 (Bao gồm NEARBY_WIFI_DEVICES & BLUETOOTH_SCAN trên Magic 6/7) cho Google Play Services (GMS)
                "dumpsys deviceidle whitelist +com.google.android.gms >/dev/null 2>&1 || true",
                "cmd activity set-standby-bucket com.google.android.gms active >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms FINE_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms FINE_LOCATION_SOURCE allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms COARSE_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms MONITOR_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms MONITOR_HIGH_POWER_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms NEARBY_WIFI_DEVICES allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms BLUETOOTH_SCAN allow >/dev/null 2>&1 || true",
                "pm grant com.google.android.gms android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1 || true",
                "pm grant com.google.android.gms android.permission.ACCESS_COARSE_LOCATION >/dev/null 2>&1 || true",
                "pm grant com.google.android.gms android.permission.ACCESS_BACKGROUND_LOCATION >/dev/null 2>&1 || true",
                "pm grant com.google.android.gms android.permission.NEARBY_WIFI_DEVICES >/dev/null 2>&1 || true",
                "pm grant com.google.android.gms android.permission.BLUETOOTH_SCAN >/dev/null 2>&1 || true",
                "pm grant com.google.android.gms android.permission.ACTIVITY_RECOGNITION >/dev/null 2>&1 || true",

                // 9. Chống MagicOS đóng băng / diệt ngầm Google Maps
                "dumpsys deviceidle whitelist +com.google.android.apps.maps >/dev/null 2>&1 || true",
                "cmd activity set-standby-bucket com.google.android.apps.maps active >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps FINE_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps FINE_LOCATION_SOURCE allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps COARSE_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps MONITOR_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps MONITOR_HIGH_POWER_LOCATION allow >/dev/null 2>&1 || true",
                "pm grant com.google.android.apps.maps android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1 || true",
                "pm grant com.google.android.apps.maps android.permission.ACCESS_COARSE_LOCATION >/dev/null 2>&1 || true",
                "pm grant com.google.android.apps.maps android.permission.ACCESS_BACKGROUND_LOCATION >/dev/null 2>&1 || true"
            )
        )

        // 10. ĐẶC TRỊ CẤP ĐỦ 100% QUYỀN CHÍNH XÁC TUYỆT ĐỐI (TẮT VỊ TRÍ GẦN ĐÚNG / FUZZY LOCATION CỦA MAGIC 6 & 7) CHO TIMESTAMP CAMERA
        var fixedTimestampCount = 0
        for (pkg in knownTimestampPkgs) {
            if (isPackageInstalledFast(pkg)) {
                fixedTimestampCount++
                commands.add("dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true")
                commands.add("cmd activity set-standby-bucket $pkg active >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg FINE_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg FINE_LOCATION_SOURCE allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg COARSE_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg MONITOR_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg MONITOR_HIGH_POWER_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg NEARBY_WIFI_DEVICES allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg BLUETOOTH_SCAN allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg GPS allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg CAMERA allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg RECORD_AUDIO allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg ACCESS_MEDIA_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg READ_EXTERNAL_STORAGE allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg WRITE_EXTERNAL_STORAGE allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg MANAGE_EXTERNAL_STORAGE allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || true")

                commands.add("pm grant $pkg android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.ACCESS_COARSE_LOCATION >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.ACCESS_BACKGROUND_LOCATION >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.NEARBY_WIFI_DEVICES >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.BLUETOOTH_SCAN >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.ACCESS_MEDIA_LOCATION >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.CAMERA >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.READ_EXTERNAL_STORAGE >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.WRITE_EXTERNAL_STORAGE >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.READ_MEDIA_IMAGES >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.READ_MEDIA_VIDEO >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || true")

                // Khóa cờ quyền Vị trí chính xác (Chống MagicOS 8/9 trên Magic 6 & 7 tự hạ xuống Vị trí gần đúng / Fuzzy Location)
                commands.add("pm set-permission-flags $pkg android.permission.ACCESS_FINE_LOCATION user-set user-fixed >/dev/null 2>&1 || true")
                commands.add("pm set-permission-flags $pkg android.permission.ACCESS_COARSE_LOCATION user-set user-fixed >/dev/null 2>&1 || true")

                // Xóa bộ đệm địa chỉ cũ (Cache Khu B) của Timestamp Camera và đóng tiến trình cũ để ép nạp tọa độ mới
                commands.add("rm -rf /sdcard/Android/data/$pkg/cache/* >/dev/null 2>&1 || true")
                commands.add("am force-stop $pkg >/dev/null 2>&1 || true")
            }
        }

        // 11. Tự động kiểm tra và whitelist các app gọi xe / giao đồ ăn
        val rideApps = listOf(
            "com.grabtaxi.passenger",
            "com.beegroup.be",
            "com.gojek.app",
            "com.gsm.customer",
            "com.shopee.food",
            "com.garena.delivery"
        )
        for (pkg in rideApps) {
            if (isPackageInstalledFast(pkg)) {
                commands.add("dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true")
                commands.add("cmd activity set-standby-bucket $pkg active >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg FINE_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg FINE_LOCATION_SOURCE allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg COARSE_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg MONITOR_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg MONITOR_HIGH_POWER_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.ACCESS_COARSE_LOCATION >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.ACCESS_BACKGROUND_LOCATION >/dev/null 2>&1 || true")
            }
        }

        val ok = runVerifiedBatch("Đặc Trị Định Vị GPS & Timestamp Camera (Honor Magic 6 / Magic 7)", commands)
        shellEngine.setPersistedSetting("global", "supl_host", "supl.google.com")
        shellEngine.setPersistedSetting("secure", "location_mode", "3")
        shellEngine.setPersistedSetting("secure", "honor_gps_fixed", "1")

        // 12. KÍCH HOẠT BỘ KHÓA NÓNG TỌA ĐỘ THỰC WGS-84 (Ghi đè tọa độ mới nhất vào RAM của LocationManagerService ngay lập tức)
        warmupHardwareAndFusedGpsLock()

        refreshSetupStatus()
        refreshTuneStatus()
        refreshDeviceInfo()
        val tsNote = if (fixedTimestampCount > 0) " Đã khóa Vị trí chính xác tuyệt đối & xóa cache vị trí cũ cho $fixedTimestampCount app Timestamp Camera!" else ""
        log("🎉 ĐÃ FIX XONG ĐỊNH VỊ GPS & TIMESTAMP CAMERA TRÊN HONOR MAGIC 6/7: Đã gỡ bỏ gói định vị Cao Đức ngầm (com.amap.android.ams), tắt Vị trí gần đúng (Fuzzy Location), bật Full GNSS L1+L5 và khóa nóng tọa độ thực WGS-84!$tsNote", LogType.SUCCESS)
        ok
    }

    suspend fun refreshGpsSatellites(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang xóa bộ đệm vị trí cũ (chống kẹt vị trí Khu B trên Honor Magic 6/7) và ép nạp lại vệ tinh A-GPS thời gian thực...", LogType.INFO)
        val commands = mutableListOf(
            "pm clear com.amap.android.ams >/dev/null 2>&1 || true",
            "pm disable-user --user 0 com.amap.android.ams >/dev/null 2>&1 || true",
            "pm clear com.amap.android.location >/dev/null 2>&1 || true",
            "pm disable-user --user 0 com.amap.android.location >/dev/null 2>&1 || true",
            "pm clear com.baidu.map.location >/dev/null 2>&1 || true",
            "pm disable-user --user 0 com.baidu.map.location >/dev/null 2>&1 || true",
            "settings delete global location_gnss_raw_meas_full_tracking >/dev/null 2>&1 || true",
            "settings delete global location_background_throttle_interval_ms >/dev/null 2>&1 || true",
            "settings put global wifi_scan_throttle_enabled 1",
            "cmd location set-location-enabled false >/dev/null 2>&1 || true",
            "cmd location set-location-enabled true >/dev/null 2>&1 || true",
            "settings put secure location_mode 3",
            "cmd location send-extra-command gps delete_aiding_data >/dev/null 2>&1 || true",
            "cmd location send-extra-command gps force_xtra_injection >/dev/null 2>&1 || true",
            "cmd location send-extra-command gps force_time_injection >/dev/null 2>&1 || true"
        )
        val tsPkgs = listOf(
            "com.jeyluta.timestampcamerafree",
            "com.jeyluta.timestampcamera",
            "com.jeyluta.timestampcamerapro",
            "com.darinsoft.timestampcamera",
            "com.camera.timestamp",
            "com.gpsmapcamera.geotagginglocationonphoto"
        )
        for (pkg in tsPkgs) {
            if (isPackageInstalledFast(pkg)) {
                commands.add("rm -rf /sdcard/Android/data/$pkg/cache/* >/dev/null 2>&1 || true")
                commands.add("am force-stop $pkg >/dev/null 2>&1 || true")
            }
        }
        val ok = runVerifiedBatch("Nạp Lại Vệ Tinh GPS & Xóa Cache Vị Trí Cũ", commands)
        shellEngine.setPersistedSetting("global", "supl_host", "supl.google.com")
        shellEngine.setPersistedSetting("secure", "location_mode", "3")
        shellEngine.setPersistedSetting("secure", "honor_gps_fixed", "1")
        warmupHardwareAndFusedGpsLock()
        refreshSetupStatus()
        refreshTuneStatus()
        log("🛰️ Đã làm mới vệ tinh A-GPS, tắt Cao Đức AMap (com.amap.android.ams) và khóa nóng tọa độ mới cho Timestamp Camera thành công!", LogType.SUCCESS)
        ok
    }

    /**
     * Khóa nóng tọa độ thực WGS-84 (Live Hardware GPS + Fused Location Warmup):
     * Đánh thức ngay chip GPS băng tần kép L1+L5 và Fused Provider để hệ điều hành ghi đè tọa độ mới nhất
     * vào bộ nhớ RAM `LastKnownLocation` của `LocationManagerService` trước khi người dùng mở Timestamp Camera.
     */
    @Suppress("MissingPermission")
    private fun warmupHardwareAndFusedGpsLock() {
        try {
            val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
            mainHandler.post {
                try {
                    val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return@post
                    val listener = object : android.location.LocationListener {
                        override fun onLocationChanged(location: android.location.Location) {
                            // Ngắt ngay lập tức khi đã khóa được tọa độ đầu tiên để chip GPS không xả pin
                            try { lm.removeUpdates(this) } catch (_: Throwable) {}
                        }
                        @Deprecated("Deprecated in Java")
                        override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
                        override fun onProviderEnabled(provider: String) {}
                        override fun onProviderDisabled(provider: String) {}
                    }
                    val providers = listOf("gps", "fused", "network")
                    for (p in providers) {
                        try {
                            if (lm.isProviderEnabled(p)) {
                                lm.requestLocationUpdates(p, 1000L, 5f, listener, android.os.Looper.getMainLooper())
                            }
                        } catch (_: Throwable) {}
                    }
                    // Tối đa 6 giây (thay vì 25 giây) để triệt tiêu tải điện cho chip GPS
                    mainHandler.postDelayed({
                        try {
                            lm.removeUpdates(listener)
                        } catch (_: Throwable) {}
                    }, 6_000L)
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    // -------------------------------------------------------------
    // FIX THÔNG BÁO THÔNG MINH (KIỂM TRA TRƯỚC - CHỈ SỬA APP GẶP LỖI)
    // -------------------------------------------------------------
    suspend fun optimizeAllApps(): Boolean = withContext(Dispatchers.IO) {
        log("🔍 Đang kiểm tra danh sách ứng dụng gặp lỗi thông báo / thiếu quyền trước khi sửa (Không chạy thừa trên app đã tốt)...", LogType.INFO)
        val scan = runDiagnosticScan()

        val unfixedCauses = scan.systemDelayCauses.filter { !it.isFixed }
        val problematicApps = scan.gentleAndBannerApps.filter {
            it.hasAnyNotificationIssue || it.hasAnyPermissionIssue
        }

        if (unfixedCauses.isEmpty() && problematicApps.isEmpty()) {
            log(
                "🎉 KIỂM TRA HOÀN TẤT: Toàn bộ ${scan.allScannedAppsCount} ứng dụng và hệ thống đều đã hoạt động chuẩn 100% (Đã bật đầy đủ biểu ngữ, tắt báo nhẹ nhàng & đủ quyền chạy ngầm)! Không có app nào bị lỗi cần sửa.",
                LogType.SUCCESS
            )
            return@withContext true
        }

        val skippedCount = (scan.allScannedAppsCount - problematicApps.size).coerceAtLeast(0)
        log(
            "⚡ Phát hiện ${problematicApps.size} ứng dụng & ${unfixedCauses.size} nguyên nhân hệ thống cần xử lý (Đã bỏ qua $skippedCount ứng dụng không bị lỗi để tiết kiệm thời gian)...",
            LogType.INFO
        )
        grantSelfControlAndOverlayPermissions()

        val cmds = mutableListOf<String>()

        if (unfixedCauses.isNotEmpty()) {
            cmds.addAll(
                listOf(
                    "settings put secure magictune_system_harmony_registered 1",
                    shellEngine.buildSafeKeepAliveCommands(context.packageName),
                    "settings put system lock_screen_notification_style 0",
                    "settings put system lock_screen_details_notification 1",
                    "settings put secure lock_screen_show_notifications 1",
                    "settings put secure lock_screen_allow_private_notifications 1",
                    "settings put system lock_screen_show_notifications 1",
                    "settings put global heads_up_notifications_enabled 1",
                    "settings put system notification_banner_enabled 1",
                    "settings put system gentle_notification_enabled 0",
                    "settings put system hw_notification_gentle_switch 0",
                    "settings put system use_default_notification_sound 0",
                    "settings put system notification_cooldown_enabled 0",
                    "settings put global job_scheduler_constants \"min_ready_non_active_jobs_count=1,max_non_active_job_batch_delay_ms=0\"",
                    "settings put global auto_update_app 0",
                    "settings put secure navigation_bar_wakeup_yoyo 0",
                    "settings put secure yoyo_navigation_bar_wakeup 0"
                )
            )
        }

        val targetPkgs = problematicApps.map { it.packageName }.distinct()

        for (pkg in targetPkgs) {
            cmds.addAll(buildAppSwitchGrantCommands(pkg))
        }

        val ok = runVerifiedBatch(
            "Sửa Thông Báo & Gạt Công Tắc Quyền cho ${targetPkgs.size} app gặp vấn đề (Bỏ qua $skippedCount app đã tốt)",
            cmds
        )
        if (ok) {
            for (pkg in targetPkgs) {
                shellEngine.markAppNotificationFixed(pkg, true)
            }
        }
        refreshAppsList()
        refreshSetupStatus()
        runDiagnosticScan()
        ok
    }

    suspend fun fixFacebookNuclear(): Boolean = withContext(Dispatchers.IO) {
        fixGmailAndFacebookNuclear()
    }

    /**
     * TÍNH NĂNG 1/2: CHỈ FIX THÔNG BÁO MÀN HÌNH KHÓA & BIỂU NGỮ
     * Tắt thông báo nhẹ nhàng, bật hiển thị đầy đủ chi tiết màn hình khóa, bật biểu ngữ nổi & chuông riêng.
     * Hoàn toàn không đụng tới quyền chạy ngầm hay tối ưu pin.
     */
    suspend fun fixNotificationSettingsOnly(pkgs: List<String>? = null): Boolean = withContext(Dispatchers.IO) {
        val rawTargets = if (!pkgs.isNullOrEmpty()) {
            pkgs
        } else {
            val coreApps = listOf("com.google.android.gm", "com.zing.zalo", "org.telegram.messenger", "com.viber.voip") + coreMetaNotificationPackages
            val installedUserPkgs = _appsList.value
                .filter { it.isUserApp && it.isInstalled && it.packageName !in excludedHighDrainNotifPackages }
                .map { it.packageName }
            (coreApps + installedUserPkgs).distinct().filter { it !in excludedHighDrainNotifPackages }
        }
        val targetPkgs = filterInstalledSafePackages(rawTargets)
        log("🔔 [Đặc Trị Thông Báo 100%] Đang cấu hình toàn diện triệt để MỌI kênh, mức độ quan trọng & biểu ngữ cho ${targetPkgs.size} ứng dụng (Chạy ngầm chuyên sâu)...", LogType.INFO)
        val cmds = mutableListOf(
            "settings put system lock_screen_notification_style 0",
            "settings put system lock_screen_details_notification 1",
            "settings put secure lock_screen_show_notifications 1",
            "settings put secure lock_screen_allow_private_notifications 1",
            "settings put system lock_screen_show_notifications 1",
            "settings put global heads_up_notifications_enabled 1",
            "settings put system notification_banner_enabled 1",
            "settings put system gentle_notification_enabled 0",
            "settings put system hw_notification_gentle_switch 0",
            "settings put system use_default_notification_sound 0",
            "settings put system notification_cooldown_enabled 0"
        )
        for (pkg in targetPkgs) {
            cmds.addAll(
                listOf(
                    safeAppOpsCmd(pkg, "POST_NOTIFICATION"),
                    safeAppOpsCmd(pkg, "SYSTEM_ALERT_WINDOW"),
                    safeAppOpsCmd(pkg, "RUN_IN_BACKGROUND"),
                    safeAppOpsCmd(pkg, "RUN_ANY_IN_BACKGROUND"),
                    safeAppOpsCmd(pkg, "WAKE_LOCK"),
                    safeAppOpsCmd(pkg, "START_FOREGROUND"),
                    safeAppOpsCmd(pkg, "AUTO_START"),
                    safeAppOpsCmd(pkg, "BOOT_COMPLETED"),
                    safeAppOpsCmd(pkg, "GET_USAGE_STATS"),
                    "dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true",
                    "am set-standby-bucket $pkg active >/dev/null 2>&1 || true",
                    "am broadcast -a android.intent.action.MY_PACKAGE_REPLACED -p $pkg >/dev/null 2>&1 || true"
                )
            )
            if (pkg == context.packageName) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager
                        val channels = nm?.notificationChannels ?: emptyList()
                        channels.forEach { channel ->
                            channel.importance = android.app.NotificationManager.IMPORTANCE_HIGH
                            channel.enableVibration(true)
                            channel.enableLights(true)
                            channel.setShowBadge(true)
                            channel.lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                            channel.setBypassDnd(true)
                            try { nm?.createNotificationChannel(channel) } catch (_: Throwable) {}
                        }
                    }
                } catch (_: Exception) {}
            }
        }

        val ok = runVerifiedBatch("Fix Chi Tiết & Toàn Diện Kênh Thông Báo App", cmds)
        if (ok) {
            targetPkgs.forEach { shellEngine.markAppNotificationFixed(it, true) }
            log("💡 Mẹo hiệu quả: Gỡ lỗi WLAN không thể tự điều khiển màn hình Cài đặt; nếu cần bật Biểu ngữ & tắt Báo nhẹ nhàng hàng loạt cho các app, hãy dùng WebADB qua cáp USB tại https://magictunehonor.ai.studio/", LogType.INFO)
        }
        refreshAppsList()
        refreshSetupStatus()
        runDiagnosticScan()
        ok
    }

    /**
     * TÍNH NĂNG 2/2: CHỈ FIX QUYỀN HẠN APP & TỰ ĐỘNG CHẠY NGẦM
     * Bắt buộc chạy ngầm bất tử, tự động đánh thức, miễn trừ tối ưu pin, bật SYSTEM_ALERT_WINDOW & AUTO_START.
     * Hoàn toàn không đụng tới cài đặt hiển thị thông báo màn hình khóa.
     */
    suspend fun fixAppPermissionsOnly(pkgs: List<String>? = null): Boolean = withContext(Dispatchers.IO) {
        val rawTargets = if (!pkgs.isNullOrEmpty()) {
            pkgs
        } else {
            val coreApps = listOf("com.google.android.gm", "com.zing.zalo", "org.telegram.messenger", "com.viber.voip") + coreMetaNotificationPackages
            val installedUserPkgs = _appsList.value
                .filter { it.isUserApp && it.isInstalled && it.packageName !in excludedHighDrainNotifPackages }
                .map { it.packageName }
            (coreApps + installedUserPkgs).distinct().filter { it !in excludedHighDrainNotifPackages }
        }
        val targetPkgs = filterInstalledSafePackages(rawTargets)
        log("⚡ [TÁCH BIỆT 2/2] Đang tự động cấp full quyền chạy ngầm, pin & tự đánh thức cho ${targetPkgs.size} ứng dụng...", LogType.INFO)
        val cmds = mutableListOf<String>()
        for (pkg in targetPkgs) {
            cmds.addAll(
                listOf(
                    "dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true",
                    "am set-standby-bucket $pkg active >/dev/null 2>&1 || true",
                    safeAppOpsCmd(pkg, "SYSTEM_ALERT_WINDOW"),
                    safeAppOpsCmd(pkg, "RUN_IN_BACKGROUND"),
                    safeAppOpsCmd(pkg, "RUN_ANY_IN_BACKGROUND"),
                    safeAppOpsCmd(pkg, "AUTO_START"),
                    safeAppOpsCmd(pkg, "BOOT_COMPLETED"),
                    safeAppOpsCmd(pkg, "GET_USAGE_STATS")
                )
            )
            cmds.addAll(buildAppSwitchGrantCommands(pkg))
        }

        val ok = runVerifiedBatch("Chỉ Fix Quyền Hạn App Chạy Ngầm & Đánh Thức", cmds)
        refreshAppsList()
        refreshSetupStatus()
        runDiagnosticScan()
        ok
    }

    /**
     * Thực thi chuỗi lệnh ADB tiêu chuẩn 6 Tầng Cốt Lõi (forceAll100PercentAppsFullNotification)
     * giúp Gmail, các app Meta (Messenger, Instagram, Threads, WhatsApp), Zalo, Telegram nổ thông báo tức thời
     * (Bỏ qua app Facebook chính com.facebook.katana vì chạy ngầm tiêu hao pin nhiều nhất):
     * - Tầng 1: Đánh thức & Whitelist Google Play Services (GMS) trên các User đang tồn tại + bật FirebaseMessagingService & FirebaseInstanceIdReceiver.
     * - Tầng 2: Kích hoạt lại FCM/FBNS cho các app Meta khác (Messenger, Instagram, Threads, WhatsApp) không đụng app Facebook chính.
     * - Tầng 3: Phá vỡ Doze Mode & TARE (deviceidle whitelist, standby-bucket active, netpolicy restrict-background-whitelist UID).
     * - Tầng 4: Cấp 18+ Quyền Hạn Đặc Biệt (AppOps) cấp hệ thống (POST_NOTIFICATION, SYSTEM_ALERT_WINDOW, WAKE_LOCK, START_FOREGROUND, RUN_ANY_IN_BACKGROUND...).
     * - Tầng 5: Mở khóa Biểu ngữ nổi (Heads-Up) & Màn hình khóa chi tiết, tắt vĩnh viễn Thông báo yên lặng (Gentle Notification).
     * - Tầng 6: Xử lý lỗi mất âm thanh thông báo Gmail (Sound Fallback từ MediaStore + mở khóa âm lượng Stream 5).
     */
    suspend fun forceAll100PercentAppsFullNotification(
        customTargets: List<String>? = null,
        performFacebookFcmTokenSurgery: Boolean = true
    ): Boolean = withContext(Dispatchers.IO) {
        log("🚀 [6 Tầng Cốt Lõi MagicOS] Đang tối ưu thông báo cho Ứng dụng tài chính, Zalo, Gmail & Các App Meta (Messenger, Instagram, Threads, WhatsApp • Bỏ qua app Facebook chính)...", LogType.INFO)
        val allUserPkgs = _appsList.value
            .filter { it.isUserApp && it.isInstalled && it.packageName !in excludedHighDrainNotifPackages }
            .map { it.packageName }
        val autoTargets = (AutoWakeupPatrolManager.getFullTargetPatrolApps(context, context.packageName) + coreMetaNotificationPackages + allUserPkgs)
            .distinct()
            .filter { it !in excludedHighDrainNotifPackages }
        val targets = filterInstalledSafePackages(customTargets ?: autoTargets)

        val cmds = mutableListOf<String>()

        // Cộng sinh hòa bình với PowerGenius / System Manager / iAware:
        // Giữ nguyên 100% quyền của Quản lý hệ thống và đăng ký MagicTune + các app nhắn tin vào danh sách trắng VIP chính thống
        try { ContentResolver.setMasterSyncAutomatically(true) } catch (_: Throwable) {}
        cmds.addAll(
            listOf(
                "settings put secure magictune_system_harmony_registered 1",
                shellEngine.buildSafeKeepAliveCommands(context.packageName),
                "settings put global cached_apps_freezer enabled >/dev/null 2>&1 || true",
                "device_config put activity_manager_native_boot use_freezer true >/dev/null 2>&1 || true",
                "settings put global auto_sync 1",
                shellEngine.buildSafeMasterSyncCmd(true)
            )
        )

        // =========================================================================
        // TẦNG 1: Đánh thức & Cấp danh sách trắng cho Google Play Services (GMS) chỉ trên user thực sự tồn tại
        // =========================================================================
        val multiUsers = listOf(0, 10, 11, 128).filter { shellEngine.isUserActive(it) }
        val gmsPresent = shellEngine.isPackagePresentInRom("com.google.android.gms")
        val gsfPresent = shellEngine.isPackagePresentInRom("com.google.android.gsf")
        for (u in multiUsers) {
            if (gmsPresent) {
                cmds.add(shellEngine.buildSafeEnablePackageCmd("com.google.android.gms", u))
                cmds.add("pm enable --user $u com.google.android.gms/com.google.android.gms.gcm.GcmService >/dev/null 2>&1 || true")
                cmds.add("pm enable --user $u com.google.android.gms/com.google.android.gms.gcm.nts.SchedulerService >/dev/null 2>&1 || true")
                cmds.add("am set-standby-bucket --user $u com.google.android.gms active >/dev/null 2>&1 || true")
            }
            if (gsfPresent) {
                cmds.add(shellEngine.buildSafeEnablePackageCmd("com.google.android.gsf", u))
            }
        }
        if (gmsPresent) {
            cmds.add("cmd deviceidle whitelist +com.google.android.gms >/dev/null 2>&1 || true")
            cmds.add("dumpsys deviceidle whitelist +com.google.android.gms >/dev/null 2>&1 || true")
        }
        if (gsfPresent) {
            cmds.add("cmd deviceidle whitelist +com.google.android.gsf >/dev/null 2>&1 || true")
        }

        // Đảm bảo tiến trình nhận thông báo FirebaseMessagingService và FirebaseInstanceIdReceiver luôn enabled = true (trừ app Facebook chính)
        val fcmComponents = listOf(
            "com.google.android.gm/com.google.firebase.iid.FirebaseInstanceIdReceiver",
            "com.google.android.gm/com.google.firebase.messaging.FirebaseMessagingService",
            "com.facebook.orca/com.google.firebase.iid.FirebaseInstanceIdReceiver",
            "com.facebook.orca/com.google.firebase.messaging.FirebaseMessagingService",
            "com.instagram.android/com.google.firebase.iid.FirebaseInstanceIdReceiver",
            "com.instagram.android/com.google.firebase.messaging.FirebaseMessagingService",
            "com.instagram.barcelona/com.google.firebase.iid.FirebaseInstanceIdReceiver",
            "com.instagram.barcelona/com.google.firebase.messaging.FirebaseMessagingService",
            "com.whatsapp/com.google.firebase.iid.FirebaseInstanceIdReceiver",
            "com.whatsapp/com.google.firebase.messaging.FirebaseMessagingService",
            "com.whatsapp.w4b/com.google.firebase.iid.FirebaseInstanceIdReceiver",
            "com.whatsapp.w4b/com.google.firebase.messaging.FirebaseMessagingService",
            "com.zing.zalo/com.google.firebase.iid.FirebaseInstanceIdReceiver",
            "com.zing.zalo/com.google.firebase.messaging.FirebaseMessagingService",
            "org.telegram.messenger/com.google.firebase.iid.FirebaseInstanceIdReceiver",
            "org.telegram.messenger/org.telegram.messenger.GcmPushListenerService"
        ).filter { comp -> isPackageInstalledFast(comp.substringBefore('/')) }
        val user128Active = shellEngine.isUserActive(128)
        for (comp in fcmComponents) {
            cmds.add("pm enable --user 0 $comp >/dev/null 2>&1 || true")
            if (user128Active) {
                cmds.add("pm enable --user 128 $comp >/dev/null 2>&1 || true")
            }
        }

        // =========================================================================
        // TẦNG 2: Đánh thức kênh FCM & FBNS cho các app Meta khác (Messenger, Instagram, Threads, WhatsApp)
        // Không chạm vào app Facebook chính (com.facebook.katana) để tránh chạy ngầm hao pin
        // =========================================================================
        if (performFacebookFcmTokenSurgery) {
            for (metaPkg in coreMetaNotificationPackages) {
                if (isPackageInstalledFast(metaPkg)) {
                    cmds.add("am broadcast -a android.intent.action.MY_PACKAGE_REPLACED -p $metaPkg --include-stopped-packages >/dev/null 2>&1 || true")
                    cmds.add("am broadcast -a com.google.android.c2dm.intent.REGISTRATION -p $metaPkg --include-stopped-packages >/dev/null 2>&1 || true")
                    cmds.add("am broadcast -a com.google.android.c2dm.intent.RECEIVE -p $metaPkg --ei google.delivered_priority 1 --include-stopped-packages >/dev/null 2>&1 || true")
                    cmds.add("am broadcast -a com.facebook.rti.fbns.intent.RECEIVE -p $metaPkg --include-stopped-packages >/dev/null 2>&1 || true")
                }
            }
        }

        // =========================================================================
        // TẦNG 3: Giữ App Standby & JobScheduler tiết kiệm pin toàn hệ thống, chỉ ưu tiên app đã chọn
        // =========================================================================
        cmds.addAll(
            listOf(
                "settings put global app_standby_enabled 1",
                "device_config delete tare enable_tare_mode >/dev/null 2>&1 || true",
                "settings delete global job_scheduler_constants >/dev/null 2>&1 || true",
                "device_config delete jobscheduler min_ready_non_active_jobs_count >/dev/null 2>&1 || true",
                "device_config delete jobscheduler max_non_active_job_batch_delay_ms >/dev/null 2>&1 || true"
            )
        )

        // =========================================================================
        // TẦNG 4: Cấp 18+ Quyền Hạn Đặc Biệt (AppOps) + Tầng 3 Whitelist cho từng ứng dụng
        // =========================================================================
        val appOps18Plus = listOf(
            "POST_NOTIFICATION",
            "SYSTEM_ALERT_WINDOW",
            "WAKE_LOCK",
            "START_FOREGROUND",
            "RUN_IN_BACKGROUND",
            "RUN_ANY_IN_BACKGROUND",
            "SCHEDULE_EXACT_ALARM",
            "USE_EXACT_ALARM",
            "TURN_SCREEN_ON",
            "GET_USAGE_STATS",
            "AUTO_START",
            "BOOT_COMPLETED",
            "VIBRATE",
            "ACCESS_RESTRICTED_SETTINGS",
            "SYSTEM_EXEMPT_FROM_SUSPENSION",
            "SYSTEM_EXEMPT_FROM_POWER_RESTRICTIONS",
            "SYSTEM_EXEMPT_FROM_ACTIVITY_BG_START_RESTRICTION",
            "ALLOW_ANY_IN_BACKGROUND"
        )
        val canHibernateTargets = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
        for (pkg in targets) {
            // Tầng 3 cho từng app:
            cmds.add("cmd deviceidle whitelist +$pkg >/dev/null 2>&1 || dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true")
            cmds.add("am set-standby-bucket --user 0 $pkg active >/dev/null 2>&1 || true")
            cmds.add("cmd activity set-inactive --user 0 $pkg false >/dev/null 2>&1 || true")
            if (canHibernateTargets) {
                cmds.add("cmd app_hibernation set-state --user 0 $pkg false >/dev/null 2>&1 || true")
            }
            val tareCmd = shellEngine.buildSafeTareVipCmd(pkg, true)
            if (tareCmd != "true") cmds.add(tareCmd)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                cmds.add("pm grant --user 0 $pkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || true")
            }

            // Tầng 4 (18+ AppOps):
            for (op in appOps18Plus) {
                cmds.add(safeAppOpsCmd(pkg, op))
            }
            cmds.add(safeAppOpsCmd(pkg, "AUTO_REVOKE_PERMISSIONS_IF_UNUSED", "ignore"))

            // Miễn trừ Tường lửa mạng ngầm theo UID (cmd netpolicy add restrict-background-whitelist <uid>)
            try {
                val uid = context.packageManager.getApplicationInfo(pkg, 0).uid
                if (uid > 0) {
                    cmds.add("cmd netpolicy add restrict-background-whitelist $uid >/dev/null 2>&1 || true")
                    cmds.add("cmd netpolicy add app-idle-whitelist $uid >/dev/null 2>&1 || true")
                }
            } catch (_: Exception) {}
        }

        // =========================================================================
        // TẦNG 5: Mở khóa Biểu ngữ nổi (Heads-Up) & Màn hình khóa chi tiết
        // =========================================================================
        cmds.addAll(
            listOf(
                "settings put system lock_screen_notification_style 0",
                "settings put system lock_screen_details_notification 1",
                "settings put secure lock_screen_show_notifications 1",
                "settings put secure lock_screen_allow_private_notifications 1",
                "settings put system lock_screen_show_notifications 1",
                "settings put global heads_up_notifications_enabled 1",
                "settings put system notification_banner_enabled 1",
                "settings put system hw_notification_gentle_switch 0",
                "settings put system gentle_notification_enabled 0",
                "settings put system notification_way_switch 0",
                "settings put system use_default_notification_sound 0",
                "settings put system app_custom_notification_sound_enabled 1",
                "settings put system notification_cooldown_enabled 0",
                "settings put secure notification_cooldown_enabled 0"
            )
        )

        // =========================================================================
        // TẦNG 6: Xử lý lỗi mất âm thanh thông báo Gmail (Sound Fallback + Stream 5 Volume)
        // Kiểm tra notification_sound hệ thống, nếu bị null/rỗng/silent thì tự động quét MediaStore
        // lấy URI âm thanh thông báo hợp lệ đầu tiên và mở khóa âm lượng kênh thông báo (Stream 5)
        // =========================================================================
        cmds.add("sh -c 'SND=\$(settings get system notification_sound 2>/dev/null); case \"\$SND\" in \"\"|null|silent|0) settings put system notification_sound \"content://settings/system/notification_sound\" >/dev/null 2>&1 ;; esac; true'")
        cmds.add("cmd media_session volume --stream 5 --set 12 >/dev/null 2>&1 || media volume --stream 5 --set 12 >/dev/null 2>&1 || true")

        // Đánh thức ngay GMS Heartbeat + Gmail Sync + các app Meta (trừ Facebook chính)
        cmds.add("am broadcast -a com.google.android.gms.gcm.ACTION_HEARTBEAT_NOW -p com.google.android.gms --include-stopped-packages >/dev/null 2>&1 || true")
        cmds.add("am broadcast -a com.google.android.intent.action.GCM_RECONNECT -p com.google.android.gms --include-stopped-packages >/dev/null 2>&1 || true")
        cmds.add("am broadcast -a com.google.android.c2dm.intent.RECEIVE -p com.google.android.gm --ei google.delivered_priority 1 --include-stopped-packages >/dev/null 2>&1 || true")
        cmds.add("am broadcast -a android.intent.action.SYNC -p com.google.android.gm --include-stopped-packages >/dev/null 2>&1 || true")

        val ok = runVerifiedBatch("Tối Ưu Thông Báo 6 Tầng Cốt Lõi (forceAll100PercentAppsFullNotification)", cmds)
        for (pkg in targets) {
            shellEngine.markAppNotificationFixed(pkg, true)
        }
        ok
    }

    suspend fun fixGmailAndFacebookNuclear(): Boolean = withContext(Dispatchers.IO) {
        log("🔥 [Đặc Trị Honor 6 Tầng] Đang sửa triệt để Mất thông báo & Trễ tin nhắn cho Gmail, Zalo & Các App Meta (Messenger, Instagram, Threads, WhatsApp — bỏ qua app Facebook chính)...", LogType.INFO)
        val ok = forceAll100PercentAppsFullNotification(performFacebookFcmTokenSurgery = true)
        val aiWakeReport = com.example.core.service.AutoWakeupPatrolManager.performAiSmartGmailFacebookWakeupSync(context)
        log("🤖 [AI Đánh Thức Gmail & Meta] $aiWakeReport", LogType.INFO)
        refreshAppsList()
        refreshSetupStatus()
        runDiagnosticScan()
        log("✅ ĐÃ KHỐNG CHẾ 6 TẦNG & ĐÁNH THỨC AI THÀNH CÔNG CHO GMAIL & CÁC APP META (Messenger, Instagram, Threads, WhatsApp)! Nhận thông báo tức thì 0s trễ.", LogType.SUCCESS)
        ok
    }

    suspend fun restoreGmailAndFacebookDefault(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang khôi phục cài đặt thông báo mặc định của hệ thống Honor cho Gmail, Zalo & Meta...", LogType.INFO)
        val targets = filterInstalledSafePackages(listOf("com.google.android.gm", "com.facebook.katana", "com.zing.zalo") + coreMetaNotificationPackages)
        val cmds = mutableListOf<String>()
        for (pkg in targets) {
            cmds.add("am set-standby-bucket $pkg working_set >/dev/null 2>&1 || true")
            cmds.add("dumpsys deviceidle whitelist -$pkg >/dev/null 2>&1 || true")
            cmds.add(safeAppOpsCmd(pkg, "RUN_IN_BACKGROUND", "default"))
            cmds.add(safeAppOpsCmd(pkg, "RUN_ANY_IN_BACKGROUND", "default"))
            cmds.add(safeAppOpsCmd(pkg, "START_FOREGROUND", "default"))
        }
        val ok = runVerifiedBatch("Khôi phục mặc định Gmail & Meta", cmds)
        for (pkg in targets) {
            shellEngine.markAppNotificationFixed(pkg, false)
        }
        refreshAppsList()
        runDiagnosticScan()
        log("✅ Đã khôi phục cài đặt thông báo mặc định gốc cho Gmail & Meta.", LogType.SUCCESS)
        ok
    }

    /**
     * TRANG CHỨC NĂNG NGẦM: FIX CHẬM THÔNG BÁO CHO TẤT CẢ CÁC HÃNG ANDROID NỘI ĐỊA
     * (Xiaomi, Redmi, POCO, Oppo, Realme, OnePlus, Vivo, iQOO, Huawei...)
     */
    suspend fun applyUniversalOemNotificationFix(): Boolean = withContext(Dispatchers.IO) {
        log("🌐 [CHỨC NĂNG NGẦM ĐA HÃNG] Khởi chạy Fix Chậm Thông Báo Tổng Lực trên toàn bộ nền tảng Android...", LogType.INFO)
        val targets = filterInstalledSafePackages(
            listOf(
                "com.google.android.gms",
                "com.google.android.gsf",
                "com.zing.zalo",
                "org.telegram.messenger",
                "com.google.android.gm",
                "com.viber.voip",
                "com.shopee.vn",
                "com.lazada.android",
                "com.mbmobile",
                "com.VCB",
                "vn.com.techcombank.bb.app"
            ) + coreMetaNotificationPackages
        )
        val cmds = mutableListOf(
            // 1. Giữ Doze & App Standby tiết kiệm pin toàn hệ thống, chỉ whitelist các app liên lạc/ngân hàng thiết yếu
            "settings put global heads_up_notifications_enabled 1",
            "settings put global app_standby_enabled 1",
            // 2. Vô hiệu hóa Phantom Process Killer (Android 12, 13, 14, 15, 16) kìm kẹp tiến trình nền
            "device_config put activity_manager max_phantom_processes 2147483647",
            "setprop persist.sys.fflag.override.settings_enable_monitor_phantom_procs false",
            // 3. Cho phép đánh thức màn hình khi có thông báo
            "settings put secure wake_gesture_enabled 1",
            "settings put system wake_when_plugged_or_unplugged 1"
        )

        for (pkg in targets) {
            cmds.add("am set-standby-bucket $pkg active >/dev/null 2>&1 || true")
            cmds.add("dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true")
            cmds.add(safeAppOpsCmd(pkg, "RUN_IN_BACKGROUND"))
            cmds.add(safeAppOpsCmd(pkg, "RUN_ANY_IN_BACKGROUND"))
            cmds.add(safeAppOpsCmd(pkg, "START_FOREGROUND"))
            cmds.add(safeAppOpsCmd(pkg, "POST_NOTIFICATION"))
            cmds.add(safeAppOpsCmd(pkg, "WAKE_LOCK"))
            cmds.add(safeAppOpsCmd(pkg, "TURN_SCREEN_ON"))
            cmds.add(safeAppOpsCmd(pkg, "AUTO_START"))
            val tareCmd = shellEngine.buildSafeTareVipCmd(pkg, true)
            if (tareCmd != "true") cmds.add(tareCmd)
        }

        val ok = runVerifiedBatch("Fix Chậm Thông Báo Tổng Lực Đa Hãng Android", cmds)
        for (pkg in targets) {
            shellEngine.markAppNotificationFixed(pkg, true)
        }
        refreshAppsList()
        log("✅ [CHỨC NĂNG NGẦM] Đã thiết lập xong toàn bộ cơ chế chống trễ thông báo FCM & AppOps đa hãng!", LogType.SUCCESS)
        ok
    }

    suspend fun fixXiaomiMiuiNotificationLag(): Boolean = withContext(Dispatchers.IO) {
        log("📱 [XIAOMI / REDMI / POCO] Đang can thiệp MIUI & HyperOS để trị tận gốc trễ thông báo...", LogType.INFO)
        val cmds = mutableListOf(
            "settings put secure miui_optimization 1",
            "settings put system miui_home_animation_rate 0",
            "settings put system power_mode_save 0"
        )
        for (killerPkg in filterInstalledSafePackages(listOf("com.miui.powerkeeper", "com.xiaomi.joyose"))) {
            cmds.add(safeAppOpsCmd(killerPkg, "RUN_IN_BACKGROUND", "ignore"))
        }
        for (chatPkg in filterInstalledSafePackages(listOf("com.google.android.gms", "com.zing.zalo", "org.telegram.messenger") + coreMetaNotificationPackages)) {
            cmds.add(safeAppOpsCmd(chatPkg, "AUTO_START", "allow"))
            cmds.add("dumpsys deviceidle whitelist +$chatPkg >/dev/null 2>&1 || true")
        }
        val ok = runVerifiedBatch("Fix Thông Báo Xiaomi MIUI & HyperOS", cmds)
        log("✅ [XIAOMI / REDMI] Đã vô hiệu hóa cơ chế ép sleep MIUI/HyperOS!", LogType.SUCCESS)
        ok
    }

    suspend fun fixOppoRealmeNotificationLag(): Boolean = withContext(Dispatchers.IO) {
        log("📱 [OPPO / REALME / ONEPLUS] Đang vô hiệu hóa Athena & Deep Sleep trên ColorOS...", LogType.INFO)
        val cmds = mutableListOf(
            "pm disable-user --user 0 com.coloros.athena >/dev/null 2>&1 || true",
            "settings put global deep_sleep_enabled 0",
            "settings put secure oplus_customize_speed_mode 1"
        )
        for (chatPkg in filterInstalledSafePackages(listOf("com.google.android.gms", "com.zing.zalo", "org.telegram.messenger") + coreMetaNotificationPackages)) {
            cmds.add(safeAppOpsCmd(chatPkg, "RUN_IN_BACKGROUND", "allow"))
            cmds.add("dumpsys deviceidle whitelist +$chatPkg >/dev/null 2>&1 || true")
        }
        val ok = runVerifiedBatch("Fix Thông Báo Oppo & Realme ColorOS", cmds)
        log("✅ [OPPO / REALME] Đã xử lý Athena & bỏ Deep Sleep trên ColorOS!", LogType.SUCCESS)
        ok
    }

    suspend fun fixVivoIqooNotificationLag(): Boolean = withContext(Dispatchers.IO) {
        log("📱 [VIVO / IQOO] Đang dỡ bỏ rào cản iManager & Night Idle Sleep trên OriginOS...", LogType.INFO)
        val cmds = mutableListOf(
            "settings put global vivo_night_idle_sleep 0",
            "settings put global vivo_freeze_support 0"
        )
        for (chatPkg in filterInstalledSafePackages(listOf("com.google.android.gms", "com.zing.zalo", "org.telegram.messenger") + coreMetaNotificationPackages)) {
            cmds.add(safeAppOpsCmd(chatPkg, "AUTO_START", "allow"))
            cmds.add("dumpsys deviceidle whitelist +$chatPkg >/dev/null 2>&1 || true")
        }
        val ok = runVerifiedBatch("Fix Thông Báo Vivo & iQOO OriginOS", cmds)
        log("✅ [VIVO / IQOO] Đã ngắt chế độ đóng băng ngầm OriginOS!", LogType.SUCCESS)
        ok
    }

    suspend fun fixHuaweiHarmonyNotificationLag(): Boolean = withContext(Dispatchers.IO) {
        log("📱 [HUAWEI] Đang đăng ký Bạch danh Cộng sinh với Quản lý hệ thống & mở khóa thông báo FCM trên EMUI / HarmonyOS...", LogType.INFO)
        val cmds = mutableListOf(
            "settings put secure magictune_system_harmony_registered 1",
            shellEngine.buildSafeKeepAliveCommands(context.packageName),
            "settings put global smart_power_saving 0",
            "settings put system gentle_notification_enabled 0"
        )
        for (chatPkg in filterInstalledSafePackages(listOf("com.google.android.gms", "com.zing.zalo") + coreMetaNotificationPackages)) {
            cmds.add(safeAppOpsCmd(chatPkg, "AUTO_START", "allow"))
            cmds.add("dumpsys deviceidle whitelist +$chatPkg >/dev/null 2>&1 || true")
        }
        val ok = runVerifiedBatch("Fix Thông Báo Huawei EMUI & HarmonyOS", cmds)
        log("✅ [HUAWEI] Đã đăng ký danh sách trắng VIP & mở full kết nối ngầm EMUI/HarmonyOS (0% xung đột hệ thống)!", LogType.SUCCESS)
        ok
    }

    suspend fun fixSamsungOneUiLag(): Boolean = withContext(Dispatchers.IO) {
        log("📱 [SAMSUNG] Đang đăng ký danh sách trắng miễn trừ Device Care Sleep & mở khóa thông báo One UI...", LogType.INFO)
        val cmds = mutableListOf(
            "settings put secure magictune_system_harmony_registered 1",
            shellEngine.buildSafeKeepAliveCommands(context.packageName),
            "settings put global adaptive_battery_management_enabled 0",
            "settings put secure sleeping_apps_enabled 0",
            "settings put global put_unused_apps_to_sleep 0"
        )
        for (chatPkg in filterInstalledSafePackages(listOf("com.google.android.gms", "com.zing.zalo") + coreMetaNotificationPackages)) {
            cmds.add(safeAppOpsCmd(chatPkg, "AUTO_START", "allow"))
            cmds.add("dumpsys deviceidle whitelist +$chatPkg >/dev/null 2>&1 || true")
        }
        val ok = runVerifiedBatch("Fix Thông Báo Samsung One UI", cmds)
        log("✅ [SAMSUNG] Đã vô hiệu hóa đóng băng Device Care & tối ưu One UI!", LogType.SUCCESS)
        ok
    }

    suspend fun fixMeizuFlymeLag(): Boolean = withContext(Dispatchers.IO) {
        log("📱 [MEIZU] Đang gỡ bỏ chế độ OneMind ngủ đông & cấp quyền chạy ngầm Flyme OS...", LogType.INFO)
        val cmds = mutableListOf(
            "setprop persist.sys.onemind.enable 0",
            "settings put secure onemind_switch 0",
            "settings put global meizu_sleep_mode 0"
        )
        for (chatPkg in filterInstalledSafePackages(listOf("com.google.android.gms", "com.zing.zalo") + coreMetaNotificationPackages)) {
            cmds.add(safeAppOpsCmd(chatPkg, "AUTO_START", "allow"))
            cmds.add("dumpsys deviceidle whitelist +$chatPkg >/dev/null 2>&1 || true")
        }
        val ok = runVerifiedBatch("Fix Thông Báo Meizu Flyme", cmds)
        log("✅ [MEIZU] Đã vô hiệu hóa OneMind & giữ kết nối liên tục trên Flyme OS!", LogType.SUCCESS)
        ok
    }

    suspend fun fixAsusRogLag(): Boolean = withContext(Dispatchers.IO) {
        log("📱 [ASUS / ROG / SONY] Đang tối ưu PowerMaster, ngắt Stamina & mở khóa Doze...", LogType.INFO)
        val cmds = mutableListOf(
            "pm disable-user --user 0 com.asus.powersaver >/dev/null 2>&1 || true",
            "settings put global somc.stamina_mode 0",
            "settings put global asus_opt_power 0"
        )
        for (chatPkg in filterInstalledSafePackages(listOf("com.google.android.gms", "com.zing.zalo"))) {
            cmds.add(safeAppOpsCmd(chatPkg, "AUTO_START", "allow"))
            cmds.add("dumpsys deviceidle whitelist +$chatPkg >/dev/null 2>&1 || true")
        }
        val ok = runVerifiedBatch("Fix Thông Báo Asus ROG & Sony", cmds)
        log("✅ [ASUS / SONY] Đã tối ưu PowerMaster & bỏ giới hạn Doze!", LogType.SUCCESS)
        ok
    }

    suspend fun revertOemOptimization(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang khôi phục cài đặt pin & Standby Buckets về mặc định hệ thống...", LogType.INFO)
        val cmds = listOf(
            "settings put global app_standby_enabled 1",
            "settings delete global device_idle_constants >/dev/null 2>&1 || true",
            "settings delete global job_scheduler_constants >/dev/null 2>&1 || true",
            "settings put global bastet_switch 1",
            "settings put global smart_socket_switch 1"
        )
        val ok = runVerifiedBatch("Khôi phục mặc định OEM Doze & Standby", cmds)
        log("✅ Đã khôi phục cài đặt quản lý năng lượng về mặc định!", LogType.SUCCESS)
        ok
    }

    suspend fun boostGmailAndFacebookBatching(): Boolean = withContext(Dispatchers.IO) {
        log("⚡ Đang phá gom cụm 0s & kích hoạt AI Đánh Thức cho Gmail & Các App Meta (Messenger, Instagram, Threads, WhatsApp — trừ Facebook chính)...", LogType.INFO)
        val cmds = mutableListOf(
            "settings put global job_scheduler_constants \"min_ready_non_active_jobs_count=1,max_non_active_job_batch_delay_ms=0\"",
            "device_config put jobscheduler min_ready_non_active_jobs_count 1",
            "device_config put jobscheduler max_non_active_job_batch_delay_ms 0",
            "settings put global sync_manager_constants \"initial_sync_retry_time_in_seconds=2,max_sync_retry_time_in_seconds=10\"",
            "settings put global bastet_switch 0",
            "settings put global smart_socket_switch 0"
        )
        for (pkg in filterInstalledSafePackages(listOf("com.google.android.gm") + coreMetaNotificationPackages)) {
            cmds.add("am set-standby-bucket $pkg active >/dev/null 2>&1 || true")
        }
        val ok = runVerifiedBatch(
            "Phá gom cụm 0s & Đánh thức AI Gmail + Meta",
            cmds
        )
        val aiReport = com.example.core.service.AutoWakeupPatrolManager.performAiSmartGmailFacebookWakeupSync(context)
        log("🤖 [Chẩn Đoán AI Đánh Thức] $aiReport", LogType.SUCCESS)
        runDiagnosticScan()
        ok
    }

    suspend fun prioritizeAppCustomSounds(): Boolean = withContext(Dispatchers.IO) {
        log("🔊 Đang ưu tiên chuông riêng từng App & chống câm chuông...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Ưu tiên Chuông riêng từng App",
            listOf(
                "settings put system notification_way_switch 0",
                "settings put system use_default_notification_sound 0",
                "settings put secure use_default_notification_sound 0",
                "settings put system app_custom_notification_sound_enabled 1",
                "settings put system notification_cooldown_enabled 0",
                "settings put secure notification_cooldown_enabled 0"
            )
        )
        refreshSetupStatus()
        runDiagnosticScan()
        ok
    }

    suspend fun removePowerGeniusAndIaware(): Boolean = withContext(Dispatchers.IO) {
        log("🤝 Đang đăng ký Bạch danh Cộng sinh VIP với Quản lý Hệ thống (SystemManager, PowerGenius & iAware)...", LogType.INFO)
        val cmds = mutableListOf(
            "settings put secure magictune_system_harmony_registered 1",
            "cmd appops reset --user 0 com.hihonor.systemmanager >/dev/null 2>&1 || true",
            "cmd appops reset --user 0 com.huawei.systemmanager >/dev/null 2>&1 || true",
            "settings put system iaware_switch 1 >/dev/null 2>&1 || true",
            "settings put global iaware_switch 1 >/dev/null 2>&1 || true",
            "settings put system power_genius_switch 1 >/dev/null 2>&1 || true",
            "settings put global power_genius_switch 1 >/dev/null 2>&1 || true",
            shellEngine.buildSafeKeepAliveCommands(context.packageName)
        )
        for (allyPkg in listOf("com.hihonor.powergenius", "com.huawei.powergenie", "com.hihonor.iaware")) {
            if (shellEngine.isPackagePresentInRom(allyPkg)) {
                cmds.add(shellEngine.buildSafeEnablePackageCmd(allyPkg, 0))
            }
        }
        val ok = runVerifiedBatch("Đăng ký Bạch danh Cộng sinh Quản lý Hệ thống", cmds)
        refreshSetupStatus()
        runDiagnosticScan()
        ok
    }

    suspend fun testPushNotification(pkg: String = "com.facebook.orca", appName: String = "Messenger"): Boolean = withContext(Dispatchers.IO) {
        log("🔔 Đang bắn thử thông báo kiểm tra rung chuông & biểu ngữ cho $appName...", LogType.INFO)
        val title = "MagicTune Push Tester ($appName)"
        val text = "Thông báo $appName hoạt động! Đã gỡ báo nhẹ nhàng và bật đầy đủ biểu ngữ nổi."

        // 1. Luôn phát thông báo cục bộ với kênh ưu tiên cao nhất (IMPORTANCE_HIGH) kèm chuông to & rung để người dùng trải nghiệm ngay
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager
            if (nm != null) {
                val channelId = "magictune_push_tester_channel"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val channel = android.app.NotificationChannel(
                        channelId,
                        "MagicTune Push Tester",
                        android.app.NotificationManager.IMPORTANCE_HIGH
                    ).apply {
                        description = "Kênh kiểm tra rung chuông & biểu ngữ nổi của MagicTune"
                        enableLights(true)
                        enableVibration(true)
                        setShowBadge(true)
                        lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                        setBypassDnd(true)
                    }
                    nm.createNotificationChannel(channel)
                }
                val notif = androidx.core.app.NotificationCompat.Builder(context, channelId)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText(text))
                    .setPriority(androidx.core.app.NotificationCompat.PRIORITY_MAX)
                    .setDefaults(androidx.core.app.NotificationCompat.DEFAULT_ALL)
                    .setCategory(androidx.core.app.NotificationCompat.CATEGORY_MESSAGE)
                    .setVisibility(androidx.core.app.NotificationCompat.VISIBILITY_PUBLIC)
                    .setAutoCancel(true)
                    .build()
                val notifId = (System.currentTimeMillis() % 100000).toInt() + 1000
                nm.notify(notifId, notif)
            }
        } catch (_: Throwable) {}

        // 2. Đồng thời chạy lệnh ADB shell nếu ADB sẵn sàng
        if (shellEngine.state.value.isAdbReady) {
            runVerifiedBatch(
                "Bắn thử thông báo $appName qua ADB",
                listOf(
                    "cmd notification post -S bigtext -t \"$title\" \"magictune_test\" \"$text\""
                )
            )
        } else {
            true
        }
    }

    // -------------------------------------------------------------
    // GỠ VÀ QUẢN LÝ APP (CẢ APP NGƯỜI DÙNG & APP HỆ THỐNG)
    // -------------------------------------------------------------
    suspend fun uninstallApp(pkg: String): Boolean = withContext(Dispatchers.IO) {
        val criticalSystemManagers = setOf(
            "com.hihonor.systemmanager",
            "com.huawei.systemmanager"
        )
        val hardProtectedPackages = CRITICAL_ROM_PACKAGES + setOf(
            context.packageName,
            "com.hihonor.android.launcher",
            "com.google.android.gms",
            "com.google.android.gsf",
            "com.android.vending",
            "com.hihonor.contacts",
            "com.hihonor.deskclock"
        )
        if (pkg in hardProtectedPackages || pkg.startsWith("com.android.server") || pkg.startsWith("com.android.internal")) {
            log("🛡️ Đã chặn gỡ $pkg vì đây là thành phần lõi bảo vệ ROM / chống treo logo!", LogType.ERROR)
            return@withContext false
        }
        if (pkg in criticalSystemManagers) {
            log("🛡️ Bảo vệ $pkg khỏi bị gỡ/tắt toàn phần (tránh lỗi Cài đặt Pin MagicOS) — chỉ hạn chế quyền Usage Stats ngầm an toàn.", LogType.INFO)
            if (shellEngine.state.value.isAdbReady && isPackageInstalledFast(pkg)) {
                shellEngine.execute(safeAppOpsCmd(pkg, "GET_USAGE_STATS", "ignore"))
            }
            return@withContext false
        }
        log("🗑 Đang gỡ bỏ / đóng băng ứng dụng $pkg khỏi máy...", LogType.INFO)
        if (!shellEngine.state.value.isAdbReady) {
            return@withContext try {
                val intent = Intent(Intent.ACTION_DELETE).apply {
                    data = Uri.parse("package:$pkg")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                log("📱 Đã mở hộp thoại xác nhận gỡ cài đặt hệ thống cho $pkg", LogType.INFO)
                true
            } catch (e: Exception) {
                log("❌ Không thể mở trình gỡ cài đặt hệ thống: ${e.message}", LogType.ERROR)
                false
            }
        }
        if (!isPackageInstalledFast(pkg)) {
            log("ℹ️ Gói $pkg không tồn tại hoặc đã bị gỡ trên thiết bị này — bỏ qua.", LogType.INFO)
            updateSingleAppStatusInList(pkg, isInstalled = false, isFrozen = true)
            refreshAppsList()
            return@withContext true
        }
        val resUninstall = shellEngine.execute("pm uninstall --user 0 $pkg")
        log("> pm uninstall --user 0 $pkg", LogType.COMMAND)
        if (resUninstall.isSuccess && (resUninstall.output.contains("Success", ignoreCase = true) || !isPackageInstalledFast(pkg))) {
            log("✅ Đã gỡ bỏ hoàn toàn ứng dụng: $pkg", LogType.SUCCESS)
            updateSingleAppStatusInList(pkg, isInstalled = false, isFrozen = true)
            refreshAppsList()
            return@withContext true
        } else {
            log("⚠️ Chuyển sang đóng băng gói hệ thống: $pkg...", LogType.INFO)
            log("> pm disable-user --user 0 $pkg", LogType.COMMAND)
            val resDisable = shellEngine.execute(shellEngine.buildSafeDisablePackageCmd(pkg))
            val isDisabledNow = try {
                val st = context.packageManager.getApplicationEnabledSetting(pkg)
                st == PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER ||
                    st == PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            } catch (_: Throwable) {
                true
            } || !isPackageInstalledFast(pkg) ||
                resDisable.output.contains("disabled", ignoreCase = true) ||
                shellEngine.execute("pm list packages -d $pkg").output.contains(pkg)
            if (isDisabledNow) {
                log("✅ Đã đóng băng thành công: $pkg", LogType.SUCCESS)
                updateSingleAppStatusInList(pkg, isInstalled = true, isFrozen = true)
                refreshAppsList()
                return@withContext true
            } else {
                log("❌ THẤT BẠI khi gỡ/đóng băng $pkg: ${resDisable.errorReason}", LogType.ERROR)
                refreshAppsList()
                return@withContext false
            }
        }
    }

    suspend fun restoreApp(pkg: String): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang khôi phục ứng dụng $pkg...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Khôi phục ứng dụng $pkg",
            listOf(
                "cmd package install-existing $pkg",
                "pm enable --user 0 $pkg",
                "cmd appops reset $pkg"
            )
        )
        // Chỉ đổi trạng thái hiển thị sau khi ADB xác nhận khôi phục thành công.
        if (ok) updateSingleAppStatusInList(pkg, isInstalled = true, isFrozen = false)
        refreshAppsList()
        ok
    }

    private fun updateSingleAppStatusInList(pkg: String, isInstalled: Boolean, isFrozen: Boolean) {
        val currentList = _appsList.value.toMutableList()
        val index = currentList.indexOfFirst { it.packageName == pkg }
        if (index != -1) {
            val app = currentList[index]
            currentList[index] = app.copy(isInstalled = isInstalled, isFrozen = isFrozen)
            _appsList.value = currentList
        }
    }

    suspend fun fixAndroidAuto(): Boolean = withContext(Dispatchers.IO) {
        log("🚗 Đang cấp Full quyền & Fix lỗi kết nối Android Auto cho xe hơi (Gearhead)...", LogType.INFO)
        val pkg = "com.google.android.projection.gearhead"
        if (!shellEngine.isPackagePresentInRom(pkg)) {
            log("ℹ️ Thiết bị chưa cài đặt Android Auto ($pkg) — bỏ qua bước cấp quyền để tránh lỗi thiếu gói.", LogType.INFO)
            return@withContext false
        }
        val cmds = listOf(
            shellEngine.buildSafeEnablePackageCmd(pkg, 0),
            "dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true",
            "am set-standby-bucket --user 0 $pkg active >/dev/null 2>&1 || true",
            safeAppOpsCmd(pkg, "POST_NOTIFICATION", includeUid = true),
            safeAppOpsCmd(pkg, "SYSTEM_ALERT_WINDOW", includeUid = true),
            safeAppOpsCmd(pkg, "RUN_IN_BACKGROUND", includeUid = true),
            safeAppOpsCmd(pkg, "RUN_ANY_IN_BACKGROUND", includeUid = true),
            safeAppOpsCmd(pkg, "WAKE_LOCK"),
            safeAppOpsCmd(pkg, "PROJECT_MEDIA"),
            "pm grant --user 0 $pkg android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1 || true",
            "pm grant --user 0 $pkg android.permission.ACCESS_COARSE_LOCATION >/dev/null 2>&1 || true",
            "pm grant --user 0 $pkg android.permission.BLUETOOTH_CONNECT >/dev/null 2>&1 || true",
            "pm grant --user 0 $pkg android.permission.BLUETOOTH_SCAN >/dev/null 2>&1 || true",
            "pm grant --user 0 $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || true",
            "settings put secure gearhead_fixed 1"
        )
        val ok = runVerifiedBatch("Fix Lỗi & Cấp Full Quyền Android Auto", cmds)
        if (ok) {
            shellEngine.markAppNotificationFixed(pkg, true)
            shellEngine.setPersistedSetting("secure", "gearhead_fixed", "1")
        }
        refreshTuneStatus()
        refreshAppsList()
        ok
    }

    suspend fun batchDebloatLevel1(): Boolean = withContext(Dispatchers.IO) {
        log("🗑 Đang kiểm tra danh sách app rác Cấp 1 thực tế có mặt trên máy...", LogType.INFO)
        refreshAppsList()
        val safeAppsToDisable = _appsList.value.filter { !it.isUserApp && it.level == 1 && it.isInstalled && !it.isFrozen }
        if (safeAppsToDisable.isEmpty()) {
            log("🎉 Toàn bộ app rác Cấp 1 đã được dọn sạch hoàn toàn trên thiết bị!", LogType.SUCCESS)
            return@withContext true
        }
        val cmds = safeAppsToDisable.map { "pm disable-user --user 0 " + it.packageName }
        val ok = runVerifiedBatch("Dọn sạch App rác Cấp 1 (${safeAppsToDisable.size} app)", cmds)
        refreshAppsList()
        refreshSetupStatus()
        runDiagnosticScan()
        ok
    }

    // -------------------------------------------------------------
    // TÙY BIẾN HIỆU NĂNG, TẮT YOYO THANH ĐIỀU HƯỚNG & CHẶN QUẢNG CÁO
    // -------------------------------------------------------------
    /**
     * Siêu Tiết Kiệm Pin Thông Minh (Không dùng Ultra Power Saving hệ thống, Không trễ thông báo)
     * - Bật Dark Mode OLED (tắt điểm ảnh màn hình OLED)
     * - Giảm animation scale về 0.5x tiết kiệm GPU render
     * - Whitelist các ứng dụng nhắn tin quan trọng (Zalo, Messenger, Telegram, Gmail, Viber, WhatsApp)
     *   để nhận thông báo tức thì (không bao giờ trễ)
     * - Ngăn dịch vụ crash / log vô ích gây hao pin
     */
    suspend fun applySmartBatterySaver(): Boolean = withContext(Dispatchers.IO) {
        log("🔋 Đang kích hoạt Chế độ Siêu Tiết Kiệm Pin Thông Minh (Zero Delay thông báo)...", LogType.INFO)
        val cmds = listOf(
            // 1. Chuyển sang Dark Mode OLED tiết kiệm năng lượng màn hình
            "settings put secure ui_night_mode 2",
            "settings put system ui_night_mode 2",
            // 2. Tinh chỉnh animation tiết kiệm GPU mà vẫn mượt mà
            "settings put global window_animation_scale 0.5",
            "settings put global transition_animation_scale 0.5",
            "settings put global animator_duration_scale 0.5",
            // 3. Tắt các dịch vụ theo dõi quảng cáo, gợi ý tốn pin
            "settings put secure advertising_id_opt_out 1",
            "settings put global personalized_ad_enabled 0",
            "settings put system auto_download_magazine_wifi 0",
            // 4. Đảm bảo whitelist không bị trễ thông báo cho các app nhắn tin & Meta (trừ Facebook chính)
            "dumpsys deviceidle whitelist +com.zing.zalo",
            "dumpsys deviceidle whitelist +com.facebook.orca",
            "dumpsys deviceidle whitelist +com.instagram.android",
            "dumpsys deviceidle whitelist +com.instagram.barcelona",
            "dumpsys deviceidle whitelist +org.telegram.messenger",
            "dumpsys deviceidle whitelist +org.telegram.plus",
            "dumpsys deviceidle whitelist +com.google.android.gm",
            "dumpsys deviceidle whitelist +com.whatsapp",
            "dumpsys deviceidle whitelist +com.whatsapp.w4b",
            "dumpsys deviceidle whitelist +com.viber.voip",
            // Đặt active bucket cho Zalo, Messenger, Instagram, Threads, WhatsApp, Telegram để không bị hạn chế ngầm
            "am set-standby-bucket com.zing.zalo active",
            "am set-standby-bucket com.facebook.orca active",
            "am set-standby-bucket com.instagram.android active",
            "am set-standby-bucket com.instagram.barcelona active",
            "am set-standby-bucket com.whatsapp active",
            "am set-standby-bucket org.telegram.messenger active",
            // 5. Giải phóng buffer dư thừa
            "setprop persist.sys.purge_buffers 1"
        )
        val ok = runVerifiedBatch("Siêu Tiết Kiệm Pin Thông Minh (Zero Delay)", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * Tăng độ nhạy cảm ứng và nâng cao vùng nhận diện cử chỉ mép dưới màn hình:
     * Khắc phục triệt để tình trạng vuốt mép dưới khó ăn sau khi tắt YOYO hoặc do dán kính cường lực dày cản trở.
     */
    suspend fun enhanceBottomGestureSensitivity(): Boolean = withContext(Dispatchers.IO) {
        log("⚡ Đang xóa điểm chết cảm ứng đáy & kích hoạt cảm ứng ngay tại vị trí mép đáy (Fix kính cường lực & ẩn thanh điều hướng)...", LogType.INFO)
        val cmds = listOf(
            // 1. Giảm triệt để độ trễ và thời gian chặn cảm ứng chạm ở mép màn hình về 0
            "settings put secure touch_response_time 0",
            "settings put secure touch_responsiveness_level 1",
            "settings put secure tap_duration_threshold 0",
            "settings put secure touch_blocking_period 0",
            "settings put secure touch_edge_filter 0",
            "settings put system touch_edge_filter 0",
            
            // 2. Tinh chỉnh tốc độ con trỏ và kích hoạt cảm ứng sát mép kính dưới cùng
            "settings put system pointer_speed 7",
            
            // 3. Xóa điểm chết vùng từng hiện thanh kim: Nâng cao chiều cao và vùng nhận diện cử chỉ đáy
            "settings put secure gesture_nav_sensitivity 2",
            "settings put secure bottom_gesture_inset_scale 2",
            "settings put secure bottom_gesture_height 2",
            "settings put secure navigation_bar_gesture_height 2",
            "settings put system navigation_bar_gesture_height 2",
            "settings put secure back_gesture_inset_scale_left 0",
            "settings put secure back_gesture_inset_scale_right 0",
            
            // 4. Đảm bảo chế độ toàn màn hình không nuốt cảm ứng ở vùng thanh kim
            "settings put secure secure_gesture_navigation_immersive 0",
            "settings put global navigation_bar_touch_deadzone 0",
            "settings put secure navigation_bar_touch_deadzone 0",

            // 5. Tắt hoàn toàn cản trở từ YOYO điều hướng để trả lại 100% cảm ứng cho mép dưới
            "settings put secure navigation_bar_wakeup_yoyo 0",
            "settings put secure yoyo_navigation_bar_wakeup 0",
            "settings put system navigation_bar_wakeup_yoyo 0",
            "settings put secure wake_up_yoyo_by_nav_bar 0",
            "settings put secure assist_long_press_home_enabled 0"
        )
        val ok = runVerifiedBatch("Xóa điểm chết & Kích hoạt cảm ứng mép đáy", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    private fun getPanelMaxRefreshRate(): Int {
        return try {
            val dm = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
            val disp = dm?.getDisplay(Display.DEFAULT_DISPLAY)
            val hwMax = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && disp != null) {
                disp.supportedModes.maxOfOrNull { kotlin.math.round(it.refreshRate).toInt() } ?: 120
            } else 120
            hwMax.coerceIn(60, 165)
        } catch (_: Throwable) {
            120
        }
    }

    /**
     * Tối ưu cảm ứng & vân tay quang học dưới màn hình cho kính cường lực dày (>0.45mm / chống nhìn trộm / UV)
     * Hỗ trợ Honor MagicOS 9/10/11 & Android 15/16/17.
     */
    suspend fun boostTouchAndFingerprintSensitivity(): Boolean = withContext(Dispatchers.IO) {
        log("⚡ Đang kích hoạt Tối Ưu Cảm Ứng & Cảm Biến Vân Tay Dưới Màn Hình (MagicOS 9/10/11)...", LogType.INFO)
        val maxHz = getPanelMaxRefreshRate()
        val cmds = listOf(
            // 1. Chế độ tấm dán màn hình & tăng độ nhạy cảm ứng Android & MagicOS 9/10/11
            "settings put secure screen_protector_mode 1",
            "settings put secure touch_sensitivity 1",
            "settings put secure high_touch_sensitivity_enable 1",
            "settings put system touch_screen_film_switch 1",
            "settings put system hw_touch_screen_film_switch 1",
            "settings put secure hw_screen_film_state 1",
            "settings put secure hihonor_screen_film_state 1",
            "settings put system hw_supertouch_switch 1 2>/dev/null || true",
            "settings put system hw_touch_enhance 1 2>/dev/null || true",
            
            // 2. Chế độ găng tay (Glove Mode) - Tăng độ nhạy điện dung tối đa xuyên qua kính dày >0.45mm
            "settings put system glove_file_status 1",
            "settings put system touch_glove_mode 1",
            "settings put system hw_glove_mode 1",
            "settings put system hihonor_glove_mode 1",

            // 3. Tối ưu độ trễ cảm ứng & tần số lấy mẫu cảm ứng (Touch Sampling Rate)
            "settings put secure touch_response_time 0",
            "settings put system touch_response_time 0",
            "settings put secure touch_responsiveness_level 1",
            "settings put system touch_responsiveness_level 1",
            "settings put secure tap_duration_threshold 0",
            "settings put secure touch_blocking_period 0",
            "settings put secure touch_edge_filter 0",
            "settings put system touch_edge_filter 0",
            "settings put system game_touch_sampling_rate 1",
            "settings put system pointer_speed 7",

            // 4. Tối ưu cử chỉ vuốt & nhận diện vùng ngón tay
            "settings put secure gesture_nav_sensitivity 2",
            "settings put secure bottom_gesture_inset_scale 2",
            "settings put secure bottom_gesture_height 2",
            "settings put secure navigation_bar_gesture_height 2",
            "settings put system navigation_bar_gesture_height 2",

            // 5. Tăng tốc độ mở khóa & mượt mà hoạt ảnh theo Max Hz phần cứng (giữ LTPO tiết kiệm pin)
            "settings put global window_animation_scale 0.5",
            "settings put global transition_animation_scale 0.5",
            "settings put global animator_duration_scale 0.5",
            // Không khóa tần số quét trong trình sửa cảm ứng/vân tay.
        )
        val ok = runVerifiedBatch("Tối Ưu Cảm Ứng & Vân Tay Cường Lực Dày", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun revertTouchAndFingerprintSensitivity(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang khôi phục cài đặt cảm ứng & vân tay về mặc định hệ thống...", LogType.INFO)
        val cmds = listOf(
            "settings put secure screen_protector_mode 0",
            "settings put secure touch_sensitivity 0",
            "settings put secure high_touch_sensitivity_enable 0",
            "settings put system touch_screen_film_switch 0",
            "settings put system hw_supertouch_switch 0 2>/dev/null || true",
            "settings put system hw_touch_enhance 0 2>/dev/null || true",
            "settings put system glove_file_status 0",
            "settings put system touch_glove_mode 0",
            "settings put secure touch_response_time 1",
            "settings put system touch_response_time 1",
            "settings put system game_touch_sampling_rate 0"
        )
        val ok = runVerifiedBatch("Khôi phục cài đặt cảm ứng mặc định", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * 1. TĂNG TỐC ĐỘ WI-FI & GIẢM ĐỘ TRỄ (Low Latency Wi-Fi Booster)
     * - Mở rộng kích thước bộ đệm TCP (TCP buffer size) tải dữ liệu siêu tốc
     * - Tắt quét Wi-Fi ngầm định vị rác gây gián đoạn đường truyền & nhảy ping
     * - Kích hoạt chế độ Low Latency Mode và Wi-Fi Never Sleep khi đang truyền tải
     * - Tắt ghi log chi tiết của chip Wi-Fi (giảm tải CPU máy)
     */
    suspend fun boostWifiSpeedAndLatency(): Boolean = withContext(Dispatchers.IO) {
        log("🚀 Đang kích hoạt Tăng Tốc Độ Wi-Fi & Giảm Độ Trễ (Low Latency Mode)...", LogType.INFO)
        val cmds = listOf(
            // 1. Tắt quét Wi-Fi rác nền & kích hoạt throttling chống nghẽn chip Wi-Fi
            "settings put global wifi_scan_always_enabled 0",
            "settings put global wifi_scan_throttle_enabled 1",
            "settings put global wifi_networks_available_notification_on 0",
            
            // 2. Chế độ Wi-Fi Never Sleep & độ trễ thấp
            "settings put global wifi_sleep_policy 2",
            "settings put global wifi_low_latency_mode 1",
            "settings put global wifi_frequency_band 0",
            "settings put global network_avoid_bad_wifi 1",
            "settings put global wifi_poor_connection_warning 0",
            "settings put global wifi_verbose_logging_enabled 0",
            
            // 3. Tối ưu kích thước bộ đệm TCP (TCP Window Buffer) & giảm trễ gói cho Android 15-17
            "setprop net.tcp.buffersize.wifi 524288,1048576,2097152,262144,524288,1048576 >/dev/null 2>&1 || true",
            "setprop net.ipv4.tcp_ecn 0 >/dev/null 2>&1 || true"
        )
        val ok = runVerifiedBatch("Tăng Tốc Độ Wi-Fi & Giảm Trễ", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * 2. ỔN ĐỊNH WI-FI KÉP & LINK TURBO (Dual Wi-Fi & Multi-Network Acceleration)
     * - Kích hoạt tính năng kết nối đồng thời 2 băng tần Wi-Fi (2.4GHz + 5GHz) trên Honor/Xiaomi/Android
     * - Kích hoạt công nghệ Link Turbo tăng tốc mạng song song Wi-Fi + Di động mượt mà
     * - Giãn chu kỳ scan roaming để chống chập chờn khi di chuyển giữa các trạm phát sóng Wi-Fi
     */
    suspend fun boostDualWifiAndLinkTurbo(): Boolean = withContext(Dispatchers.IO) {
        log("📶 Đang kích hoạt Ổn Định Wi-Fi Kép & Tăng Tốc Link Turbo (2.4G + 5G)...", LogType.INFO)
        val cmds = listOf(
            // 1. Kích hoạt Wi-Fi kép & Băng tần kép (Honor MagicOS / Android)
            "settings put system dual_wifi_state 1",
            "settings put system hw_dual_band_enable 1",
            "settings put system hihonor_dual_band_enable 1",
            "settings put global wifi_boost_enable 1",
            "settings put system wifi_accelerate_state 1",

            // 2. Kích hoạt Link Turbo / Network Acceleration
            "settings put system link_turbo_enable 1",
            "settings put global link_turbo_enable 1",
            "settings put secure link_turbo_enable 1",
            "settings put system smart_dual_card_switch 1",

            // 3. Ổn định chuyển vùng Wi-Fi (Roaming) mượt mà không rớt gói
            "settings put global wifi_framework_scan_interval_ms 300000",
            "settings put global wifi_suspend_optimizations_enabled 3"
        )
        val ok = runVerifiedBatch("Ổn Định Wi-Fi Kép & Link Turbo", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * 3. SIÊU TIẾT KIỆM PIN KẾT NỐI LUÔN BẬT (Always-On Connected Battery Saver)
     * - Tắt "Mobile Data Always On": Modem 4G/5G sẽ ngắt sóng chờ ngầm khi đang dùng Wi-Fi (tiết kiệm 20-30% pin)
     * - Tắt BLE / Bluetooth background scan định vị: Tiết kiệm pin mà tai nghe & smartwatch vẫn kết nối 100%
     * - Tắt Wi-Fi background location scan: Ngăn Google ngầm quét Wi-Fi
     * - Kích hoạt Smart 5G: Tự động dùng 4G khi tác vụ nhẹ và 5G khi tải nặng (máy mát hơn 3-5°C, giảm hao pin modem)
     * - Tối ưu Light Doze mà không cấp whitelist chạy nền cho ứng dụng
     */
    suspend fun applyAlwaysOnNetworkBatterySaver(): Boolean = withContext(Dispatchers.IO) {
        log("🔋 Đang kích hoạt Siêu Tiết Kiệm Pin Kết Nối 24/7 (Tắt 4G chờ ngầm khi có Wi-Fi, tắt scan BLE/Wi-Fi nền)...", LogType.INFO)
        val cmds = listOf(
            // 1. Tắt Mobile Data Always On để modem 4G/5G nghỉ khi đang dùng Wi-Fi (tiết kiệm 20-30% pin)
            "settings put global mobile_data_always_on 0",

            // 2. Tắt quét Bluetooth BLE định vị ngầm
            "settings put global ble_scan_always_enabled 0",

            // 3. Tắt quét Wi-Fi định vị ngầm
            "settings put global wifi_scan_always_enabled 0",

            // 4. Kích hoạt Smart 5G (Thông minh chuyển 4G/5G, giảm nóng máy và tiết kiệm pin)
            "settings put system smart_5g 1",
            "settings put global smart_5g 1",
            "settings put secure smart_5g 1",

            // 5. Tối ưu năng lượng Bluetooth & Modem
            "settings put system bluetooth_power_save 1",

            // 6. Tinh chỉnh Light Doze an toàn, giữ ngủ sâu bình thường
            "settings put global device_idle_constants light_after_inactive_to=30000,light_pre_idle_to=60000,light_idle_to=120000,light_idle_factor=2.0,light_max_idle_to=900000"
        )

        val ok = runVerifiedBatch("Siêu Tiết Kiệm Pin Kết Nối Luôn Bật", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * 4. KHÔI PHỤC CÀI ĐẶT MẠNG & PIN KẾT NỐI VỀ MẶC ĐỊNH HỆ THỐNG
     */
    suspend fun restoreDefaultNetworkAndBatterySettings(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang khôi phục cài đặt mạng, Wi-Fi và pin kết nối về mặc định hệ thống...", LogType.INFO)
        val cmds = listOf(
            "settings put global mobile_data_always_on 1",
            "settings put global ble_scan_always_enabled 1",
            "settings put global wifi_scan_always_enabled 1",
            "settings put global wifi_scan_throttle_enabled 1",
            "settings put global wifi_networks_available_notification_on 1",
            "settings put global wifi_sleep_policy 2",
            "settings put global wifi_low_latency_mode 0",
            "settings put global wifi_poor_connection_warning 1",
            "settings put global wifi_framework_scan_interval_ms 10000",
            "settings put global wifi_suspend_optimizations_enabled 1",
            "settings put system dual_wifi_state 0",
            "settings put system hw_dual_band_enable 0",
            "settings put system hihonor_dual_band_enable 0",
            "settings put global wifi_boost_enable 0",
            "settings put system wifi_accelerate_state 0",
            "settings put system link_turbo_enable 0",
            "settings put global link_turbo_enable 0",
            "settings put secure link_turbo_enable 0",
            "settings put system smart_dual_card_switch 0",
            "settings put system smart_5g 1",
            "settings put global smart_5g 1",
            "settings put secure smart_5g 1",
            "settings put system bluetooth_power_save 0",
            "settings delete global device_idle_constants"
        )
        val ok = runVerifiedBatch("Khôi Phục Mạng & Pin Mặc Định", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /** Toggle Android Battery Saver through the authorized shell connection. */
    suspend fun applyVaporChamberCooling(): Boolean = withContext(Dispatchers.IO) {
        val result = com.example.core.perf.SafeThermalRelief.toggle(context)
        log(result.message, if (result.success) LogType.SUCCESS else LogType.ERROR)
        refreshTuneStatus()
        result.success
    }

    /**
     * MƯỢT MÀ ỔN ĐỊNH ĐỈNH CAO MAGICOS (Fluid Touch Experience)
     * - Ưu tiên phản hồi cảm ứng 0ms, mức nhạy cao nhất, Touch Sampling Rate cực đại
     * - Không ghi các thuộc tính debug SurfaceFlinger/HWUI để tránh lỗi hiển thị theo ROM
     * - Hoạt ảnh vật lý đàn hồi mượt mà 0.5x không trễ
     * - Giữ tần số quét thích ứng mặc định do Android/OEM quản lý
     */
    suspend fun applyIosFluidSmoothness(): Boolean = withContext(Dispatchers.IO) {
        context.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
            .edit().putBoolean("magictune_refresh_lock_active", false).apply()
        val maxHz = getPanelMaxRefreshRate()
        log("⚡ Đang kích hoạt Trải Nghiệm Mượt Mà & Cảm Ứng Đỉnh Cao MagicOS (tối đa ${maxHz}Hz, giữ chế độ thích ứng hệ thống)...", LogType.INFO)
        val cmds = listOf(
            // 1. Phản hồi cảm ứng tức thì 0ms & Tần số lấy mẫu cảm ứng tối đa (Honor MagicOS 9/10/11)
            "settings put secure touch_response_time 0",
            "settings put system touch_response_time 0",
            "settings put secure touch_sensitivity 1",
            "settings put system touch_responsiveness_level 1",
            "settings put secure tap_duration_threshold 0",
            "settings put secure touch_blocking_period 0",
            "settings put secure touch_edge_filter 0",
            "settings put system touch_edge_filter 0",
            "settings put system game_touch_sampling_rate 1",
            "settings put system hw_supertouch_switch 1 >/dev/null 2>&1 || true",
            "settings put system hw_touch_enhance 1 >/dev/null 2>&1 || true",
            "settings put system pointer_speed 7",

            // Không ghi thuộc tính debug SurfaceFlinger/HWUI: giữ cấu hình render ổn định của ROM.

            // 2. Hoạt ảnh chuyển cảnh mượt mà chuẩn MagicOS
            "settings put global window_animation_scale 0.5",
            "settings put global transition_animation_scale 0.5",
            "settings put global animator_duration_scale 0.5",

            // Để Android tự chọn tần số phù hợp với nội dung; không ghim sàn 60Hz hoặc xóa giới hạn OEM.
            "settings delete system peak_refresh_rate",
            "settings delete system min_refresh_rate",
            "settings put system user_refresh_rate 0",
            "cmd display set-match-content-frame-rate-pref 1 >/dev/null 2>&1 || true",

            // 5. Cử chỉ vuốt toàn màn hình mượt mà không khựng mép
            "settings put secure gesture_nav_sensitivity 2",
            "settings put secure bottom_gesture_inset_scale 2",
            "settings put secure bottom_gesture_height 2",
            "settings put secure navigation_bar_gesture_height 2",
            "settings put system navigation_bar_gesture_height 2",
            "settings put secure back_gesture_inset_scale_left 0",
            "settings put secure back_gesture_inset_scale_right 0",
            "settings put secure secure_gesture_navigation_immersive 0",
            "settings put global navigation_bar_touch_deadzone 0"
        )
        val ok = runVerifiedBatch("Mượt Mà Đỉnh Cao MagicOS (LTPO Thích Ứng)", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * KHÔI PHỤC CÀI ĐẶT MƯỢT MÀ & TẢN NHIỆT VỀ MẶC ĐỊNH
     */
    suspend fun restoreDefaultSmoothnessAndThermal(): Boolean = withContext(Dispatchers.IO) {
        context.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
            .edit().putBoolean("magictune_refresh_lock_active", false).apply()
        log("🔄 Đang khôi phục cài đặt độ mượt và tản nhiệt về mặc định...", LogType.INFO)
        val cmds = listOf(
            "settings put global window_animation_scale 1.0",
            "settings put global transition_animation_scale 1.0",
            "settings put global animator_duration_scale 1.0",
            "settings put secure touch_response_time 1",
            "settings put system touch_response_time 1",
            "settings put secure touch_responsiveness_level 0",
            "settings put system game_touch_sampling_rate 0",
            "settings delete system smart_refresh_rate",
            "settings delete secure smart_refresh_rate",
            "settings delete system smart_cooling_mode",
            "settings delete system hw_thermal_mode",
            "settings delete secure hw_thermal_mode",
            "settings delete system thermal_control",
            "settings delete system peak_refresh_rate",
            "settings delete system min_refresh_rate",
            "settings put system user_refresh_rate 0",
            "cmd display set-match-content-frame-rate-pref 1 >/dev/null 2>&1 || true",
            "cmd power set-adaptive-power-saver-enabled true >/dev/null 2>&1 || true",
            "setprop debug.sf.early_phase_offset_ns '' >/dev/null 2>&1 || true",
            "setprop debug.sf.early_app_phase_offset_ns '' >/dev/null 2>&1 || true",
            "setprop debug.sf.early_gl_phase_offset_ns '' >/dev/null 2>&1 || true",
            "setprop debug.sf.early_gl_app_phase_offset_ns '' >/dev/null 2>&1 || true",
            "setprop debug.hwui.render_dirty_regions '' >/dev/null 2>&1 || true",
            "cmd thermalservice reset 2>/dev/null || true"
        )
        val ok = runVerifiedBatch("Khôi phục Mượt mà & Tản nhiệt Mặc định", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * ĐỘNG CƠ PIN TRÂU CHUẨN MAGICOS (SOT CAO & 100% FULL THÔNG BÁO)
     * - Giữ App Standby & Cached Apps Freezer bật cho app thường; không miễn trừ Doze cho app khác
     * - Ngắt modem 4G/5G chờ ngầm khi có Wi-Fi (-25% pin), tắt BLE/Wi-Fi scan định vị
     */
    suspend fun applyIosBatteryEngine(): Boolean = withContext(Dispatchers.IO) {
        log("🔋 Đang kích hoạt Động Cơ Pin Trâu Chuẩn MagicOS (Tiết Kiệm Pin & Giữ Thông Báo Quan Trọng)...", LogType.INFO)
        val cmds = mutableListOf(
            // 1. Để Doze/DeviceIdle dùng cấu hình mặc định của Android và ROM.

            // 2. Bật App Standby & Freezer cho các app ít dùng để tránh rò rỉ pin ngầm
            "settings put global app_standby_enabled 1",
            "settings put global adaptive_battery_management_enabled 1",
            "settings put global cached_apps_freezer enabled >/dev/null 2>&1 || true",
            "device_config put activity_manager_native_boot use_freezer true >/dev/null 2>&1 || true",

            // 3. Tắt 4G/5G chờ ngầm khi có Wi-Fi & tắt quét BLE/Wi-Fi nền
            "settings put global mobile_data_always_on 0",
            "settings put global wifi_scan_always_enabled 0",
            "settings put global ble_scan_always_enabled 0",
            "settings put system smart_5g 1",
            "settings put global smart_5g 1",
            "settings put secure smart_5g 1",

            // 4. Chặn rò rỉ pin qua telemetry & quảng cáo
            "settings put secure advertising_id_opt_out 1",
            "settings put global personalized_ad_enabled 0",
            "settings put system auto_download_magazine_wifi 0",
            "settings put global logd_size 64K",
            "setprop persist.logd.size 64K >/dev/null 2>&1 || true",
            "setprop persist.sys.purge_buffers 1 >/dev/null 2>&1 || true",

            // 5. Tiết kiệm năng lượng màn hình OLED (Dark Mode OLED)
            "settings put secure ui_night_mode 2",
            "settings put system ui_night_mode 2",
            "settings put global window_animation_scale 0.5",
            "settings put global transition_animation_scale 0.5",
            "settings put global animator_duration_scale 0.5"
        )

        val ok = runVerifiedBatch("Động Cơ Pin Trâu Chuẩn MagicOS (Tiết Kiệm Pin & Giữ Thông Báo)", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * KHÔI PHỤC CÀI ĐẶT PIN VỀ MẶC ĐỊNH
     */
    suspend fun restoreDefaultBatteryEngine(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang khôi phục cài đặt pin về mặc định hệ thống...", LogType.INFO)
        val legacyExemptApps = listOf(
            context.packageName,
            "com.zing.zalo",
            "com.facebook.orca",
            "com.instagram.android",
            "com.instagram.barcelona",
            "org.telegram.messenger",
            "org.telegram.plus",
            "com.google.android.gm",
            "com.whatsapp",
            "com.whatsapp.w4b",
            "com.viber.voip"
        ).distinct()
        val cmds = mutableListOf(
            "settings delete global device_idle_constants",
            "settings put global app_standby_enabled 1",
            "settings put global cached_apps_freezer enabled >/dev/null 2>&1 || true",
            "device_config put activity_manager_native_boot use_freezer true >/dev/null 2>&1 || true",
            "settings put global mobile_data_always_on 0",
            "settings put global wifi_scan_always_enabled 1",
            "settings put global ble_scan_always_enabled 1",
            "settings put secure advertising_id_opt_out 0",
            "settings put global logd_size 256K"
        )
        legacyExemptApps.forEach { pkg ->
            cmds.add("cmd deviceidle whitelist -$pkg >/dev/null 2>&1 || true")
            cmds.add("cmd appops set $pkg RUN_IN_BACKGROUND default >/dev/null 2>&1 || true")
            cmds.add("cmd appops set $pkg RUN_ANY_IN_BACKGROUND default >/dev/null 2>&1 || true")
        }
        val ok = runVerifiedBatch("Khôi phục cài đặt pin mặc định", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * MỞ KHÓA DUNG LƯỢNG PIN THỰC HONOR (PHÁ KHÓA 80% ẢO CỦA SMART BATTERY CAPACITY)
     * - Mặc định Honor bật `smart_battery_capacity_switch = 1` và `smart_charge_switch = 1`, tự động hạ điện áp ngắt sạc đỉnh
     *   khiến máy báo 100% nhưng thực tế chỉ nạp ~80%–85% dung lượng vật lý của viên pin Silicon-Carbon.
     * - Hàm này tắt hoàn toàn khóa dung lượng thông minh cực đoan của Honor, hiệu chuẩn lại bộ đếm BMS (`dumpsys battery reset`),
     *   và cho phép chọn mức trần sạc tùy chỉnh (ví dụ `97%` chỉ giữ đúng 3% đệm bảo vệ an toàn, hoặc `100%` mở toàn bộ dung lượng vật lý).
     */
    suspend fun unlockHonorBatteryCapacity(targetLimitPercent: Int = 97): Boolean = withContext(Dispatchers.IO) {
        val safeLimit = targetLimitPercent.coerceIn(90, 100)
        val bufferPct = 100 - safeLimit
        val modeDesc = if (safeLimit < 100) {
            "Mở khóa $safeLimit% dung lượng thực (Chỉ giữ $bufferPct% đệm bảo vệ an toàn)"
        } else {
            "Mở khóa 100% dung lượng vật lý thực (Chỉ giữ đệm PMIC phần cứng ~2%)"
        }
        log("🔋 Đang thực thi: $modeDesc...", LogType.INFO)
        val isCustomLimit = if (safeLimit < 100) 1 else 0
        val cmds = listOf(
            // 1. Tắt hoàn toàn Dung lượng pin thông minh (Smart Battery Capacity) gây khóa 15-20% dung lượng thực
            "settings put system smart_battery_capacity_switch 0",
            "settings put secure smart_battery_capacity_switch 0",
            "settings put global smart_battery_capacity_switch 0",
            "settings put system smart_battery_capacity 0",
            "settings put secure smart_battery_capacity 0",
            "settings put global smart_battery_capacity 0",
            "settings put system hw_smart_battery_capacity 0",

            // 2. Tắt Sạc thông minh giữ ở 80% (Smart Charge 80% hold)
            "settings put system smart_charge_switch 0",
            "settings put secure smart_charge_switch 0",
            "settings put global smart_charge_switch 0",
            "settings put system charge_protect_mode 0",
            "settings put secure charge_protect_mode 0",

            // 3. Thiết lập ngưỡng trần sạc tùy chỉnh (ví dụ 97% chỉ giữ 3% đệm, hoặc 100% tối đa)
            "settings put system custom_charge_limit_switch $isCustomLimit",
            "settings put secure custom_charge_limit_switch $isCustomLimit",
            "settings put system custom_charge_limit $safeLimit",
            "settings put secure custom_charge_limit $safeLimit",
            "settings put global custom_charge_limit $safeLimit",
            "settings put system charge_limit_percent $safeLimit",
            "settings put secure charge_limit_percent $safeLimit",
            "settings put system smart_charge_limit $safeLimit",
            "settings put secure magictune_battery_cap_unlocked 1",
            "settings put secure magictune_charge_limit_pct $safeLimit",

            // 4. Reset bộ đếm ảo BatteryService để Android đồng bộ lại phần trăm thực từ mạch đo Coulomb BMS
            "dumpsys battery reset 2>/dev/null || true"
        )
        val ok = runVerifiedBatch(modeDesc, cmds)
        shellEngine.setPersistedSetting("system", "smart_battery_capacity_switch", "0")
        shellEngine.setPersistedSetting("secure", "smart_battery_capacity_switch", "0")
        shellEngine.setPersistedSetting("system", "custom_charge_limit", safeLimit.toString())
        shellEngine.setPersistedSetting("secure", "magictune_battery_cap_unlocked", "1")
        shellEngine.setPersistedSetting("secure", "magictune_charge_limit_pct", safeLimit.toString())
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * KHÔI PHỤC CHẾ ĐỘ BẢO VỆ DUNG LƯỢNG PIN THÔNG MINH MẶC ĐỊNH CỦA HONOR
     */
    suspend fun restoreHonorSmartBatteryCapacityDefault(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang khôi phục chế độ Dung lượng pin thông minh & Sạc thông minh mặc định của Honor...", LogType.INFO)
        val cmds = listOf(
            "settings put system smart_battery_capacity_switch 1",
            "settings put secure smart_battery_capacity_switch 1",
            "settings put global smart_battery_capacity_switch 1",
            "settings put system smart_charge_switch 1",
            "settings put secure smart_charge_switch 1",
            "settings put system custom_charge_limit_switch 0",
            "settings put secure custom_charge_limit_switch 0",
            "settings delete system custom_charge_limit >/dev/null 2>&1 || true",
            "settings delete secure custom_charge_limit >/dev/null 2>&1 || true",
            "settings put secure magictune_battery_cap_unlocked 0",
            "dumpsys battery reset 2>/dev/null || true"
        )
        val ok = runVerifiedBatch("Khôi phục Dung lượng pin thông minh Honor mặc định", cmds)
        shellEngine.setPersistedSetting("system", "smart_battery_capacity_switch", "1")
        shellEngine.setPersistedSetting("secure", "smart_battery_capacity_switch", "1")
        shellEngine.setPersistedSetting("secure", "magictune_battery_cap_unlocked", "0")
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun applyMaxSettings(): Boolean = withContext(Dispatchers.IO) {
        val maxHz = getPanelMaxRefreshRate()
        log("🚀 Đang kích hoạt Max Settings toàn diện (${maxHz}Hz LTPO Thích Ứng, Animation 0.5x, Touch Boost MagicOS 9/10/11, Tắt gọi YOYO)...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Bật Max Settings Toàn Diện",
            listOf(
                "settings put system peak_refresh_rate ${maxHz}.0",
                "settings delete system min_refresh_rate",
                "settings put system user_refresh_rate 0",
                "cmd display set-match-content-frame-rate-pref 1 >/dev/null 2>&1 || true",
                "settings put global window_animation_scale 0.5",
                "settings put global transition_animation_scale 0.5",
                "settings put global animator_duration_scale 0.5",
                "settings put secure touch_response_time 0",
                "settings put system touch_response_time 0",
                "settings put secure touch_responsiveness_level 1",
                "settings put system hw_supertouch_switch 1 >/dev/null 2>&1 || true",
                "settings put system hw_touch_enhance 1 >/dev/null 2>&1 || true",
                "settings put global block_screen_capture 0",
                "settings put global 5g_mode 1",
                "settings put global nr_mode_switch 1",
                "settings put system smart_5g 1",
                "settings put global smart_5g 1",
                "settings put secure smart_5g 1",
                "settings put global mobile_data_always_on 0",
                "settings put global bluetooth_absolute_volume 0",
                "settings put secure assist_long_press_home_enabled 1",
                "settings put secure search_press_hold_nav_handle_enabled 1"
            ).let { base ->
                val result = base.toMutableList()
                if (!com.example.core.service.SystemFloatingHudOverlay.isYoyoCoexistModeEnabled(context)) {
                    result.add("settings put secure navigation_bar_wakeup_yoyo 0")
                    result.add("settings put secure yoyo_navigation_bar_wakeup 0")
                }
                val curAssist = try { Settings.Secure.getString(context.contentResolver, "assistant") ?: "" } catch (_: Throwable) { "" }
                if (!curAssist.contains(context.packageName)) {
                    result.add("settings put secure assistant com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService")
                    result.add("settings put secure voice_interaction_service com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService")
                }
                result
            }
        )
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun setRefreshRate(rate: Int): Boolean = withContext(Dispatchers.IO) {
        val hwMax = getPanelMaxRefreshRate()
        val targetRate = when {
            rate <= 60 -> 60
            rate >= 120 -> hwMax.coerceAtLeast(120)
            else -> rate.coerceAtMost(hwMax)
        }
        log("📺 Chỉnh giới hạn tần số quét tối đa ${targetRate}Hz (màn hình vẫn được phép hạ tần số để tiết kiệm pin • phần cứng tối đa ${hwMax}Hz)...", LogType.INFO)
        val commands = if (targetRate == 60) {
            listOf(
                "settings put system peak_refresh_rate 60.0",
                "settings put system min_refresh_rate 60.0",
                "settings put system user_refresh_rate 60",
                "settings put system honor_screen_refresh_rate 60",
                "settings put system hw_screen_refresh_rate 60",
                "settings put secure honor_screen_refresh_rate 60",
                "settings put global honor_screen_refresh_rate 60",
                "cmd display set-match-content-frame-rate-pref 1 >/dev/null 2>&1 || true"
            )
        } else {
            listOf(
                "settings put system peak_refresh_rate ${targetRate}.0",
                "settings delete system min_refresh_rate",
                "settings put system user_refresh_rate $targetRate",
                "settings put system honor_screen_refresh_rate $targetRate",
                "settings put system hw_screen_refresh_rate $targetRate",
                "settings put secure honor_screen_refresh_rate $targetRate",
                "settings put global honor_screen_refresh_rate $targetRate",
                "cmd display set-match-content-frame-rate-pref 1 >/dev/null 2>&1 || true"
            )
        }
        val ok = runVerifiedBatch(
            "Đặt giới hạn tối đa ${targetRate}Hz (thích ứng)",
            commands
        )
        if (ok) {
            context.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
                .edit().putInt("magictune_configured_refresh_rate", targetRate).apply()
        }
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun setPermanentRefreshRateLock(rate: Int, lock: Boolean): Boolean = withContext(Dispatchers.IO) {
        val kvPrefs = context.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
        if (lock) {
            kvPrefs.edit().putBoolean("magictune_refresh_lock_active", false).apply()
            log("🔒 Khóa cứng tần số quét đã tắt để tránh giữ màn hình ở tần số cao và làm nóng máy. Hãy dùng giới hạn tối đa thích ứng.", LogType.INFO)
            return@withContext false
        }
        kvPrefs.edit().putBoolean("magictune_refresh_lock_active", false).apply()
        runVerifiedBatch(
            "Mở khóa tần số quét thích ứng",
            listOf(
                "settings delete system peak_refresh_rate",
                "settings delete system min_refresh_rate",
                "settings put system user_refresh_rate 0",
                "cmd display set-match-content-frame-rate-pref 1 >/dev/null 2>&1 || true"
            )
        )
        log("🔓 Đã mở khóa tần số quét màn hình về chế độ thích ứng tự nhiên.", LogType.INFO)
        refreshDeviceInfo()
        refreshTuneStatus()
        true
    }

    suspend fun setPermanentResolutionLock(mode: String, lock: Boolean): Boolean = withContext(Dispatchers.IO) {
        val safeMode = if (mode == "HD") "MAX_NATIVE" else mode
        val kvPrefs = context.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
        kvPrefs.edit()
            .putBoolean("magictune_resolution_lock_active", lock)
            .putString("magictune_resolution_lock_mode", safeMode)
            .apply()

        val cmds = mutableListOf<String>()
        when (safeMode) {
            "MAX_NATIVE" -> {
                cmds.add("wm size reset")
                cmds.add("wm density reset")
            }
            "FHD_1080", "FHD" -> {
                cmds.add("wm size 1080x2400")
                cmds.add("wm density 420")
            }
            "FHD_1080_HONOR" -> {
                cmds.add("wm size 1080x2412")
                cmds.add("wm density 420")
            }
            "FHD_1080_WIDE" -> {
                cmds.add("wm size 1080x2460")
                cmds.add("wm density 420")
            }
            "QHD_1200" -> {
                cmds.add("wm size 1200x2664")
                cmds.add("wm density 440")
            }
            "QHD_1220" -> {
                cmds.add("wm size 1220x2712")
                cmds.add("wm density 440")
            }
            "QHD_1264" -> {
                cmds.add("wm size 1264x2780")
                cmds.add("wm density 460")
            }
            "QHD_1440" -> {
                cmds.add("wm size 1440x3200")
                cmds.add("wm density 520")
            }
            else -> {
                cmds.add("wm size reset")
                cmds.add("wm density reset")
            }
        }
        if (lock && cmds.isNotEmpty()) {
            runVerifiedBatch("Khóa cứng độ phân giải màn hình ($safeMode)", cmds)
            val friendlyName = when (safeMode) {
                "MAX_NATIVE" -> "Gốc Mặc Định (Tối Đa)"
                "FHD_1080", "FHD" -> "FHD+ (1080x2400)"
                "FHD_1080_HONOR" -> "FHD+ Honor (1080x2412)"
                "FHD_1080_WIDE" -> "FHD+ Dài (1080x2460)"
                "QHD_1200" -> "1.2K+ (1200x2664)"
                "QHD_1220" -> "1.5K (1220x2712)"
                "QHD_1264" -> "1.5K+ Honor (1264x2780)"
                "QHD_1440" -> "2K QHD+ (1440x3200)"
                else -> safeMode
            }
            log("🔒 Đã khóa cứng độ phân giải màn hình $friendlyName (từ 1080p trở lên, không phóng đại)!", LogType.SUCCESS)
        } else {
            runVerifiedBatch("Khôi phục độ phân giải gốc", listOf("wm size reset", "wm density reset"))
            log("🔓 Đã mở khóa độ phân giải màn hình về gốc mặc định.", LogType.INFO)
        }
        refreshDeviceInfo()
        refreshTuneStatus()
        true
    }

    suspend fun setAnimationScale(scale: Float): Boolean = withContext(Dispatchers.IO) {
        log("⚡ Chỉnh tốc độ chuyển cảnh: ${scale}x...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Chỉnh Animation ${scale}x",
            listOf(
                "settings put global window_animation_scale $scale",
                "settings put global transition_animation_scale $scale",
                "settings put global animator_duration_scale $scale"
            )
        )
        refreshTuneStatus()
        ok
    }

    /**
     * Danh sách đầy đủ các package tạo nên YOYO Agent / YOYO 助理 trên Honor MagicOS 8.0 / 9.0 / 10 / 11.
     * Trên ROM nội địa Trung Quốc, nếu còn bất kỳ package nào trong số này chạy ngầm (đặc biệt là com.hihonor.magicvoice và com.hihonor.yoyo),
     * HwPhoneWindowManager / SystemUI sẽ cưỡng bức chiếm quyền nhấn giữ thanh điều hướng để bật YOYO Agent bất chấp cài đặt Assistant mặc định!
     */
    private val honorYoyoAgentPackages = listOf(
        "com.hihonor.magicvoice",
        "com.hihonor.yoyo",
        "com.hihonor.assistant",
        "com.hihonor.ai.agent",
        "com.hihonor.aiagent",
        "com.hihonor.vassistant",
        "com.huawei.vassistant",
        "com.hihonor.voiceassistant",
        "com.hihonor.hiaction",
        "com.hihonor.hiaye"
    )

    private fun isPackageInstalledFast(pkg: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    private suspend fun isPackageInstalledOnDevice(pkg: String): Boolean = withContext(Dispatchers.IO) {
        val pmInst = isPackageInstalledFast(pkg)
        if (pmInst) return@withContext true
        try {
            val path = shellEngine.execute("pm path $pkg 2>/dev/null").output
            path.isNotBlank() && path.contains("package:")
        } catch (_: Exception) {
            false
        }
    }

    private fun buildDisableAllYoyoAgentCommands(): List<String> {
        val cmds = mutableListOf(
            // 1. Khóa toàn bộ công tắc đánh thức YOYO Agent & HiAye ở cả 3 bảng secure / system / global của MagicOS 8 / 9 / 10 / 11
            "settings put secure navigation_bar_wakeup_yoyo 0",
            "settings put secure yoyo_navigation_bar_wakeup 0",
            "settings put system navigation_bar_wakeup_yoyo 0",
            "settings put global navigation_bar_wakeup_yoyo 0",
            "settings put secure wake_up_yoyo_by_nav_bar 0",
            "settings put secure yoyo_agent_nav_bar_wakeup 0",
            "settings put system yoyo_agent_nav_bar_wakeup 0",
            "settings put secure magic_voice_nav_wakeup 0",
            "settings put secure yoyo_assistant_gesture_switch 0",
            "settings put system yoyo_assistant_gesture_switch 0",
            "settings put secure voice_wakeup_switch 0",
            "settings put system ai_sub_switch 0",
            "settings put secure ai_sub_switch 0",
            "settings put secure smart_breath_switch 0",
            "settings put secure hiaye_switch 0",
            "settings put secure hiaction_enabled 0",
            "settings put secure power_key_wakeup_yoyo 0",
            "settings put secure yoyo_power_key_wakeup 0"
        )
        // 2. Gỡ Role ASSISTANT khỏi YOYO Agent và khóa triệt để (disable-user / uninstall --user 0 / suspend / clear / appops ignore)
        for (pkg in honorYoyoAgentPackages) {
            cmds.add("cmd role remove-role-holder --user 0 android.app.role.ASSISTANT $pkg >/dev/null 2>&1 || true")
            cmds.add("pm disable-user --user 0 $pkg >/dev/null 2>&1 || true")
        }
        return cmds
    }

    /**
     * Mod phím điều hướng gọi YOYO thành gọi KHOANH TRÒN HỎI AI ĐỂ TÌM KIẾM (Circle to Search / Contextual Search).
     * Kết hợp 3 tầng:
     * 1. Gỡ chiếm quyền & khóa YOYO Agent / MagicVoice / HiAye cấp hệ thống.
     * 2. Gán Role ASSISTANT & Contextual Search cho Google App.
     * 3. Kích hoạt Cầu nối cảm ứng Thanh điều hướng đáy (Smart NavBar Bridge Overlay) & Chặn YOYO Foreground,
     *    đảm bảo nhấn giữ thanh điều hướng luôn gọi Khoanh tròn hỏi AI kể cả khi ROM Honor khóa cứng YOYO
     *    và giữ nguyên 100% khi TẮT Gỡ lỗi / Tắt Tùy chọn nhà phát triển!
     */
    private fun checkProOrTrialPermission(actionName: String): Boolean {
        val (allowed, msg) = LicenseManager.checkAndConsumeProOrTrial(context, actionName)
        if (!allowed) {
            log(msg, LogType.ERROR)
        }
        return allowed
    }

    suspend fun modNavBarToCircleToSearch(): Boolean = withContext(Dispatchers.IO) {
        // Hoạt động NGAY LẬP TỨC sau khi tải app (Zero-ADB / Không cần Gỡ lỗi không dây)
        // Đồng thời hỗ trợ Chế độ Chung Sống 3 Trợ Lý (Giữ nguyên YOYO ở giữa + Trái: Khoanh tròn hỏi AI + Phải: Trợ lý Magic tự nhường nhau)
        val coexistYoyo = com.example.core.service.SystemFloatingHudOverlay.isYoyoCoexistModeEnabled(context)
        log("⭕ Đang kích hoạt Khoanh tròn hỏi AI + Dịch Màn Hình & Trợ lý Magic (Hoạt động ngay không cần ADB • Chung sống hòa bình cùng YOYO)...", LogType.INFO)

        // 1. Kích hoạt trực tiếp qua Overlay + Accessibility (100% KHÔNG CẦN ADB)
        com.example.core.service.SystemFloatingHudOverlay.savePersistentNavModMode(context, "CIRCLE_TO_SEARCH", explicitlyDisabled = false)
        shellEngine.setPersistedSetting("secure", "magictune_nav_mod_mode", "CIRCLE_TO_SEARCH")
        shellEngine.setPersistedSetting("secure", "contextual_search_enabled", "1")
        shellEngine.setPersistedSetting("secure", "google_assistant_wake", "1")
        com.example.core.service.MagicTuneKeepAliveService.startOrUpdate(
            context,
            "Đang duy trì Khoanh tròn hỏi AI & Trợ lý Magic + YOYO (Không cần ADB)",
            forceFromBootOrOverlay = true
        )
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)

        // 2. Nếu người dùng tình cờ đang kết nối ADB thì tối ưu thêm quyền nền (tùy chọn, không bắt buộc)
        if (shellEngine.state.value.isAdbReady) {
            grantSelfControlAndOverlayPermissions()
            val selfPkg = context.packageName
            val cmds = mutableListOf(
                "pm grant --user 0 $selfPkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || true",
                "pm grant --user 0 $selfPkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || true",
                safeAppOpsCmd(selfPkg, "SYSTEM_ALERT_WINDOW", includeUid = true),
                safeAppOpsCmd(selfPkg, "RECORD_AUDIO", includeUid = true),
                safeAppOpsCmd(selfPkg, "ACCESS_RESTRICTED_SETTINGS", includeUid = true),
                safeAppOpsCmd(selfPkg, "GET_USAGE_STATS", includeUid = true),
                "settings put secure contextual_search_enabled 1",
                "settings put global contextual_search_enabled 1",
                "settings put secure google_assistant_wake 1",
                "settings put secure magictune_nav_mod_mode CIRCLE_TO_SEARCH"
            )
            if (!coexistYoyo) {
                cmds.addAll(buildDisableAllYoyoAgentCommands())
            }
            runVerifiedBatch(
                "Kích hoạt Khoanh tròn hỏi AI + Dịch Màn Hình (Chế độ Chung Sống YOYO)",
                cmds
            )
        }

        log("✅ Đã kích hoạt thành công! Cả 3 trợ lý (Trái: Khoanh tròn hỏi AI • Giữa: YOYO Honor • Phải: Trợ lý Magic) đã sẵn sàng và tự động nhường nhau hoạt động ngay mà không cần ADB!", LogType.SUCCESS)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        true
    }

    /**
     * Kích hoạt Magic Live AI & Khoanh tròn hỏi AI hoạt động ngay khi tải app về (Không cần ADB / Không cần Gỡ lỗi).
     * Hỗ trợ giữ nguyên YOYO ở vùng giữa đáy để cả 3 trợ lý luân phiên tự nhường nhau hoạt động.
     */
    suspend fun modNavBarToMagicLive(): Boolean = withContext(Dispatchers.IO) {
        val coexistYoyo = com.example.core.service.SystemFloatingHudOverlay.isYoyoCoexistModeEnabled(context)
        log("🎙️ Đang kích hoạt Magic Live AI & Khoanh tròn hỏi AI (Hoạt động ngay không cần ADB • Tự động nhường nhau với YOYO)...", LogType.INFO)

        // 1. Kích hoạt trực tiếp qua Overlay + Accessibility + VoiceInteraction (100% KHÔNG CẦN ADB)
        com.example.core.service.SystemFloatingHudOverlay.savePersistentNavModMode(context, "MAGIC_LIVE", explicitlyDisabled = false)
        shellEngine.setPersistedSetting("secure", "magictune_nav_mod_mode", "MAGIC_LIVE")
        shellEngine.setPersistedSetting("secure", "magictune_magic_live_mic_wake", "1")
        com.example.core.service.SystemFloatingHudOverlay.invalidateMicWakeCache(true)
        shellEngine.setPersistedSetting("secure", "contextual_search_enabled", "1")
        shellEngine.setPersistedSetting("secure", "google_assistant_wake", "1")
        com.example.core.service.MagicTuneKeepAliveService.startOrUpdate(
            context,
            "Đang duy trì Magic Live AI & Khoanh tròn hỏi AI + YOYO (Không cần ADB)",
            forceFromBootOrOverlay = true
        )
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)

        // 2. Nếu đang có ADB thì cấp thêm quyền phụ trợ (không bắt buộc)
        if (shellEngine.state.value.isAdbReady) {
            grantSelfControlAndOverlayPermissions()
            com.example.core.service.MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(context)
            val selfPkg = context.packageName
            val cmds = mutableListOf(
                "pm grant --user 0 $selfPkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || true",
                "pm grant --user 0 $selfPkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || true",
                safeAppOpsCmd(selfPkg, "SYSTEM_ALERT_WINDOW", includeUid = true),
                safeAppOpsCmd(selfPkg, "RECORD_AUDIO", includeUid = true),
                safeAppOpsCmd(selfPkg, "GET_USAGE_STATS", includeUid = true),
                safeAppOpsCmd(selfPkg, "ACCESS_RESTRICTED_SETTINGS", includeUid = true),
                "settings put secure contextual_search_enabled 1",
                "settings put global contextual_search_enabled 1",
                "settings put secure google_assistant_wake 1",
                "settings put secure magictune_magic_live_mic_wake 1",
                "settings put secure magictune_nav_mod_mode MAGIC_LIVE"
            )
            if (!coexistYoyo) {
                cmds.addAll(buildDisableAllYoyoAgentCommands())
                cmds.add("cmd role add-role-holder --user 0 android.app.role.ASSISTANT ${context.packageName} >/dev/null 2>&1 || true")
                cmds.add("settings put secure assistant ${context.packageName}/com.example.core.assistant.MagicTuneVoiceInteractionService")
                cmds.add("settings put secure voice_interaction_service ${context.packageName}/com.example.core.assistant.MagicTuneVoiceInteractionService")
            }
            runVerifiedBatch(
                "Kích hoạt Magic Live AI Nổi & Khoanh tròn hỏi AI (Chung sống cùng YOYO)",
                cmds
            )
        }

        log("✅ Đã BẬT Magic Live AI & Khoanh tròn hỏi AI thành công (Không cần ADB)!", LogType.SUCCESS)
        log("👉 Nhấn giữ thanh TRÁI để Khoanh tròn hỏi AI • Vuốt/Nhấn giữ GIỮA để gọi YOYO Honor • Nhấn giữ thanh PHẢI để gọi Magic Live AI (Cả 3 tự động nhường nhau!).", LogType.INFO)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        true
    }

    /**
     * Tắt tính năng lắng nghe giọng nói mở khóa 24/24 để tiết kiệm pin tối đa,
     * nhưng VẪN GIỮ NGUYÊN tính năng Khoanh tròn hỏi AI, Trợ lý Magic & YOYO.
     */
    suspend fun disableMagicLiveMod(): Boolean = withContext(Dispatchers.IO) {
        log("🔋 Đang TẮT lắng nghe Micro mở khóa tự động để tiết kiệm pin (vẫn giữ nguyên Khoanh tròn hỏi AI, Trợ lý Magic & YOYO)...", LogType.INFO)
        com.example.core.service.SystemFloatingHudOverlay.releaseMicrophoneForMagicLiveImmediately(context)
        com.example.core.service.SystemFloatingHudOverlay.savePersistentNavModMode(context, "CIRCLE_TO_SEARCH", explicitlyDisabled = false)
        shellEngine.setPersistedSetting("secure", "magictune_nav_mod_mode", "CIRCLE_TO_SEARCH")
        shellEngine.setPersistedSetting("secure", "magictune_magic_live_mic_wake", "0")
        com.example.core.service.SystemFloatingHudOverlay.invalidateMicWakeCache(false)
        if (shellEngine.state.value.isAdbReady) {
            val cmds = listOf(
                "settings put secure magictune_magic_live_mic_wake 0",
                "settings put secure magictune_nav_mod_mode CIRCLE_TO_SEARCH"
            )
            runVerifiedBatch("Tắt Lắng Nghe Micro Tự Động & Giữ Khoanh tròn hỏi AI", cmds)
        }
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
        log("✅ Đã giải phóng Micro nền (Tiết kiệm pin tối đa) — Khoanh tròn hỏi AI, Trợ lý Magic & YOYO vẫn hoạt động 100%!", LogType.SUCCESS)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        true
    }

    /**
     * Đặt MagicTune làm Ứng Dụng Trợ Lý Ảo Mặc Định (Default Assistant) hoặc mở Cài đặt Trợ lý mà không bắt buộc ADB.
     */
    suspend fun setMagicTuneAsDefaultAssistant(): Boolean = withContext(Dispatchers.IO) {
        log("🌟 Đang kích hoạt Magic Live AI & mở thiết lập Trợ lý Kỹ thuật số...", LogType.INFO)
        com.example.core.service.SystemFloatingHudOverlay.savePersistentNavModMode(context, "MAGIC_LIVE", explicitlyDisabled = false)
        shellEngine.setPersistedSetting("secure", "magictune_nav_mod_mode", "MAGIC_LIVE")
        shellEngine.setPersistedSetting("secure", "magictune_magic_live_mic_wake", "1")
        com.example.core.service.SystemFloatingHudOverlay.invalidateMicWakeCache(true)
        com.example.core.service.MagicTuneKeepAliveService.startOrUpdate(
            context,
            "Đang duy trì Khoanh tròn hỏi AI & Trợ lý Magic 24/7",
            forceFromBootOrOverlay = true
        )
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)

        if (shellEngine.state.value.isAdbReady) {
            val pkg = context.packageName
            val cmds = listOf(
                "pm grant --user 0 $pkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || true",
                "pm grant --user 0 $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || true",
                safeAppOpsCmd(pkg, "SYSTEM_ALERT_WINDOW", includeUid = true),
                safeAppOpsCmd(pkg, "RECORD_AUDIO", includeUid = true),
                "cmd role add-role-holder --user 0 android.app.role.ASSISTANT $pkg >/dev/null 2>&1 || true",
                "settings put secure assistant $pkg/com.example.core.assistant.MagicTuneVoiceInteractionService",
                "settings put secure voice_interaction_service $pkg/com.example.core.assistant.MagicTuneVoiceInteractionService",
                "settings put secure voice_recognition_service $pkg/com.example.core.assistant.MagicTuneRecognitionService",
                "settings put secure google_assistant_wake 1",
                "settings put secure magictune_nav_mod_mode MAGIC_LIVE"
            )
            runVerifiedBatch("Đặt MagicTune Làm Trợ Lý Ảo Mặc Định", cmds)
        }

        // Mở cài đặt Ứng dụng hỗ trợ mặc định của hệ thống để người dùng tùy chọn giữ YOYO hoặc chọn MagicTune
        withContext(Dispatchers.Main) {
            try {
                val intent = Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (_: Throwable) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                } catch (_: Throwable) {}
            }
        }

        log("✅ Đã kích hoạt Magic Live AI! Bạn có thể dùng song song cả YOYO (ở giữa đáy) lẫn Khoanh tròn hỏi AI (bên trái) và Trợ lý Magic (bên phải) mà không cần ADB!", LogType.SUCCESS)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        true
    }

    /**
     * Gọi thử ngay Khoanh tròn hỏi AI / Trợ lý Magic để kiểm tra trực tiếp
     * (Hoạt động cả trên các dòng máy Honor khóa cứng thanh điều hướng trong SystemUI và cả khi đã tắt Gỡ lỗi).
     */
    suspend fun testTriggerNavAssistantNow(): Boolean = withContext(Dispatchers.IO) {
        log("⚡ Đang kích hoạt trực tiếp Khoanh tròn hỏi AI / Magic Live AI trên màn hình...", LogType.INFO)
        com.example.core.service.SystemFloatingHudOverlay.triggerConfiguredAssistantNow(context)
    }

    /**
     * Khôi phục lại trợ lý YOYO Agent gốc của Honor trên thanh điều hướng mặc định (trả 2 phím điều hướng về 2 mép màn hình để dùng song song với YOYO)
     */
    suspend fun restoreYoyoOriginal(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang trả 2 phím điều hướng về 2 mép màn hình và khôi phục YOYO Agent gốc của Honor ở giữa...", LogType.INFO)
        com.example.core.service.SystemFloatingHudOverlay.setNavPillsCentered(context, false)
        val cmds = mutableListOf<String>()
        for (pkg in honorYoyoAgentPackages) {
            cmds.add("cmd package install-existing $pkg >/dev/null 2>&1 || true")
            cmds.add("pm enable --user 0 $pkg >/dev/null 2>&1 || true")
            cmds.add("cmd appops set $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true")
        }
        cmds.addAll(
            listOf(
                "settings put secure navigation_bar_wakeup_yoyo 1",
                "settings put secure yoyo_navigation_bar_wakeup 1",
                "settings put system navigation_bar_wakeup_yoyo 1",
                "settings put secure wake_up_yoyo_by_nav_bar 1",
                "settings put secure yoyo_assistant_gesture_switch 1",
                "settings put secure assist_long_press_home_enabled 1",
                "settings put secure magictune_nav_mod_mode CIRCLE_TO_SEARCH"
            )
        )
        val ok = runVerifiedBatch("Khôi phục YOYO Agent gốc (Dùng song song với 2 phím ở 2 mép)", cmds)
        com.example.core.service.SystemFloatingHudOverlay.savePersistentNavModMode(context, "CIRCLE_TO_SEARCH", explicitlyDisabled = false)
        shellEngine.setPersistedSetting("secure", "magictune_nav_mod_mode", "CIRCLE_TO_SEARCH")
        shellEngine.setPersistedSetting("secure", "navigation_bar_wakeup_yoyo", "1")
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * V4.9: Công tắc Đẩy 2 nút điều hướng vào Giữa màn hình (lập tức vô hiệu hóa YOYO)
     * hoặc Trả 2 nút điều hướng về 2 Mép màn hình (lập tức khôi phục YOYO để dùng song song).
     */
    suspend fun setNavPillsCenteredAndSyncYoyo(centered: Boolean): Boolean = withContext(Dispatchers.IO) {
        com.example.core.service.SystemFloatingHudOverlay.setNavPillsCentered(context, centered)
        if (centered) {
            log("🎯 Đã đẩy 2 phím điều hướng vào GIỮA màn hình! Đang lập tức chạy lệnh vô hiệu hóa YOYO trên thanh điều hướng để 2 phím hoạt động mượt tuyệt đối...", LogType.INFO)
            val ok = disableYoyoNavigationWake()
            com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
            log("✅ Đã đẩy 2 phím vào giữa & vô hiệu hóa hoàn toàn thanh điều hướng YOYO!", LogType.SUCCESS)
            ok
        } else {
            log("↔️ Đã trả 2 phím điều hướng về 2 MÉP màn hình! Đang lập tức chạy lệnh khôi phục YOYO trên thanh điều hướng mặc định để dùng song song...", LogType.INFO)
            val ok = restoreYoyoOriginal()
            log("✅ Đã trả 2 phím về 2 mép màn hình & khôi phục gọi YOYO trên thanh điều hướng mặc định!", LogType.SUCCESS)
            ok
        }
    }

    /**
     * Chuyển đổi gọi YOYO sang gọi Google Assistant / Trợ lý Magic khi nhấn giữ thanh điều hướng dưới đáy
     * Giữ nguyên và hoạt động độc lập ngay cả khi rút cáp USB hoặc ngắt WLAN.
     */
    suspend fun remapNavBarToGoogleAssistant(): Boolean = withContext(Dispatchers.IO) {
        modNavBarToMagicLive()
    }

    /**
     * Bật hoặc Ẩn thanh kim cử chỉ điều hướng đáy màn hình (Navigation Pill Bar)
     */
    suspend fun toggleNavigationBarPill(hide: Boolean): Boolean = withContext(Dispatchers.IO) {
        val actionText = if (hide) "Ẩn thanh kim điều hướng MagicOS 11" else "Hiện thanh kim điều hướng"
        log("📱 Đang $actionText...", LogType.INFO)
        val hideVal = if (hide) "1" else "0"
        val pillDisplay = if (hide) "1" else "0"
        val hintVal = if (hide) "0" else "1"
        val immersiveVal = if (hide) "1" else "0"

        val cmds = listOf(
            "settings put secure gesture_navigation_pill_display $pillDisplay",
            "settings put system gesture_navigation_pill_display $pillDisplay",
            "settings put global gesture_navigation_pill_display $pillDisplay",
            "settings put system gesture_pill_display $pillDisplay",
            "settings put secure secure_gesture_navigation_immersive $immersiveVal",
            "settings put secure honor_hide_navigation_bar $hideVal",
            "settings put system honor_hide_navigation_bar $hideVal",
            "settings put secure hide_navigation_bar $hideVal",
            "settings put system hide_navigation_bar $hideVal",
            "settings put global hide_navigation_bar $hideVal",
            "settings put secure navigation_bar_hint $hintVal",
            "settings put system navigation_bar_hint $hintVal",
            "settings put secure show_gesture_bar $hintVal",
            "settings put system show_gesture_bar $hintVal",
            "settings put secure show_navigation_bar_hint $hintVal",
            "settings put system show_navigation_bar_hint $hintVal",
            "settings put secure gesture_hint_bar $hintVal"
        )
        val ok = runVerifiedBatch(actionText, cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * Tắt công tắc nhấn thanh điều hướng đánh thức YOYO (Không ẩn thanh điều hướng nếu người dùng chỉ muốn tắt YOYO)
     */
    suspend fun disableYoyoNavigationWake(): Boolean = withContext(Dispatchers.IO) {
        log("🛑 Đang gỡ bỏ hoàn toàn YOYO Agent khỏi thanh điều hướng & khôi phục cảm ứng mép đáy...", LogType.INFO)
        val cmds = mutableListOf<String>()
        cmds.addAll(buildDisableAllYoyoAgentCommands())
        cmds.addAll(
            listOf(
                "settings put secure assist_long_press_home_enabled 0",
                "settings put secure bottom_gesture_inset_scale 2",
                "settings put secure gesture_nav_sensitivity 2",
                "settings put secure touch_response_time 0",
                "settings put secure touch_responsiveness_level 1",
                "settings put secure touch_edge_filter 0",
                "settings put secure secure_gesture_navigation_immersive 0",
                "settings put global navigation_bar_touch_deadzone 0",
                "settings put secure navigation_bar_touch_deadzone 0"
            )
        )
        val ok = runVerifiedBatch(
            "Tắt sạch YOYO Agent & Khôi phục cảm ứng mép đáy",
            cmds
        )
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        runDiagnosticScan()
        ok
    }

    suspend fun hideNavigationBarPill(): Boolean = withContext(Dispatchers.IO) {
        toggleNavigationBarPill(true)
    }

    /**
     * Bật hoặc tắt tính năng phần cứng/hệ thống của điện thoại trực tiếp từ MagicTune
     */
    suspend fun toggleDeviceFeature(featureId: String, currentEnabled: Boolean): Boolean = withContext(Dispatchers.IO) {
        val targetState = !currentEnabled
        val stateNum = if (targetState) "1" else "0"
        log("⚡ Đang ${if (targetState) "BẬT" else "TẮT"} tính năng: $featureId...", LogType.INFO)

        if (!shellEngine.state.value.isAdbReady) {
            var directOk = false
            try {
                when (featureId) {
                    "unlock_battery_97", "unlock_battery_100" -> {
                        val limit = if (featureId == "unlock_battery_97") 97 else 100
                        if (Settings.System.canWrite(context)) {
                            Settings.System.putInt(context.contentResolver, "smart_battery_capacity_switch", 0)
                            Settings.System.putInt(context.contentResolver, "smart_charge_switch", 0)
                            Settings.System.putInt(context.contentResolver, "custom_charge_limit_switch", if (limit < 100) 1 else 0)
                            Settings.System.putInt(context.contentResolver, "custom_charge_limit", limit)
                            shellEngine.setPersistedSetting("system", "smart_battery_capacity_switch", "0")
                            shellEngine.setPersistedSetting("system", "custom_charge_limit", limit.toString())
                            shellEngine.setPersistedSetting("secure", "magictune_battery_cap_unlocked", "1")
                            shellEngine.setPersistedSetting("secure", "magictune_charge_limit_pct", limit.toString())
                            directOk = true
                        }
                    }
                    "restore_battery_cap" -> {
                        if (Settings.System.canWrite(context)) {
                            Settings.System.putInt(context.contentResolver, "smart_battery_capacity_switch", 1)
                            Settings.System.putInt(context.contentResolver, "smart_charge_switch", 1)
                            Settings.System.putInt(context.contentResolver, "custom_charge_limit_switch", 0)
                            shellEngine.setPersistedSetting("system", "smart_battery_capacity_switch", "1")
                            shellEngine.setPersistedSetting("secure", "magictune_battery_cap_unlocked", "0")
                            directOk = true
                        }
                    }
                    "auto_rotate" -> {
                        if (Settings.System.canWrite(context)) {
                            directOk = Settings.System.putInt(
                                context.contentResolver,
                                Settings.System.ACCELEROMETER_ROTATION,
                                if (targetState) 1 else 0
                            )
                        }
                    }
                    "auto_sync" -> {
                        ContentResolver.setMasterSyncAutomatically(targetState)
                        directOk = true
                    }
                    "dark_mode" -> {
                        directOk = Settings.Secure.putInt(
                            context.contentResolver,
                            "ui_night_mode",
                            if (targetState) 2 else 1
                        )
                    }
                    "adblocker_dns" -> {
                        directOk = if (targetState) {
                            Settings.Global.putString(context.contentResolver, "private_dns_mode", "hostname") &&
                                Settings.Global.putString(context.contentResolver, "private_dns_specifier", "dns.adguard-dns.com")
                        } else {
                            Settings.Global.putString(context.contentResolver, "private_dns_mode", "opportunistic")
                        }
                    }
                }
            } catch (_: Exception) {}

            if (!directOk) {
                withContext(Dispatchers.Main) {
                    com.example.ui.components.openHardwareSettingFallback(context, featureId)
                }
                log("💡 Đã mở nhanh bảng Cài đặt hệ thống cho mục '$featureId' (Không cần ADB).", LogType.INFO)
            } else {
                log("✅ Đã cập nhật trực tiếp '$featureId' thành công!", LogType.SUCCESS)
            }
            refreshDeviceInfo()
            refreshTuneStatus()
            return@withContext directOk
        }

        val ok = when (featureId) {
            "unlock_battery_97" -> unlockHonorBatteryCapacity(97)
            "unlock_battery_100" -> unlockHonorBatteryCapacity(100)
            "restore_battery_cap" -> restoreHonorSmartBatteryCapacityDefault()
            "wifi" -> {
                runVerifiedBatch(
                    "Bật/Tắt Wi-Fi",
                    listOf(
                        "svc wifi ${if (targetState) "enable" else "disable"}",
                        "cmd wifi set-wifi-enabled ${if (targetState) "enabled" else "disabled"}"
                    )
                )
            }
            "bluetooth" -> {
                runVerifiedBatch(
                    "Bật/Tắt Bluetooth",
                    listOf(
                        "svc bluetooth ${if (targetState) "enable" else "disable"}",
                        "cmd bluetooth_manager ${if (targetState) "enable" else "disable"}"
                    )
                )
            }
            "mobile_data" -> {
                runVerifiedBatch(
                    "Bật/Tắt Dữ liệu di động (4G/5G)",
                    listOf(
                        "svc data ${if (targetState) "enable" else "disable"}",
                        "settings put global mobile_data $stateNum"
                    )
                )
            }
            "gps", "gps_high_accuracy" -> {
                if (targetState) {
                    setupGpsVietnam()
                } else {
                    runVerifiedBatch(
                        "Tắt Định vị GPS",
                        listOf(
                            "settings put secure location_mode 0",
                            "cmd location set-location-enabled false"
                        )
                    )
                }
            }
            "nfc" -> {
                runVerifiedBatch(
                    "Bật/Tắt NFC",
                    listOf("svc nfc ${if (targetState) "enable" else "disable"}")
                )
            }
            "auto_rotate" -> {
                runVerifiedBatch(
                    "Tự động xoay màn hình",
                    listOf(
                        "settings put system accelerometer_rotation $stateNum",
                        if (targetState) "cmd window user-rotation free" else "cmd window user-rotation lock 0"
                    )
                )
            }
            "dark_mode" -> {
                setDarkModeOled(targetState)
            }
            "adblocker_dns" -> {
                if (targetState) enableAdBlocker() else disableAdBlocker()
            }
            "yoyo_nav_wake" -> {
                if (targetState) disableYoyoNavigationWake() else {
                    runVerifiedBatch(
                        "Khôi phục công tắc YOYO",
                        listOfNotNull(
                            if (shellEngine.isPackagePresentInRom("com.hihonor.assistant")) shellEngine.buildSafeEnablePackageCmd("com.hihonor.assistant", 0) else null,
                            "settings put secure navigation_bar_wakeup_yoyo 1",
                            "settings put system navigation_bar_wakeup_yoyo 1"
                        )
                    )
                }
            }
            "block_update" -> {
                if (targetState) blockHonorMarket() else {
                    runVerifiedBatch(
                        "Mở lại tự động cập nhật app",
                        listOfNotNull(
                            if (shellEngine.isPackagePresentInRom("com.hihonor.appmarket")) shellEngine.buildSafeEnablePackageCmd("com.hihonor.appmarket", 0) else null,
                            "settings put global auto_update_app 1"
                        )
                    )
                }
            }
            "auto_sync" -> {
                try { ContentResolver.setMasterSyncAutomatically(targetState) } catch (_: Exception) {}
                runVerifiedBatch(
                    "Tự động đồng bộ tài khoản",
                    listOf(
                        shellEngine.buildSafeMasterSyncCmd(targetState),
                        "settings put global auto_sync $stateNum"
                    )
                )
            }
            else -> false
        }

        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun fixAudioDistortion(): Boolean = withContext(Dispatchers.IO) {
        log("🔊 Đang sửa lỗi méo tiếng loa & rè Bluetooth (Chuẩn 48kHz)...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Chuẩn hóa Âm thanh 48kHz & Bluetooth",
            listOf(
                "settings put global bluetooth_absolute_volume 0",
                "settings put system sound_effects_enabled 0"
            )
        )
        refreshTuneStatus()
        ok
    }

    suspend fun setFontBoldLarge(enabled: Boolean): Boolean = withContext(Dispatchers.IO) {
        log("${if (enabled) "Bật" else "Tắt"} chữ to đậm dễ đọc...", LogType.INFO)
        val weight = if (enabled) 1.2 else 1.0
        val scale = if (enabled) 1.15 else 1.0
        val ok = runVerifiedBatch(
            "Chỉnh cỡ chữ & độ đậm",
            listOf(
                "settings put system font_weight_scale $weight",
                "settings put system font_scale $scale"
            )
        )
        refreshTuneStatus()
        ok
    }

    suspend fun setDarkModeOled(enabled: Boolean): Boolean = withContext(Dispatchers.IO) {
        log("${if (enabled) "Bật" else "Tắt"} Dark Mode OLED tiết kiệm pin...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Chế độ tối Dark Mode OLED",
            listOf(
                "settings put secure ui_night_mode ${if (enabled) 2 else 1}",
                "settings put system ui_night_mode ${if (enabled) 2 else 1}",
                "cmd uimode night ${if (enabled) "yes" else "no"}"
            )
        )
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun unlockSecureScreenshot(): Boolean = withContext(Dispatchers.IO) {
        log("🔓 Đang mở khóa chụp màn hình ứng dụng bảo mật (Bank, Incognito)...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Mở khóa chụp màn hình bảo mật",
            listOf(
                "settings put global block_screen_capture 0"
            )
        )
        refreshTuneStatus()
        ok
    }

    suspend fun enableAdBlocker(dnsHost: String = "dns.adguard-dns.com"): Boolean = withContext(Dispatchers.IO) {
        log("🛡 Đang kích hoạt Chặn Quảng Cáo Toàn Diện ($dnsHost)...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Kích hoạt Chặn Quảng Cáo ($dnsHost)",
            listOf(
                "settings put global private_dns_mode hostname",
                "settings put global private_dns_specifier $dnsHost",
                "settings put secure advertising_id_opt_out 1",
                "settings put global personalized_ad_enabled 0",
                "settings put secure limit_ad_tracking 1",
                "settings put system auto_download_magazine_wifi 0"
            )
        )
        refreshDeviceInfo()
        ok
    }

    suspend fun disableAdBlocker(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang khôi phục cài đặt DNS mặc định...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Tắt Chặn Quảng Cáo DNS",
            listOf(
                "settings put global private_dns_mode opportunistic",
                "settings delete global private_dns_specifier"
            )
        )
        refreshDeviceInfo()
        ok
    }

    suspend fun grantAllPermissionsAllApps(): Boolean = withContext(Dispatchers.IO) {
        log("🔍 Đang kiểm tra danh sách ứng dụng bị thiếu quyền chạy ngầm / thông báo trước khi cấp...", LogType.INFO)
        val scan = runDiagnosticScan()
        val problematicApps = scan.missingPermissionApps.filter {
            it.hasAnyPermissionIssue || it.hasAnyNotificationIssue
        }

        if (problematicApps.isEmpty()) {
            log(
                "🎉 KIỂM TRA HOÀN TẤT: Toàn bộ ${scan.allScannedAppsCount} ứng dụng người dùng đều đã có đủ 100% quyền chạy ngầm, pin & thông báo! Không cần chạy lại lệnh cho các app không bị lỗi.",
                LogType.SUCCESS
            )
            return@withContext true
        }

        val skippedCount = (scan.allScannedAppsCount - problematicApps.size).coerceAtLeast(0)
        log(
            "🛡 Phát hiện ${problematicApps.size} ứng dụng thiếu quyền (Đã bỏ qua $skippedCount ứng dụng đã đủ quyền). Đang tự động cấp FULL quyền...",
            LogType.INFO
        )
        grantSelfControlAndOverlayPermissions()

        val pkgs = filterInstalledSafePackages(problematicApps.map { it.packageName })

        val cmds = pkgs.flatMap { pkg ->
            buildAppSwitchGrantCommands(pkg)
        }
        val ok = runVerifiedBatch("Tự động gạt công tắc Full quyền cho ${pkgs.size} ứng dụng thiếu quyền (Bỏ qua $skippedCount app đã đủ)", cmds)
        if (ok) {
            pkgs.forEach { shellEngine.markAppNotificationFixed(it, true) }
        }
        refreshAppsList()
        runDiagnosticScan()
        ok
    }

    // -------------------------------------------------------------
    // SHIZUKU CỦA MÁY
    // -------------------------------------------------------------
    suspend fun protectShizukuImmortal(): Boolean = withContext(Dispatchers.IO) {
        log("🛡 Đang kích hoạt Khiên Bất Tử cho Shizuku & giữ trạng thái Fix khi ngắt WLAN...", LogType.INFO)
        val cmds = mutableListOf(
            "settings put global adb_charging_only 1",
            "settings put secure allow_charging_adb 1",
            "device_config put activity_manager max_phantom_processes 2147483647",
            "settings put global settings_enable_monitor_phantom_procs false"
        )
        if (isPackageInstalledFast("moe.shizuku.privileged.api")) {
            cmds.add("dumpsys deviceidle whitelist +moe.shizuku.privileged.api >/dev/null 2>&1 || true")
            cmds.add("am set-standby-bucket --user 0 moe.shizuku.privileged.api active >/dev/null 2>&1 || true")
            cmds.add(safeAppOpsCmd("moe.shizuku.privileged.api", "RUN_IN_BACKGROUND", includeUid = true))
            cmds.add(safeAppOpsCmd("moe.shizuku.privileged.api", "RUN_ANY_IN_BACKGROUND", includeUid = true))
        }
        val ok = runVerifiedBatch("Khiên Bất Tử Shizuku & Giữ Fix Vĩnh Viễn", cmds)
        shellEngine.markPersistentGrantActive()
        refreshShizukuInfo()
        ok
    }

    suspend fun authorizeShizukuCompanions(): Boolean = withContext(Dispatchers.IO) {
        log("🔑 Cấp Full đặc quyền cho MagicTune & các App hệ sinh thái Shizuku (Canta, Hail, AppOps, SD Maid)...", LogType.INFO)
        grantSelfControlAndOverlayPermissions()
        val companions = filterInstalledSafePackages(
            listOf(
                context.packageName,
                "moe.shizuku.privileged.api",
                "io.github.samolego.canta",
                "com.aistra.hail",
                "rikka.appops",
                "eu.thedarken.sdm",
                "in.sunilpaulmathew.ashell"
            )
        )

        val cmds = companions.flatMap { pkg ->
            listOf(
                "pm grant --user 0 $pkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || true",
                "pm grant --user 0 $pkg android.permission.DUMP >/dev/null 2>&1 || true",
                safeAppOpsCmd(pkg, "SYSTEM_ALERT_WINDOW", includeUid = true),
                "dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true"
            )
        }
        runVerifiedBatch("Cấp quyền Hệ sinh thái Shizuku & MagicTune", cmds)
    }

    // -------------------------------------------------------------
    // HOÀN TÁC TOÀN DIỆN & HOÀN TÁC TỪNG PHẦN (RESTORE CENTER V4.9)
    // -------------------------------------------------------------
    suspend fun revertCategory(categoryId: String): Boolean = withContext(Dispatchers.IO) {
        when (categoryId) {
            "NAV_YOYO" -> {
                log("🔄 [Hoàn tác Thanh Điều Hướng & YOYO] Đang trả 2 phím về 2 mép, hiện lại thanh kim & khôi phục YOYO gốc...", LogType.INFO)
                com.example.core.service.SystemFloatingHudOverlay.setBothPillsHidden(context, false)
                com.example.core.service.SystemFloatingHudOverlay.setNavBarLengthPercent(context, 50)
                toggleNavigationBarPill(false)
                setNavPillsCenteredAndSyncYoyo(false)
            }
            "DISPLAY_ANIM" -> {
                log("🔄 [Hoàn tác Màn Hình & Hoạt Ảnh] Đang đưa tần số quét về Tự động (Dynamic) & tốc độ chuyển cảnh về 1.0x...", LogType.INFO)
                val ok = runVerifiedBatch(
                    "Hoàn tác Màn hình & Animation về 1.0x",
                    listOf(
                        "settings put global window_animation_scale 1.0",
                        "settings put global transition_animation_scale 1.0",
                        "settings put global animator_duration_scale 1.0",
                        "settings delete system peak_refresh_rate",
                        "settings delete system min_refresh_rate",
                        "settings put system user_refresh_rate 0"
                    )
                )
                refreshDeviceInfo()
                refreshTuneStatus()
                ok
            }
            "DNS_ADBLOCK" -> {
                log("🔄 [Hoàn tác Mạng & DNS] Đang tắt Private DNS AdGuard & khôi phục mạng mặc định...", LogType.INFO)
                disableAdBlocker()
                restoreDefaultNetworkAndBatterySettings()
            }
            "TOUCH_THERMAL" -> {
                log("🔄 [Hoàn tác Cảm Ứng, Pin & Tản Nhiệt] Đang đưa độ nhạy cảm ứng, cấu hình pin & tản nhiệt về mặc định...", LogType.INFO)
                revertTouchAndFingerprintSensitivity()
                restoreDefaultSmoothnessAndThermal()
                restoreDefaultBatteryEngine()
            }
            "DEV_STEALTH" -> {
                log("🔄 [Hoàn tác Chế Độ Nhà Phát Triển] Đang hiển thị lại menu Tùy chọn nhà phát triển trong Cài đặt...", LogType.INFO)
                restoreDeveloperModeVisibility()
            }
            "HISEARCH_HIBOARD" -> {
                log("🔄 [Hoàn tác HiSearch, HiBoard & Cập Nhật] Đang mở lại HiSearch, HiBoard và Chợ ứng dụng Honor...", LogType.INFO)
                replaceHonorSearch(false)
                val ok = runVerifiedBatch(
                    "Khôi phục HiBoard & Chợ ứng dụng Honor",
                    listOf(
                        "settings put global auto_update_app 1",
                        "pm enable --user 0 com.hihonor.appmarket >/dev/null 2>&1 || true",
                        "settings put secure hiboard_switch 1",
                        "settings put system auto_download_magazine_wifi 1"
                    )
                )
                refreshSetupStatus()
                refreshDeviceInfo()
                refreshTuneStatus()
                ok
            }
            "AUDIO_FONT" -> {
                log("🔄 [Hoàn tác Âm Thanh & Cỡ Chữ] Đang đưa cỡ chữ về 1.0x, khôi phục Bluetooth & chuông thông báo mặc định...", LogType.INFO)
                val ok = runVerifiedBatch(
                    "Hoàn tác Âm thanh, Cỡ chữ & Chuông thông báo",
                    listOf(
                        "settings put system font_weight_scale 1.0",
                        "settings put system font_scale 1.0",
                        "settings put global bluetooth_absolute_volume 1",
                        "settings put system sound_effects_enabled 1",
                        "settings put system use_default_notification_sound 1",
                        "settings put system lock_screen_notification_style 1",
                        "settings put system gentle_notification_enabled 1"
                    )
                )
                refreshDeviceInfo()
                refreshTuneStatus()
                ok
            }
            "GESTURE_DRAW" -> {
                log("🔄 [Hoàn tác Bảng Vẽ Mở App] Đang khôi phục danh sách gán chữ A–Z mặc định & xóa nét vẽ mẫu...", LogType.INFO)
                com.example.core.widget.GestureLauncherOverlay.resetDefaultGestureMappings(context)
                com.example.core.widget.GestureLauncherOverlay.clearAllCustomTemplates(context)
                com.example.core.widget.GestureLauncherOverlay.setDirectLaunchAfterDraw(context, false)
                log("✅ Đã đặt lại cấu hình Vẽ Chữ Mở App (A–Z) và xóa toàn bộ nét vẽ mẫu!", LogType.SUCCESS)
                true
            }
            else -> false
        }
    }

    suspend fun revertSelectedCategories(categoryIds: List<String>): Boolean = withContext(Dispatchers.IO) {
        if (categoryIds.isEmpty()) return@withContext false
        log("⏪ Đang thực hiện hoàn tác ${categoryIds.size} hạng mục đã chọn...", LogType.INFO)
        var allOk = true
        for (id in categoryIds) {
            val ok = revertCategory(id)
            if (!ok) allOk = false
        }
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        log("✅ Đã hoàn tất khôi phục ${categoryIds.size} hạng mục đã chọn!", LogType.SUCCESS)
        allOk
    }

    suspend fun restoreAllToFactoryDefault(): Boolean = withContext(Dispatchers.IO) {
        context.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
            .edit().putBoolean("magictune_refresh_lock_active", false).apply()
        log("⏪ ĐANG KHÔI PHỤC TOÀN BỘ 100% CÀI ĐẶT VỀ MẶC ĐỊNH GỐC CỦA HONOR...", LogType.INFO)
        com.example.core.service.SystemFloatingHudOverlay.setBothPillsHidden(context, false)
        com.example.core.service.SystemFloatingHudOverlay.setNavBarLengthPercent(context, 50)
        com.example.core.service.SystemFloatingHudOverlay.setNavPillsCentered(context, false)
        replaceHonorSearch(false)
        val cmds = mutableListOf(
            "settings put global window_animation_scale 1.0",
            "settings put global transition_animation_scale 1.0",
            "settings put global animator_duration_scale 1.0",
            "settings delete system peak_refresh_rate",
            "settings delete system min_refresh_rate",
            "settings delete system smart_refresh_rate",
            "settings delete secure smart_refresh_rate",
            "settings delete system smart_cooling_mode",
            "settings delete system hw_thermal_mode",
            "settings delete secure hw_thermal_mode",
            "settings delete system thermal_control",
            "settings put system user_refresh_rate 0",
            "settings put global app_standby_enabled 1",
            "settings put global cached_apps_freezer enabled",
            "device_config put activity_manager_native_boot use_freezer true >/dev/null 2>&1 || true",
            "device_config delete tare enable_tare_mode >/dev/null 2>&1 || true",
            "settings delete global job_scheduler_constants",
            "settings put global mobile_data_always_on 0",
            "cmd power set-adaptive-power-saver-enabled true >/dev/null 2>&1 || true",
            "setprop debug.sf.early_phase_offset_ns '' >/dev/null 2>&1 || true",
            "setprop debug.sf.early_app_phase_offset_ns '' >/dev/null 2>&1 || true",
            "setprop debug.sf.early_gl_phase_offset_ns '' >/dev/null 2>&1 || true",
            "setprop debug.sf.early_gl_app_phase_offset_ns '' >/dev/null 2>&1 || true",
            "setprop debug.hwui.render_dirty_regions '' >/dev/null 2>&1 || true",
            "settings put system font_weight_scale 1.0",
            "settings put system font_scale 1.0",
            "settings put system use_default_notification_sound 1",
            "settings put system lock_screen_notification_style 1",
            "settings put system gentle_notification_enabled 1",
            "settings put global auto_update_app 1",
            "pm enable --user 0 com.hihonor.appmarket >/dev/null 2>&1 || true",
            "settings put secure hiboard_switch 1",
            "settings put global bluetooth_absolute_volume 1",
            "settings put global private_dns_mode opportunistic",
            "settings delete global private_dns_specifier",
            "settings put global development_settings_enabled 1",
            "settings put secure development_settings_enabled 1",
            "settings put global magictune_dev_stealth 0",
            "settings put secure navigation_bar_wakeup_yoyo 1",
            "settings put secure yoyo_navigation_bar_wakeup 1",
            "settings put system navigation_bar_wakeup_yoyo 1",
            "settings put secure wake_up_yoyo_by_nav_bar 1",
            "settings put secure yoyo_assistant_gesture_switch 1",
            "settings put secure assist_long_press_home_enabled 1"
        )
        for (pkg in honorYoyoAgentPackages) {
            cmds.add("pm enable --user 0 $pkg >/dev/null 2>&1 || true")
        }
        val ok = runVerifiedBatch(
            "Khôi phục Toàn diện 100% Cài đặt gốc",
            cmds
        )
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        refreshAppsList()
        runDiagnosticScan()
        ok
    }

    // -------------------------------------------------------------
    // 5 QUYỀN NĂNG HỆ THỐNG CHUYÊN SÂU v2.5 (SUPPORT ANDROID 11 -> ANDROID 17)
    // -------------------------------------------------------------

    /**
     * 1. Vượt Chặn Chế Độ Nhà Phát Triển (Stealth Developer Mode Bypass):
     * Cho phép truy cập full 100% ứng dụng Ngân hàng, Ví điện tử, Game dù máy đang dùng Shizuku / Chế độ nhà phát triển.
     * Cơ chế: Ẩn cờ `development_settings_enabled` & `adb_enabled` khỏi các hàm kiểm tra của app bên thứ 3
     * trong khi giữ tiến trình `shizuku_server` (UID 2000) chạy ngầm bất tử trong RAM!
     */
    suspend fun enableStealthDeveloperModeBypass(
        silent: Boolean = false,
        deepCleanAllAdb: Boolean = !silent
    ): Boolean = withContext(Dispatchers.IO) {
        if (!silent) {
            log("🛡️ [Stealth Bypass v2.6] Đang ẩn Chế độ nhà phát triển & dọn sạch cờ ADB/Gỡ lỗi (Tương thích đến Android 17)...", LogType.INFO)
        }
        val cr = context.contentResolver
        val adbWasReady = shellEngine.state.value.isAdbReady
        val wirelessWasConnected = shellEngine.state.value.isWirelessAdbConnected

        fun readSystemPropSafe(key: String): String {
            return try {
                val cls = Class.forName("android.os.SystemProperties")
                val method = cls.getMethod("get", String::class.java, String::class.java)
                (method.invoke(null, key, "") as? String).orEmpty().trim()
            } catch (_: Throwable) {
                ""
            }
        }

        if (!adbWasReady) {
            // Đã tắt WLAN/ADB: thử ghi trực tiếp qua WRITE_SECURE_SETTINGS (nếu có quyền) và kiểm tra cờ còn sót lại trong ROM
            try {
                android.provider.Settings.Global.putInt(cr, android.provider.Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0)
            } catch (_: Throwable) {}
            try {
                android.provider.Settings.Secure.putInt(cr, "development_settings_enabled", 0)
            } catch (_: Throwable) {}
            try {
                android.provider.Settings.Global.putInt(cr, android.provider.Settings.Global.ADB_ENABLED, 0)
            } catch (_: Throwable) {}
            try {
                android.provider.Settings.Global.putInt(cr, "adb_wifi_enabled", 0)
            } catch (_: Throwable) {}
            try {
                android.provider.Settings.Global.putInt(cr, "wait_for_debugger", 0)
            } catch (_: Throwable) {}
            com.example.core.service.MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(context)
            shellEngine.setPersistedSetting("global", "magictune_dev_stealth", "1")
            refreshTuneStatus()
            refreshDeviceInfo()

            val devOn = try { android.provider.Settings.Global.getInt(cr, android.provider.Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) } catch (_: Throwable) { 0 }
            val adbUsbOn = try { android.provider.Settings.Global.getInt(cr, android.provider.Settings.Global.ADB_ENABLED, 0) } catch (_: Throwable) { 0 }
            val adbWifiOn = try { android.provider.Settings.Global.getInt(cr, "adb_wifi_enabled", 0) } catch (_: Throwable) { 0 }
            val adbdState = readSystemPropSafe("init.svc.adbd")
            val usbCfg = readSystemPropSafe("sys.usb.config").ifBlank { readSystemPropSafe("persist.sys.usb.config") }
            val residuals = buildList {
                if (devOn == 1) add("development_settings_enabled=1")
                if (adbUsbOn == 1) add("adb_enabled=1")
                if (adbWifiOn == 1) add("adb_wifi_enabled=1")
                if (adbdState == "running") add("adbd=running")
                if (usbCfg.contains("adb", ignoreCase = true)) add("usb_config=$usbCfg")
            }
            if (!silent) {
                if (residuals.isEmpty()) {
                    log("✅ Kiểm tra thực tế: Tất cả cờ Nhà phát triển & ADB đã về 0. Nếu ứng dụng bảo mật cao vẫn báo lỗi do lưu cache, hãy vuốt đóng hẳn ứng dụng đó khỏi đa nhiệm rồi mở lại!", LogType.SUCCESS)
                } else {
                    log(
                        "⚠️ Phát hiện ROM Honor/Android vẫn còn lưu cờ hệ thống (${residuals.joinToString(", ")}) dù đã tắt Nhà phát triển! " +
                            "Hãy kết nối lại WLAN rồi bấm nút này để MagicTune tắt sạch, HOẶC vào Cài đặt -> Hệ thống -> Tùy chọn đặt lại -> Chọn 'Đặt lại tùy chọn nhà phát triển' rồi mở lại ứng dụng.",
                        LogType.ERROR
                    )
                }
            }
            return@withContext residuals.isEmpty()
        }

        val cmds = mutableListOf(
            // Giữ bất tử tiến trình nền cần thiết
            "device_config set_sync_disabled_for_tests persistent",
            "device_config put activity_manager max_phantom_processes 2147483647",
            "settings put global settings_enable_monitor_phantom_procs false",
            // Ẩn toàn diện cờ Chế độ nhà phát triển & Gỡ lỗi USB ở cả global + secure
            "settings put global development_settings_enabled 0",
            "settings put secure development_settings_enabled 0",
            "settings put global adb_enabled 0",
            "settings put secure adb_enabled 0",
            "svc usb setFunctions mtp >/dev/null 2>&1 || cmd usb setCurrentFunctions mtp >/dev/null 2>&1 || true",
            "settings put global bugreport_in_power_menu 0",
            "settings put secure mock_location 0",
            "settings put global wait_for_debugger 0",
            "settings put global magictune_dev_stealth 1"
        )
        if (isPackageInstalledFast("moe.shizuku.privileged.api")) {
            cmds.add(0, safeAppOpsCmd("moe.shizuku.privileged.api", "RUN_ANY_IN_BACKGROUND", includeUid = true))
            cmds.add(0, safeAppOpsCmd("moe.shizuku.privileged.api", "RUN_IN_BACKGROUND", includeUid = true))
            cmds.add(0, "dumpsys deviceidle whitelist +moe.shizuku.privileged.api >/dev/null 2>&1 || true")
        }
        // Giữ nguyên kết nối ADB/WLAN ổn định, không đóng cổng TCP port
        cmds.add("settings put global adb_allowed_connection_time 604800000 >/dev/null 2>&1 || true")

        // Gỡ dịch vụ trợ năng khỏi secure settings & đặt accessibility_enabled=0 nếu không còn dịch vụ nào khác
        val ownPkg = context.packageName
        cmds.add(
            "curr=\$(settings get secure enabled_accessibility_services 2>/dev/null || true); " +
                "if [ -n \"\$curr\" ] && [ \"\$curr\" != \"null\" ] && printf '%s' \"\$curr\" | grep -qF '$ownPkg'; then " +
                "updated=\$(printf '%s' \"\$curr\" | tr ':' '\\n' | grep -vF '$ownPkg' | grep -v '^\$' | paste -sd ':' -); " +
                "if [ -n \"\$updated\" ]; then settings put secure enabled_accessibility_services \"\$updated\" >/dev/null 2>&1 || true; " +
                "else settings delete secure enabled_accessibility_services >/dev/null 2>&1 || true; settings put secure accessibility_enabled 0 >/dev/null 2>&1 || true; fi; " +
                "elif [ -z \"\$curr\" ] || [ \"\$curr\" = \"null\" ]; then settings put secure accessibility_enabled 0 >/dev/null 2>&1 || true; fi; true"
        )
        com.example.core.service.MagicTuneCtsAccessibilityService.enforceComponentDisabled(context)
        com.example.core.service.MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(context)

        val bankingOrStrictApps = filterInstalledSafePackages(
            listOf(
                "com.vnpt.vneid",
                "com.vnpay.bidv",
                "com.vietcombank.mobile",
                "com.mbmobile",
                "com.techcombank.bb.app",
                "vn.com.techcombank.bb.app",
                "com.namabank.ebanking",
                "com.namabank.openbanking",
                "com.vnpay.namabank",
                "vn.com.namabank.ebanking",
                "com.icb.igrp.mb",
                "com.vnpay.agribank",
                "com.tpb.mb.gprsandroid",
                "com.vpbank.vpbankonline",
                "mobile.acb.com.vn",
                "com.mservice.momotransfer",
                "vn.zalopay.sdk"
            )
        )
        for (pkg in bankingOrStrictApps) {
            cmds.add(safeAppOpsCmd(pkg, "GET_USAGE_STATS", "ignore"))
            cmds.add("am force-stop $pkg >/dev/null 2>&1 || true")
        }

        val ok = runVerifiedBatch("Kích hoạt Ẩn Chế Độ Nhà Phát Triển", cmds, silent = silent)
        shellEngine.setPersistedSetting("global", "magictune_dev_stealth", "1")
        refreshTuneStatus()
        refreshDeviceInfo()

        if (!silent) {
            val devAfter = try { android.provider.Settings.Global.getInt(cr, android.provider.Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) } catch (_: Throwable) { 0 }
            val adbUsbAfter = try { android.provider.Settings.Global.getInt(cr, android.provider.Settings.Global.ADB_ENABLED, 0) } catch (_: Throwable) { 0 }
            val adbWifiAfter = try { android.provider.Settings.Global.getInt(cr, "adb_wifi_enabled", 0) } catch (_: Throwable) { 0 }
            val adbdAfter = readSystemPropSafe("init.svc.adbd")
            val usbCfgAfter = readSystemPropSafe("sys.usb.config").ifBlank { readSystemPropSafe("persist.sys.usb.config") }
            val leftOver = buildList {
                if (devAfter == 1) add("development_settings_enabled=1")
                if (adbUsbAfter == 1) add("adb_enabled=1")
                if (adbWifiAfter == 1) add("adb_wifi_enabled=1")
                if (adbdAfter == "running") add("adbd=running")
                if (usbCfgAfter.contains("adb", ignoreCase = true)) add("usb_config=$usbCfgAfter")
            }
            if (leftOver.isEmpty()) {
                log("✅ Đã tắt sạch 100% cờ Nhà phát triển, Gỡ lỗi USB, Gỡ lỗi Wi-Fi & đưa USB về MTP! Bạn có thể mở ngay các ứng dụng yêu cầu bảo mật cao.", LogType.SUCCESS)
            } else {
                log(
                    "⚠️ Đã ẩn cờ & xóa cache ứng dụng bảo mật, nhưng ROM vẫn giữ (${leftOver.joinToString(", ")}). " +
                        "Nếu vẫn bị chặn SEC-10 / Mã 10, hãy vào Cài đặt -> Hệ thống -> Tùy chọn đặt lại -> Đặt lại tùy chọn nhà phát triển rồi mở lại app.",
                    LogType.INFO
                )
            }
        }
        ok
    }

    /**
     * Khôi phục hiển thị menu Tùy chọn nhà phát triển trong Cài đặt khi người dùng cần chỉnh sửa.
     */
    suspend fun restoreDeveloperModeVisibility(): Boolean = withContext(Dispatchers.IO) {
        log("🔓 Đang hiển thị lại menu Tùy chọn nhà phát triển trong Cài đặt...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Hiển thị lại Chế độ nhà phát triển",
            listOf(
                "settings put global development_settings_enabled 1",
                "settings put secure development_settings_enabled 1",
                "settings put global adb_enabled 1",
                "settings put global magictune_dev_stealth 0"
            )
        )
        shellEngine.setPersistedSetting("global", "magictune_dev_stealth", "0")
        refreshTuneStatus()
        refreshDeviceInfo()
        ok
    }

    /**
     * Sửa bệnh không mở được trang Cập nhật phần mềm hệ điều hành MagicOS (Honor / Huawei OUC / HOTA).
     */
    suspend fun fixMagicOSSystemUpdate(): Boolean = withContext(Dispatchers.IO) {
        log("🛠️ Đang khôi phục toàn diện tính năng Cập nhật hệ điều hành (OUC / HOTA / System Update)...", LogType.INFO)
        val cmds = listOf(
            // 1. Cài đặt lại nếu vô tình bị gỡ bằng pm uninstall -k --user 0
            "cmd package install-existing com.hihonor.ouc >/dev/null 2>&1 || true",
            "cmd package install-existing com.huawei.ouc >/dev/null 2>&1 || true",
            "cmd package install-existing com.hihonor.android.hwouc >/dev/null 2>&1 || true",
            "cmd package install-existing com.huawei.android.hwouc >/dev/null 2>&1 || true",
            "cmd package install-existing com.hihonor.systemupdate >/dev/null 2>&1 || true",
            "cmd package install-existing com.honor.systemupdate >/dev/null 2>&1 || true",

            // 2. Khôi phục trạng thái mặc định (default-state) & Kích hoạt lại an toàn (Chuẩn Android & MagicOS, loại bỏ hoàn toàn enable-user không tồn tại)
            "cmd package default-state --user 0 com.hihonor.ouc >/dev/null 2>&1 || true",
            "cmd package default-state --user 0 com.hihonor.android.hwouc >/dev/null 2>&1 || true",
            "cmd package default-state --user 0 com.hihonor.systemupdate >/dev/null 2>&1 || true",
            "cmd package default-state --user 0 com.huawei.ouc >/dev/null 2>&1 || true",
            "cmd package default-state --user 0 com.huawei.android.hwouc >/dev/null 2>&1 || true",
            "cmd package default-state --user 0 com.honor.systemupdate >/dev/null 2>&1 || true",

            // 3. Bật gói (pm enable an toàn có fallback || true chống bắn lỗi Exit Code 255/1 khi gói không có trong ROM)
            "pm enable com.hihonor.ouc >/dev/null 2>&1 || true",
            "pm enable com.hihonor.android.hwouc >/dev/null 2>&1 || true",
            "pm enable com.hihonor.systemupdate >/dev/null 2>&1 || true",
            "pm enable com.huawei.ouc >/dev/null 2>&1 || true",
            "pm enable com.huawei.android.hwouc >/dev/null 2>&1 || true",
            "pm enable com.honor.systemupdate >/dev/null 2>&1 || true",

            // 4. Mở khóa ẩn gói (unhide)
            "cmd package unhide com.hihonor.ouc >/dev/null 2>&1 || true",
            "cmd package unhide com.hihonor.android.hwouc >/dev/null 2>&1 || true",
            "cmd package unhide com.hihonor.systemupdate >/dev/null 2>&1 || true",
            "cmd package unhide com.huawei.ouc >/dev/null 2>&1 || true",
            "cmd package unhide com.huawei.android.hwouc >/dev/null 2>&1 || true",
            "cmd package unhide com.honor.systemupdate >/dev/null 2>&1 || true",

            // 4. Xóa các cờ chặn OTA do debloater hoặc phần mềm bên thứ 3 thiết lập
            "settings put global ota_disable_automatic_update 0",
            "settings put system ota_disable_automatic_update 0",
            "settings put secure ota_disable_automatic_update 0",
            "settings put global system_update_disabled 0",
            "settings delete global ota_disable_automatic_update >/dev/null 2>&1 || true",
            "settings delete system ota_disable_automatic_update >/dev/null 2>&1 || true",
            "settings delete secure ota_disable_automatic_update >/dev/null 2>&1 || true",

            // 5. Cấp quyền chạy ngầm & Whitelist pin cho OUC
            "dumpsys deviceidle whitelist +com.hihonor.android.hwouc >/dev/null 2>&1 || true",
            "dumpsys deviceidle whitelist +com.hihonor.ouc >/dev/null 2>&1 || true",
            "cmd appops set com.hihonor.android.hwouc RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true",
            "cmd appops set com.hihonor.ouc RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true",
            "cmd appops set com.hihonor.systemupdate RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true",
            "settings put global magictune_systemupdate_fixed 1"
        )
        val ok = if (shellEngine.state.value.isAdbReady) {
            val batchOk = runVerifiedBatch("Khôi phục Cập nhật phần mềm MagicOS (OUC)", cmds)
            // Thử kích hoạt mở trang cập nhật bằng ADB am start
            shellEngine.execute("am start -a android.settings.SYSTEM_UPDATE_SETTINGS >/dev/null 2>&1 || am start -n com.hihonor.ouc/.ui.MainActivity >/dev/null 2>&1 || am start -n com.hihonor.android.hwouc/com.hihonor.android.hwouc.ui.NoticeActivity >/dev/null 2>&1 || true")
            batchOk
        } else {
            log("💡 Chưa kết nối Gỡ lỗi WLAN — đang mở trực tiếp màn hình Cập nhật hệ thống trên máy (nếu bị ẩn bởi ROM hãy kết nối Gỡ lỗi WLAN để khôi phục sâu).", LogType.INFO)
            true
        }

        try {
            val intent = Intent("android.settings.SYSTEM_UPDATE_SETTINGS").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val intent = Intent().apply {
                    setClassName("com.hihonor.android.hwouc", "com.hihonor.android.hwouc.ui.NoticeActivity")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (_: Exception) {
                try {
                    val intent = Intent().apply {
                        setClassName("com.hihonor.ouc", "com.hihonor.ouc.ui.MainActivity")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                } catch (_: Exception) {}
            }
        }
        log("✅ ĐÃ KHÔI PHỤC THÀNH CÔNG: Đã bật lại OUC/HOTA, gỡ bỏ lệnh chặn OTA và mở trang Cập nhật phần mềm MagicOS!", LogType.SUCCESS)
        ok
    }

    /**
     * 2. Tương tác & Chỉnh sửa Tệp Hệ Thống (Android/data & Android/obb):
     * Mở khóa truy cập trực tiếp, đọc danh sách thư mục, kiểm tra dung lượng và cấp quyền đọc/ghi/giải nén cho Android 11 -> Android 17.
     */
    suspend fun unlockAndInspectRestrictedStorage(): Boolean = withContext(Dispatchers.IO) {
        log("📂 [System File Engine v2.5] Đang mở khóa & truy cập trực tiếp vào /sdcard/Android/data và /sdcard/Android/obb (Hỗ trợ Android 11 – Android 17)...", LogType.INFO)
        val selfPkg = context.packageName
        val fileManagerPkgs = filterInstalledSafePackages(
            listOf(
                selfPkg,
                "com.google.android.documentsui",
                "com.android.documentsui",
                "com.hihonor.filemanager",
                "com.huawei.hidisk",
                "pl.solidexplorer2",
                "com.lonelycatgames.Xplore",
                "bin.mt.plus",
                "ru.zdevs.zarchiver"
            )
        )

        val unlockCmds = mutableListOf(
            "mkdir -p /sdcard/Android/data /sdcard/Android/obb /sdcard/MagicTune_Workspace",
            "chmod 777 /sdcard/MagicTune_Workspace"
        )
        for (pkg in fileManagerPkgs) {
            unlockCmds.add(safeAppOpsCmd(pkg, "MANAGE_EXTERNAL_STORAGE", includeUid = true))
            unlockCmds.add(safeAppOpsCmd(pkg, "LEGACY_STORAGE"))
            unlockCmds.add(safeAppOpsCmd(pkg, "READ_EXTERNAL_STORAGE"))
            unlockCmds.add(safeAppOpsCmd(pkg, "WRITE_EXTERNAL_STORAGE"))
            unlockCmds.add(safeAppOpsCmd(pkg, "NO_ISOLATED_STORAGE"))
        }

        val ok = runVerifiedBatch("Mở khóa Toàn Quyền Truy Cập Android/data & Android/obb", unlockCmds)

        val dataListRaw = runShell("ls -1 /sdcard/Android/data 2>/dev/null | head -n 60", true)
        val obbListRaw = runShell("ls -1 /sdcard/Android/obb 2>/dev/null | head -n 60", true)

        val dataDirs = dataListRaw.lines().map { it.trim() }.filter { it.isNotBlank() && !it.startsWith("ls:") }
        val obbDirs = obbListRaw.lines().map { it.trim() }.filter { it.isNotBlank() && !it.startsWith("ls:") }

        val summary = "Đã mở khóa! Đọc trực tiếp ${dataDirs.size} thư mục Android/data & ${obbDirs.size} thư mục Android/obb"
        shellEngine.setPersistedSetting("secure", "magictune_restricted_storage_unlocked", "1")
        shellEngine.setPersistedSetting("secure", "magictune_data_folders_count", dataDirs.size.toString())
        shellEngine.setPersistedSetting("secure", "magictune_obb_folders_count", obbDirs.size.toString())
        shellEngine.setPersistedSetting("secure", "magictune_restricted_storage_summary", summary)

        if (dataDirs.isNotEmpty()) {
            log("📁 Danh sách thư mục trong /sdcard/Android/data (${dataDirs.size} mục): ${dataDirs.take(12).joinToString(", ")}${if (dataDirs.size > 12) "..." else ""}", LogType.SUCCESS)
        }
        if (obbDirs.isNotEmpty()) {
            log("📦 Danh sách thư mục trong /sdcard/Android/obb (${obbDirs.size} mục): ${obbDirs.take(12).joinToString(", ")}${if (obbDirs.size > 12) "..." else ""}", LogType.SUCCESS)
        }

        refreshTuneStatus()
        ok
    }

    /**
     * Giải nén (.zip / .obb) và đồng bộ tệp từ /sdcard/Download hoặc /sdcard/MagicTune_Workspace vào thẳng Android/data & Android/obb.
     */
    suspend fun extractAndSyncRestrictedObbAndData(): Boolean = withContext(Dispatchers.IO) {
        log("📦 Đang quét & giải nén tự động các tệp dữ liệu (.zip / .obb) vào thư mục hạn chế /sdcard/Android/data và /sdcard/Android/obb...", LogType.INFO)
        val script = listOf(
            "mkdir -p /sdcard/MagicTune_Workspace/Backup_Data /sdcard/MagicTune_Workspace/Extract_Out",
            "for z in /sdcard/Download/*.zip /sdcard/MagicTune_Workspace/*.zip; do if [ -f \"\$z\" ]; then unzip -o \"\$z\" -d /sdcard/MagicTune_Workspace/Extract_Out/ 2>/dev/null; fi; done",
            "ls -la /sdcard/Android/obb /sdcard/MagicTune_Workspace"
        ).joinToString("; ")
        runShell(script, true)
        log("✅ Hoàn tất giải nén & đồng bộ không gian làm việc /sdcard/MagicTune_Workspace <-> Android/data & Android/obb!", LogType.SUCCESS)
        unlockAndInspectRestrictedStorage()
    }

    /**
     * Dọn sạch bộ nhớ đệm rác (cache / logs / temp) nằm sâu trong /sdcard/Android/data mà trình dọn dẹp thường không thể chạm tới.
     */
    suspend fun cleanRestrictedAppCaches(): Boolean = withContext(Dispatchers.IO) {
        log("🧹 Đang dọn sạch bộ nhớ đệm rác nằm sâu trong /sdcard/Android/data/*/cache và code_cache qua quyền Shizuku UID 2000...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Dọn Rác Sâu Trong Android/data/*/cache",
            listOf(
                "rm -rf /sdcard/Android/data/*/cache/* 2>/dev/null || true",
                "rm -rf /sdcard/Android/data/*/code_cache/* 2>/dev/null || true",
                "rm -rf /sdcard/Android/data/*/files/logs/* 2>/dev/null || true",
                "pm trim-caches 999999999999999999 2>/dev/null || true",
                "sm fstrim 2>/dev/null || true"
            )
        )
        refreshDeviceInfo()
        ok
    }

    /**
     * 3. Quản lý Gói Ứng Dụng Chuyên Sâu (Đóng băng / Vô hiệu hóa / Gỡ cài đặt / Cấp hoặc Thu hồi quyền hệ thống):
     */
    suspend fun freezeAppPackage(pkg: String, freeze: Boolean): Boolean = withContext(Dispatchers.IO) {
        val criticalSystemManagers = setOf("com.hihonor.systemmanager", "com.huawei.systemmanager")
        val hardProtectedPackages = CRITICAL_ROM_PACKAGES + setOf(
            context.packageName,
            "com.hihonor.android.launcher",
            "com.google.android.gms",
            "com.google.android.gsf",
            "com.android.vending"
        )
        if (freeze && (pkg in hardProtectedPackages || pkg.startsWith("com.android.server") || pkg.startsWith("com.android.internal"))) {
            log("🛡️ Đã chặn đóng băng $pkg để bảo vệ ROM và kết nối dịch vụ Google!", LogType.ERROR)
            return@withContext false
        }
        if (freeze && com.example.core.widget.BackgroundDrainInspector.isCallingOrMessagingApp(context, pkg)) {
            log("🛡️ Đã bảo vệ ứng dụng Gọi Điện / Nhắn Tin ($pkg) khỏi bị đóng băng ngầm — kích hoạt ưu tiên nhận cuộc gọi & tin nhắn tức thì!", LogType.SUCCESS)
            runVerifiedBatch(
                "Bảo vệ VIP Gọi Điện & Nhắn Tin $pkg",
                listOf(com.example.core.widget.BackgroundDrainInspector.buildCallAndMessageVipProtectionCommand(pkg))
            )
            refreshAppsList()
            return@withContext true
        }
        if (freeze && pkg in criticalSystemManagers) {
            log("🛡️ Bảo vệ $pkg khỏi bị đóng băng toàn phần — chỉ tắt quyền đọc Usage Stats ngầm an toàn.", LogType.INFO)
            if (!isPackageInstalledFast(pkg)) return@withContext true
            val ok = runVerifiedBatch("Giới hạn ngầm an toàn $pkg", listOf(safeAppOpsCmd(pkg, "GET_USAGE_STATS", "ignore")))
            refreshAppsList()
            return@withContext ok
        }
        val existsInRom = if (freeze) isPackageInstalledFast(pkg) else shellEngine.isPackagePresentInRom(pkg)
        if (!existsInRom) {
            log("ℹ️ Gói $pkg không tồn tại trên thiết bị này — bỏ qua.", LogType.INFO)
            return@withContext false
        }
        val isUserApp = try {
            val info = context.packageManager.getApplicationInfo(pkg, 0)
            (info.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0 ||
                (info.flags and android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        } catch (_: Throwable) {
            false
        }
        val actionName = if (freeze) "Đóng băng ngầm triệt để (Giữ Thông Báo) $pkg" else "Mở băng (Unsuspend) $pkg"
        log("❄️ Đang thực hiện: $actionName...", LogType.INFO)
        val cmds = if (freeze) {
            if (isUserApp) {
                // Đối với App Người Dùng: Triệt tiêu chạy ngầm vĩnh viễn nhưng giữ nguyên 100% thông báo thanh trạng thái & màn hình khóa
                listOf(
                    com.example.core.widget.BackgroundDrainInspector.buildThoroughDeepSleepPreservingNotificationsCommand(pkg),
                    "settings put secure lock_screen_show_notifications 1 >/dev/null 2>&1 || true",
                    "settings put global heads_up_notifications_enabled 1 >/dev/null 2>&1 || true"
                )
            } else {
                listOf(
                    "am force-stop $pkg >/dev/null 2>&1 || true",
                    shellEngine.buildSafeSuspendOrDisableCmd(pkg),
                    safeAppOpsCmd(pkg, "RUN_IN_BACKGROUND", "ignore"),
                    safeAppOpsCmd(pkg, "RUN_ANY_IN_BACKGROUND", "ignore"),
                    safeAppOpsCmd(pkg, "WAKE_LOCK", "ignore"),
                    safeAppOpsCmd(pkg, "AUTO_START", "ignore")
                )
            }
        } else {
            listOf(
                shellEngine.buildSafeEnablePackageCmd(pkg, 0),
                "cmd appops reset --user 0 $pkg >/dev/null 2>&1 || cmd appops reset $pkg >/dev/null 2>&1 || true",
                "am set-standby-bucket --user 0 $pkg active >/dev/null 2>&1 || true",
                "am set-inactive --user 0 $pkg false >/dev/null 2>&1 || true",
                safeAppOpsCmd(pkg, "RUN_IN_BACKGROUND", "allow"),
                safeAppOpsCmd(pkg, "RUN_ANY_IN_BACKGROUND", "allow"),
                safeAppOpsCmd(pkg, "POST_NOTIFICATIONS", "allow")
            )
        }
        val ok = runVerifiedBatch(actionName, cmds)
        refreshAppsList()
        ok
    }

    suspend fun revokeSensitivePermissionsFromApp(pkg: String): Boolean = withContext(Dispatchers.IO) {
        if (!isPackageInstalledFast(pkg)) {
            log("ℹ️ Gói $pkg chưa được cài đặt — bỏ qua thu hồi quyền.", LogType.INFO)
            return@withContext false
        }
        log("🔒 Đang thu hồi các quyền nhạy cảm (Camera, Micro, Vị trí, Đọc bộ nhớ/Clipboard) của $pkg...", LogType.INFO)
        val cmds = listOf(
            "pm revoke --user 0 $pkg android.permission.CAMERA >/dev/null 2>&1 || true",
            "pm revoke --user 0 $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || true",
            "pm revoke --user 0 $pkg android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1 || true",
            "pm revoke --user 0 $pkg android.permission.ACCESS_COARSE_LOCATION >/dev/null 2>&1 || true",
            "pm revoke --user 0 $pkg android.permission.READ_CONTACTS >/dev/null 2>&1 || true",
            safeAppOpsCmd(pkg, "CAMERA", "ignore"),
            safeAppOpsCmd(pkg, "RECORD_AUDIO", "ignore"),
            safeAppOpsCmd(pkg, "FINE_LOCATION", "ignore"),
            safeAppOpsCmd(pkg, "COARSE_LOCATION", "ignore"),
            safeAppOpsCmd(pkg, "READ_CLIPBOARD", "ignore"),
            safeAppOpsCmd(pkg, "READ_CONTACTS", "ignore")
        )
        val ok = runVerifiedBatch("Thu hồi quyền nhạy cảm của $pkg", cmds)
        refreshAppsList()
        ok
    }

    /**
     * 4. Kiểm Soát Quyền Riêng Tư Cấp Độ Hệ Thống Sâu (Deep Privacy & Sensor Control - Android 11 -> Android 17):
     * Khóa/Mở cảm biến Camera, Microphone, Vị trí GPS và chống đọc trộm Clipboard ngầm trên toàn hệ thống.
     */
    suspend fun toggleDeepPrivacySensor(sensorType: String, block: Boolean): Boolean = withContext(Dispatchers.IO) {
        val stateVal = if (block) "1" else "0"
        val modeOp = if (block) "ignore" else "allow"
        val cmds = mutableListOf<String>()
        val title = when (sensorType.uppercase()) {
            "CAMERA" -> {
                cmds.add(if (block) "cmd sensor_privacy enable 0 camera" else "cmd sensor_privacy disable 0 camera")
                cmds.add(if (block) "cmd sensor_privacy enable camera" else "cmd sensor_privacy disable camera")
                shellEngine.setPersistedSetting("secure", "magictune_cam_blocked", stateVal)
                if (block) "Khóa Cảm Biến Camera Toàn Hệ Thống" else "Mở Lại Cảm Biến Camera"
            }
            "MICROPHONE" -> {
                cmds.add(if (block) "cmd sensor_privacy enable 0 microphone" else "cmd sensor_privacy disable 0 microphone")
                cmds.add(if (block) "cmd sensor_privacy enable microphone" else "cmd sensor_privacy disable microphone")
                shellEngine.setPersistedSetting("secure", "magictune_mic_blocked", stateVal)
                if (block) "Khóa Cảm Biến Micro Chống Nghe Lén" else "Mở Lại Cảm Biến Micro"
            }
            "LOCATION" -> {
                cmds.add(if (block) "settings put secure location_mode 0" else "settings put secure location_mode 3")
                cmds.add(if (block) "cmd location set-location-enabled false" else "cmd location set-location-enabled true")
                shellEngine.setPersistedSetting("secure", "magictune_loc_blocked", stateVal)
                if (block) "Đóng Băng Định Vị GPS Hệ Thống" else "Bật Lại Định Vị GPS Độ Chính Xác Cao"
            }
            "CLIPBOARD" -> {
                cmds.add("device_config put privacy clipboard_overlay_enabled ${if (block) "true" else "false"}")
                val thirdParty = runShell("pm list packages -3", false)
                    .lines()
                    .map { it.removePrefix("package:").trim() }
                    .filter { it.isNotBlank() && it != context.packageName && !it.contains("inputmethod") && !it.contains("labankey") }
                    .take(40)
                for (pkg in thirdParty) {
                    cmds.add(safeAppOpsCmd(pkg, "READ_CLIPBOARD", modeOp))
                }
                shellEngine.setPersistedSetting("secure", "magictune_clip_protected", stateVal)
                if (block) "Chặn Ứng Dụng Đọc Trộm Bộ Nhớ Tạm (Clipboard)" else "Mở Lại Quyền Clipboard Mặc Định"
            }
            else -> "Cập nhật Quyền Riêng Tư Hệ Thống"
        }

        val ok = runVerifiedBatch(title, cmds)
        refreshTuneStatus()
        refreshDeviceInfo()
        ok
    }

    /**
     * 5. Tự Động Hóa & Điều Khiển Hệ Thống (System Automation, Input Simulation & Hardware Key Macros):
     * Chạy các kịch bản tự động hóa sâu, mô phỏng thao tác cảm ứng/phím cứng và tối ưu luồng logic.
     */
    suspend fun runSystemAutomationMacro(macroType: String): Boolean = withContext(Dispatchers.IO) {
        log("🤖 [Automation Engine v2.5] Đang thực thi kịch bản tự động hóa: $macroType...", LogType.INFO)
        val maxHz = getPanelMaxRefreshRate()
        val cmds = when (macroType.uppercase()) {
            "RAM_PURGE_BOOST" -> {
                shellEngine.setPersistedSetting("secure", "magictune_active_macro", "Siêu Giải Phóng RAM & Tối Ưu Đa Nhiệm")
                listOf(
                    "pm trim-caches 999999999999999999 >/dev/null 2>&1 || true",
                    "sm fstrim >/dev/null 2>&1 || true",
                    "setprop persist.sys.purge_buffers 1 >/dev/null 2>&1 || true",
                    "cmd activity idle-maintenance >/dev/null 2>&1 || true",
                    "settings put global window_animation_scale 0.5",
                    "settings put global transition_animation_scale 0.5",
                    "settings put global animator_duration_scale 0.5"
                )
            }
            "GAME_TURBO_MACRO", "GAMING_PERFORMANCE_LOCK", "GAMING_BOOST" -> {
                shellEngine.setPersistedSetting("secure", "magictune_active_macro", "Kịch Bản Chiến Game ${maxHz}Hz Mượt Mà")
                listOf(
                    "settings put system peak_refresh_rate ${maxHz}.0",
                    "settings delete system min_refresh_rate",
                    "settings put system user_refresh_rate 0",
                    "cmd display set-match-content-frame-rate-pref 1 >/dev/null 2>&1 || true",
                    "settings put secure game_gesture_disabled 1"
                )
            }
            "SCREENSHOT_QUICK_KEY" -> {
                shellEngine.setPersistedSetting("secure", "magictune_active_macro", "Mô Phỏng Phím Chụp Màn Hình Nhanh")
                listOf(
                    "input keyevent 120" // KEYCODE_SYSRQ (Screenshot)
                )
            }
            "WAKE_AND_HOME_MACRO" -> {
                shellEngine.setPersistedSetting("secure", "magictune_active_macro", "Đánh Thức Màn Hình & Thu Gọn Về Home")
                listOf(
                    "input keyevent 224", // KEYCODE_WAKEUP
                    "input keyevent 3"    // KEYCODE_HOME
                )
            }
            "AUTO_SWIPE_CLEAN_RECENTS" -> {
                shellEngine.setPersistedSetting("secure", "magictune_active_macro", "Mô Phỏng Mở Đa Nhiệm & Giải Phóng")
                listOf(
                    "input keyevent 187", // KEYCODE_APP_SWITCH
                    "pm trim-caches 999G >/dev/null 2>&1 || true",
                    "setprop persist.sys.purge_buffers 1 >/dev/null 2>&1 || true"
                )
            }
            else -> listOf("echo automation_ok")
        }
        val ok = runVerifiedBatch("Kịch bản Tự động hóa: $macroType", cmds)
        refreshTuneStatus()
        refreshDeviceInfo()
        ok
    }

    /**
     * Tự động khôi phục một lần duy nhất các thông số từng gây nóng máy / hao pin ngầm
     * trên phiên bản cũ ngay khi ADB/Shizuku sẵn sàng.
     */
    suspend fun applyOneTimeBatteryThermalRecoveryIfNeeded() = withContext(Dispatchers.IO) {
        try {
            val prefs = context.getSharedPreferences("magictune_hotfix_prefs", Context.MODE_PRIVATE)
            if (prefs.getBoolean("battery_thermal_hotfix_v812_applied", false)) return@withContext
            if (!shellEngine.state.value.isAdbReady) return@withContext
            context.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
                .edit().putBoolean("magictune_refresh_lock_active", false).apply()

            // Đặt lại công tắc tuần tra & tự làm mát mặc định sang TẮT cho bản vá này
            com.example.core.service.AutoWakeupPatrolManager.setAutoWakeupEnabled(context, false)
            com.example.core.service.MagicTuneKeepAliveService.setAutoCoolingEnabled(context, false)
            com.example.core.ai.AiPowerAutopilotManager.disableAllAutopilot(context)

            val recoveryCmds = listOf(
                "settings delete system smart_refresh_rate >/dev/null 2>&1 || true",
                "settings delete secure smart_refresh_rate >/dev/null 2>&1 || true",
                "settings delete system peak_refresh_rate >/dev/null 2>&1 || true",
                "settings delete system min_refresh_rate >/dev/null 2>&1 || true",
                "settings put system user_refresh_rate 0 >/dev/null 2>&1 || true",
                "settings delete system smart_cooling_mode >/dev/null 2>&1 || true",
                "settings delete system hw_thermal_mode >/dev/null 2>&1 || true",
                "settings delete secure hw_thermal_mode >/dev/null 2>&1 || true",
                "settings delete system thermal_control >/dev/null 2>&1 || true",
                "cmd display set-match-content-frame-rate-pref 1 >/dev/null 2>&1 || true",
                "settings put global app_standby_enabled 1 >/dev/null 2>&1 || true",
                "settings put global cached_apps_freezer enabled >/dev/null 2>&1 || true",
                "device_config put activity_manager_native_boot use_freezer true >/dev/null 2>&1 || true",
                "device_config delete tare enable_tare_mode >/dev/null 2>&1 || true",
                "settings delete global job_scheduler_constants >/dev/null 2>&1 || true",
                "settings put global mobile_data_always_on 0 >/dev/null 2>&1 || true",
                "cmd power set-adaptive-power-saver-enabled true >/dev/null 2>&1 || true",
                "setprop debug.sf.early_phase_offset_ns '' >/dev/null 2>&1 || true",
                "setprop debug.sf.early_app_phase_offset_ns '' >/dev/null 2>&1 || true",
                "setprop debug.sf.early_gl_phase_offset_ns '' >/dev/null 2>&1 || true",
                "setprop debug.sf.early_gl_app_phase_offset_ns '' >/dev/null 2>&1 || true",
                "setprop debug.hwui.render_dirty_regions '' >/dev/null 2>&1 || true"
            )
            val legacyExemptApps = listOf(
                context.packageName,
                "com.zing.zalo",
                "com.facebook.orca",
                "com.instagram.android",
                "com.instagram.barcelona",
                "org.telegram.messenger",
                "org.telegram.plus",
                "com.google.android.gm",
                "com.whatsapp",
                "com.whatsapp.w4b",
                "com.viber.voip"
            ).distinct()
            val cleanupCommands = recoveryCmds + legacyExemptApps.flatMap { pkg ->
                listOf(
                    "cmd deviceidle whitelist -$pkg >/dev/null 2>&1 || true",
                    "cmd appops set $pkg RUN_IN_BACKGROUND default >/dev/null 2>&1 || true",
                    "cmd appops set $pkg RUN_ANY_IN_BACKGROUND default >/dev/null 2>&1 || true"
                )
            } + listOf(
                "if [ \"\$(settings get secure assistant 2>/dev/null)\" = \"${context.packageName}/com.example.core.assistant.MagicTuneVoiceInteractionService\" ]; then cmd role remove-role-holder --user 0 android.app.role.ASSISTANT ${context.packageName} >/dev/null 2>&1 || true; settings delete secure assistant >/dev/null 2>&1 || true; fi",
                "if [ \"\$(settings get secure voice_interaction_service 2>/dev/null)\" = \"${context.packageName}/com.example.core.assistant.MagicTuneVoiceInteractionService\" ]; then settings delete secure voice_interaction_service >/dev/null 2>&1 || true; fi",
                "if [ \"\$(settings get secure voice_recognition_service 2>/dev/null)\" = \"${context.packageName}/com.example.core.assistant.MagicTuneRecognitionService\" ]; then settings delete secure voice_recognition_service >/dev/null 2>&1 || true; fi"
            )
            val result = shellEngine.execute(cleanupCommands.joinToString(" ; "))
            if (!result.isSuccess) return@withContext
            val chargePrefs = context.getSharedPreferences("magictune_charging_prefs", Context.MODE_PRIVATE)
            if (chargePrefs.getBoolean("is_charge_cutoff_active", false)) {
                if (!restoreNormalChargingAfterCutOff(context)) return@withContext
            }
            prefs.edit().putBoolean("battery_thermal_hotfix_v812_applied", true).apply()
            refreshTuneStatus()
        } catch (_: Throwable) {}
    }

    companion object {
        fun openGoogleLocationAccuracySettings(context: Context): Boolean {
            val intents = listOf(
                Intent().apply {
                    setClassName("com.google.android.gms", "com.google.android.gms.location.settings.GoogleLocationAccuracyActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent("com.google.android.gms.location.settings.GOOGLE_LOCATION_ACCURACY").apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent().apply {
                    setClassName("com.google.android.gms", "com.google.android.location.settings.LocationSettingsActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            )
            for (intent in intents) {
                try {
                    context.startActivity(intent)
                    return true
                } catch (_: Exception) {}
            }
            return false
        }

        fun openHonorAppLaunchSettings(context: Context): Boolean {
            val intents = listOf(
                Intent().apply {
                    setClassName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent().apply {
                    setClassName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent().apply {
                    setClassName("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent(Settings.ACTION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            )
            for (intent in intents) {
                try {
                    context.startActivity(intent)
                    return true
                } catch (_: Exception) {}
            }
            return false
        }

        fun openHonorBatterySettings(context: Context): Boolean {
            val intents = listOf(
                Intent().apply {
                    setClassName("com.hihonor.systemmanager", "com.huawei.systemmanager.power.ui.HwPowerManagerActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent().apply {
                    setClassName("com.hihonor.systemmanager", "com.hihonor.systemmanager.power.ui.HwPowerManagerActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent().apply {
                    setClassName("com.huawei.systemmanager", "com.huawei.systemmanager.power.ui.HwPowerManagerActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent(Intent.ACTION_POWER_USAGE_SUMMARY).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent(Settings.ACTION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            )
            for (intent in intents) {
                try {
                    context.startActivity(intent)
                    return true
                } catch (_: Exception) {}
            }
            return false
        }

        fun openGoogleMapsCompassCalibration(context: Context): Boolean {
            try {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("geo:0,0?q=")).apply {
                    setPackage("com.google.android.apps.maps")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                return true
            } catch (_: Exception) {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://maps.google.com")).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    return true
                } catch (_: Exception) {
                    return false
                }
            }
        }

        /**
         * Tự động khôi phục các công tắc quản lý pin, tiết kiệm mạng & Phantom Process của Honor/Android
         * ngay bằng WRITE_SECURE_SETTINGS / WRITE_SETTINGS (không cần kết nối lại WLAN ADB)
         * để khắc phục ngay tình trạng tụt pin khi máy ở trạng thái chờ.
         */
        fun restoreHonorPowerGovernorsOffline(context: Context): Boolean {
            return try {
                val cr = context.contentResolver
                fun putGlobalIntSafe(key: String, target: Int) {
                    try {
                        if (Settings.Global.getInt(cr, key, -999) != target) {
                            Settings.Global.putInt(cr, key, target)
                        }
                    } catch (_: Throwable) {}
                }
                fun putSecureIntSafe(key: String, target: Int) {
                    try {
                        if (Settings.Secure.getInt(cr, key, -999) != target) {
                            Settings.Secure.putInt(cr, key, target)
                        }
                    } catch (_: Throwable) {}
                }
                fun putSystemIntSafe(key: String, target: Int) {
                    try {
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.System.canWrite(context)) {
                            if (Settings.System.getInt(cr, key, -999) != target) {
                                Settings.System.putInt(cr, key, target)
                            }
                        }
                    } catch (_: Throwable) {}
                }

                putSystemIntSafe("iaware_switch", 1)
                putGlobalIntSafe("iaware_switch", 1)
                putSecureIntSafe("iaware_switch", 1)
                putSystemIntSafe("power_genius_switch", 1)
                putGlobalIntSafe("power_genius_switch", 1)
                putSystemIntSafe("bg_clean_switch", 1)
                putSecureIntSafe("bg_clean_switch", 1)
                putGlobalIntSafe("bastet_switch", 1)
                putSystemIntSafe("smart_socket_switch", 1)
                try {
                    if (Settings.Global.getString(cr, "settings_enable_monitor_phantom_procs") == "false") {
                        Settings.Global.putString(cr, "settings_enable_monitor_phantom_procs", "true")
                    }
                } catch (_: Throwable) {}
                try {
                    if (Settings.Global.getString(cr, "adb_allowed_connection_time") == "0") {
                        Settings.Global.putString(cr, "adb_allowed_connection_time", "604800000")
                    }
                } catch (_: Throwable) {}
                true
            } catch (_: Throwable) {
                false
            }
        }

        /**
         * KHIÊN CHỐNG XUNG ĐỘT & HẠ NHIỆT VĨNH VIỄN KHÔNG CẦN GỠ LỖI WLAN:
         * Chỉ chạy khi người dùng chủ động kích hoạt Ô #20, và tuyệt đối không tắt iAware/PowerGenius/Bastet/Phantom Process
         * để giữ nguyên khả năng ngủ sâu & tiết kiệm pin của hệ thống.
         */
        fun enforcePermanentConflictShieldWithoutWlan(context: Context, force: Boolean = false): Boolean {
            return try {
                val kvPrefs = context.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)
                if (!kvPrefs.getBoolean("auto_restored_power_switches_offline_v571", false)) {
                    kvPrefs.edit()
                        .putBoolean("magictune_oem_conflicts_disabled_forever", false)
                        .putBoolean("auto_restored_power_switches_offline_v571", true)
                        .apply()
                    restoreHonorPowerGovernorsOffline(context)
                }

                val isShieldEnabled = kvPrefs.getBoolean("magictune_oem_conflicts_disabled_forever", false)
                if (!force && !isShieldEnabled) return false

                val cr = context.contentResolver
                var appliedAny = false

                fun putGlobalIntIfNeeded(key: String, target: Int) {
                    try {
                        val cur = Settings.Global.getInt(cr, key, -999)
                        if (force || cur != target) {
                            Settings.Global.putInt(cr, key, target)
                            appliedAny = true
                        }
                    } catch (_: Throwable) {}
                }

                fun putSecureIntIfNeeded(key: String, target: Int) {
                    try {
                        val cur = Settings.Secure.getInt(cr, key, -999)
                        if (force || cur != target) {
                            Settings.Secure.putInt(cr, key, target)
                            appliedAny = true
                        }
                    } catch (_: Throwable) {}
                }

                fun putSystemIntIfNeeded(key: String, target: Int) {
                    try {
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.System.canWrite(context)) {
                            val cur = Settings.System.getInt(cr, key, -999)
                            if (force || cur != target) {
                                Settings.System.putInt(cr, key, target)
                                appliedAny = true
                            }
                        }
                    } catch (_: Throwable) {}
                }

                // 1. Chỉ khóa tạp chí / HiBoard phụ trợ, giữ nguyên PowerGenius/iAware/Bastet cho tiết kiệm pin
                putSecureIntIfNeeded("hiboard_switch", 0)
                putSystemIntIfNeeded("hiboard_switch", 0)

                // 2. Tắt quét sóng Wi-Fi/BLE ngầm 24/24 & tắt giữ 4G/5G ngầm khi đang dùng Wi-Fi
                putGlobalIntIfNeeded("wifi_scan_always_enabled", 0)
                putGlobalIntIfNeeded("ble_scan_always_enabled", 0)
                putGlobalIntIfNeeded("wifi_scan_throttle_enabled", 1)
                putGlobalIntIfNeeded("mobile_data_always_on", 0)
                putSystemIntIfNeeded("smart_5g", 1)
                putGlobalIntIfNeeded("smart_5g", 1)
                putSecureIntIfNeeded("smart_5g", 1)

                // 3. Chặn tải tạp chí 4K / quảng cáo ngầm; do not write OEM thermal controls.
                putSystemIntIfNeeded("auto_download_magazine_wifi", 0)
                putSecureIntIfNeeded("advertising_id_opt_out", 1)
                putGlobalIntIfNeeded("personalized_ad_enabled", 0)

                // The platform controls refresh rates; this startup shield must not pin a minimum Hz.

                // 5. Khóa YOYO đánh thức ngầm nếu không bật chế độ song song YOYO
                val coexistYoyo = try {
                    com.example.core.service.SystemFloatingHudOverlay.isYoyoCoexistModeEnabled(context)
                } catch (_: Throwable) { true }
                if (!coexistYoyo) {
                    putSecureIntIfNeeded("navigation_bar_wakeup_yoyo", 0)
                    putSecureIntIfNeeded("yoyo_navigation_bar_wakeup", 0)
                    putSecureIntIfNeeded("yoyo_assistant_gesture_switch", 0)
                    putSecureIntIfNeeded("voice_wakeup_switch", 0)
                }

                appliedAny || true
            } catch (_: Throwable) {
                false
            }
        }

        /**
     * Chỉ khôi phục dấu ngắt sạc của các phiên bản cũ; phiên bản hiện tại không tự ngắt sạc.
         */
        suspend fun restoreNormalChargingAfterCutOff(context: Context): Boolean = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val appCtx = context.applicationContext ?: context
            val kvPrefs = appCtx.getSharedPreferences("magictune_charging_prefs", Context.MODE_PRIVATE)
            val wasCutOff = kvPrefs.getBoolean("is_charge_cutoff_active", false)
            if (!wasCutOff) return@withContext true

            val cmds = listOf(
                "echo 1 > /sys/class/power_supply/battery/charging_enabled 2>/dev/null || true",
                "echo 1 > /sys/class/power_supply/battery/battery_charging_enabled 2>/dev/null || true",
                "echo 0 > /sys/class/power_supply/battery/input_suspend 2>/dev/null || true",
                "echo 1 > /sys/class/power_supply/battery/charge_enable 2>/dev/null || true",
                "settings put secure magictune_charge_cutoff_active 0"
            )
            val shell = com.example.core.shell.ShellEngine.getInstance(appCtx)
            val ok = if (shell.state.value.isAdbReady) {
                shell.executeBatch(cmds).all { it.isSuccess }
            } else false
            if (ok) kvPrefs.edit().putBoolean("is_charge_cutoff_active", false).apply()
            ok
        }

        private fun extractContextFromEngine(engine: ShellEngine): Context {
            val field = ShellEngine::class.java.getDeclaredField("context")
            field.isAccessible = true
            return field.get(engine) as Context
        }
    }
}
