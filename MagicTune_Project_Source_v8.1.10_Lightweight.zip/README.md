# MagicTune Tool V4.1 (Bản Tối Ưu Hóa Honor & Android)

**MagicTune Tool** là bộ công cụ tối ưu hóa chuyên sâu dành cho các dòng điện thoại thông minh Android, đặc biệt tối ưu tuyệt đối cho hệ máy **Honor nội địa** (chạy MagicOS 7.x, 8.x, 9.x, 10.x, 11.x trên nền Android 13/14/15/16/17).

---

## 🚀 Các Tính Năng Nổi Bật

1. **Direct WLAN ADB (Mã Ghép Nối 6 Số)**
   - Kết nối trực tiếp ADB qua Wi-Fi nội bộ bằng giao thức TLS 1.3 / Conscrypt & SPAKE2 pairing mà không cần PC (tương thích hoàn toàn đến Android 17 / API 37+).
   - Quản lý và kích hoạt Shizuku Server tự động trong nền (UID 2000).

2. **Đặc Trị Honor Nội Địa (MagicOS 7 / 8 / 9 / 10 / 11)**
   - **Chống Đóng Băng & Giết Ngầm (PowerGenie Killer):** Khắc chế cơ chế đóng băng của `com.hihonor.powergenius`, `iaware` và `systemmanager`.
   - **Khắc Phục Lệch Tọa Độ GPS (Timestamp Camera):** Xử lý triệt để lỗi sai lệch 500m–2km do hệ thống định vị ngầm Cao Đức (`com.amap.android.ams`) chuyển đổi từ GCJ-02 sang WGS-84 chuẩn quốc tế.
   - **Gỡ Bỏ Ứng Dụng Rác (Debloat):** Tắt các ứng dụng chạy ngầm gây hao pin như HiBoard, Honor Search, Báo Mới Lockscreen, Baidu Input Honor.
   - **Tối Ưu Cảm Ứng & Màn Hình 120Hz:** Mở khóa độ nhạy màng cường lực (`hihonor_screen_film_state`), chế độ găng tay và giữ 120Hz mượt mà ngay cả khi pin yếu.
   - **Thay Thế Trợ Lý Ảo YOYO:** Chuyển đổi phím nguồn hoặc cử chỉ gọi YOYO tiếng Trung sang Google Assistant / Trợ lý MagicTune.

3. **Bàn Phím IME Tiếng Việt Tích Hợp**
   - Bộ gõ Telex/VNI chuẩn, tự động nhận diện mã OTP ngân hàng, quản lý clipboard và bảo mật tài khoản.

4. **Trợ Năng Tự Động Hóa & Tìm Kiếm Thông Minh (Circle to Search)**
   - Đọc cấu trúc màn hình, khoanh vùng dịch thuật đa ngôn ngữ (Google Screen Translator & Groq Vision AI).
   - Nhận diện ký tự OCR ngoại tuyến (Google ML Kit Latin & Chinese).

5. **Hệ Thống Widget & Bảng Điều Khiển Live**
   - Widget Pin thông minh (đo công suất Watt, nhiệt độ, chu kỳ sạc thời gian thực).
   - Widget RAM/ROM và Thanh tìm kiếm nhanh trên màn hình chính Honor.
   - Điều khiển và in hóa đơn máy in nhiệt K80/K57 qua Wi-Fi / Bluetooth LAN.

---

## 🛠 Công Nghệ & Kiến Trúc

- **Ngôn ngữ:** Kotlin 2.2.10
- **Giao diện:** Jetpack Compose (Material 3 Dark Glassmorphism)
- **Kiến trúc:** MVVM (Model-View-ViewModel) + Clean Architecture
- **Mạng & API:** Firebase Firestore (Dữ liệu đám mây), Firebase Auth, Credential Manager, ML Kit
- **Hệ thống Shell:** Shizuku API + Direct WLAN ADB Socket + Local Su / Toybox Fallback
- **Build System:** Gradle Kotlin DSL (`build.gradle.kts`), AGP 9.1.1, Java 21, minSdk 26, targetSdk 36
