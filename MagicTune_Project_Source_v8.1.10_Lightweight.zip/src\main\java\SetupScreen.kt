package com.example.ui.components

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DeviceInfo
import com.example.data.NewDeviceSetupStatus
import com.example.data.ShizukuInfo
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicPurple
import com.example.ui.theme.MagicPurpleLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

private val SetupCyanEmeraldGradBrush = Brush.horizontalGradient(listOf(MagicCyan, MagicEmerald))

@Composable
fun SetupScreen(
    status: NewDeviceSetupStatus = NewDeviceSetupStatus(),
    shizukuInfo: ShizukuInfo = ShizukuInfo(),
    deviceInfo: DeviceInfo = DeviceInfo(),
    isAdbReady: Boolean = false,
    isBusy: Boolean = false,
    onRunSetupAll: () -> Unit,
    onRunSetupForceFull: () -> Unit = {},
    onRunSingleSetupItem: (Int) -> Unit = {},
    onOpenPlayStore: (String) -> Unit = {},
    onOpenYouTube: () -> Unit = {},
    onRefreshDeviceInfo: () -> Unit = {},
    onOpenPrinter: () -> Unit = {},
    onRestartShizuku: () -> Unit = {},
    onRequestShizukuPermission: () -> Unit = {},
    onOpenShizukuApp: () -> Unit = {},
    onOpenDirectWlanTab: () -> Unit = {},
    onOpenWlanDialog: () -> Unit = {},
    onFixMagicOSSystemUpdate: () -> Unit = {},
    onRefreshSatellites: () -> Unit = {},
    onToggleDeviceFeature: (String, Boolean) -> Unit = { _, _ -> },
    onNavigateToUniversalFix: () -> Unit = {},
    onOpenAiBatteryDoctor: () -> Unit = {}
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        // Ô #00: THẺ BẢN QUYỀN PRO & THÔNG TIN MÁY
        item(key = "setup_card_00", contentType = "pro_card") {
            ProLicenseCard(cardNumberBadge = "Ô #00")
        }

        // LỐI TẮT NHANH: AI PHÂN TÍCH HAO PIN & SIÊU TIẾT KIỆM ĐIỆN
        item(key = "setup_ai_battery_doctor_shortcut", contentType = "ai_battery_shortcut") {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpenAiBatteryDoctor)
                    .testTag("setup_ai_battery_doctor_shortcut_btn"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1628)),
                border = BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.65f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(11.dp))
                            .background(MagicEmerald.copy(alpha = 0.2f))
                            .border(1.dp, MagicEmerald.copy(alpha = 0.6f), RoundedCornerShape(11.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI phân tích hao pin",
                            tint = MagicEmeraldLight,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column(
                        modifier = Modifier.fillMaxHeight().weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = "🤖 AI Siêu Tiết Kiệm Pin 10X & Autopilot 24/7",
                            color = Color.White,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Chẩn đoán 12 lớp • Ngủ đông tắt màn 45s • Sinh Tồn Pin Trâu • Bảo vệ 100% Trợ năng",
                            color = TextSecondary,
                            fontSize = 10.5.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicEmerald)
                            .padding(horizontal = 10.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = "Mở AI →",
                            color = Color(0xFF04130D),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }

        // Banner Kết Nối Nhanh (Chỉ hiển thị gọn gàng nếu chưa kết nối ADB để không che mất các ô Thiết lập nhanh không cần ADB)
        if (!isAdbReady) {
            item(key = "setup_banner_no_adb", contentType = "banner") {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.65f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        modifier = Modifier.fillMaxHeight().weight(1f),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = "💡 Chế độ Cài Đặt Nhanh Không Cần ADB Đang Sẵn Sàng",
                            color = MagicAmber,
                            fontSize = 11.8.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Bạn có thể dùng ngay tất cả các ô Thiết lập nhanh không cần ADB bên dưới, hoặc bấm Kết nối Mã 6 Số để chạy tự động 1-chạm.",
                            color = TextSecondary,
                            fontSize = 10.5.sp,
                            lineHeight = 14.5.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onOpenWlanDialog,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicCyan,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Wifi, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Nhập 6 Số", fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
            }
        }

        // Ô #01: BẢNG THÔNG SỐ PHẦN CỨNG THỜI GIAN THỰC & TRẠNG THÁI BẬT/TẮT (CHỈ XEM + NÚT ⚙️ MỞ CÀI ĐẶT)
        item(key = "setup_card_01", contentType = "hardware_card") {
            HardwareAndFeaturesCard(
                deviceInfo = deviceInfo,
                onRefresh = onRefreshDeviceInfo,
                onToggleFeature = onToggleDeviceFeature,
                cardNumberBadge = "Ô #01"
            )
        }

        // Ô #02: CÁC Ô THIẾT LẬP NHANH CHO MÁY NỘI ĐỊA MỚI (KHÔNG CẦN ADB - 1 CHẠM MỞ THẲNG) + AUTO 8-IN-1
        item(key = "setup_card_02", contentType = "feature_card") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.5.dp, SetupCyanEmeraldGradBrush)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(text = "Ô #02", color = Color(0xFF020617), fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicEmerald.copy(alpha = 0.2f))
                                .border(1.dp, MagicEmerald, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "Đạt ${status.readyScore}/9",
                                color = MagicEmeraldLight,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    Text(
                        text = "⚡ THIẾT LẬP NHANH MÁY NỘI ĐỊA MỚI (KHÔNG CẦN ADB)",
                        color = MagicCyanLight,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "Mở thẳng các trang ẩn của máy nội địa chỉ bằng 1 chạm hoặc chạy tự động 8-trong-1",
                        color = TextSecondary,
                        fontSize = 10.5.sp,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // BẢNG 10 Ô THIẾT LẬP NHANH KHÔNG CẦN ADB CHO MÁY NỘI ĐỊA MỚI (2 CỘT x 5 HÀNG)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF090F1D))
                        .border(1.dp, MagicCyan.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "🟢 CÁC Ô CÀI ĐẶT NHANH TRỰC TIẾP (HOẠT ĐỘNG 100% KHÔNG CẦN ADB):",
                            color = MagicEmeraldLight,
                            fontSize = 11.2.sp,
                            fontWeight = FontWeight.Black
                        )

                        // Hàng 1: Ngôn ngữ Tiếng Việt + Bật Dịch vụ Google (GMS)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            NoAdbQuickTile(
                                modifier = Modifier.fillMaxHeight().weight(1f),
                                title = "🌐 1. Ngôn Ngữ & Vùng",
                                subtitle = if (status.isVietnameseLocale) "✓ Đã Tiếng Việt (${status.currentLocale})" else "Mở thêm Tiếng Việt",
                                isDone = status.isVietnameseLocale,
                                accentColor = MagicCyan,
                                onClick = { openSafeSettingsIntent(context, Settings.ACTION_LOCALE_SETTINGS) }
                            )
                            NoAdbQuickTile(
                                modifier = Modifier.fillMaxHeight().weight(1f),
                                title = "🇬 2. Bật Dịch Vụ Google",
                                subtitle = if (status.gmsEnabled) "✓ GMS đã bật sẵn sàng" else "Mở công tắc GMS máy nội địa",
                                isDone = status.gmsEnabled,
                                accentColor = MagicEmerald,
                                onClick = { openDomesticGmsSettings(context) }
                            )
                        }

                        // Hàng 2: Cửa hàng CH Play + Chọn Bàn Phím Mặc Định Ngay
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            NoAdbQuickTile(
                                modifier = Modifier.fillMaxHeight().weight(1f),
                                title = "🛍️ 3. Mở / Tải CH Play",
                                subtitle = if (status.playStoreInstalled) "✓ Đã cài CH Play (Bấm mở)" else "Tải & cài đặt CH Play",
                                isDone = status.playStoreInstalled,
                                accentColor = MagicEmerald,
                                onClick = { openOrDownloadPlayStore(context, onOpenPlayStore) }
                            )
                            NoAdbQuickTile(
                                modifier = Modifier.fillMaxHeight().weight(1f),
                                title = "⌨️ 4. Đổi Bàn Phím Ngay",
                                subtitle = when {
                                    status.vietnameseKeyboardDefault -> "✓ Đang dùng Laban Key / Gboard"
                                    status.labanKeyEnabled || status.gboardEnabled -> "Chạm để chọn làm mặc định"
                                    status.labanKeyInstalled || status.gboardInstalled -> "Bật bàn phím ở mục 5 trước"
                                    else -> "Cài Laban Key / Gboard trước"
                                },
                                isDone = status.vietnameseKeyboardDefault,
                                accentColor = MagicCyan,
                                onClick = { showSystemInputMethodPicker(context) }
                            )
                        }

                        // Hàng 3: Bật Bàn Phím Trong Cài Đặt + Ngày Giờ & Múi Giờ VN
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            NoAdbQuickTile(
                                modifier = Modifier.fillMaxHeight().weight(1f),
                                title = "⚙️ 5. Quản Lý Bàn Phím",
                                subtitle = when {
                                    status.labanKeyEnabled || status.gboardEnabled -> "✓ Bàn phím Laban / Gboard đã bật"
                                    status.labanKeyInstalled || status.gboardInstalled -> "Đã cài; chạm để bật bàn phím"
                                    else -> "Cài Laban Key / Gboard trước"
                                },
                                isDone = status.labanKeyEnabled || status.gboardEnabled,
                                accentColor = MagicPurpleLight,
                                onClick = { openSafeSettingsIntent(context, Settings.ACTION_INPUT_METHOD_SETTINGS) }
                            )
                            NoAdbQuickTile(
                                modifier = Modifier.fillMaxHeight().weight(1f),
                                title = "🕒 6. Múi Giờ & Giờ 24h",
                                subtitle = if (status.isVietnamTimezone && status.is24HourFormat) "✓ GMT+7 & 24h chuẩn" else "Mở chỉnh giờ GMT+7 & 24h",
                                isDone = status.isVietnamTimezone && status.is24HourFormat,
                                accentColor = MagicAmber,
                                onClick = { openSafeSettingsIntent(context, Settings.ACTION_DATE_SETTINGS) }
                            )
                        }

                        // Hàng 4: Quản lý Khởi chạy ứng dụng (Pin ngầm Honor) + Quản lý Thông báo
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            NoAdbQuickTile(
                                modifier = Modifier.fillMaxHeight().weight(1f),
                                title = "🔋 7. Khởi Chạy Ngầm Pin",
                                subtitle = "Bật Thủ công cho Zalo / FB / Mess",
                                isDone = status.powerGeniusRemoved,
                                accentColor = MagicEmerald,
                                onClick = { openHonorAutoLaunchSettings(context) }
                            )
                            NoAdbQuickTile(
                                modifier = Modifier.fillMaxHeight().weight(1f),
                                title = "🔔 8. Quản Lý Thông Báo",
                                subtitle = "Bật Biểu ngữ nổi & Chuông app",
                                isDone = status.customAppSoundsEnabled,
                                accentColor = MagicCyan,
                                onClick = { openSafeSettingsIntent(context, "android.settings.ALL_APPS_NOTIFICATION_SETTINGS", Settings.ACTION_APPLICATION_SETTINGS) }
                            )
                        }

                        // Hàng 5: Thanh điều hướng YOYO + Ứng dụng Mặc định / Trợ lý ảo
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            NoAdbQuickTile(
                                modifier = Modifier.fillMaxHeight().weight(1f),
                                title = "🧭 9. Điều Hướng & YOYO",
                                subtitle = "Cài đặt cử chỉ & Đánh thức YOYO",
                                isDone = status.yoyoNavWakeDisabled,
                                accentColor = MagicAmber,
                                onClick = { com.example.core.service.SystemFloatingHudOverlay.openSystemNavigationSettings(context) }
                            )
                            NoAdbQuickTile(
                                modifier = Modifier.fillMaxHeight().weight(1f),
                                title = "🌟 10. App Mặc Định & AI",
                                subtitle = "Mở để chọn ứng dụng mặc định và trợ lý",
                                isDone = null,
                                accentColor = MagicPurpleLight,
                                onClick = { openSafeSettingsIntent(context, Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS, Settings.ACTION_VOICE_INPUT_SETTINGS) }
                            )
                        }
                    }
                }

                // 2 Nút Chạy Tự Động 8-in-1 (Khi có ADB)
                Row(
                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onRunSetupAll,
                        enabled = !isBusy,
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .defaultMinSize(minHeight = 36.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "⚡ Tự Động 8-in-1",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Button(
                        onClick = onRunSetupForceFull,
                        enabled = !isBusy,
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .defaultMinSize(minHeight = 36.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald, contentColor = Color(0xFF020617))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "🔄 Chạy Lại Full",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
        }

        // Ô #03: TRẠM KHÔI PHÚC VÀ KHẮC PHỤC SỰ CỐ TỐC ĐỘ CAO
        item(key = "setup_card_03", contentType = "feature_card") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicPurple)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(text = "Ô #03", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald.copy(alpha = 0.2f))
                                .border(1.dp, MagicEmerald, RoundedCornerShape(6.dp))
                                .padding(horizontal = 7.dp, vertical = 2.5.dp)
                        ) {
                            Text(
                                text = "MIỄN PHÍ VĨNH VIỄN",
                                color = MagicEmeraldLight,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                    Text(
                        text = "🛠️ TRẠM SỬA LỖI & CẬP NHẬT HỆ THỐNG",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onFixMagicOSSystemUpdate,
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .defaultMinSize(minHeight = 36.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B), contentColor = MagicCyanLight),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.SystemUpdate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Mở Cập Nhật MagicOS\n(OUC/HOTA • Free 100%)",
                                fontSize = 10.8.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center,
                                lineHeight = 14.sp
                            )
                        }
                    }

                    Button(
                        onClick = { onOpenPlayStore("com.google.android.gms") },
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .defaultMinSize(minHeight = 36.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B), contentColor = MagicEmeraldLight),
                        border = BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.5f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)
                        ) {
                            Icon(imageVector = Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Cập Nhật Google\nPlay Services",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onOpenPrinter,
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .defaultMinSize(minHeight = 32.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "🖨️ Trạm In Nhiệt K80 (LAN/Wi-Fi)",
                            color = MagicCyanLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                    OutlinedButton(
                        onClick = onNavigateToUniversalFix,
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .defaultMinSize(minHeight = 32.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MagicPurple.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "🌐 Trung Tâm Đa Hãng OEM",
                            color = MagicPurpleLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
        }

        // Ô #04: CÀI BÀN PHÍM VIỆT LABAN KEY & GBOARD CHÍNH GỐC (CÓ NÚT CHỌN PHÍM KHÔNG CẦN ADB)
        item(key = "setup_card_04", contentType = "feature_card") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(text = "Ô #04", color = Color(0xFF020617), fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                        SetupStatusChip(isDone = status.vietnameseKeyboardDefault)
                    }
                    Text(
                        text = "⌨️ BÀN PHÍM TIẾNG VIỆT LABAN KEY & GBOARD",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Text(
                    text = "Tải Laban Key hoặc Gboard, sau đó bấm 'Bật Bàn Phím' và 'Chọn Phím Mặc Định' ngay lập tức mà không cần ADB.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { openInstalledAppOrStore(context, "com.vng.inputmethod.labankey", onOpenPlayStore) },
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .defaultMinSize(minHeight = 36.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B), contentColor = MagicCyanLight),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = if (status.labanKeyInstalled) "✓ Đã Cài Laban Key\n(Bấm Mở)" else "📥 Tải Laban Key\nChính Gốc",
                            fontSize = 10.8.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            lineHeight = 14.sp
                        )
                    }

                    Button(
                        onClick = { openInstalledAppOrStore(context, "com.google.android.inputmethod.latin", onOpenPlayStore) },
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .defaultMinSize(minHeight = 36.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B), contentColor = MagicEmeraldLight),
                        border = BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = if (status.gboardInstalled) "✓ Đã Cài Gboard\n(Bấm Mở)" else "📥 Tải Google Gboard\nChính Gốc",
                            fontSize = 10.8.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            lineHeight = 14.sp
                        )
                    }
                }

                Button(
                    onClick = { onRunSingleSetupItem(3) },
                        enabled = !isBusy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 34.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                ) {
                    Text(
                        text = "⚡ Tự Động Kích Hoạt & Đặt Laban Key / Gboard Mặc Định (ADB)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
        }

        // Ô #05: VIỆT HÓA NGÔN NGỮ, MÚI GIỜ VIỆT NAM (GMT+7) & ĐỊNH DẠNG 24H
        item(key = "setup_card_05", contentType = "feature_card") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(text = "Ô #05", color = Color(0xFF020617), fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                        SetupStatusChip(isDone = status.isVietnameseLocale && status.isVietnamTimezone && status.is24HourFormat)
                    }
                    Text(
                        text = "🌐 VIỆT HÓA, MÚI GIỜ VN & ĐỊNH DẠNG 24H",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Text(
                    text = "Hiện tại: Ngôn ngữ ${status.currentLocale} • Múi giờ ${status.currentTimezone} • ${if (status.is24HourFormat) "Định dạng 24h" else "Định dạng 12h"}.",
                    color = MagicCyanLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                Button(
                    onClick = { onRunSingleSetupItem(1) },
                    enabled = !isBusy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 36.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald, contentColor = Color(0xFF020617))
                ) {
                    Icon(imageVector = Icons.Default.Language, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "⚡ Tự Động Việt Hóa 100%, Đặt Múi Giờ VN & 24h (ADB)",
                        fontSize = 11.2.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
        }

        // Ô #06: ĐỒNG BỘ NỀN TẢNG GOOGLE PLAY SERVICES & DANH BẠ GOOGLE
        item(key = "setup_card_06", contentType = "feature_card") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(text = "Ô #06", color = Color(0xFF020617), fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                        SetupStatusChip(isDone = status.gmsEnabled && status.playStoreInstalled)
                    }
                    Text(
                        text = "🔄 BẬT GOOGLE SERVICES (GMS) & ĐỒNG BỘ DANH BẠ",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Text(
                    text = "Bật Dịch vụ Google cơ bản có sẵn trên máy nội địa, mở khóa đồng bộ Danh bạ Google và tải CH Play.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )

                OutlinedButton(
                    onClick = { openSafeSettingsIntent(context, Settings.ACTION_SYNC_SETTINGS, Settings.ACTION_ADD_ACCOUNT) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 32.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "👥 Mở Tài Khoản Google & Đồng Bộ Danh Bạ (Không Cần ADB)",
                        color = MagicEmeraldLight,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }

                Button(
                    onClick = { onRunSingleSetupItem(2) },
                    enabled = !isBusy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 36.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
                ) {
                    Icon(imageVector = Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "⚡ Kích Hoạt Full Google Services & Danh Bạ (ADB)",
                        fontSize = 11.2.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
        }

        // Ô #07: CHẶN CHỢ ỨNG DỤNG HONOR APPMARKET TỰ CẬP NHẬT & DỌN UI TRUNG
        item(key = "setup_card_07", contentType = "feature_card") {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicRose)
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(text = "Ô #07", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                        SetupStatusChip(isDone = status.honorMarketUpdateBlocked)
                    }
                    Text(
                        text = "🚫 CHẶN CHỢ HONOR TỰ UPDATE & DỌN UI TRUNG",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Text(
                    text = "Ngăn chợ ứng dụng Honor AppMarket tự động cập nhật đè các ứng dụng tiếng Việt sang bản nội địa tiếng Trung.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            openAppDetailsFallback(context, "com.hihonor.appmarket", "com.huawei.appmarket")
                        },
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .defaultMinSize(minHeight = 34.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MagicRose.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "Mở Cài Đặt Chợ Honor\n(Tắt Quyền Thủ Công)",
                            color = Color(0xFFFCA5A5),
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            lineHeight = 13.5.sp
                        )
                    }
                    OutlinedButton(
                        onClick = { onRunSingleSetupItem(5) },
                        enabled = !isBusy,
                        modifier = Modifier
                            .fillMaxHeight().weight(1f)
                            .defaultMinSize(minHeight = 34.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MagicPurple.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "🧹 Dọn Rác Giao Diện\nTiếng Trung (ADB)",
                            color = MagicPurpleLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            lineHeight = 13.5.sp
                        )
                    }
                }

                Button(
                    onClick = { onRunSingleSetupItem(7) },
                    enabled = !isBusy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 36.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose, contentColor = Color.White)
                ) {
                    Icon(imageVector = Icons.Default.Block, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "⚡ Chặn Vĩnh Viễn Chợ Honor AppMarket Tự Cập Nhật (ADB)",
                        fontSize = 11.2.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
        }

        // Ô #08: HỢP NHẤT ĐẶC TRỊ ĐỊNH VỊ GPS, LA BÀN SỐ TRỰC QUAN, GOOGLE MAPS & TIMESTAMP CAMERA
        item(key = "setup_card_08", contentType = "feature_card") {
            HonorGpsFixCard(
                isGpsOptimized = status.gpsOptimized,
                isBusy = isBusy,
                onFixGps = { onRunSingleSetupItem(6) },
                onRefreshSatellites = onRefreshSatellites,
                onFixCallerIdAnd5G = { onRunSingleSetupItem(4) },
                onOpenPlayStore = { pkg -> openInstalledAppOrStore(context, pkg, onOpenPlayStore) },
                cardNumberBadge = "Ô #08"
            )
        }

        item(key = "setup_footer", contentType = "footer") {
            HonorOptimizationDisclaimerFooter(onNavigateToUniversalFix = onNavigateToUniversalFix)
        }
    }
}

@Composable
private fun NoAdbQuickTile(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    isDone: Boolean?,
    accentColor: Color,
    onClick: () -> Unit
) {
    val statusBorderColor = when (isDone) {
        true -> MagicEmerald.copy(alpha = 0.55f)
        false -> accentColor.copy(alpha = 0.4f)
        null -> MagicBorder
    }
    val statusDotColor = when (isDone) {
        true -> MagicEmerald
        false -> accentColor
        null -> TextMuted
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(MagicSurfaceCard)
            .border(
                width = 1.dp,
                color = statusBorderColor,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 6.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxHeight().weight(1f)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(statusDotColor)
            )
        }
    }
}

private fun openInstalledAppOrStore(
    context: Context,
    packageName: String,
    onOpenPlayStore: (String) -> Unit
) {
    try {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            return
        }
    } catch (_: Exception) { }
    onOpenPlayStore(packageName)
}

@Composable
private fun SetupStatusChip(isDone: Boolean) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isDone) MagicEmerald.copy(alpha = 0.18f) else MagicAmber.copy(alpha = 0.18f))
            .border(1.dp, if (isDone) MagicEmerald.copy(alpha = 0.5f) else MagicAmber.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 2.5.dp)
    ) {
        Text(
            text = if (isDone) "✓ ĐÃ CHUẨN" else "CẦN CHỈNH",
            color = if (isDone) MagicEmeraldLight else MagicAmber,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Black
        )
    }
}

private fun openSafeSettingsIntent(context: Context, vararg actions: String) {
    for (action in actions) {
        try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return
        } catch (_: Exception) {}
    }
    try {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {}
}

private fun openDomesticGmsSettings(context: Context) {
    val candidates = listOf(
        Intent().setComponent(ComponentName("com.google.android.gms", "com.google.android.gms.app.settings.GoogleSettingsIALink")),
        Intent().setComponent(ComponentName("com.google.android.gms", "com.google.android.gms.app.settings.GoogleSettingsLink")),
        Intent("com.android.settings.gms.GMS_SETTINGS"),
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:com.google.android.gms")
        },
        Intent(Settings.ACTION_SYNC_SETTINGS),
        Intent(Settings.ACTION_SETTINGS)
    )
    for (intent in candidates) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return
        } catch (_: Exception) {}
    }
}

private fun openOrDownloadPlayStore(context: Context, onOpenPlayStore: (String) -> Unit) {
    try {
        val launchIntent = context.packageManager.getLaunchIntentForPackage("com.android.vending")
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            return
        }
    } catch (_: Exception) {}
    onOpenPlayStore("com.android.vending")
}

private fun showSystemInputMethodPicker(context: Context) {
    try {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        if (imm != null) {
            imm.showInputMethodPicker()
            return
        }
    } catch (_: Exception) {}
    openSafeSettingsIntent(context, Settings.ACTION_INPUT_METHOD_SETTINGS)
}

private fun openHonorAutoLaunchSettings(context: Context) {
    val candidates = listOf(
        Intent().setComponent(ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
        Intent().setComponent(ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.optimize.process.ProtectActivity")),
        Intent().setComponent(ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
        Intent().setComponent(ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.power.ui.HwPowerManagerActivity")),
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
        Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
        Intent(Settings.ACTION_SETTINGS)
    )
    for (intent in candidates) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return
        } catch (_: Exception) {}
    }
    Toast.makeText(context, "Vui lòng mở Cài đặt -> Pin -> Khởi chạy ứng dụng", Toast.LENGTH_LONG).show()
}

private fun openAppDetailsFallback(context: Context, vararg packages: String) {
    for (pkg in packages) {
        try {
            val info = context.packageManager.getPackageInfo(pkg, 0)
            if (info != null) {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$pkg")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            }
        } catch (_: Exception) {}
    }
    openSafeSettingsIntent(context, Settings.ACTION_APPLICATION_SETTINGS)
}
