package com.example.core.shell

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.example.core.adb.AdbDiagnosticReport
import com.example.core.adb.AdbNsdScanner
import com.example.core.adb.AdbTelemetrySnapshot
import com.example.core.service.MagicTuneKeepAliveService
import com.example.core.service.MagicTuneTileService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import com.example.core.adb.DirectAdbManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

enum class ShellMode {
    SHIZUKU,
    WIRELESS_ADB,
    ROOT,
    LOCAL_LIMITED,
    NONE
}

data class ShellResult(
    val command: String = "",
    val exitCode: Int,
    val output: String,
    val error: String,
    val modeUsed: ShellMode
) {
    val combinedOutput: String
        get() = listOf(output, error).filter { it.isNotBlank() }.joinToString("\n")

    val hasFatalErrorText: Boolean
        get() {
            val text = combinedOutput
            if (text.isBlank()) return false
            val fatalPatterns = listOf(
                "SecurityException",
                "Permission denial",
                "Permission denied",
                "java.lang.",
                "Failure [",
                "Error:",
                "Exception occurred",
                "neither user",
                "nor current process has",
                "Can't find service",
                "inaccessible or not found",
                "not allowed to",
                "Operation not permitted",
                "Unknown command",
                "bad argument",
                "Killed",
                "Aborted",
                // "not found" removed from fatalPatterns to avoid false positives
            )
            return fatalPatterns.any { text.contains(it, ignoreCase = true) }
        }

    /**
     * Strictly checks if the ADB/Shell command actually succeeded.
     * Never reports false success when exitCode != 0 or when output/stderr contains
     * SecurityException, Permission denial, Failure, Error:, etc.
     */
    val isSuccess: Boolean
        get() {
            if (exitCode != 0) return false
            if (hasFatalErrorText) return false
            return true
        }

    val errorReason: String
        get() {
            if (isSuccess) return ""
            val raw = error.ifBlank { output }.trim()
            val rawLower = raw.lowercase()
            val exitStr = if (exitCode != 0) " [Exit Code: $exitCode]" else ""
            
            // 1. Phân loại lỗi quyền chi tiết
            if (raw.contains("WRITE_SECURE_SETTINGS", ignoreCase = true) ||
                raw.contains("Permission denial", ignoreCase = true) ||
                raw.contains("SecurityException", ignoreCase = true) ||
                raw.contains("neither user", ignoreCase = true) ||
                raw.contains("not allowed to", ignoreCase = true)
            ) {
                val lineDetail = raw.lines().firstOrNull {
                    it.contains("SecurityException", true) ||
                        it.contains("Permission", true) ||
                        it.contains("neither user", true) ||
                        it.contains("not allowed", true)
                } ?: raw.lines().firstOrNull().orEmpty()
                return "Từ chối quyền hệ thống Android$exitStr: $lineDetail"
            }
            
            // 2. Phân loại lỗi gói ứng dụng hoặc lệnh không tồn tại
            if (rawLower.contains("unknown package") || rawLower.contains("not found") || rawLower.contains("failure [not installed")) {
                val line = raw.lines().firstOrNull { it.isNotBlank() }.orEmpty()
                return "Không tìm thấy gói/lệnh trên thiết bị$exitStr: $line"
            }
            
            // 3. Phân loại lỗi tiến trình bị giết / Binder chết
            if (exitCode == 137 || rawLower.contains("killed") || rawLower.contains("binder") || rawLower.contains("dead")) {
                return "Tiến trình Shell bị ngắt đột ngột (Binder Dead / HĐH đóng kết nối)$exitStr: ${raw.ifBlank { "Signal 9 / Out of Memory / Mất gỡ lỗi Wi-Fi" }}"
            }
            
            // 4. Lỗi khác kèm trích xuất 3 dòng chi tiết thực tế
            if (raw.isNotBlank()) {
                val details = raw.lines().filter { it.isNotBlank() }.take(3).joinToString(" ➔ ")
                return "Chi tiết lỗi từ hệ thống$exitStr: $details"
            }
            return "Lệnh không trả về kết quả hoặc bị hệ điều hành từ chối$exitStr"
        }

    val displayOutput: String
        get() {
            if (!isSuccess) {
                return "❌ THẤT BẠI: $errorReason"
            }
            if (output.isNotBlank()) return output
            return "✅ Thành công (Exit 0)"
        }
}

@androidx.compose.runtime.Immutable
data class ShellEngineState(
    val mode: ShellMode = ShellMode.NONE,
    val isShizukuInstalled: Boolean = false,
    val isShizukuRunning: Boolean = false,
    val isShizukuPermissionGranted: Boolean = false,
    val isAdbWifiEnabled: Boolean = true,
    val isShizukuSeveredFromAdb: Boolean = false,
    val isWirelessAdbConnected: Boolean = false,
    val wirelessAdbPort: Int = 5555,
    val isRootAvailable: Boolean = false,
    val hasPersistentGrant: Boolean = false,
    val isKeepAliveActive: Boolean = true,
    val activeUid: String = "Unknown",
    val statusMessage: String = "Chưa kết nối"
) {
    val isAdbReady: Boolean
        get() =
            (isShizukuRunning && isShizukuPermissionGranted) ||
                isWirelessAdbConnected ||
                (mode == ShellMode.ROOT && isRootAvailable) ||
                com.example.core.adb.DirectAdbManager.isInstanceConnectedFast()
}

class ShellEngine(private val context: Context) {

    private val prefs = context.getSharedPreferences("magictune_shell_prefs", Context.MODE_PRIVATE)
    private val kvPrefs = context.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)

    // Mỗi lần app bị đóng khỏi đa nhiệm và khởi động lại, luôn bắt đầu ở trạng thái CHƯA KẾT NỐI,
    // tuyệt đối không khôi phục trạng thái kết nối ảo cũ từ SharedPreferences!
    private val _state = MutableStateFlow(
        ShellEngineState(
            isWirelessAdbConnected = false,
            wirelessAdbPort = prefs.getInt(KEY_WLAN_PORT, 5555),
            hasPersistentGrant = false,
            mode = ShellMode.NONE,
            statusMessage = "Chưa kết nối (Cần kết nối Gỡ lỗi Wi-Fi)"
        )
    )
    val state: StateFlow<ShellEngineState> = _state

    private var permissionListener: Shizuku.OnRequestPermissionResultListener? = null
    private var binderReceivedListener: Shizuku.OnBinderReceivedListener? = null
    private var binderDeadListener: Shizuku.OnBinderDeadListener? = null

    val directAdbManager: DirectAdbManager by lazy { DirectAdbManager.getInstance(context) }
    val adbTelemetry: StateFlow<AdbTelemetrySnapshot> get() = directAdbManager.telemetry
    private val engineScope = CoroutineScope(
        Dispatchers.IO + SupervisorJob() + com.example.MagicTuneApplication.globalCoroutineExceptionHandler
    )
    private val processExecutionSemaphore = kotlinx.coroutines.sync.Semaphore(3)
    private var monitorJob: Job? = null
    private var eventReconnectJob: Job? = null
    private var adbWifiObserver: ContentObserver? = null
    private var wifiNetworkCallback: ConnectivityManager.NetworkCallback? = null
    private var consecutiveWlanFailures = 0
    @Volatile
    private var isUserDisconnected: Boolean = false
    @Volatile
    private var isUserWlanDisconnected: Boolean = false
    @Volatile
    private var lastAutoGrantCompletedMs: Long = 0L

    fun isUserWlanDisconnected(): Boolean = isUserWlanDisconnected

    fun wasSelfPermsAutoGrantedRecently(): Boolean {
        val last = lastAutoGrantCompletedMs
        return last != 0L && (android.os.SystemClock.elapsedRealtime() - last) < 30_000L
    }

    // Theo dõi các tiến trình đang chạy để cho phép lệnh mới nhất ưu tiên thực thi ngay lập tức (Preempt Old Commands)
    private val shizukuExecMutex = Mutex()
    private val selfPermMutex = Mutex()
    private val preflightMutex = Mutex()
    private val activeShizukuExecCount = AtomicInteger(0)
    private val interactivePriorityWaiters = AtomicInteger(0)
    private val runningProcesses = java.util.concurrent.ConcurrentHashMap.newKeySet<Process>()

    private data class CachedShellRead(val result: ShellResult, val timestampMs: Long)
    private val bgReadCache = java.util.concurrent.ConcurrentHashMap<String, CachedShellRead>()

    private fun isSafeCacheableReadCommand(cmd: String): Boolean {
        val c = cmd.trim()
        if (c.contains(";") || c.contains("&&") || c.contains("||") || c.contains(">")) return false
        return c.startsWith("dumpsys ") || c.startsWith("getprop ") || c.startsWith("settings get ")
    }

    data class DeviceShellCapabilities(
        val sdkInt: Int = Build.VERSION.SDK_INT,
        val hasTareService: Boolean = false,
        val hasAppHibernationService: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S,
        val hasRoleService: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q,
        val hasDeviceIdleService: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M,
        val hasPmSuspend: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P,
        val activeUserIds: Set<Int> = setOf(0),
        val probed: Boolean = false
    )

    @Volatile
    private var sessionCapabilities: DeviceShellCapabilities? = null
    private val supportedAppOpsCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private val installedPkgCache = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val installedPkgMissCache = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private val romPresentPkgCache = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    
    /**
     * Cưỡng bức làm mới kết nối Binder tới Shizuku Server.
     * Giải quyết lỗi shizuku.newProcess bị treo hoặc trả về lỗi giao tiếp Binder.
     */
    fun forceResetBinder() {
        engineScope.launch {
            preemptRunningProcesses()
            try {
                binderDeadListener?.onBinderDead()
                delay(200)
                checkShizukuStatus()
            } catch (_: Exception) {}
        }
    }

    /**
     * Ngắt ngay lập tức các tiến trình lệnh cũ đang chạy dở để ưu tiên tài nguyên 100% cho lệnh mới nhất!
     */
    fun preemptRunningProcesses(): Int {
        var count = 0
        try {
            if (directAdbManager.abortCurrentCommand()) {
                count++
            }
        } catch (_: Throwable) {}
        val snapshot = runningProcesses.toList()
        for (proc in snapshot) {
            try {
                runningProcesses.remove(proc)
                try { proc.inputStream?.close() } catch (_: Throwable) {}
                try { proc.errorStream?.close() } catch (_: Throwable) {}
                try { proc.outputStream?.close() } catch (_: Throwable) {}
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    proc.destroyForcibly()
                } else {
                    proc.destroy()
                }
                count++
            } catch (_: Throwable) {}
        }
        return count
    }

    @Volatile
    private var cachedNewProcessMethod: Method? = null

    private fun getShizukuNewProcessMethod(): Method {
        cachedNewProcessMethod?.let { return it }
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        cachedNewProcessMethod = m
        return m
    }

    init {
        instance = this
        setupShizukuListeners()
        registerEventDrivenWlanObservers()
        engineScope.launch {
            refreshStatus()
        }
        startKeepAliveServiceIfNeeded()
    }

    /**
     * Cơ chế tự động nối lại Event-Driven (0% CPU/Pin khi nghỉ):
     * - Lắng nghe thay đổi trực tiếp công tắc `adb_wifi_enabled` (Settings.Global).
     * - Lắng nghe Wi-Fi NetworkCallback (TRANSPORT_WIFI) khi người dùng bật lại Wi-Fi hoặc đổi mạng.
     */
    private fun registerEventDrivenWlanObservers() {
        try {
            val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
                override fun onChange(selfChange: Boolean) {
                    val (adbWifiOn, devOn) = checkAdbWifiSystemSetting()
                    if (!devOn || !adbWifiOn) {
                        forceDisconnectWirelessAdbImmediately("Đã tắt Tùy chọn nhà phát triển hoặc Gỡ lỗi qua Wi-Fi trong Cài đặt")
                    } else if (adbWifiOn && devOn && hasPairedBefore() &&
                        com.example.core.perf.MagicTuneSelfPowerGovernor.isMainActivityCurrentlyForeground() &&
                        !isUserWlanDisconnected && !isUserDisconnected
                    ) {
                        scheduleEventDrivenReconnect(debounceMs = 450L)
                    }
                }
            }
            adbWifiObserver = observer
            val uriAdbWifi = Settings.Global.getUriFor("adb_wifi_enabled")
            if (uriAdbWifi != null) {
                context.contentResolver.registerContentObserver(uriAdbWifi, false, observer)
            }
            val uriDev = Settings.Global.getUriFor(Settings.Global.DEVELOPMENT_SETTINGS_ENABLED)
            if (uriDev != null) {
                context.contentResolver.registerContentObserver(uriDev, false, observer)
            }
        } catch (_: Throwable) {}

        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            if (cm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val callback = object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        if (hasPairedBefore() &&
                            com.example.core.perf.MagicTuneSelfPowerGovernor.isMainActivityCurrentlyForeground() &&
                            !isUserWlanDisconnected && !isUserDisconnected && !_state.value.isWirelessAdbConnected
                        ) {
                            scheduleEventDrivenReconnect(debounceMs = 900L)
                        }
                    }

                    override fun onLost(network: Network) {
                        if (_state.value.isWirelessAdbConnected) {
                            engineScope.launch { refreshStatus() }
                        }
                    }
                }
                wifiNetworkCallback = callback
                val req = NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .build()
                cm.registerNetworkCallback(req, callback)
            }
        } catch (_: Throwable) {}
    }

    private fun scheduleEventDrivenReconnect(debounceMs: Long) {
        eventReconnectJob?.cancel()
        eventReconnectJob = engineScope.launch {
            delay(debounceMs)
            if (!com.example.core.perf.MagicTuneSelfPowerGovernor.isMainActivityCurrentlyForeground()) return@launch
            if (isUserDisconnected || isUserWlanDisconnected || _state.value.isWirelessAdbConnected) return@launch
            if (!hasPairedBefore()) return@launch
            val (adbWifiOn, _) = checkAdbWifiSystemSetting()
            if (!adbWifiOn) return@launch
            autoConnectBestWirelessAdb()
        }
    }

    fun hasWriteSecureSettingsPermission(): Boolean {
        return try {
            context.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) ==
                PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) {
            false
        }
    }

    fun hasOverlayPermission(): Boolean {
        val appCtx = context.applicationContext
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(appCtx) || kvPrefs.getBoolean("appop_${appCtx.packageName}_SYSTEM_ALERT_WINDOW", false)
            } else true
        } catch (_: Exception) {
            kvPrefs.getBoolean("appop_${appCtx.packageName}_SYSTEM_ALERT_WINDOW", false)
        }
    }

    fun hasControlPermission(): Boolean {
        return hasWriteSecureSettingsPermission() ||
            _state.value.hasPersistentGrant ||
            _state.value.isWirelessAdbConnected ||
            _state.value.isShizukuPermissionGranted ||
            _state.value.isRootAvailable
    }

    private fun saveWlanState(connected: Boolean, port: Int, persistentGrant: Boolean = _state.value.hasPersistentGrant) {
        prefs.edit()
            .putBoolean(KEY_WLAN_CONNECTED, connected)
            .putInt(KEY_WLAN_PORT, port)
            .putBoolean(KEY_PERSISTENT_GRANT, persistentGrant)
            .apply()
        if (connected) {
            com.example.core.permission.AppPermissionChecker.markWlanActivated(context)
        }
    }

    fun markPersistentGrantActive() {
        prefs.edit().putBoolean(KEY_PERSISTENT_GRANT, true).apply()
        _state.update { it.copy(hasPersistentGrant = true) }
    }

    fun isPackageMarkedDisabled(pkg: String): Boolean {
        val disabledSet = kvPrefs.getStringSet(KEY_DISABLED_PACKAGES, emptySet()) ?: emptySet()
        return disabledSet.contains(pkg)
    }

    fun isPackageMarkedUninstalled(pkg: String): Boolean {
        val uninstalledSet = kvPrefs.getStringSet(KEY_UNINSTALLED_PACKAGES, emptySet()) ?: emptySet()
        return uninstalledSet.contains(pkg)
    }

    fun getPersistedSetting(namespace: String, key: String): String? {
        return kvPrefs.getString("setting_${namespace}_$key", null)
    }

    fun setPersistedSetting(namespace: String, key: String, value: String?) {
        val editor = kvPrefs.edit()
        if (value == null) {
            editor.remove("setting_${namespace}_$key")
        } else {
            editor.putString("setting_${namespace}_$key", value)
        }
        editor.apply()
    }

    fun isAppVisuallyUiToggled(pkg: String): Boolean {
        return kvPrefs.getBoolean("ui_toggled_gentle_banner_$pkg", false)
    }

    fun markAppVisuallyUiToggled(pkg: String, toggled: Boolean = true) {
        kvPrefs.edit()
            .putBoolean("ui_toggled_gentle_banner_$pkg", toggled)
            .putBoolean("fixed_notif_$pkg", toggled)
            .apply()
    }

    fun resetNotificationScanCache() {
        val editor = kvPrefs.edit()
        kvPrefs.all.keys.forEach { key ->
            if (key.startsWith("fixed_notif_") || key.startsWith("ui_toggled_gentle_banner_")) {
                editor.remove(key)
            }
        }
        editor.apply()
    }

    fun isAppActuallyNotificationEnabled(pkg: String): Boolean {
        return try {
            // Trên Honor MagicOS, POST_NOTIFICATION=allow chỉ là công tắc tổng "Cho phép thông báo",
            // KHÔNG có nghĩa là đã tắt "Thông báo nhẹ nhàng" hay đã bật "Biểu ngữ" (Banners)!
            // Do đó chỉ xác nhận đã xử lý triệt để khi đã chạy Auto-Click UI gạt công tắc thực tế hoặc xác thực qua kênh dumpsys.
            val uiToggled = kvPrefs.getBoolean("ui_toggled_gentle_banner_$pkg", false)
            if (!uiToggled) return false
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? android.app.AppOpsManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT && appOps != null) {
                val uid = context.packageManager.getPackageUid(pkg, 0)
                val postNotifAllowed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    appOps.checkOpNoThrow("android:post_notification", uid, pkg) == android.app.AppOpsManager.MODE_ALLOWED
                } else true
                postNotifAllowed && uiToggled
            } else {
                uiToggled
            }
        } catch (_: Exception) {
            kvPrefs.getBoolean("ui_toggled_gentle_banner_$pkg", false)
        }
    }

    fun isAppActuallyBackgroundWhitelisted(pkg: String): Boolean {
        return try {
            val fixedInPrefs = kvPrefs.getBoolean("whitelist_$pkg", false) &&
                kvPrefs.getBoolean("appop_${pkg}_RUN_IN_BACKGROUND", false)
            if (fixedInPrefs) return true
            val pm = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
            val isIgnoringBattery = pm?.isIgnoringBatteryOptimizations(pkg) ?: false
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? android.app.AppOpsManager
            val alertWindowAllowed = if (appOps != null) {
                try {
                    val uid = context.packageManager.getPackageUid(pkg, 0)
                    appOps.checkOpNoThrow(
                        android.app.AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW,
                        uid,
                        pkg
                    ) == android.app.AppOpsManager.MODE_ALLOWED
                } catch (_: Exception) { false }
            } else false
            isIgnoringBattery && alertWindowAllowed
        } catch (_: Exception) {
            kvPrefs.getBoolean("whitelist_$pkg", false)
        }
    }

    fun isAppWhitelistedOrFixed(pkg: String): Boolean {
        return kvPrefs.getBoolean("fixed_notif_$pkg", false)
    }

    fun markAppNotificationFixed(pkg: String, fixed: Boolean = true) {
        kvPrefs.edit()
            .putBoolean("fixed_notif_$pkg", fixed)
            .putBoolean("appop_${pkg}_POST_NOTIFICATION", fixed)
            .putBoolean("appop_${pkg}_SYSTEM_ALERT_WINDOW", fixed)
            .putBoolean("appop_${pkg}_RUN_IN_BACKGROUND", fixed)
            .putBoolean("whitelist_$pkg", fixed)
            .apply()
    }

    fun isAppPermissionGranted(pkg: String): Boolean {
        return kvPrefs.getBoolean("appop_${pkg}_RUN_IN_BACKGROUND", false) &&
            kvPrefs.getBoolean("whitelist_$pkg", false)
    }

    @Volatile
    private var lastOfflineNavGuardMs: Long = 0L

    private fun putSecureIfChanged(cr: android.content.ContentResolver, key: String, value: String) {
        try {
            if (Settings.Secure.getString(cr, key) != value) {
                Settings.Secure.putString(cr, key, value)
            }
        } catch (_: Exception) {}
    }

    private fun putGlobalIfChanged(cr: android.content.ContentResolver, key: String, value: String) {
        try {
            if (Settings.Global.getString(cr, key) != value) {
                Settings.Global.putString(cr, key, value)
            }
        } catch (_: Exception) {}
    }

    /**
     * Cơ chế bảo vệ Mod Phím Điều Hướng (Khoanh tròn hỏi AI / Trợ lý Magic / Khóa YOYO)
     * hoạt động độc lập ngay cả khi đã TẮT GỠ LỖI (nhờ quyền WRITE_SECURE_SETTINGS vĩnh viễn).
     * Chỉ ghi vào Settings.Secure khi giá trị thực sự bị thay đổi để triệt tiêu 100% nghẽn IPC / giật đơ máy!
     */
    fun enforceOfflineNavBarModGuard() {
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
            if (pm != null && !pm.isInteractive) return
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastOfflineNavGuardMs < 180_000L && lastOfflineNavGuardMs != 0L) {
                return
            }
            lastOfflineNavGuardMs = now

            val navMode = getPersistedSetting("secure", "magictune_nav_mod_mode") ?: return
            if (navMode !in listOf("CIRCLE_TO_SEARCH", "MAGIC_LIVE", "DISABLED_YOYO")) return
            if (!hasWriteSecureSettingsPermission()) return

            val coexistYoyo = com.example.core.service.SystemFloatingHudOverlay.isYoyoCoexistModeEnabled(context)
            val shouldLockYoyoOff = !coexistYoyo || navMode == "DISABLED_YOYO"

            val cr = context.contentResolver
            // 1. Chỉ khóa cứng công tắc đánh thức YOYO khi KHÔNG bật chế độ Chung Sống 3 Trợ Lý (hoặc khi chọn tắt hẳn YOYO)
            if (shouldLockYoyoOff) {
                val yoyoSecureKeys = listOf(
                    "navigation_bar_wakeup_yoyo",
                    "yoyo_navigation_bar_wakeup",
                    "wake_up_yoyo_by_nav_bar",
                    "yoyo_agent_nav_bar_wakeup",
                    "magic_voice_nav_wakeup",
                    "yoyo_assistant_gesture_switch",
                    "voice_wakeup_switch",
                    "ai_sub_switch",
                    "smart_breath_switch",
                    "hiaye_switch",
                    "hiaction_enabled"
                )
                for (k in yoyoSecureKeys) {
                    putSecureIfChanged(cr, k, "0")
                }
                try {
                    if (Settings.System.getString(cr, "navigation_bar_wakeup_yoyo") != "0") {
                        Settings.System.putString(cr, "navigation_bar_wakeup_yoyo", "0")
                    }
                    if (Settings.System.getString(cr, "yoyo_agent_nav_bar_wakeup") != "0") {
                        Settings.System.putString(cr, "yoyo_agent_nav_bar_wakeup", "0")
                    }
                    if (Settings.System.getString(cr, "yoyo_assistant_gesture_switch") != "0") {
                        Settings.System.putString(cr, "yoyo_assistant_gesture_switch", "0")
                    }
                } catch (_: Exception) {}
            }

            val googleAssistantService = "com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService"
            val googleRecogService = "com.google.android.googlequicksearchbox/com.google.android.voicesearch.serviceapi.GoogleRecognitionService"

            if (shouldLockYoyoOff) {
                val curAssist = Settings.Secure.getString(cr, "assistant")
                if (curAssist.isNullOrBlank() || curAssist.contains("hihonor", ignoreCase = true) || curAssist.contains("huawei", ignoreCase = true) || curAssist.contains("yoyo", ignoreCase = true) || curAssist.contains("VoiceSearchActivity", ignoreCase = true)) {
                    putSecureIfChanged(cr, "assistant", googleAssistantService)
                }
                val curVoice = Settings.Secure.getString(cr, "voice_interaction_service")
                if (curVoice.isNullOrBlank() || curVoice.contains("hihonor", ignoreCase = true) || curVoice.contains("huawei", ignoreCase = true) || curVoice.contains("yoyo", ignoreCase = true)) {
                    putSecureIfChanged(cr, "voice_interaction_service", googleAssistantService)
                }
                val curRecog = Settings.Secure.getString(cr, "voice_recognition_service")
                if (curRecog.isNullOrBlank() || curRecog.contains("hihonor", ignoreCase = true) || curRecog.contains("huawei", ignoreCase = true)) {
                    putSecureIfChanged(cr, "voice_recognition_service", googleRecogService)
                }
            }

            putSecureIfChanged(cr, "assist_structure_enabled", "1")
            putSecureIfChanged(cr, "assist_screenshot_enabled", "1")
            putSecureIfChanged(cr, "assist_disclosure_enabled", "1")

            if (navMode == "CIRCLE_TO_SEARCH") {
                putSecureIfChanged(cr, "assist_long_press_home_enabled", "0")
                putSecureIfChanged(cr, "search_press_hold_nav_handle_enabled", "0")
                putSecureIfChanged(cr, "contextual_search_enabled", "1")
                putSecureIfChanged(cr, "contextual_search_package", "com.google.android.googlequicksearchbox")
                putSecureIfChanged(cr, "visual_query_accessibility_detection_enabled", "1")
                putGlobalIfChanged(cr, "contextual_search_enabled", "1")
                com.example.core.service.MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(context)
            } else if (navMode == "MAGIC_LIVE") {
                putSecureIfChanged(cr, "assist_long_press_home_enabled", "1")
                putSecureIfChanged(cr, "search_press_hold_nav_handle_enabled", "1")
                putSecureIfChanged(cr, "assist_touch_gesture_enabled", "1")
            }
        } catch (_: Exception) {}
    }

    fun startKeepAliveServiceIfNeeded() {
        // ZERO-DRAIN GUARD: Nếu app đang ở nền sau và không có overlay nào thì tuyệt đối không kích hoạt service chạy ngầm
        if (!com.example.core.perf.MagicTuneSelfPowerGovernor.isMainActivityCurrentlyForeground()) {
            val hasActiveOverlay = com.example.core.widget.GoogleLiveTranslateOverlay.isRunning ||
                com.example.core.widget.MagicLiveFloatingOverlay.isShowing ||
                com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive ||
                com.example.core.widget.CircleToSearchWindowOverlay.isShowing
            if (!hasActiveOverlay) return
        }
        val st = _state.value
        val hasActiveSession = (st.mode == ShellMode.SHIZUKU && st.isShizukuPermissionGranted && st.isShizukuRunning) ||
            st.isWirelessAdbConnected ||
            (st.mode == ShellMode.ROOT && st.isRootAvailable)
        if (!hasActiveSession) {
            // Không tự động bật Foreground Service khi chưa có phiên ADB/Shizuku đang hoạt động
            return
        }
        val msg = when {
            st.mode == ShellMode.SHIZUKU && st.isShizukuPermissionGranted ->
                "Shizuku: Đang kết nối (UID 2000) • Giữ chạy nền đa nhiệm"
            st.isWirelessAdbConnected ->
                "WLAN: Đang kết nối (Cổng ${st.wirelessAdbPort}) • Giữ chạy nền đa nhiệm"
            else ->
                "MagicTune: Đang duy trì kết nối gỡ lỗi"
        }
        MagicTuneKeepAliveService.startOrUpdate(context, msg)
    }

    private fun setupShizukuListeners() {
        permissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
            val granted = grantResult == PackageManager.PERMISSION_GRANTED
            if (granted) {
                isUserDisconnected = false
                markPersistentGrantActive()
            }
            val running = isShizukuServerTrulyAlive()
            _state.update { cur -> cur.copy(
                isShizukuRunning = running,
                isShizukuPermissionGranted = granted,
                isShizukuSeveredFromAdb = false,
                hasPersistentGrant = granted || cur.hasPersistentGrant,
                mode = if (granted && running) ShellMode.SHIZUKU else cur.mode,
                statusMessage = when {
                    granted && running -> "Shizuku: Đang kết nối (UID 2000)"
                    running && !granted -> "Shizuku: Chưa cấp quyền (Cần bấm cấp quyền)"
                    else -> "Shizuku: Server đã ngắt kết nối"
                }
            ) }
            engineScope.launch { refreshStatus() }
            engineScope.launch { startKeepAliveServiceIfNeeded() }
        }
        try {
            permissionListener?.let { Shizuku.addRequestPermissionResultListener(it) }
        } catch (_: Exception) {}

        binderReceivedListener = Shizuku.OnBinderReceivedListener {
            isUserDisconnected = false
            engineScope.launch {
                checkShizukuStatus()
                startKeepAliveServiceIfNeeded()
            }
        }
        try {
            // Dùng Sticky Listener để nếu Binder đã kết nối sẵn trước khi Engine khởi tạo, callback sẽ kích hoạt ngay lập tức
            binderReceivedListener?.let { Shizuku.addBinderReceivedListenerSticky(it) }
        } catch (_: Exception) {
            try {
                binderReceivedListener?.let { Shizuku.addBinderReceivedListener(it) }
            } catch (_: Exception) {}
        }

        binderDeadListener = Shizuku.OnBinderDeadListener {
            consecutiveWlanFailures = 0
            engineScope.launch {
                // Đợi ngắn và thử ping lại trước khi kết luận Binder thực sự chết (tránh báo giả khi chạy lệnh nặng)
                delay(150)
                if (pingShizukuBinderResilient()) {
                    checkShizukuStatus()
                    return@launch
                }
                enforceOfflineNavBarModGuard()
                val (adbWifiOn, _) = checkAdbWifiSystemSetting()
                _state.update { cur -> cur.copy(
                    isShizukuRunning = false,
                    isShizukuPermissionGranted = false,
                    isShizukuSeveredFromAdb = false,
                    isAdbWifiEnabled = adbWifiOn,
                    mode = if (cur.isWirelessAdbConnected) ShellMode.WIRELESS_ADB else ShellMode.NONE,
                    statusMessage = "Shizuku đã ngắt kết nối (Server đã đóng)"
                ) }
            }
        }
        try {
            binderDeadListener?.let { Shizuku.addBinderDeadListener(it) }
        } catch (_: Exception) {}
    }

    fun checkAdbWifiSystemSetting(): Pair<Boolean, Boolean> {
        val devOn = try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1
        } catch (_: Exception) { false }
        if (!devOn) {
            return Pair(false, false)
        }
        val adbWifiOn = try {
            val raw = Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", -1)
            if (raw != -1) raw == 1 else false
        } catch (_: Exception) { false }
        return Pair(adbWifiOn, true)
    }

    fun onScreenStateChanged(screenOn: Boolean) {
        if (screenOn) {
            monitorJob?.cancel()
            monitorJob = engineScope.launch {
                val (adbWifiOn, devOn) = checkAdbWifiSystemSetting()
                if (!devOn || !adbWifiOn) {
                    forceDisconnectWirelessAdbImmediately("Đã tắt Tùy chọn nhà phát triển hoặc Gỡ lỗi Wi-Fi")
                }
                enforceOfflineNavBarModGuard()
                if (activeShizukuExecCount.get() == 0) {
                    val wasRunning = _state.value.isShizukuRunning
                    val wasGranted = _state.value.isShizukuPermissionGranted
                    val nowRunning = isShizukuServerTrulyAlive()
                    val nowGranted = if (nowRunning && !isUserDisconnected) checkShizukuPermissionResilient() else false
                    if (wasRunning != nowRunning || wasGranted != nowGranted) {
                        checkShizukuStatus()
                    }
                }
                if (_state.value.isWirelessAdbConnected && !directAdbManager.verifyConnectedIo()) {
                    val port = _state.value.wirelessAdbPort
                    saveWlanState(false, port, true)
                    _state.update { cur ->
                        cur.copy(
                            isWirelessAdbConnected = false,
                            hasPersistentGrant = true,
                            mode = if (cur.isShizukuRunning && cur.isShizukuPermissionGranted) ShellMode.SHIZUKU else ShellMode.LOCAL_LIMITED,
                            statusMessage = "WLAN tạm ngắt • Sẵn sàng nối lại theo nhu cầu"
                        )
                    }
                }
            }
        } else {
            // Never let a pending Wi-Fi callback reconnect ADB after the display turns off.
            eventReconnectJob?.cancel()
            eventReconnectJob = null
            monitorJob?.cancel()
            monitorJob = null
            try {
                val nsd = AdbNsdScanner.getInstance(context)
                nsd.stopDiscovery(updateStatusText = false)
                nsd.releaseMulticastLock()
            } catch (_: Throwable) {}
            try {
                directAdbManager.closePersistentShellOnScreenOff()
            } catch (_: Throwable) {}
        }
    }

    fun cleanup() {
        // Nếu đây là Singleton dùng chung toàn app thì giữ sống monitor cho Service & Patrol
        if (this === instance) return
        monitorJob?.cancel()
        eventReconnectJob?.cancel()
        engineScope.cancel()
        try {
            adbWifiObserver?.let { context.contentResolver.unregisterContentObserver(it) }
        } catch (_: Throwable) {}
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            wifiNetworkCallback?.let { cm?.unregisterNetworkCallback(it) }
        } catch (_: Throwable) {}
        try {
            permissionListener?.let { Shizuku.removeRequestPermissionResultListener(it) }
            binderReceivedListener?.let { Shizuku.removeBinderReceivedListener(it) }
            binderDeadListener?.let { Shizuku.removeBinderDeadListener(it) }
        } catch (_: Exception) {}
    }

    /**
     * Đọc song song stdout và stderr bằng Coroutine IO kết hợp timeout chặt chẽ,
     * đồng thời LUÔN đóng stream và gọi proc.destroy() trong khối finally để giải phóng IRemoteProcess Binder
     * bên trong shizuku_server, triệt tiêu 100% lỗi rò rỉ Binder khiến "Shizuku Binder không phản hồi".
     */
    /** Process.waitFor(timeout, unit) mới có từ API 26 — fallback poll cho Android 7.0 (API 24/25). */
    private suspend fun waitForProcessCompat(proc: Process, timeoutSec: Long): Boolean {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            return withContext(Dispatchers.IO) {
                try {
                    proc.waitFor(timeoutSec, TimeUnit.SECONDS)
                } catch (_: InterruptedException) {
                    false
                }
            }
        }
        val deadline = System.currentTimeMillis() + timeoutSec.coerceIn(0, 3600) * 1000L
        while (System.currentTimeMillis() < deadline) {
            try { proc.exitValue(); return true } catch (_: IllegalThreadStateException) {}
            delay(50L)
        }
        return try { proc.exitValue(); true } catch (_: IllegalThreadStateException) { false }
    }

    private fun readBoundedStream(stream: java.io.InputStream?, maxChars: Int = 256 * 1024): String {
        if (stream == null) return ""
        return try {
            stream.bufferedReader().use { reader ->
                val sb = StringBuilder()
                val buf = CharArray(4096)
                while (sb.length < maxChars) {
                    val read = reader.read(buf, 0, minOf(buf.size, maxChars - sb.length))
                    if (read <= 0) break
                    sb.append(buf, 0, read)
                }
                sb.toString().trim()
            }
        } catch (_: Throwable) {
            ""
        }
    }

    private suspend fun runProcessSafely(
        proc: Process,
        timeoutSec: Long = 10L
    ): Triple<Int, String, String> = withContext(Dispatchers.IO) {
        processExecutionSemaphore.acquire()
        runningProcesses.add(proc)
        try {
            try { proc.outputStream?.close() } catch (_: Throwable) {}
            val outDeferred = async(Dispatchers.IO) {
                readBoundedStream(proc.inputStream)
            }
            val errDeferred = async(Dispatchers.IO) {
                readBoundedStream(proc.errorStream, maxChars = 64 * 1024)
            }
            val finished = waitForProcessCompat(proc, timeoutSec)
            if (!finished) {
                outDeferred.cancel()
                errDeferred.cancel()
                Triple(124, "", "Tiến trình Shell vượt quá thời gian chờ (${timeoutSec}s)")
            } else {
                val outText = kotlinx.coroutines.withTimeoutOrNull(1500L) { outDeferred.await() } ?: ""
                val errText = kotlinx.coroutines.withTimeoutOrNull(1500L) { errDeferred.await() } ?: ""
                val exitCode = try { proc.exitValue() } catch (_: Throwable) { 0 }
                Triple(exitCode, outText, errText)
            }
        } finally {
            runningProcesses.remove(proc)
            try { proc.inputStream?.close() } catch (_: Throwable) {}
            try { proc.errorStream?.close() } catch (_: Throwable) {}
            try { proc.outputStream?.close() } catch (_: Throwable) {}
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    proc.destroyForcibly()
                } else {
                    proc.destroy()
                }
            } catch (_: Throwable) {}
            processExecutionSemaphore.release()
        }
    }

    fun isShizukuInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    @Volatile
    private var cachedRootAvailable: Boolean? = null

    fun isRootAvailable(): Boolean {
        cachedRootAvailable?.let { return it }
        val result = try {
            val suPaths = arrayOf(
                "/system/bin/su",
                "/system/xbin/su",
                "/sbin/su",
                "/su/bin/su",
                "/debug_ramdisk/su",
                "/data/local/xbin/su",
                "/data/local/bin/su"
            )
            suPaths.any { File(it).exists() }
        } catch (_: Throwable) {
            false
        }
        cachedRootAvailable = result
        return result
    }

    /**
     * Ping Shizuku Binder với cơ chế thử lại chống nghẽn tạm thời (Retry Backoff),
     * đảm bảo không bao giờ báo lỗi "Shizuku Binder không phản hồi" giả khi vừa chạy nhiều lệnh liên tiếp.
     */
    private fun pingShizukuBinderResilient(): Boolean {
        if (activeShizukuExecCount.get() > 0) return true
        return try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }
    }

    private fun checkShizukuPermissionResilient(): Boolean {
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            _state.value.isShizukuPermissionGranted && activeShizukuExecCount.get() > 0
        }
    }

    fun isShizukuServerTrulyAlive(): Boolean {
        if (!isShizukuInstalled()) return false
        if (!pingShizukuBinderResilient()) return false

        // Kiểm tra xem Shizuku Server Daemon (UID 2000 hoặc 0) có thực sự đang chạy
        return try {
            val version = Shizuku.getVersion()
            if (version < 11) return false
            val uid = Shizuku.getUid()
            val baseUid = uid % 100000
            baseUid == 2000 || baseUid == 0
        } catch (_: Exception) {
            // Nếu đang bận chạy lệnh mà getUid tạm thời ném ngoại lệ giao tiếp thì giữ trạng thái sống
            activeShizukuExecCount.get() > 0 && _state.value.isShizukuRunning
        }
    }

    /**
     * Kiểm tra thực tế khả năng thực thi lệnh qua Shizuku.
     * Sử dụng runProcessSafely để đảm bảo đóng stream và giải phóng IRemoteProcess Binder triệt để,
     * khắc phục lỗi "shizuku.newProcess" bị treo hoặc chết sau một thời gian sử dụng.
     */
    suspend fun testShizukuExecution(): Boolean {
        return try {
            if (!isShizukuServerTrulyAlive()) return false
            if (!checkShizukuPermissionResilient()) return false
            
            val newProcMethod = getShizukuNewProcessMethod()
            val proc = withContext(Dispatchers.IO) {
                shizukuExecMutex.withLock {
                    newProcMethod.invoke(null, arrayOf("sh", "-c", "echo test_ok"), null, null) as? Process
                }
            } ?: return false
            
            // Sử dụng cơ chế chạy an toàn với timeout 5 giây để không bao giờ treo app
            val (code, out, _) = runProcessSafely(proc, 5L)
            code == 0 && out.contains("test_ok")
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Chẩn đoán toàn diện kết nối Shizuku và trả về kết quả chi tiết từng bước.
     */
    suspend fun runComprehensiveShizukuDiagnostic(): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val sb = StringBuilder()
        // Bước 1: Ứng dụng Shizuku
        val installed = isShizukuInstalled()
        if (!installed) {
            sb.append("❌ Chưa cài đặt ứng dụng Shizuku (moe.shizuku.privileged.api). Vui lòng cài từ Google Play hoặc GitHub.")
            return@withContext Pair(false, sb.toString())
        }
        sb.append("✓ Đã cài đặt Shizuku Manager\n")

        // Bước 2: Binder & Server Alive (kèm thử lại chống nghẽn)
        val ping = pingShizukuBinderResilient()
        if (!ping) {
            sb.append("❌ Shizuku Binder không phản hồi (pingBinder = false). Dịch vụ Shizuku chưa chạy. Vui lòng mở app Shizuku và bấm 'Bắt đầu' qua Gỡ lỗi Wi-Fi.")
            return@withContext Pair(false, sb.toString())
        }
        sb.append("✓ Binder phản hồi tốt (pingBinder = true)\n")

        val version = try { Shizuku.getVersion() } catch (e: Exception) { -1 }
        val uid = try { Shizuku.getUid() } catch (e: Exception) { -1 }
        val baseUid = if (uid >= 0) uid % 100000 else 2000
        sb.append("✓ Shizuku API: v$version • Server UID: $uid\n")

        if (baseUid != 2000 && baseUid != 0) {
            sb.append("⚠️ Cảnh báo: Server Shizuku UID=$uid không phải UID Shell (2000) hoặc Root (0).\n")
        }

        // Bước 3: Kiểm tra quyền
        val granted = checkShizukuPermissionResilient()
        if (!granted) {
            sb.append("⚠️ MagicTune chưa được cấp quyền trong Shizuku (PERMISSION_DENIED). Hãy bấm 'Cấp quyền Shizuku' hoặc mở app Shizuku -> Quản lý ứng dụng ủy quyền -> bật MagicTune.\n")
            return@withContext Pair(false, sb.toString())
        }
        sb.append("✓ Đã được cấp quyền truy cập Shizuku (PERMISSION_GRANTED)\n")

        // Bước 4: Kiểm tra Process Execution thực tế
        val execOk = testShizukuExecution()
        if (!execOk) {
            sb.append("⚠️ Không thể thực thi tiến trình qua Shizuku.newProcess (Thử lại sau 1-2 giây hoặc khởi động lại Shizuku).")
            return@withContext Pair(false, sb.toString())
        }
        sb.append("✓ Thực thi lệnh Shell qua Shizuku hoàn hảo (echo test_ok -> OK)!")
        Pair(true, sb.toString())
    }

    @Volatile
    private var lastStatusCheckMs = 0L

    fun checkShizukuStatus(force: Boolean = false) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (!force && (now - lastStatusCheckMs < 1_200L)) {
            return
        }
        lastStatusCheckMs = now
        val installed = isShizukuInstalled()
        val running = if (installed) isShizukuServerTrulyAlive() else false
        val realGranted = if (running) {
            checkShizukuPermissionResilient()
        } else false
        val granted = if (isUserDisconnected) false else realGranted

        val (adbWifiOn, devOn) = checkAdbWifiSystemSetting()
        val root = isRootAvailable()
        val wlanAllowed = devOn && adbWifiOn && !isUserDisconnected && !isUserWlanDisconnected
        if (!wlanAllowed && (_state.value.isWirelessAdbConnected || DirectAdbManager.isInstanceConnectedFast())) {
            directAdbManager.disconnectDirect()
            try {
                val scanner = AdbNsdScanner.getInstance(context)
                scanner.stopDiscovery(updateStatusText = false)
                scanner.releaseMulticastLock()
                scanner.clearDiscoveredPorts()
            } catch (_: Throwable) {}
        }
        val wlanConnected = wlanAllowed && (_state.value.isWirelessAdbConnected || DirectAdbManager.isInstanceConnectedFast())
        val wlanPort = _state.value.wirelessAdbPort
        val persistentGrant = prefs.getBoolean(KEY_PERSISTENT_GRANT, false) ||
            hasWriteSecureSettingsPermission() ||
            (running && granted) ||
            wlanConnected

        val activeMode = when {
            running && granted -> ShellMode.SHIZUKU
            wlanConnected -> ShellMode.WIRELESS_ADB
            root -> ShellMode.ROOT
            else -> ShellMode.NONE
        }

        val msg = when {
            running && granted && wlanConnected -> "Đã kết nối: Shizuku + Direct ADB (UID 2000)"
            running && granted -> "Đã kết nối: Shizuku (UID 2000)"
            wlanConnected -> "Đã kết nối: Direct WLAN ADB (127.0.0.1:$wlanPort • UID 2000)"
            running && !granted -> "Shizuku đang chạy (Cần bấm cấp quyền)"
            installed && !running -> "Shizuku đã cài (Chưa khởi động Server)"
            root -> "Đã kết nối: Root (UID 0)"
            persistentGrant -> "Đã lưu quyền Fix (Chưa kết nối ADB)"
            else -> "Chưa kết nối ADB (WLAN)"
        }

        _state.update { cur ->
            cur.copy(
                isShizukuInstalled = installed,
                isShizukuRunning = running,
                isShizukuPermissionGranted = granted,
                isAdbWifiEnabled = adbWifiOn,
                isShizukuSeveredFromAdb = false,
                isWirelessAdbConnected = wlanConnected,
                isRootAvailable = root,
                hasPersistentGrant = persistentGrant,
                mode = activeMode,
                statusMessage = msg
            )
        }
        MagicTuneTileService.requestTileSync(context)

        // Connecting a shell transport must not silently grant broad permissions or alter power policy.
    }

    fun requestShizukuPermission(requestCode: Int = 1001) {
        isUserDisconnected = false
        val (adbWifiOn, _) = checkAdbWifiSystemSetting()

        // 1. Kiểm tra đã cài đặt app Shizuku hay chưa
        if (!isShizukuInstalled()) {
            _state.update {
                it.copy(
                    statusMessage = "⚠️ Chưa cài đặt Shizuku! Vui lòng cài app Shizuku hoặc dùng Kết Nối Trực Tiếp (Mã 6 số)."
                )
            }
            return
        }

        // 2. Kiểm tra Shizuku Server Daemon đã được khởi động chưa
        val isTrulyAlive = isShizukuServerTrulyAlive()
        if (!isTrulyAlive) {
            // Nếu Direct WLAN ADB hoặc Root đang sẵn sàng (hoặc NSD có cổng kết nối), tự động kích hoạt Shizuku Server ngầm!
            engineScope.launch {
                val (started, startMsg) = ShizukuStarterModule.startShizukuServerViaAdb(context, this@ShellEngine)
                if (started && isShizukuServerTrulyAlive()) {
                    checkShizukuStatus()
                    if (!checkShizukuPermissionResilient()) {
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            try {
                                Shizuku.requestPermission(requestCode)
                            } catch (_: Exception) {}
                        }
                    }
                } else {
                    _state.update {
                        it.copy(
                            isShizukuRunning = false,
                            isShizukuPermissionGranted = false,
                            mode = if (it.isWirelessAdbConnected) ShellMode.WIRELESS_ADB else ShellMode.NONE,
                            statusMessage = if (startMsg.isNotBlank()) startMsg else "⚠️ Shizuku Server chưa chạy! Hãy mở app Shizuku và bấm 'Bắt đầu' (Start)."
                        )
                    }
                }
            }
            return
        }

        // 3. Nếu Server Daemon đang chạy, kiểm tra quyền cấp cho MagicTune
        val selfPerm = if (checkShizukuPermissionResilient()) PackageManager.PERMISSION_GRANTED else -1
        if (selfPerm == PackageManager.PERMISSION_GRANTED) {
            markPersistentGrantActive()
            _state.update {
                it.copy(
                    isShizukuPermissionGranted = true,
                    isShizukuRunning = true,
                    isShizukuSeveredFromAdb = false,
                    isAdbWifiEnabled = adbWifiOn,
                    hasPersistentGrant = true,
                    mode = ShellMode.SHIZUKU,
                    statusMessage = "Shizuku: Đang kết nối (UID 2000)"
                )
            }
            startKeepAliveServiceIfNeeded()
            return
        }

        // 4. Nếu chưa có quyền, gửi request cấp quyền qua popup hệ thống của Shizuku trên Main Thread
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                Shizuku.requestPermission(requestCode)
            } catch (e: Exception) {
                _state.update { it.copy(statusMessage = "Lỗi yêu cầu quyền Shizuku: ${e.message}") }
            }
        }
    }

    suspend fun testWirelessAdbPort(port: Int): Boolean = withContext(Dispatchers.IO) {
        val hosts = directAdbManager.getCandidateHosts()
        for (host in hosts) {
            try {
                val socket = Socket().apply { soTimeout = 1200 }
                socket.connect(InetSocketAddress(host, port), 1200)
                socket.close()
                return@withContext true
            } catch (_: Exception) {}
        }
        false
    }

    suspend fun pairWirelessAdb(port: Int, pairingCode: String): Result<Boolean> = withContext(Dispatchers.IO) {
        val result = directAdbManager.pairDirect(port, pairingCode)
        if (result.isSuccess && result.getOrDefault(false)) {
            isUserDisconnected = false
            isUserWlanDisconnected = false
            prefs.edit().putInt(KEY_PAIR_PORT, port).apply()
            com.example.core.permission.AppPermissionChecker.markWlanActivated(context)
            _state.update { it.copy(statusMessage = "Ghép nối WLAN thành công tại cổng $port! Sẵn sàng kết nối.") }
        } else {
            val err = result.exceptionOrNull()?.localizedMessage ?: "Mã ghép đôi không đúng hoặc cổng hết hạn"
            _state.update { it.copy(statusMessage = "Lỗi ghép nối WLAN: $err") }
        }
        result
    }

    fun hasPairedBefore(): Boolean {
        return prefs.getInt(KEY_PAIR_PORT, -1) > 0
    }

    suspend fun connectWirelessAdb(port: Int): Boolean = withContext(Dispatchers.IO) {
        isUserDisconnected = false
        isUserWlanDisconnected = false
        val isValidPort = port in 1..65535
        if (!isValidPort) {
            _state.update { it.copy(statusMessage = "Cổng $port không hợp lệ (1-65535). Hãy kiểm tra lại!") }
            return@withContext false
        }

        // Ưu tiên 1: Kết nối Direct WLAN ADB (TLS/SPAKE2 - UID 2000 gốc độc lập không cần Shizuku)
        val directRes = try {
            directAdbManager.connectDirect(port)
        } catch (t: Throwable) {
            Result.failure(t)
        }
        val isDirectConnected = directRes.isSuccess && directRes.getOrDefault(false) && directAdbManager.verifyConnectedIo()

        // Ưu tiên 2: Nếu thiết bị có sẵn binary /system/bin/adb, kiểm tra xác thực thực tế (echo adb_ok)
        var isBinaryAdbAuthenticated = false
        if (!isDirectConnected && File("/system/bin/adb").exists()) {
            try {
                val env = arrayOf(
                    "HOME=${context.filesDir.absolutePath}",
                    "TMPDIR=${context.cacheDir.absolutePath}",
                    "ADB_VENDOR_KEYS=${context.filesDir.absolutePath}"
                )
                val connectProc = Runtime.getRuntime().exec(
                    arrayOf("/system/bin/adb", "connect", "127.0.0.1:$port"),
                    env,
                    context.filesDir
                )
                waitForProcessCompat(connectProc, 3L)

                val verifyProc = Runtime.getRuntime().exec(
                    arrayOf("/system/bin/adb", "-s", "127.0.0.1:$port", "shell", "echo adb_ok"),
                    env,
                    context.filesDir
                )
                val (vCode, vOut, vErr) = runProcessSafely(verifyProc, 4L)
                isBinaryAdbAuthenticated = (vCode == 0 && vOut.contains("adb_ok") && !vErr.contains("unauthorized", true))
            } catch (_: Exception) {}
        }

        if (isDirectConnected || isBinaryAdbAuthenticated) {
            consecutiveWlanFailures = 0
            saveWlanState(connected = true, port = port, persistentGrant = true)

            // Keep the ADB transport available without exempting MagicTune from Doze/background limits.
            val pkg = context.packageName
            _state.update {
                it.copy(
                    isWirelessAdbConnected = true,
                    wirelessAdbPort = port,
                    hasPersistentGrant = true,
                    mode = ShellMode.WIRELESS_ADB,
                    statusMessage = "Direct WLAN ADB: Đang kết nối (127.0.0.1:$port • UID 2000 Độc Lập)"
                )
            }
            MagicTuneTileService.requestTileSync(context)
            // Đo nhanh RTT & UID để cập nhật Telemetry HUD ngay
            engineScope.launch {
                try { directAdbManager.pingLatencyMs() } catch (_: Throwable) {}
            }
            // Trì hoãn nhẹ kích hoạt chéo Shizuku để tránh xung đột với các tác vụ khởi tạo sau kết nối
            if (isShizukuInstalled() && !isShizukuServerTrulyAlive()) {
                engineScope.launch {
                    try {
                        delay(900L)
                        if (!isUserDisconnected && !isUserWlanDisconnected && !isShizukuServerTrulyAlive()) {
                            ShizukuStarterModule.startShizukuServerViaAdb(context, this@ShellEngine)
                            checkShizukuStatus()
                        }
                    } catch (_: Throwable) {}
                }
            }
            startKeepAliveServiceIfNeeded()
            true
        } else {
            val tcpOpen = testWirelessAdbPort(port)
            val err = directRes.exceptionOrNull()?.localizedMessage
                ?: if (tcpOpen) "Cổng $port đang mở nhưng chưa xác thực TLS (Hãy ghép nối mã PIN 6 số trước!)"
                else "Không thể mở kết nối tới cổng $port"
            _state.update { it.copy(
                isWirelessAdbConnected = false,
                statusMessage = "Không thể kết nối 127.0.0.1:$port ($err)."
            ) }
            MagicTuneTileService.requestTileSync(context)
            false
        }
    }

    /**
     * Tự động dò đa tầng (SystemProp -> mDNS QU burst -> Parallel TCP probe) và kết nối ngay không cần nhập tay cổng.
     */
    suspend fun autoConnectBestWirelessAdb(preferredPort: Int? = null): Pair<Boolean, Int?> = withContext(Dispatchers.IO) {
        isUserDisconnected = false
        isUserWlanDisconnected = false

        // Lớp 1: Thử probe ngay các cổng đã biết/system trong < 200ms
        val fastProbe = directAdbManager.probeAndAutoConnect(preferredPort)
        if (fastProbe.isSuccess) {
            val port = fastProbe.getOrNull() ?: directAdbManager.activePort
            if (directAdbManager.verifyConnectedIo()) {
                val ok = connectWirelessAdb(port)
                if (ok) return@withContext (true to port)
            }
        }

        // Lớp 2: Bật active QU mDNS burst tìm cổng mới trong 2.8s rồi nối
        val scanner = AdbNsdScanner.getInstance(context)
        val discovered = scanner.discoverConnectPortWithin(2800L)
        if (discovered != null && discovered in 1..65535) {
            val ok = connectWirelessAdb(discovered)
            if (ok) return@withContext (true to discovered)
        }

        (false to null)
    }

    suspend fun pingWirelessAdbLatency(): Long? = withContext(Dispatchers.IO) {
        directAdbManager.pingLatencyMs()
    }

    suspend fun runWirelessAdbDiagnostics(): AdbDiagnosticReport = withContext(Dispatchers.IO) {
        directAdbManager.runDiagnostics(hasPairedBefore())
    }

    /**
     * Tự động cấp trọn bộ quyền ADB & AppOps mạnh nhất cho chính MagicTune (cả cấp độ Package và --uid)
     * và tự động chạy các lệnh bảo vệ app (Anti-Kill, Bạch danh Doze, TARE VIP, Bỏ giới hạn Phantom Process)
     * cùng các lệnh tối ưu hóa hiệu năng, độ nhạy cảm ứng và biên dịch AOT Speed mã máy riêng cho điện thoại.
     */
    suspend fun autoGrantSelfPermissions(force: Boolean = false) {
        selfPermMutex.withLock {
            val nowMs = android.os.SystemClock.elapsedRealtime()
            val hasWriteSecure = hasWriteSecureSettingsPermission()
            val hasOverlay = try { android.provider.Settings.canDrawOverlays(context) } catch (_: Throwable) { false }
            if (!force && lastAutoGrantCompletedMs != 0L && (nowMs - lastAutoGrantCompletedMs) < 25_000L && hasWriteSecure && hasOverlay) {
                return
            }

            val pkg = context.packageName
            val appOpsToUnlock = listOf(
                "SYSTEM_ALERT_WINDOW",
                "PICTURE_IN_PICTURE",
                "PROJECT_MEDIA",
                "ACCESS_RESTRICTED_SETTINGS",
                "WRITE_SETTINGS",
                "GET_USAGE_STATS",
                "LOADER_USAGE_STATS",
                "POST_NOTIFICATION",
                "RECORD_AUDIO",
                "READ_CLIPBOARD",
                "WRITE_CLIPBOARD",
                "TOAST_WINDOW",
                "INSTALL_SHORTCUT",
                "SHORTCUT",
                "AUTO_REVOKE_PERMISSIONS_IF_UNUSED"
            )
            val editor = kvPrefs.edit()
            for (op in appOpsToUnlock) {
                editor.putBoolean("appop_${pkg}_$op", true)
            }
            editor.apply()

            try {
                // Tự động khôi phục các bộ quản lý pin & nhiệt gốc của Honor/Android để cộng sinh 100% không xung đột (v7.0)
                if (!kvPrefs.getBoolean("auto_restored_power_switches_offline_v70", false)) {
                    kvPrefs.edit()
                        .putBoolean("magictune_oem_conflicts_disabled_forever", false)
                        .putBoolean("auto_restored_power_switches_offline_v571", true)
                        .putBoolean("auto_restored_power_switches_offline_v70", true)
                        .apply()
                    com.example.data.MagicTuneRepository.restoreHonorPowerGovernorsOffline(context)
                }

                val hasRestoredShellPkgs = kvPrefs.getBoolean("auto_restored_power_pkgs_shell_v70", false)
                val isAlreadyGranted = kvPrefs.getBoolean("auto_granted_self_perms_v70", false) && hasWriteSecure && hasOverlay

                if (force || !isAlreadyGranted || !hasRestoredShellPkgs) {
                    val cmdsToRun = mutableListOf<String>()

                    // 1. Mở khóa Cài đặt bị hạn chế & Cửa sổ nổi & Tạo lối tắt màn hình chính trước
                    cmdsToRun.add("cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1 || true")
                    cmdsToRun.add("cmd appops set --user 0 $pkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1 || true")
                    cmdsToRun.add("cmd appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || true")
                    cmdsToRun.add("cmd appops set --user 0 $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || true")
                    cmdsToRun.add("cmd appops set $pkg INSTALL_SHORTCUT allow >/dev/null 2>&1 || appops set $pkg INSTALL_SHORTCUT allow >/dev/null 2>&1 || true")
                    cmdsToRun.add("cmd appops set --user 0 $pkg INSTALL_SHORTCUT allow >/dev/null 2>&1 || true")
                    cmdsToRun.add("cmd appops set $pkg SHORTCUT allow >/dev/null 2>&1 || appops set $pkg SHORTCUT allow >/dev/null 2>&1 || true")
                    cmdsToRun.add("cmd appops set --user 0 $pkg SHORTCUT allow >/dev/null 2>&1 || true")
                    cmdsToRun.add("cmd appops set $pkg 10017 allow >/dev/null 2>&1 || appops set $pkg 10017 allow >/dev/null 2>&1 || true")
                    cmdsToRun.add("cmd appops set --user 0 $pkg 10017 allow >/dev/null 2>&1 || true")
                    cmdsToRun.add("pm grant --user 0 $pkg com.android.launcher.permission.INSTALL_SHORTCUT >/dev/null 2>&1 || pm grant $pkg com.android.launcher.permission.INSTALL_SHORTCUT >/dev/null 2>&1 || true")

                    // 2. Chỉ cấp các quyền Runtime & System thực sự hợp lệ
                    val runtimePerms = buildList {
                        add("android.permission.WRITE_SECURE_SETTINGS")
                        add("android.permission.WRITE_SETTINGS")
                        add("android.permission.DUMP")
                        add("android.permission.READ_LOGS")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            add("android.permission.POST_NOTIFICATIONS")
                        }
                        add("android.permission.RECORD_AUDIO")
                        add("android.permission.PACKAGE_USAGE_STATS")
                        add("com.android.launcher.permission.INSTALL_SHORTCUT")
                    }
                    for (perm in runtimePerms) {
                        if (force || context.checkSelfPermission(perm) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            cmdsToRun.add("pm grant --user 0 $pkg $perm >/dev/null 2>&1 || pm grant $pkg $perm >/dev/null 2>&1 || true")
                        }
                    }

                    // 3. Mở khóa AppOps ở mức package và --uid (kiểm tra op hợp lệ tránh Exit 255 trên Android 12-15)
                    for (op in appOpsToUnlock) {
                        cmdsToRun.add(buildSafeAppOpsCmd(pkg, op, "allow", includeUid = true))
                    }

                    // 4. ĐĂNG KÝ ĐỊNH DANH "NGƯỜI NHÀ HỆ THỐNG" (TRUSTED SYSTEM COMPANION)
                    // Đưa MagicTune vào nhóm EXEMPTED (cấp bậc ứng dụng hệ thống), sys-whitelist, TARE VIP & NetPolicy UID
                    // để SystemManager / PowerGenius / iAware coi app như thành phần nội bộ của máy, không bao giờ xung đột.
                    cmdsToRun.add(buildSafeKeepAliveCommands(pkg))
                    cmdsToRun.add("cmd appops set --user 0 $pkg AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore >/dev/null 2>&1 || true")
                    cmdsToRun.add("cmd appops set $pkg AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore >/dev/null 2>&1 || true")
                    cmdsToRun.add("settings put secure magictune_wlan_activated_forever 1 >/dev/null 2>&1 || true")
                    cmdsToRun.add("settings put secure magictune_system_harmony_registered 1 >/dev/null 2>&1 || true")

                    // 5. Khôi phục PowerGenius / iAware / SystemManager / Phantom Process / Thermal chuẩn để cộng sinh hòa bình 100%
                    if (!hasRestoredShellPkgs) {
                        val restorePkgs = listOf(
                            "com.hihonor.powergenius",
                            "com.huawei.powergenie",
                            "com.hihonor.iaware",
                            "com.hihonor.hiai.engine"
                        )
                        for (rp in restorePkgs) {
                            cmdsToRun.add(
                                "cmd package install-existing --user 0 $rp >/dev/null 2>&1; " +
                                    "pm unsuspend --user 0 $rp >/dev/null 2>&1; " +
                                    "pm enable --user 0 $rp >/dev/null 2>&1 || pm enable $rp >/dev/null 2>&1; " +
                                    "cmd app_hibernation set-state --user 0 $rp false >/dev/null 2>&1; " +
                                    "cmd appops reset --user 0 $rp >/dev/null 2>&1 || true"
                            )
                        }
                        cmdsToRun.add("cmd appops reset --user 0 com.hihonor.systemmanager >/dev/null 2>&1 || true")
                        cmdsToRun.add("cmd appops reset --user 0 com.huawei.systemmanager >/dev/null 2>&1 || true")
                        cmdsToRun.add("settings put system iaware_switch 1 >/dev/null 2>&1 || true")
                        cmdsToRun.add("settings put global iaware_switch 1 >/dev/null 2>&1 || true")
                        cmdsToRun.add("settings put secure iaware_switch 1 >/dev/null 2>&1 || true")
                        cmdsToRun.add("settings put system power_genius_switch 1 >/dev/null 2>&1 || true")
                        cmdsToRun.add("settings put global power_genius_switch 1 >/dev/null 2>&1 || true")
                        cmdsToRun.add("settings put system bg_clean_switch 1 >/dev/null 2>&1 || true")
                        cmdsToRun.add("settings put secure bg_clean_switch 1 >/dev/null 2>&1 || true")
                        cmdsToRun.add("settings put global bastet_switch 1 >/dev/null 2>&1 || true")
                        cmdsToRun.add("settings put system smart_socket_switch 1 >/dev/null 2>&1 || true")
                        cmdsToRun.add("device_config delete activity_manager max_phantom_processes >/dev/null 2>&1 || true")
                        cmdsToRun.add("settings put global settings_enable_monitor_phantom_procs true >/dev/null 2>&1 || true")
                        cmdsToRun.add("settings delete global adb_allowed_connection_time >/dev/null 2>&1 || true")
                    }

                    // Permission grants must not change the user's display refresh policy.

                    // Assistant role and microphone/screen-capture services are enabled only by
                    // the dedicated user action, never as a side effect of connecting ADB.

                    for (chunk in cmdsToRun.chunked(10)) {
                        execute(chunk.joinToString("; "))
                        delay(45L)
                    }

                    kvPrefs.edit()
                        .putBoolean("auto_granted_self_perms_v571", true)
                        .putBoolean("auto_restored_power_pkgs_shell_v571", true)
                        .putBoolean("auto_granted_self_perms_v70", true)
                        .putBoolean("auto_restored_power_pkgs_shell_v70", true)
                        .apply()
                    com.example.core.permission.AppPermissionChecker.markWlanActivated(context)
                }

                // Đảm bảo Trợ Năng luôn ẩn ở trạng thái nghỉ mà không spam shell nếu đã ẩn rồi
                com.example.core.service.MagicTuneCtsAccessibilityService.enforceComponentDisabled(context)
                if (com.example.core.service.MagicTuneCtsAccessibilityService.isServiceEnabledInSettings(context)) {
                    com.example.core.service.MagicTuneCtsAccessibilityService.purgeFromSecureSettingsIfIdle(context)
                }

                lastAutoGrantCompletedMs = android.os.SystemClock.elapsedRealtime()
                com.example.core.license.LicenseManager.persistHardwareProSignatureIfNeeded(context)
                com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
            } catch (_: Exception) {}
        }
    }

    fun forceDisconnectWirelessAdbImmediately(reason: String = "Đã ngắt kết nối (Tùy chọn nhà phát triển hoặc Gỡ lỗi Wi-Fi đã tắt)") {
        eventReconnectJob?.cancel()
        eventReconnectJob = null
        monitorJob?.cancel()
        monitorJob = null
        isUserWlanDisconnected = true
        isUserDisconnected = true
        consecutiveWlanFailures = 0
        resetSessionCapabilityCache()
        directAdbManager.disconnectDirect()
        try {
            val scanner = AdbNsdScanner.getInstance(context)
            scanner.stopDiscovery(updateStatusText = false)
            scanner.releaseMulticastLock()
            scanner.clearDiscoveredPorts()
        } catch (_: Throwable) {}
        saveWlanState(connected = false, port = _state.value.wirelessAdbPort, persistentGrant = true)
        val keepShizuku = _state.value.isShizukuRunning && _state.value.isShizukuPermissionGranted && isShizukuServerTrulyAlive()
        _state.update { cur ->
            cur.copy(
                isWirelessAdbConnected = false,
                isAdbWifiEnabled = false,
                hasPersistentGrant = true,
                mode = if (keepShizuku) ShellMode.SHIZUKU else ShellMode.LOCAL_LIMITED,
                statusMessage = reason
            )
        }
        MagicTuneTileService.requestTileSync(context)
    }

    fun disconnectWirelessAdb() {
        isUserWlanDisconnected = true
        isUserDisconnected = true
        consecutiveWlanFailures = 0
        resetSessionCapabilityCache()
        directAdbManager.disconnectDirect()
        saveWlanState(connected = false, port = _state.value.wirelessAdbPort, persistentGrant = true)
        _state.update { cur -> cur.copy(
            isWirelessAdbConnected = false,
            isShizukuRunning = false,
            isShizukuPermissionGranted = false,
            hasPersistentGrant = true,
            mode = ShellMode.NONE,
            statusMessage = "Đã ngắt kết nối • Giữ nguyên 100% trạng thái đã Fix"
        ) }
        MagicTuneTileService.requestTileSync(context)
        startKeepAliveServiceIfNeeded()
    }

    fun disconnectWirelessAdbCleanlyForStealth() {
        isUserWlanDisconnected = true
        consecutiveWlanFailures = 0
        directAdbManager.disconnectDirect()
        saveWlanState(connected = false, port = _state.value.wirelessAdbPort, persistentGrant = true)
        val keepShizuku = _state.value.isShizukuRunning &&
            _state.value.isShizukuPermissionGranted &&
            isShizukuServerTrulyAlive()
        _state.update { cur ->
            cur.copy(
                isWirelessAdbConnected = false,
                isAdbWifiEnabled = false,
                hasPersistentGrant = true,
                mode = if (keepShizuku) ShellMode.SHIZUKU else ShellMode.NONE,
                statusMessage = if (keepShizuku) {
                    "Đã tắt sạch ADB/Wi-Fi • Shizuku chạy nền sạch sẽ"
                } else {
                    "Đã tắt sạch ADB • Sẵn sàng mở App bảo mật cao"
                }
            )
        }
        startKeepAliveServiceIfNeeded()
    }

    fun disconnectSession() {
        isUserDisconnected = true
        isUserWlanDisconnected = true
        consecutiveWlanFailures = 0
        resetSessionCapabilityCache()
        directAdbManager.disconnectDirect()
        saveWlanState(connected = false, port = _state.value.wirelessAdbPort, persistentGrant = true)
        val (adbWifiOn, _) = checkAdbWifiSystemSetting()
        _state.update { cur -> cur.copy(
            isWirelessAdbConnected = false,
            isShizukuPermissionGranted = false,
            isShizukuSeveredFromAdb = false,
            isAdbWifiEnabled = adbWifiOn,
            mode = ShellMode.NONE,
            statusMessage = "Chưa kết nối (Đã chủ động ngắt phiên làm việc)"
        ) }
    }

    fun refreshStatus() {
        checkShizukuStatus()
    }

    /**
     * Chuẩn hóa và gia cố câu lệnh Shell để khi thực thi qua Shizuku (UID 2000) trên Android 11–16 / MagicOS:
     * 1. Gạt công tắc thực tế trên máy: AppOps phải được set cho cả Package lẫn `--uid` (vì Cài đặt Android đọc theo UID mode).
     * 2. Bỏ hạn chế Pin (Unrestricted Battery): Phải kết hợp `cmd deviceidle whitelist +pkg`, `dumpsys deviceidle whitelist +pkg` và `RUN_ANY_IN_BACKGROUND allow` (cả package và `--uid`).
     * 3. Quyền Runtime (`pm grant`): Tự động chuyển các quyền đặc biệt như `SCHEDULE_EXACT_ALARM` sang AppOps để không bị lỗi SecurityException, và thêm `--user 0` cho `pm grant`.
     * 4. Cài đặt hệ thống (`settings put`): Thực thi đồng thời `settings put` và `cmd settings put`, đồng thời kích hoạt service tương ứng (`cmd uimode`, `cmd location`, `cmd content`) để công tắc trên máy đổi trạng thái ngay lập tức.
     */
    private val protectedHangingAppOpsPackages = setOf(
        "com.hihonor.detectrepair",
        "com.huawei.detectrepair"
    )

    private fun resetSessionCapabilityCache() {
        sessionCapabilities = null
        supportedAppOpsCache.clear()
        installedPkgCache.clear()
        installedPkgMissCache.clear()
        romPresentPkgCache.clear()
    }

    fun sanitizeShellCommand(rawCommand: String): String {
        return rawCommand
            .replace("\r\n", "\n")
            .replace("\r", "")
            .replace(Regex(">/dev/null\\s+2>&(?!1)\\b"), ">/dev/null 2>&1")
            .replace(Regex("\\\\\\s*\\n"), " ")
            .trim()
    }

    fun isPackageInstalledQuick(pkg: String): Boolean {
        val clean = pkg.trim().substringBefore("/")
        if (clean.isEmpty()) return false
        if (clean == context.packageName) return true
        val now = android.os.SystemClock.elapsedRealtime()
        installedPkgCache[clean]?.let { if (now - it < 20_000L) return true }
        installedPkgMissCache[clean]?.let { if (now - it < 20_000L) return false }
        val exists = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(clean, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(clean, 0)
            }
            true
        } catch (_: Throwable) {
            false
        }
        if (exists) installedPkgCache[clean] = now else installedPkgMissCache[clean] = now
        return exists
    }

    @Suppress("DEPRECATION")
    fun isPackagePresentInRom(pkg: String): Boolean {
        val clean = pkg.trim().substringBefore("/")
        if (clean.isEmpty()) return false
        if (clean == context.packageName) return true
        romPresentPkgCache[clean]?.let { return it }
        val flags = PackageManager.MATCH_UNINSTALLED_PACKAGES or PackageManager.MATCH_DISABLED_COMPONENTS
        val present = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(clean, PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                context.packageManager.getPackageInfo(clean, flags)
            }
            true
        } catch (_: Throwable) {
            false
        }
        romPresentPkgCache[clean] = present
        return present
    }

    fun getCapabilitiesSnapshot(): DeviceShellCapabilities {
        return sessionCapabilities ?: DeviceShellCapabilities()
    }

    fun isUserActive(userId: Int): Boolean {
        if (userId == 0) return true
        val caps = sessionCapabilities ?: return false
        return !caps.probed || userId in caps.activeUserIds
    }

    suspend fun ensurePreflightCapabilities(): DeviceShellCapabilities = withContext(Dispatchers.IO) {
        sessionCapabilities?.takeIf { it.probed }?.let { return@withContext it }
        if (!_state.value.isAdbReady) {
            return@withContext sessionCapabilities ?: DeviceShellCapabilities()
        }
        preflightMutex.withLock {
            sessionCapabilities?.takeIf { it.probed }?.let { return@withLock it }
            val probeScript = buildString {
                append("echo \"__PF_SERVICES__\"\n")
                append("cmd -l 2>/dev/null || true\n")
                append("echo \"__PF_USERS__\"\n")
                append("pm list users 2>/dev/null || true\n")
                append("echo \"__PF_SUSPEND__\"\n")
                append("pm suspend --help 2>&1 || true\n")
            }
            val rawOut = try {
                when {
                    !isUserDisconnected && !isUserWlanDisconnected && directAdbManager.verifyConnectedIo() -> {
                        directAdbManager.executeCommand(probeScript, timeoutSec = 8L).output
                    }
                    !isUserDisconnected && isShizukuInstalled() && pingShizukuBinderResilient() && checkShizukuPermissionResilient() -> {
                        activeShizukuExecCount.incrementAndGet()
                        try {
                            val m = getShizukuNewProcessMethod()
                            val proc = shizukuExecMutex.withLock {
                                m.invoke(null, arrayOf("sh", "-c", probeScript), null, null) as Process
                            }
                            runProcessSafely(proc, 8L).second
                        } finally {
                            activeShizukuExecCount.decrementAndGet()
                        }
                    }
                    else -> ""
                }
            } catch (_: Throwable) {
                ""
            }

            if (rawOut.isBlank()) {
                return@withLock sessionCapabilities ?: DeviceShellCapabilities()
            }

            val servicesBlock = rawOut.substringAfter("__PF_SERVICES__", "").substringBefore("__PF_USERS__", "")
            val usersBlock = rawOut.substringAfter("__PF_USERS__", "").substringBefore("__PF_SUSPEND__", "")
            val suspendBlock = rawOut.substringAfter("__PF_SUSPEND__", "")

            val services = servicesBlock.lines()
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .toSet()

            val userRegex = Regex("""UserInfo\{(\d+):""")
            val parsedUsers = userRegex.findAll(usersBlock)
                .mapNotNull { it.groupValues.getOrNull(1)?.toIntOrNull() }
                .toMutableSet()
            parsedUsers.add(0)

            val suspendSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
                suspendBlock.contains("suspend", ignoreCase = true) &&
                !suspendBlock.contains("Unknown command", ignoreCase = true) &&
                !suspendBlock.contains("Unsupported", ignoreCase = true)

            val resolved = DeviceShellCapabilities(
                sdkInt = Build.VERSION.SDK_INT,
                hasTareService = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && "tare" in services,
                hasAppHibernationService = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && "app_hibernation" in services,
                hasRoleService = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && "role" in services,
                hasDeviceIdleService = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && "deviceidle" in services,
                hasPmSuspend = suspendSupported,
                activeUserIds = parsedUsers,
                probed = true
            )
            sessionCapabilities = resolved
            resolved
        }
    }

    fun buildSafeTareVipCmd(pkg: String, vip: Boolean): String {
        val cleanPkg = pkg.trim()
        if (cleanPkg.isEmpty() || !isPackageInstalledQuick(cleanPkg)) return "true"
        val caps = sessionCapabilities
        if (caps?.probed == true && !caps.hasTareService) return "true"
        val flag = if (vip) "true" else "false"
        return "if cmd -l 2>/dev/null | grep -qw tare; then cmd tare set-vip --user 0 $cleanPkg $flag >/dev/null 2>&1 || true; fi"
    }

    fun buildSafeAppOpsCmd(pkg: String, op: String, mode: String = "allow", includeUid: Boolean = false): String {
        val cleanPkg = pkg.trim()
        val cleanOp = op.trim()
        val cleanMode = mode.trim()
        if (cleanPkg.isEmpty() || cleanOp.isEmpty()) return "true"
        if (cleanPkg in protectedHangingAppOpsPackages) return "true"
        // Cộng sinh thân thiện với Hệ thống: Không bao giờ tước quyền (ignore/deny) của SystemManager, PowerGenius, iAware hay App hệ thống cốt lõi
        if (cleanMode != "allow" && cleanMode != "default" &&
            com.example.core.widget.BackgroundDrainInspector.isSystemFamilyOrManagerApp(cleanPkg)
        ) {
            return "true"
        }
        if (!isPackageInstalledQuick(cleanPkg)) return "true"
        if (supportedAppOpsCache[cleanOp] == false) return "true"
        val uidClause = if (includeUid) {
            "cmd appops set --uid $cleanPkg $cleanOp $cleanMode >/dev/null 2>&1 || true; "
        } else ""
        return "{ if cmd appops get --user 0 $cleanPkg $cleanOp >/dev/null 2>&1; then cmd appops set --user 0 $cleanPkg $cleanOp $cleanMode >/dev/null 2>&1 || cmd appops set $cleanPkg $cleanOp $cleanMode >/dev/null 2>&1 || appops set $cleanPkg $cleanOp $cleanMode >/dev/null 2>&1 || true; $uidClause fi; true; }"
    }

    fun buildSafeSuspendOrDisableCmd(pkg: String): String {
        val cleanPkg = pkg.trim()
        if (cleanPkg.isEmpty() || !isPackageInstalledQuick(cleanPkg)) return "true"
        // Tuyệt đối không đóng băng/vô hiệu hóa Quản lý hệ thống & Điều phối gốc của máy
        if (com.example.core.widget.BackgroundDrainInspector.isSystemFamilyOrManagerApp(cleanPkg)) {
            return "true"
        }
        val caps = sessionCapabilities
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && (caps == null || !caps.probed || caps.hasPmSuspend)) {
            "{ if pm path $cleanPkg >/dev/null 2>&1; then pm suspend --user 0 $cleanPkg >/dev/null 2>&1 || cmd package suspend --user 0 $cleanPkg >/dev/null 2>&1 || pm disable-user --user 0 $cleanPkg >/dev/null 2>&1 || pm disable $cleanPkg >/dev/null 2>&1 || true; fi; true; }"
        } else {
            buildSafeDisablePackageCmd(cleanPkg)
        }
    }

    fun buildSafeDisablePackageCmd(pkg: String): String {
        val cleanPkg = pkg.trim()
        if (cleanPkg.isEmpty() || !isPackageInstalledQuick(cleanPkg)) return "true"
        // Tuyệt đối không vô hiệu hóa Quản lý hệ thống & Điều phối gốc của máy
        if (com.example.core.widget.BackgroundDrainInspector.isSystemFamilyOrManagerApp(cleanPkg)) {
            return "true"
        }
        return "{ if pm path $cleanPkg >/dev/null 2>&1; then am force-stop $cleanPkg >/dev/null 2>&1 || true; pm disable-user --user 0 $cleanPkg >/dev/null 2>&1 || pm disable $cleanPkg >/dev/null 2>&1 || true; fi; true; }"
    }

    fun buildSafeEnablePackageCmd(target: String, userId: Int = 0): String {
        val cleanTarget = target.trim()
        val pkg = cleanTarget.substringBefore("/")
        if (pkg.isEmpty() || !isPackagePresentInRom(pkg)) return "true"
        if (userId != 0 && !isUserActive(userId)) return "true"
        return if (userId == 0) {
            "{ cmd package install-existing --user 0 $pkg >/dev/null 2>&1 || true; pm unsuspend --user 0 $pkg >/dev/null 2>&1 || true; pm enable --user 0 $cleanTarget >/dev/null 2>&1 || pm enable $cleanTarget >/dev/null 2>&1 || true; }"
        } else {
            "{ pm enable --user $userId $cleanTarget >/dev/null 2>&1 || true; }"
        }
    }

    fun buildSafeMasterSyncCmd(enabled: Boolean): String {
        val v = if (enabled) "1" else "0"
        return "{ settings put global master_sync_enabled $v >/dev/null 2>&1 || true; settings put global auto_sync $v >/dev/null 2>&1 || true; true; }"
    }

    fun buildSafeKeepAliveCommands(pkg: String): String {
        val cleanPkg = pkg.trim().substringBefore("/")
        if (cleanPkg.isEmpty() || !isPackageInstalledQuick(cleanPkg)) return "true"
        if (cleanPkg == context.packageName) return "true"
        val caps = sessionCapabilities
        val tareSnippet = if (caps == null || !caps.probed) {
            "if cmd -l 2>/dev/null | grep -qw tare; then cmd tare set-vip --user 0 $cleanPkg true >/dev/null 2>&1 || true; fi; "
        } else if (caps.hasTareService) {
            "cmd tare set-vip --user 0 $cleanPkg true >/dev/null 2>&1 || true; "
        } else ""
        val hibSnippet = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            "cmd app_hibernation set-state --user 0 $cleanPkg false >/dev/null 2>&1 || true; "
        } else ""
        return "cmd deviceidle whitelist +$cleanPkg >/dev/null 2>&1 || dumpsys deviceidle whitelist +$cleanPkg >/dev/null 2>&1 || true; " +
            "cmd deviceidle sys-whitelist +$cleanPkg >/dev/null 2>&1 || true; " +
            "am set-standby-bucket --user 0 $cleanPkg exempted >/dev/null 2>&1 || am set-standby-bucket --user 0 $cleanPkg active >/dev/null 2>&1 || pm set-app-standby-bucket $cleanPkg active >/dev/null 2>&1 || true; " +
            "cmd activity set-inactive --user 0 $cleanPkg false >/dev/null 2>&1 || true; " +
            "pm set-auto-revoke-permissions-mode $cleanPkg false >/dev/null 2>&1 || true; " +
            hibSnippet +
            tareSnippet +
            "cmd appops set --user 0 $cleanPkg RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true; " +
            "cmd appops set --uid $cleanPkg RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true; " +
            "cmd appops set --user 0 $cleanPkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true; " +
            "cmd appops set --uid $cleanPkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true; " +
            "cmd appops set --user 0 $cleanPkg AUTO_START allow >/dev/null 2>&1 || true; " +
            "cmd appops set --user 0 $cleanPkg BOOT_COMPLETED allow >/dev/null 2>&1 || true; " +
            "cmd appops set --user 0 $cleanPkg START_FOREGROUND allow >/dev/null 2>&1 || true; " +
            "cmd appops set --user 0 $cleanPkg FOREGROUND_SERVICE_SPECIAL_USE allow >/dev/null 2>&1 || true; " +
            "cmd appops set --user 0 $cleanPkg WAKE_LOCK allow >/dev/null 2>&1 || true; " +
            "cmd appops set --user 0 $cleanPkg SCHEDULE_EXACT_ALARM allow >/dev/null 2>&1 || true; " +
            "cmd appops set --user 0 $cleanPkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || true; " +
            "cmd appops set --uid $cleanPkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || true; " +
            "cmd appops set --user 0 $cleanPkg GET_USAGE_STATS allow >/dev/null 2>&1 || true; " +
            "cmd appops set --uid $cleanPkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1 || true; " +
            "cmd appops set --user 0 $cleanPkg SYSTEM_EXEMPT_FROM_POWER_RESTRICTIONS allow >/dev/null 2>&1 || true; " +
            "cmd appops set --user 0 $cleanPkg SYSTEM_EXEMPT_FROM_HIBERNATION allow >/dev/null 2>&1 || true; " +
            "cmd appops set --user 0 $cleanPkg SYSTEM_EXEMPT_FROM_ACTIVITY_BG_START_RESTRICTION allow >/dev/null 2>&1 || true; " +
            "cmd game mode performance $cleanPkg >/dev/null 2>&1 || cmd game set --mode 2 --user 0 $cleanPkg >/dev/null 2>&1 || true"
    }

    private fun buildResilientShellCommand(rawCommand: String, useBatchTimeoutVar: Boolean = false): String {
        val trimmed = sanitizeShellCommand(rawCommand)
        if (trimmed.isEmpty()) return trimmed

        // Bảo vệ khỏi các gói chẩn đoán hệ thống bị khóa khiến `cmd appops set` treo 25s (Exit 124)
        if ((trimmed.contains("appops ") || trimmed.contains("am set-standby-bucket")) &&
            protectedHangingAppOpsPackages.any { trimmed.contains(it) }
        ) {
            return "true"
        }

        // Chặn/chuyển đổi lệnh lỗi thời kể cả khi nằm trong lệnh đơn:
        if (trimmed.contains("cmd content set-master-sync-automatically")) {
            val enableSync = !trimmed.contains("false", ignoreCase = true) && !trimmed.endsWith("0")
            if (!trimmed.contains(";") && !trimmed.contains("&&") && !trimmed.contains("||")) {
                return buildSafeMasterSyncCmd(enableSync)
            }
        }

        // Nếu là lệnh phức hợp sẵn (chứa ; hoặc || hoặc &&), giữ nguyên (nhưng bảo vệ thêm nếu là lệnh đơn lẻ cmd tare/pm suspend)
        if (trimmed.contains(";") || trimmed.contains("&&") || trimmed.contains("||") || trimmed.startsWith("{") || trimmed.startsWith("if ")) {
            return trimmed
        }

        val tokens = tokenizeCommand(trimmed)
        if (tokens.isEmpty()) return trimmed

        val toPrefix = if (useBatchTimeoutVar) "\$_mt_to " else ""
        val caps = sessionCapabilities

        // 0. Guarded `cmd tare ...` -> Chỉ chạy khi service tare thực sự tồn tại (Honor MagicOS không có -> bỏ qua)
        if (tokens.size >= 2 && tokens[0] == "cmd" && tokens[1] == "tare") {
            if (caps?.probed == true && !caps.hasTareService) return "true"
            return "if cmd -l 2>/dev/null | grep -qw tare; then $trimmed >/dev/null 2>&1 || true; fi"
        }

        // 0b. Guarded `cmd app_hibernation ...` -> Android 12+ & service tồn tại
        if (tokens.size >= 2 && tokens[0] == "cmd" && tokens[1] == "app_hibernation") {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || (caps?.probed == true && !caps.hasAppHibernationService)) {
                return "true"
            }
            return "{ $trimmed >/dev/null 2>&1 || true; }"
        }

        // 0c. Guarded `cmd content set-master-sync-automatically`
        if (tokens.size >= 3 && tokens[0] == "cmd" && tokens[1] == "content" && tokens[2] == "set-master-sync-automatically") {
            val enableSync = tokens.getOrNull(3)?.equals("true", ignoreCase = true) == true || tokens.getOrNull(3) == "1"
            return buildSafeMasterSyncCmd(enableSync)
        }

        // 1. Chuẩn hóa cmd appops set [--user N] [--uid] <pkg> <OP> <mode>
        if (tokens.size >= 4 && ((tokens[0] == "cmd" && tokens[1] == "appops" && tokens[2] == "set") || (tokens[0] == "appops" && tokens[1] == "set"))) {
            var idx = if (tokens[0] == "cmd") 3 else 2
            var targetUserId = 0
            var hasUidFlag = false
            while (idx < tokens.size) {
                when (tokens[idx]) {
                    "--user", "-u" -> {
                        targetUserId = tokens.getOrNull(idx + 1)?.toIntOrNull() ?: 0
                        idx += 2
                    }
                    "--uid" -> {
                        hasUidFlag = true
                        idx += 1
                    }
                    else -> break
                }
            }
            if (idx + 1 < tokens.size) {
                val pkg = tokens[idx]
                val op = tokens[idx + 1]
                val mode = tokens.getOrElse(idx + 2) { "allow" }
                if (pkg in protectedHangingAppOpsPackages) return "true"
                if (!isPackageInstalledQuick(pkg)) return "true"
                if (targetUserId != 0 && !isUserActive(targetUserId)) return "true"
                if (supportedAppOpsCache[op] == false) return "true"
                val needsUid = hasUidFlag || op in setOf("POST_NOTIFICATION", "SYSTEM_ALERT_WINDOW", "RUN_IN_BACKGROUND", "RUN_ANY_IN_BACKGROUND")
                val uidHook = if (needsUid) "; ${toPrefix}cmd appops set --uid $pkg $op $mode >/dev/null 2>&1 || true" else ""
                return "{ if ${toPrefix}cmd appops get --user $targetUserId $pkg $op >/dev/null 2>&1; then ${toPrefix}cmd appops set --user $targetUserId $pkg $op $mode >/dev/null 2>&1 || ${toPrefix}cmd appops set $pkg $op $mode >/dev/null 2>&1 || ${toPrefix}appops set $pkg $op $mode >/dev/null 2>&1 || true$uidHook; fi; true; }"
            }
        }

        // 2. Chuẩn hóa dumpsys / cmd deviceidle whitelist +<pkg>
        if ((trimmed.startsWith("dumpsys deviceidle whitelist +") || trimmed.startsWith("cmd deviceidle whitelist +")) && tokens.size >= 4) {
            val plusPkg = tokens[3]
            val pkg = plusPkg.removePrefix("+").trim()
            if (pkg.isNotEmpty()) {
                if (!isPackageInstalledQuick(pkg)) return "true"
                val tareLine = if (caps?.probed == true && !caps.hasTareService) {
                    ""
                } else if (caps?.probed == true && caps.hasTareService) {
                    "cmd tare set-vip --user 0 $pkg true >/dev/null 2>&1 || true; "
                } else {
                    "if cmd -l 2>/dev/null | grep -qw tare; then cmd tare set-vip --user 0 $pkg true >/dev/null 2>&1 || true; fi; "
                }
                return "{ cmd deviceidle whitelist +$pkg >/dev/null 2>&1; dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1; cmd deviceidle sys-whitelist +$pkg >/dev/null 2>&1; cmd appops set --user 0 $pkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; cmd appops set --uid $pkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; cmd appops set --user 0 $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1; cmd appops set --uid $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1; am set-standby-bucket --user 0 $pkg active >/dev/null 2>&1; cmd activity set-inactive --user 0 $pkg false >/dev/null 2>&1; ${tareLine}true; }"
            }
        }

        // 3. Chuẩn hóa pm grant <pkg> <perm>
        if (tokens.size >= 4 && tokens[0] == "pm" && tokens[1] == "grant") {
            var idx = 2
            var targetUserId = 0
            if (tokens[idx] == "--user" || tokens[idx] == "-u") {
                targetUserId = tokens.getOrNull(idx + 1)?.toIntOrNull() ?: 0
                idx += 2
            }
            if (idx + 1 < tokens.size) {
                val pkg = tokens[idx]
                val perm = tokens[idx + 1]
                if (!isPackageInstalledQuick(pkg)) return "true"
                if (targetUserId != 0 && !isUserActive(targetUserId)) return "true"
                return when {
                    perm.endsWith("SCHEDULE_EXACT_ALARM") ->
                        buildSafeAppOpsCmd(pkg, "SCHEDULE_EXACT_ALARM", "allow")
                    perm.endsWith("SYSTEM_ALERT_WINDOW") ->
                        buildSafeAppOpsCmd(pkg, "SYSTEM_ALERT_WINDOW", "allow", includeUid = true)
                    perm.endsWith("PICTURE_IN_PICTURE") ->
                        buildSafeAppOpsCmd(pkg, "PICTURE_IN_PICTURE", "allow")
                    perm.endsWith("WRITE_SETTINGS") ->
                        buildSafeAppOpsCmd(pkg, "WRITE_SETTINGS", "allow")
                    perm.endsWith("PACKAGE_USAGE_STATS") ->
                        "{ cmd appops set --user 0 $pkg GET_USAGE_STATS allow >/dev/null 2>&1 || true; pm grant --user 0 $pkg $perm >/dev/null 2>&1 || true; }"
                    perm.endsWith("PROJECT_MEDIA") ->
                        buildSafeAppOpsCmd(pkg, "PROJECT_MEDIA", "allow")
                    perm.endsWith("ACCESS_RESTRICTED_SETTINGS") ->
                        buildSafeAppOpsCmd(pkg, "ACCESS_RESTRICTED_SETTINGS", "allow", includeUid = true)
                    perm.endsWith("POST_NOTIFICATIONS") ->
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            "{ pm grant --user $targetUserId $pkg $perm >/dev/null 2>&1 || pm grant $pkg $perm >/dev/null 2>&1 || true; cmd appops set --user 0 $pkg POST_NOTIFICATION allow >/dev/null 2>&1 || true; }"
                        } else {
                            buildSafeAppOpsCmd(pkg, "POST_NOTIFICATION", "allow", includeUid = true)
                        }
                    else ->
                        "{ pm grant --user $targetUserId $pkg $perm >/dev/null 2>&1 || pm grant $pkg $perm >/dev/null 2>&1 || true; }"
                }
            }
        }

        // 4. Chuẩn hóa cmd notification set_...
        if (tokens.size >= 3 && tokens[0] == "cmd" && tokens[1] == "notification" && tokens[2].startsWith("set_")) {
            if (tokens[2] == "set_dnd") {
                return tokens.joinToString(" ")
            }
            val pkg = tokens.getOrElse(3) { "" }
            return if (pkg.isNotEmpty() && !pkg.startsWith("-") && isPackageInstalledQuick(pkg)) {
                "{ ${buildSafeAppOpsCmd(pkg, "POST_NOTIFICATION", "allow", includeUid = true)} ${buildSafeAppOpsCmd(pkg, "SYSTEM_ALERT_WINDOW", "allow", includeUid = true)} true; }"
            } else "true"
        }

        // 5. Chuẩn hóa settings put <ns> <key> <val>
        if (tokens.size >= 5 && tokens[0] == "settings" && tokens[1] == "put") {
            val ns = tokens[2].lowercase()
            val key = tokens[3]
            if (ns == "system" && (key == "location_nlp_pkg" || key == "location_fuzzy_enabled")) {
                return "true"
            }
            val value = tokens.subList(4, tokens.size).joinToString(" ").trim('"')
            if (hasWriteSecureSettingsPermission()) {
                writeAndroidSetting(ns, key, value)
                if (key == "lock_screen_show_notifications" || key == "lock_screen_allow_private_notifications") {
                    writeAndroidSetting("secure", key, value)
                    writeAndroidSetting("system", key, value)
                }
            }
            val extraHook = when (key) {
                "ui_night_mode" -> if (value == "2") "; cmd uimode night yes >/dev/null 2>&1" else if (value == "1") "; cmd uimode night no >/dev/null 2>&1" else ""
                "location_mode" -> if (value != "0") "; cmd location set-location-enabled true >/dev/null 2>&1" else "; cmd location set-location-enabled false >/dev/null 2>&1"
                "lock_screen_show_notifications", "lock_screen_allow_private_notifications" ->
                    "; settings put secure $key $value >/dev/null 2>&1; cmd settings put secure $key $value >/dev/null 2>&1; settings put system $key $value >/dev/null 2>&1"
                "min_refresh_rate", "peak_refresh_rate" -> {
                    val num = value.toFloatOrNull()?.toInt() ?: 60
                    val modeVal = if (num >= 120) "2" else if (num >= 90) "1" else "0"
                    val smartLtpo = if (num >= 120) "0" else "1"
                    "; settings put system SmartModeStatus $modeVal >/dev/null 2>&1; settings put secure refresh_rate_mode $modeVal >/dev/null 2>&1; settings put system hw_refresh_rate_mode $modeVal >/dev/null 2>&1; settings put system smart_refresh_rate $smartLtpo >/dev/null 2>&1"
                }
                else -> ""
            }
            return "{ settings put $ns $key \"$value\" >/dev/null 2>&1 || cmd settings put $ns $key \"$value\" >/dev/null 2>&1$extraHook; true; }"
        }

        // 5b. Guarded `pm suspend` / `cmd package suspend` -> Kiểm tra gói & SDK >= 9, fallback sang pm disable-user
        if ((tokens.size >= 3 && tokens[0] == "pm" && tokens[1] == "suspend") ||
            (tokens.size >= 4 && tokens[0] == "cmd" && tokens[1] == "package" && tokens[2] == "suspend")
        ) {
            val pkg = tokens.last()
            if (pkg.startsWith("-")) return "true"
            return buildSafeSuspendOrDisableCmd(pkg)
        }

        // 6. Chuẩn hóa pm disable-user / pm disable <pkg> -> Kiểm tra tồn tại gói trước khi thao tác, fallback an toàn (không xóa dữ liệu người dùng ngoài ý muốn)
        if (tokens.size >= 3 && tokens[0] == "pm" && (tokens[1] == "disable-user" || tokens[1] == "disable")) {
            val pkg = tokens.last()
            if (!isPackageInstalledQuick(pkg)) return "true"
            return "{ if pm path $pkg >/dev/null 2>&1; then am force-stop $pkg >/dev/null 2>&1 || true; pm disable-user --user 0 $pkg >/dev/null 2>&1 || pm disable $pkg >/dev/null 2>&1 || true; fi; cmd appops set --user 0 $pkg RUN_IN_BACKGROUND ignore >/dev/null 2>&1 || true; cmd appops set --user 0 $pkg RUN_ANY_IN_BACKGROUND ignore >/dev/null 2>&1 || true; am set-standby-bucket --user 0 $pkg restricted >/dev/null 2>&1 || true; true; }"
        }

        // 6b. Chuẩn hóa pm enable [--user N] <pkg_or_comp> -> Kiểm tra user & gói có trong ROM
        if (tokens.size >= 3 && tokens[0] == "pm" && tokens[1] == "enable") {
            var userId = 0
            val uIdx = tokens.indexOfFirst { it == "--user" || it == "-u" }
            if (uIdx != -1) {
                userId = tokens.getOrNull(uIdx + 1)?.toIntOrNull() ?: 0
            }
            val target = tokens.last()
            return buildSafeEnablePackageCmd(target, userId)
        }

        // 7. Chuẩn hóa pm revoke <pkg> <perm> (Kiểm tra gói tồn tại & hỗ trợ --user 0)
        if (tokens.size >= 4 && tokens[0] == "pm" && tokens[1] == "revoke") {
            val hasUser = tokens[2] == "--user" || tokens[2] == "-u"
            val pkg = if (hasUser) tokens.getOrElse(4) { "" } else tokens[2]
            val perm = if (hasUser) tokens.getOrElse(5) { "" } else tokens[3]
            if (pkg.isEmpty() || perm.isEmpty() || !isPackageInstalledQuick(pkg)) return "true"
            return "{ if pm path $pkg >/dev/null 2>&1; then pm revoke --user 0 $pkg $perm >/dev/null 2>&1 || pm revoke $pkg $perm >/dev/null 2>&1 || true; fi; true; }"
        }

        // 8. Chuẩn hóa cmd role (add-role-holder / remove-role-holder) -> Kiểm tra Role service & Android 10+
        if (tokens.size >= 3 && tokens[0] == "cmd" && tokens[1] == "role") {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || (caps?.probed == true && !caps.hasRoleService)) {
                return "true"
            }
            val subOp = tokens[2]
            val nonFlagTokens = tokens.drop(3).filter { !it.startsWith("-") && it != "0" }
            if (subOp == "add-role-holder" && nonFlagTokens.size >= 2) {
                val roleName = nonFlagTokens[0]
                val pkg = nonFlagTokens[1]
                if (!isPackageInstalledQuick(pkg)) return "true"
                return "{ cmd role add-role-holder --user 0 $roleName $pkg 1 >/dev/null 2>&1 || cmd role add-role-holder --user 0 $roleName $pkg >/dev/null 2>&1 || cmd role add-role-holder $roleName $pkg >/dev/null 2>&1 || true; }"
            } else if (subOp == "remove-role-holder" && nonFlagTokens.size >= 2) {
                val roleName = nonFlagTokens[0]
                val pkg = nonFlagTokens[1]
                if (!isPackageInstalledQuick(pkg)) return "true"
                return "{ cmd role remove-role-holder --user 0 $roleName $pkg 1 >/dev/null 2>&1 || cmd role remove-role-holder --user 0 $roleName $pkg >/dev/null 2>&1 || cmd role remove-role-holder $roleName $pkg >/dev/null 2>&1 || true; }"
            }
            return "{ $trimmed >/dev/null 2>&1 || true; }"
        }

        // 8b. Chuẩn hóa am start / am start-service / am set-standby-bucket / am force-stop
        if (tokens.size >= 2 && tokens[0] == "am") {
            val sub = tokens[1]
            return when (sub) {
                "start" -> {
                    val base = trimmed.replace("am start ", "am start --user 0 --activity-clear-top --activity-single-top --activity-no-animation ")
                    "{ $base >/dev/null 2>&1 || $trimmed >/dev/null 2>&1 || true; }"
                }
                "start-service", "set-standby-bucket", "force-stop", "clear" -> {
                    "{ $trimmed >/dev/null 2>&1 || true; }"
                }
                else -> "{ $trimmed >/dev/null 2>&1 || true; }"
            }
        }

        // 8c. Chuẩn hóa cmd sensor_privacy / cmd locale / cmd device_config
        if (tokens.size >= 3 && tokens[0] == "cmd" && tokens[1] in listOf("sensor_privacy", "locale", "device_config")) {
            return "{ $trimmed >/dev/null 2>&1 || true; }"
        }

        // 9. Chuẩn hóa device_config và setprop (tránh lỗi SecurityException trên Android 14-17 làm gãy batch)
        if (tokens[0] == "device_config" || tokens[0] == "setprop") {
            return "{ $trimmed >/dev/null 2>&1 || true; }"
        }

        return trimmed
    }

    /**
     * Thực thi hàng loạt lệnh trong MỘT tiến trình Shizuku hoặc Direct WLAN ADB duy nhất theo từng cụm (chunk 25 lệnh),
     * giúp tốc độ nhanh gấp 15 lần và TRIỆT TIÊU HOÀN TOÀN lỗi nghẽn tiến trình!
     */
    suspend fun executeBatch(commands: List<String>): List<ShellResult> = withContext(Dispatchers.IO) {
        val cleanCommands = commands.map { sanitizeShellCommand(it) }.filter { it.isNotEmpty() }
        if (cleanCommands.isEmpty()) return@withContext emptyList()

        // Đảm bảo làm mới trạng thái nếu Shizuku hoặc Direct ADB đang sống nhưng state chưa kịp cập nhật
        if (!_state.value.isAdbReady && !isUserDisconnected) {
            if ((!isUserWlanDisconnected && directAdbManager.verifyConnectedIo()) ||
                (isShizukuInstalled() && pingShizukuBinderResilient() && checkShizukuPermissionResilient())
            ) {
                checkShizukuStatus()
            }
        }
        if (_state.value.isAdbReady) {
            ensurePreflightCapabilities()
        }

        val currentState = _state.value
        val useDirectAdbBatch = !isUserDisconnected && !isUserWlanDisconnected && (
            directAdbManager.verifyConnectedIo() ||
                (currentState.isWirelessAdbConnected && directAdbManager.activePort in 1..65535 && checkAdbWifiSystemSetting().first)
            )
        val useShizukuBatch = currentState.isShizukuRunning &&
            currentState.isShizukuPermissionGranted &&
            pingShizukuBinderResilient()

        if (!useDirectAdbBatch && !useShizukuBatch) {
            if (currentState.isShizukuRunning && !pingShizukuBinderResilient()) {
                checkShizukuStatus()
            }
            if (!_state.value.isAdbReady && !currentState.isRootAvailable) {
                val noAdbMsg = "Chưa kết nối Shizuku / WLAN ADB (UID 2000): Lệnh này yêu cầu quyền hệ thống. Hãy kết nối Gỡ lỗi Wi-Fi hoặc Shizuku trước khi thực hiện!"
                return@withContext cleanCommands.map { cmd ->
                    if (isCommandRequiringAdb(cmd)) {
                        ShellResult(
                            command = cmd,
                            exitCode = 1,
                            output = "",
                            error = noAdbMsg,
                            modeUsed = ShellMode.NONE
                        )
                    } else {
                        execute(cmd)
                    }
                }
            }
            return@withContext cleanCommands.map { execute(it) }
        }

        val results = mutableListOf<ShellResult>()
        val batchModeUsed = if (useDirectAdbBatch) ShellMode.WIRELESS_ADB else ShellMode.SHIZUKU

        // Chia thành từng lô 15 lệnh, mỗi lô chỉ mở ĐÚNG 1 tiến trình / stream duy nhất và có probe `timeout 8` chống treo cmd appops
        val chunks = cleanCommands.chunked(15)
        for (chunk in chunks) {
            val scriptBuilder = StringBuilder(
                "export PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin:\$PATH\n" +
                    "_mt_to=\"\"\n" +
                    "timeout 8 true >/dev/null 2>&1 && _mt_to=\"timeout 8\"\n"
            )
            chunk.forEachIndexed { idx, origCmd ->
                val resilientCmd = buildResilientShellCommand(origCmd, useBatchTimeoutVar = true)
                scriptBuilder.append("echo \"__MT_B_\"\"${idx}__\"\n")
                scriptBuilder.append(resilientCmd).append("\n")
                scriptBuilder.append("__mt_ec=\$?\n")
                scriptBuilder.append("echo \"__MT_E_\"\"${idx}__:\$__mt_ec\"\n")
            }

            val chunkResults: Triple<Int, String, String> = if (useDirectAdbBatch) {
                val directRes = directAdbManager.executeCommand(scriptBuilder.toString(), timeoutSec = 25L)
                if (directRes.exitCode != 0 && !directRes.output.contains("__MT_B_")) {
                    Triple(if (directRes.exitCode == 124) 124 else -1, directRes.output, directRes.error)
                } else {
                    Triple(directRes.exitCode, directRes.output, directRes.error)
                }
            } else {
                activeShizukuExecCount.incrementAndGet()
                try {
                    val newProcMethod = getShizukuNewProcessMethod()
                    val proc = shizukuExecMutex.withLock {
                        newProcMethod.invoke(null, arrayOf("sh", "-c", scriptBuilder.toString()), null, null) as Process
                    }
                    val (code, outText, errText) = runProcessSafely(proc, 20L)
                    Triple(code, outText, errText)
                } catch (e: Throwable) {
                    val realCause = if (e is InvocationTargetException && e.targetException != null) e.targetException else e
                    Triple(-1, "", realCause.localizedMessage ?: realCause.message ?: "Shizuku execution error")
                } finally {
                    activeShizukuExecCount.decrementAndGet()
                }
            }

            val (batchExit, rawBatchOut, batchErr) = chunkResults
            val batchOut = rawBatchOut
                .replace(Regex("\\u001B\\[[0-9;?]*[ -/]*[@-~]"), "")
                .replace(Regex("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F\\u007F]"), "")

            if (batchExit == -1 && !batchOut.contains("__MT_B_")) {
                if (batchModeUsed == ShellMode.SHIZUKU) {
                    checkShizukuStatus()
                }
                val stillReady = (batchModeUsed == ShellMode.WIRELESS_ADB && directAdbManager.verifyConnectedIo()) ||
                    (batchModeUsed == ShellMode.SHIZUKU && pingShizukuBinderResilient() && checkShizukuPermissionResilient())
                if (!stillReady) {
                    if (batchModeUsed == ShellMode.WIRELESS_ADB) {
                        saveWlanState(false, currentState.wirelessAdbPort, true)
                        _state.update {
                            it.copy(
                                isWirelessAdbConnected = false,
                                mode = if (it.isShizukuRunning && it.isShizukuPermissionGranted) ShellMode.SHIZUKU else ShellMode.NONE,
                                statusMessage = "Mất kết nối WLAN socket"
                            )
                        }
                    }
                    // Dịch vụ ADB/Shizuku vừa ngắt -> Không spam thử lại toàn bộ chunk
                    val disconnectMsg = if (batchModeUsed == ShellMode.SHIZUKU) {
                        "Lỗi kết nối Shizuku: Dịch vụ Shizuku chưa chạy hoặc đã bị đóng ($batchErr)."
                    } else {
                        batchErr.ifBlank { "Direct ADB tạm ngắt kết nối." }
                    }
                    for (origCmd in chunk) {
                        results.add(
                            ShellResult(
                                command = origCmd,
                                exitCode = -1,
                                output = "",
                                error = disconnectMsg,
                                modeUsed = batchModeUsed
                            )
                        )
                    }
                    break
                }
                // Nếu vẫn còn kết nối thì mới fallback từng lệnh
                for (origCmd in chunk) {
                    results.add(execute(origCmd))
                }
            } else {
                // Phân tách kết quả từng lệnh từ stdout của batch (kể cả khi một lệnh ở cuối bị timeout 124)
                for (idx in chunk.indices) {
                    val origCmd = chunk[idx]
                    val startMarker = "__MT_B_${idx}__"
                    val endMarkerPrefix = "__MT_E_${idx}__:"
                    val startPos = batchOut.indexOf(startMarker)
                    val endPos = if (startPos != -1) batchOut.indexOf(endMarkerPrefix, startPos) else -1
                    if (startPos != -1 && endPos != -1 && endPos > startPos) {
                        val rawCmdOut = batchOut.substring(startPos + startMarker.length, endPos)
                        val cmdOut = rawCmdOut.lines().filterNot { line ->
                            val l = line.trim()
                            l == origCmd || l.contains("__mt_ec=") || l.contains("\"__MT_E_\"") || l.contains("\"__MT_B_\"")
                        }.joinToString("\n").trim()
                        val afterEnd = batchOut.substring(endPos + endMarkerPrefix.length)
                        val exitLine = afterEnd.lineSequence().firstOrNull()?.trim() ?: "0"
                        val cmdExit = exitLine.toIntOrNull() ?: 0
                        val itemRes = ShellResult(
                            command = origCmd,
                            exitCode = cmdExit,
                            output = cmdOut,
                            error = if (cmdExit != 0) batchErr.ifBlank { cmdOut } else "",
                            modeUsed = batchModeUsed
                        )
                        if (itemRes.isSuccess) {
                            recordCommandSideEffects(origCmd)
                        }
                        results.add(itemRes)
                    } else {
                        val itemExit = if (batchExit == 0) 0 else batchExit
                        val itemErr = if (itemExit == 124) {
                            "Quá thời gian thực thi lệnh (Timeout) — đã tự động bỏ qua để không treo hệ thống"
                        } else if (itemExit == 0) "" else batchErr
                        val itemRes = ShellResult(
                            command = origCmd,
                            exitCode = itemExit,
                            output = "",
                            error = itemErr,
                            modeUsed = batchModeUsed
                        )
                        if (itemRes.isSuccess) {
                            recordCommandSideEffects(origCmd)
                        }
                        results.add(itemRes)
                    }
                }
            }
        }
        results
    }

    suspend fun execute(command: String, isBackground: Boolean = false): ShellResult = withContext(Dispatchers.IO) {
        val trimmed = sanitizeShellCommand(command)
        if (trimmed.isEmpty()) {
            return@withContext ShellResult("", 0, "", "", _state.value.mode)
        }

        if (isBackground && isSafeCacheableReadCommand(trimmed)) {
            val cached = bgReadCache[trimmed]
            if (cached != null && (android.os.SystemClock.elapsedRealtime() - cached.timestampMs) < 2_500L) {
                return@withContext cached.result
            }
        }

        if (!isBackground) {
            interactivePriorityWaiters.incrementAndGet()
        } else {
            var waited = 0
            while (interactivePriorityWaiters.get() > 0 && waited < 450) {
                delay(30L)
                waited += 30
            }
        }
        try {
            // Tự động đồng bộ trạng thái Shizuku hoặc Direct ADB nếu đang sống nhưng state chưa kịp cập nhật
            if (!_state.value.isAdbReady && !isUserDisconnected) {
                if ((!isUserWlanDisconnected && directAdbManager.verifyConnectedIo()) ||
                    (isShizukuInstalled() && pingShizukuBinderResilient() && checkShizukuPermissionResilient())
                ) {
                    checkShizukuStatus()
                }
            }
            if (_state.value.isAdbReady && sessionCapabilities?.probed != true && !trimmed.contains("__PF_SERVICES__")) {
                ensurePreflightCapabilities()
            }

            val currentState = _state.value
            val tokens = tokenizeCommand(trimmed)

            // 0. Ưu tiên TỐI CAO: Direct WLAN ADB độc lập (UID 2000 Native qua TLS socket, cho phép tự nối lại khi socket nghỉ)
            val (adbWifiOn, devOn) = checkAdbWifiSystemSetting()
            val canUseDirectAdb = !isUserDisconnected && !isUserWlanDisconnected && devOn && adbWifiOn && (
                directAdbManager.verifyConnectedIo() ||
                    (currentState.isWirelessAdbConnected && directAdbManager.activePort in 1..65535)
                )
            if (canUseDirectAdb) {
                val resilientCmd = buildResilientShellCommand(trimmed)
                val directRes = directAdbManager.executeCommand(resilientCmd)
                if (directRes.isSuccess) {
                    recordCommandSideEffects(trimmed)
                    val finalRes = directRes.copy(command = trimmed)
                    if (isBackground && isSafeCacheableReadCommand(trimmed)) {
                        bgReadCache[trimmed] = CachedShellRead(finalRes, android.os.SystemClock.elapsedRealtime())
                    }
                    return@withContext finalRes
                }
                val isSocketDisconnected = directRes.exitCode != 0 && (
                    directRes.error.contains("Broken pipe", true) ||
                        directRes.error.contains("Not connected", true) ||
                        directRes.error.contains("chưa được kết nối", true) ||
                        directRes.error.contains("chưa mở", true) ||
                        directRes.error.contains("closed", true) ||
                        directRes.error.contains("reset", true)
                    )
                if (isSocketDisconnected) {
                    saveWlanState(false, currentState.wirelessAdbPort, true)
                    _state.update {
                        it.copy(
                            isWirelessAdbConnected = false,
                            mode = if (it.isShizukuRunning && it.isShizukuPermissionGranted) ShellMode.SHIZUKU else it.mode,
                            statusMessage = if (it.isShizukuRunning && it.isShizukuPermissionGranted) "Đã chuyển dự phòng sang Shizuku (UID 2000)" else "Mất kết nối WLAN socket"
                        )
                    }
                    val shizukuReadyForFailover = (currentState.isShizukuRunning && currentState.isShizukuPermissionGranted) ||
                        (!isUserDisconnected && isShizukuInstalled() && pingShizukuBinderResilient() && checkShizukuPermissionResilient())
                    if (!shizukuReadyForFailover) {
                        return@withContext directRes.copy(command = trimmed)
                    }
                    // Nếu Shizuku đang sẵn sàng -> Tự động chuyển tiếp (Zero-Downtime Failover) xuống nhánh Shizuku ngay bên dưới!
                } else {
                    return@withContext directRes.copy(command = trimmed)
                }
            }

        // 1. Ưu tiên Shizuku (UID 2000 Shell thực sự cấp độ WebADB • Tương thích Android 11 -> Android 17)
        val isShizukuLiveNow = !isUserDisconnected &&
            isShizukuInstalled() &&
            pingShizukuBinderResilient() &&
            checkShizukuPermissionResilient()
        if (currentState.isShizukuRunning && !isShizukuLiveNow) {
            checkShizukuStatus()
        }
        if (isShizukuLiveNow) {
            val resilientCmd = buildResilientShellCommand(trimmed)
            val wrappedCommand = "export PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin:\$PATH; $resilientCmd"

            var lastException: Throwable? = null
            for (attempt in 1..2) {
                try {
                    activeShizukuExecCount.incrementAndGet()
                    val (code, outText, errText) = try {
                        val newProcMethod = getShizukuNewProcessMethod()
                        // Truyền `null` cho env để giữ nguyên BOOTCLASSPATH & biến môi trường gốc của shizuku_server trên Android 11-17
                        val proc = shizukuExecMutex.withLock {
                            newProcMethod.invoke(null, arrayOf("sh", "-c", wrappedCommand), null, null) as Process
                        }
                        runProcessSafely(proc, 12L)
                    } finally {
                        activeShizukuExecCount.decrementAndGet()
                    }

                    val res = ShellResult(
                        command = trimmed,
                        exitCode = code,
                        output = outText,
                        error = errText,
                        modeUsed = ShellMode.SHIZUKU
                    )
                    if (res.isSuccess) {
                        recordCommandSideEffects(trimmed)
                        if (isBackground && isSafeCacheableReadCommand(trimmed)) {
                            bgReadCache[trimmed] = CachedShellRead(res, android.os.SystemClock.elapsedRealtime())
                        }
                        return@withContext res
                    } else if (attempt == 1 && (res.exitCode == 137 || res.error.contains("binder", true) || res.error.contains("dead", true))) {
                        delay(50L)
                        continue
                    } else {
                        return@withContext res
                    }
                } catch (e: Throwable) {
                    lastException = e
                    if (attempt == 1) {
                        delay(50L)
                    }
                }
            }

            checkShizukuStatus()
            val realCause = if (lastException is InvocationTargetException && lastException.targetException != null) {
                lastException.targetException
            } else {
                lastException
            }
            val errorMsg = realCause?.localizedMessage ?: realCause?.message ?: "Chưa khởi chạy"
            val detailMsg = if (errorMsg.contains("newProcess", true)) {
                "Lỗi tiến trình Shizuku (shizuku.newProcess): Shizuku Server bị treo hoặc từ chối tạo tiến trình mới. Cách sửa: Mở app Shizuku -> Bấm Tạm dừng (Stop) -> Bấm Bắt đầu (Start) lại, sau đó Cấp lại quyền cho MagicTune."
            } else {
                "Lỗi kết nối Shizuku: Dịch vụ Shizuku chưa chạy hoặc đã bị đóng ($errorMsg). Vui lòng mở app Shizuku và bấm 'Bắt đầu' (Start) qua Gỡ lỗi Wi-Fi trước khi thực hiện!"
            }
            return@withContext ShellResult(
                command = trimmed,
                exitCode = -1,
                output = "",
                error = detailMsg,
                modeUsed = ShellMode.SHIZUKU
            )
        }

        // 2. Nếu có Root (su)
        if (currentState.isRootAvailable) {
            try {
                val resilientCmd = buildResilientShellCommand(trimmed)
                val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", resilientCmd))
                val (code, outText, errText) = runProcessSafely(proc, 15L)
                val res = ShellResult(
                    command = trimmed,
                    exitCode = code,
                    output = outText,
                    error = errText,
                    modeUsed = ShellMode.ROOT
                )
                if (res.isSuccess) {
                    recordCommandSideEffects(trimmed)
                    return@withContext res
                }
            } catch (_: Exception) {}
        }

        // 3. Nếu đang kết nối Wireless ADB và máy có sẵn binary /system/bin/adb
        if (currentState.isWirelessAdbConnected && File("/system/bin/adb").exists()) {
            try {
                val env = arrayOf(
                    "HOME=${context.filesDir.absolutePath}",
                    "TMPDIR=${context.cacheDir.absolutePath}",
                    "ADB_VENDOR_KEYS=${context.filesDir.absolutePath}"
                )
                val resilientCmd = buildResilientShellCommand(trimmed)
                val proc = Runtime.getRuntime().exec(
                    arrayOf("/system/bin/adb", "-s", "127.0.0.1:${currentState.wirelessAdbPort}", "shell", resilientCmd),
                    env,
                    context.filesDir
                )
                val (code, outText, errText) = runProcessSafely(proc, 6L)
                if (code != 124) {
                    val candidate = ShellResult(
                        command = trimmed,
                        exitCode = code,
                        output = outText,
                        error = errText,
                        modeUsed = ShellMode.WIRELESS_ADB
                    )
                    if (candidate.isSuccess &&
                        !errText.contains("device offline", true) &&
                        !errText.contains("unauthorized", true) &&
                        !errText.contains("more than one device", true)
                    ) {
                        recordCommandSideEffects(trimmed)
                        return@withContext candidate
                    }
                }
            } catch (_: Exception) {}
        }

        // 4. Khi KHÔNG có Shizuku / Root / WLAN ADB thực tế:
        // Chỉ hỗ trợ ghi Settings nếu app đã được cấp quyền WRITE_SECURE_SETTINGS thực sự.
        if (hasWriteSecureSettingsPermission() && tokens.isNotEmpty() && tokens[0] == "settings") {
            val handled = executeViaAndroidBridgeAndPersistence(trimmed, currentState)
            if (handled != null) {
                return@withContext handled
            }
        }

        // 4b. Chặn triệt để fall-through lệnh đặc quyền / shell phức hợp vào shell cục bộ không quyền (tránh treo 10s/lệnh)
        if (!_state.value.isAdbReady && isCommandRequiringAdb(trimmed)) {
            return@withContext ShellResult(
                command = trimmed,
                exitCode = 1,
                output = "",
                error = "Chưa kết nối Shizuku / WLAN ADB (UID 2000): Lệnh này yêu cầu quyền hệ thống. Hãy kết nối Gỡ lỗi Wi-Fi hoặc Shizuku trước khi thực hiện!",
                modeUsed = ShellMode.NONE
            )
        }

        // 5. Thực thi trên Shell tiến trình cục bộ với cơ chế đọc bất đồng bộ chống treo
        try {
            val proc = Runtime.getRuntime().exec(arrayOf("sh", "-c", trimmed))
            val (code, outText, errText) = runProcessSafely(proc, 10L)
            val res = ShellResult(
                command = trimmed,
                exitCode = code,
                output = outText,
                error = errText,
                modeUsed = if (currentState.isWirelessAdbConnected) ShellMode.WIRELESS_ADB else ShellMode.LOCAL_LIMITED
            )
            if (res.isSuccess) {
                recordCommandSideEffects(trimmed)
            }
            return@withContext res
        } catch (e: Exception) {
            return@withContext ShellResult(
                command = trimmed,
                exitCode = -1,
                output = "",
                error = "Lỗi thực thi lệnh: ${e.message}",
                modeUsed = ShellMode.NONE
            )
        }
        } finally {
            if (!isBackground) {
                interactivePriorityWaiters.decrementAndGet()
            }
        }
    }

    /**
     * Thực thi đọc/ghi Settings hệ thống thực tế khi ứng dụng đã được cấp quyền WRITE_SECURE_SETTINGS.
     */
    private fun executeViaAndroidBridgeAndPersistence(
        cmd: String,
        currentState: ShellEngineState
    ): ShellResult? {
        val mode = if (currentState.isWirelessAdbConnected) ShellMode.WIRELESS_ADB else ShellMode.LOCAL_LIMITED
        val tokens = tokenizeCommand(cmd)
        if (tokens.size < 4 || tokens[0] != "settings") return null

        val op = tokens[1].lowercase()
        val namespace = tokens[2].lowercase()
        val key = tokens[3]
        if (namespace !in listOf("system", "secure", "global")) return null

        return when (op) {
            "get" -> {
                val persisted = getPersistedSetting(namespace, key)
                if (persisted != null) {
                    ShellResult(cmd, 0, persisted, "", mode)
                } else {
                    val sysVal = readAndroidSetting(namespace, key)
                    ShellResult(cmd, 0, sysVal ?: "null", "", mode)
                }
            }
            "put" -> {
                val value = if (tokens.size >= 5) tokens.subList(4, tokens.size).joinToString(" ").trim('"') else ""
                val written = writeAndroidSetting(namespace, key, value)
                if (written) {
                    setPersistedSetting(namespace, key, value)
                    ShellResult(cmd, 0, "Đã lưu $namespace/$key = $value", "", mode)
                } else {
                    ShellResult(cmd, 1, "", "Từ chối quyền: Không thể ghi $namespace/$key (cần Shizuku hoặc ADB)", mode)
                }
            }
            "delete" -> {
                setPersistedSetting(namespace, key, null)
                ShellResult(cmd, 0, "Deleted $namespace/$key", "", mode)
            }
            else -> null
        }
    }

    private fun splitCompoundSubcommands(cmd: String): List<String> {
        val parts = mutableListOf<String>()
        val sb = StringBuilder()
        var inDoubleQuotes = false
        var inSingleQuotes = false
        var i = 0
        while (i < cmd.length) {
            val c = cmd[i]
            when {
                c == '"' && !inSingleQuotes -> {
                    inDoubleQuotes = !inDoubleQuotes
                    sb.append(c)
                }
                c == '\'' && !inDoubleQuotes -> {
                    inSingleQuotes = !inSingleQuotes
                    sb.append(c)
                }
                !inDoubleQuotes && !inSingleQuotes && c == ';' -> {
                    val part = sb.toString().trim()
                    if (part.isNotEmpty()) parts.add(part)
                    sb.clear()
                }
                !inDoubleQuotes && !inSingleQuotes && (c == '&' || c == '|') && i + 1 < cmd.length && cmd[i + 1] == c -> {
                    val part = sb.toString().trim()
                    if (part.isNotEmpty()) parts.add(part)
                    sb.clear()
                    i++
                }
                else -> sb.append(c)
            }
            i++
        }
        val tail = sb.toString().trim()
        if (tail.isNotEmpty()) parts.add(tail)
        return parts
    }

    private fun recordCommandSideEffects(cmd: String) {
        val subcommands = splitCompoundSubcommands(cmd)
        if (subcommands.isEmpty()) return
        for (subCmd in subcommands) {
            val cleaned = subCmd.substringBefore(" >/dev/null").substringBefore(" 2>/dev/null").trim()
            val tokens = tokenizeCommand(cleaned)
            if (tokens.isEmpty()) continue
            when (tokens[0]) {
                "settings" -> {
                    if (tokens.size >= 5 && tokens[1] == "put") {
                        val ns = tokens[2].lowercase()
                        val key = tokens[3]
                        val v = tokens.subList(4, tokens.size).joinToString(" ").trim('"')
                        setPersistedSetting(ns, key, v)
                        if (key == "lock_screen_show_notifications" || key == "lock_screen_allow_private_notifications") {
                            setPersistedSetting("secure", key, v)
                            setPersistedSetting("system", key, v)
                        }
                    } else if (tokens.size >= 4 && tokens[1] == "delete") {
                        setPersistedSetting(tokens[2].lowercase(), tokens[3], null)
                    }
                }
                "cmd" -> {
                    if (tokens.size >= 5 && tokens[1] == "appops" && tokens[2] == "set") {
                        val hasUserFlag = tokens.size >= 7 && (tokens[3] == "--user" || tokens[3] == "-u")
                        val offset = if (hasUserFlag) 2 else 0
                        val hasUidFlag = tokens.size >= 6 + offset && tokens[3 + offset] == "--uid"
                        val pkgIdx = 3 + offset + if (hasUidFlag) 1 else 0
                        val opIdx = pkgIdx + 1
                        if (tokens.size > opIdx + 1) {
                            val pkg = tokens[pkgIdx]
                            val op = tokens[opIdx]
                            val mode = tokens.last().lowercase()
                            val allowed = mode == "allow" || mode == "default"
                            kvPrefs.edit().putBoolean("appop_${pkg}_$op", allowed).apply()
                            if (op == "POST_NOTIFICATION" && allowed) {
                                kvPrefs.edit().putBoolean("post_notif_allowed_$pkg", true).apply()
                            }
                        }
                    } else if (tokens.size >= 4 && tokens[1] == "deviceidle" && tokens[2] == "whitelist") {
                        val target = tokens.last()
                        if (target.startsWith("+")) {
                            val pkg = target.removePrefix("+")
                            kvPrefs.edit().putBoolean("whitelist_$pkg", true).apply()
                        } else if (target.startsWith("-")) {
                            val pkg = target.removePrefix("-")
                            kvPrefs.edit().putBoolean("whitelist_$pkg", false).apply()
                        }
                    }
                }
                "dumpsys" -> {
                    if (tokens.size >= 4 && tokens[1] == "deviceidle" && tokens[2] == "whitelist") {
                        val target = tokens.last()
                        if (target.startsWith("+")) {
                            val pkg = target.removePrefix("+")
                            kvPrefs.edit().putBoolean("whitelist_$pkg", true).apply()
                        } else if (target.startsWith("-")) {
                            val pkg = target.removePrefix("-")
                            kvPrefs.edit().putBoolean("whitelist_$pkg", false).apply()
                        }
                    }
                }
                "pm" -> {
                    if (tokens.size >= 2 && tokens[1] in listOf("disable-user", "disable")) {
                        val pkg = tokens.last()
                        val set = (kvPrefs.getStringSet(KEY_DISABLED_PACKAGES, emptySet()) ?: emptySet()).toMutableSet()
                        set.add(pkg)
                        kvPrefs.edit().putStringSet(KEY_DISABLED_PACKAGES, set).apply()
                    } else if (tokens.size >= 2 && tokens[1] == "enable") {
                        val pkg = tokens.last()
                        val set = (kvPrefs.getStringSet(KEY_DISABLED_PACKAGES, emptySet()) ?: emptySet()).toMutableSet()
                        set.remove(pkg)
                        kvPrefs.edit().putStringSet(KEY_DISABLED_PACKAGES, set).apply()
                    }
                }
            }
        }
    }

    private fun readAndroidSetting(namespace: String, key: String): String? {
        return try {
            val cr = context.contentResolver
            when (namespace) {
                "system" -> Settings.System.getString(cr, key)
                "secure" -> Settings.Secure.getString(cr, key)
                "global" -> Settings.Global.getString(cr, key)
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun writeAndroidSetting(namespace: String, key: String, value: String): Boolean {
        return try {
            val cr = context.contentResolver
            when (namespace) {
                "system" -> Settings.System.putString(cr, key, value)
                "secure" -> Settings.Secure.putString(cr, key, value)
                "global" -> Settings.Global.putString(cr, key, value)
                else -> false
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun queryInstalledPackages(
        onlyThirdParty: Boolean,
        onlySystem: Boolean,
        onlyDisabled: Boolean
    ): String {
        val disabledSet = kvPrefs.getStringSet(KEY_DISABLED_PACKAGES, emptySet()) ?: emptySet()
        val uninstalledSet = kvPrefs.getStringSet(KEY_UNINSTALLED_PACKAGES, emptySet()) ?: emptySet()
        return try {
            val pm = context.packageManager
            val apps = pm.getInstalledApplications(0)
            val result = mutableListOf<String>()
            for (app in apps) {
                val pkg = app.packageName
                if (uninstalledSet.contains(pkg) && !onlyDisabled) continue
                val isSys = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val isDis = !app.enabled || disabledSet.contains(pkg)
                if (onlyThirdParty && isSys) continue
                if (onlySystem && !isSys) continue
                if (onlyDisabled && !isDis) continue
                result.add("package:$pkg")
            }
            if (onlyDisabled) {
                for (dPkg in disabledSet) {
                    val line = "package:$dPkg"
                    if (!result.contains(line)) result.add(line)
                }
            }
            result.joinToString("\n")
        } catch (_: Exception) {
            ""
        }
    }

    private fun postLocalTestNotification(title: String, message: String) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val channelId = "magictune_push_test_channel"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    channelId,
                    "MagicTune Kiểm Tra Chuông & Biểu Ngữ",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Kênh kiểm tra thông báo nổi (Banner) và âm thanh chuông"
                    enableVibration(true)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(channel)
            }
            val notif = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(com.example.R.drawable.ic_stat_magictune)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)
                .build()
            nm.notify((System.currentTimeMillis() % 10000).toInt(), notif)
        } catch (_: Throwable) {}
    }

    private fun isCommandRequiringAdb(rawCmd: String): Boolean {
        val trimmed = rawCmd.trim()
        if (trimmed.isEmpty()) return false
        val lower = trimmed.lowercase()
        if (lower.startsWith("{") ||
            lower.startsWith("if ") ||
            lower.startsWith("for ") ||
            lower.startsWith("while ") ||
            lower.startsWith("timeout ") ||
            lower.startsWith("export ") ||
            lower.contains("/data/local/tmp")
        ) {
            return true
        }
        val adbOnlyBins = setOf(
            "pm", "cmd", "am", "wm", "input", "dumpsys", "svc",
            "appops", "device_config", "setprop", "content", "service",
            "uiautomator", "logcat", "kill", "pkill", "chmod", "chown",
            "unzip", "screencap", "screenrecord", "ime", "sm"
        )
        val segments = trimmed.split(";", "&&", "||", "\n")
        for (seg in segments) {
            val parts = tokenizeCommand(seg.trim())
            if (parts.isEmpty()) continue
            val bin = parts[0].lowercase()
            if (bin in adbOnlyBins) return true
            if (bin == "settings" && parts.getOrNull(1)?.lowercase() in setOf("put", "delete", "reset")) {
                return true
            }
        }
        return false
    }

    private fun tokenizeCommand(cmd: String): List<String> {
        val tokens = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        for (c in cmd) {
            when {
                c == '"' -> {
                    inQuotes = !inQuotes
                }
                c.isWhitespace() && !inQuotes -> {
                    if (sb.isNotEmpty()) {
                        tokens.add(sb.toString())
                        sb.clear()
                    }
                }
                else -> sb.append(c)
            }
        }
        if (sb.isNotEmpty()) tokens.add(sb.toString())
        return tokens
    }

    companion object {
        private const val KEY_WLAN_CONNECTED = "wlan_connected"
        private const val KEY_WLAN_PORT = "wlan_port"
        private const val KEY_PAIR_PORT = "pair_port"
        private const val KEY_PERSISTENT_GRANT = "persistent_grant"
        private const val KEY_DISABLED_PACKAGES = "disabled_packages"
        private const val KEY_UNINSTALLED_PACKAGES = "uninstalled_packages"

        @Volatile
        private var instance: ShellEngine? = null

        fun getInstanceIfCreated(): ShellEngine? = instance

        fun getInstance(context: Context): ShellEngine {
            return instance ?: synchronized(this) {
                instance ?: ShellEngine(context.applicationContext).also { instance = it }
            }
        }
    }
}
