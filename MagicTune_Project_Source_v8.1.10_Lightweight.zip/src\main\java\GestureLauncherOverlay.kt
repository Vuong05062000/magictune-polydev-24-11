package com.example.core.widget

import com.example.core.perf.ScreenPowerOptimizer
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint as AndroidPaint
import android.graphics.Path as AndroidPath
import com.example.core.ocr.ScreenOcrEngine
import com.example.core.service.MagicTuneCtsAccessibilityService
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer
import kotlin.math.*

data class LauncherAppItem(
    val packageName: String,
    val label: String,
    val normalizedLabel: String
)

data class CustomTemplateMatch(
    val letter: Char,
    val similarityPercent: Float
)

data class UnifiedDrawingResultItem(
    val letter: Char,
    val packageName: String?,
    val label: String,
    val isPrimary: Boolean,
    val tagText: String,
    val similarityPercent: Int? = null,
    val isCustomTemplate: Boolean = false
)

/**
 * Màn hình Vẽ Chữ Cái (A-Z) & Viết Tên App Mở Nhanh Ứng Dụng:
 * - Khi vẽ 1 chữ cái (A-Z): Dựa hoàn toàn 100% theo danh sách thiết lập ở trang Tab 6 (Cài Đặt Chữ).
 * - Khi viết nhiều chữ cái / toàn bộ tên app (VD: GEMINI, ZALO, YOUTUBE...): Nhận diện từng chữ và tìm mở chính xác ứng dụng theo tên.
 * - Hoạt động độc lập 100% offline trên thiết bị, KHÔNG cần kết nối gỡ lỗi WLAN hay ADB.
 */
object GestureLauncherOverlay {
    private const val PREFS_NAME = "magictune_gestures"
    private var overlayView: ComposeView? = null
    private var windowManager: WindowManager? = null
    private var currentContext: Context? = null
    private val cacheWarmupScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private const val SNAPSHOT_LAUNCHER_APPS_FILE = "launcher_apps_cache_v1.json"

    @Volatile
    private var cachedInstalledApps: List<LauncherAppItem>? = null

    @Volatile
    private var cachedMappings: Map<Char, String>? = null

    @Volatile
    private var cachedCustomTemplateCount: Int? = null

    @Volatile
    private var lastCacheUpdateMs: Long = 0L

    private val cachedParsedTemplates = java.util.concurrent.ConcurrentHashMap<Char, List<List<Offset>>>()
    private val cachedTemplateSources = java.util.concurrent.ConcurrentHashMap<Char, String>()

    @Volatile
    private var autoTemplatesSeededInRam: Boolean = false

    fun peekCachedInstalledApps(): List<LauncherAppItem>? = cachedInstalledApps

    fun peekOrHydrateInstalledApps(context: Context): List<LauncherAppItem> {
        cachedInstalledApps?.takeIf { it.isNotEmpty() }?.let { return it }
        try {
            val raw = com.example.core.perf.DeviceMemoryStorageOptimizer.readFastSnapshotJson(
                context,
                SNAPSHOT_LAUNCHER_APPS_FILE
            )
            if (!raw.isNullOrBlank()) {
                val arr = org.json.JSONArray(raw)
                val restored = ArrayList<LauncherAppItem>(arr.length())
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val pkg = obj.optString("p")
                    val lbl = obj.optString("l")
                    val norm = obj.optString("n")
                    if (pkg.isNotBlank() && lbl.isNotBlank()) {
                        restored.add(
                            LauncherAppItem(
                                packageName = pkg,
                                label = lbl,
                                normalizedLabel = norm.ifBlank { normalizeAppText(lbl) }
                            )
                        )
                    }
                }
                if (restored.isNotEmpty()) {
                    cachedInstalledApps = restored
                    return restored
                }
            }
        } catch (_: Throwable) {}
        return emptyList()
    }

    private fun saveInstalledAppsSnapshotToRom(context: Context, apps: List<LauncherAppItem>) {
        if (apps.isEmpty()) return
        try {
            val arr = org.json.JSONArray()
            for (item in apps) {
                val obj = org.json.JSONObject()
                obj.put("p", item.packageName)
                obj.put("l", item.label)
                obj.put("n", item.normalizedLabel)
                arr.put(obj)
            }
            com.example.core.perf.DeviceMemoryStorageOptimizer.writeFastSnapshotJson(
                context,
                SNAPSHOT_LAUNCHER_APPS_FILE,
                arr.toString()
            )
        } catch (_: Throwable) {}
    }

    fun peekCachedMappingsFast(context: Context): Map<Char, String> {
        cachedMappings?.let { return it }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val fastMap = mutableMapOf<Char, String>()
        for (c in 'A'..'Z') {
            val savedPkg = prefs.getString("gesture_$c", null)
            if (!savedPkg.isNullOrBlank() && savedPkg != UNASSIGNED_MARKER) {
                fastMap[c] = savedPkg
            }
        }
        return fastMap
    }

    fun peekCachedCustomTemplateCount(): Int? = cachedCustomTemplateCount

    fun prewarmCacheAsync(context: Context, forceRefresh: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!forceRefresh && cachedInstalledApps != null && (now - lastCacheUpdateMs) < 90_000L) {
            return
        }
        val appCtx = context.applicationContext ?: context
        cacheWarmupScope.launch {
            try {
                if (cachedInstalledApps == null) {
                    peekOrHydrateInstalledApps(appCtx)
                }
                // The caller may already have populated the launcher-app cache while opening
                // this overlay. Reuse it instead of querying PackageManager a second time.
                val apps = getInstalledLauncherApps(appCtx)
                val mappings = getOrInitAllGestureMappings(appCtx, apps)
                val tmplCount = getAllCustomTemplateChars(appCtx).size
                for (c in 'A'..'Z') {
                    getCustomTemplate(appCtx, c)
                }
                cachedInstalledApps = apps
                cachedMappings = mappings
                cachedCustomTemplateCount = tmplCount
                lastCacheUpdateMs = System.currentTimeMillis()
            } catch (_: Throwable) {}
        }
    }

    // Danh sách ưu tiên thông minh khi khởi tạo mặc định lần đầu cho 26 chữ cái A-Z
    private val PREFERRED_LETTER_KEYWORDS: Map<Char, List<String>> = mapOf(
        'A' to listOf("album", "anh", "app store", "android auto"),
        'B' to listOf("ban do", "bando", "bilibili", "brave"),
        'C' to listOf("chrome", "camera", "cai dat", "capcut"),
        'D' to listOf("dien thoai", "danh ba", "drive", "douyin"),
        'E' to listOf("edge", "email", "excel"),
        'F' to listOf("facebook", "files", "find"),
        'G' to listOf("gemini", "gmail", "google", "gallery"),
        'H' to listOf("honor", "health", "home"),
        'I' to listOf("instagram", "imess"),
        'K' to listOf("keep", "kakaotalk"),
        'L' to listOf("laban key", "lien quan", "line", "locket"),
        'M' to listOf("messenger", "maps", "messages", "magictune", "music"),
        'N' to listOf("notes", "netflix", "nhac"),
        'O' to listOf("opera", "onedrive", "outlook"),
        'P' to listOf("photos", "play store", "phone"),
        'Q' to listOf("qq", "quora"),
        'R' to listOf("reddit", "recorder"),
        'S' to listOf("settings", "shopee", "spotify", "safari"),
        'T' to listOf("tiktok", "telegram", "threads", "translate"),
        'V' to listOf("vneid", "vietcombank", "viber", "video"),
        'W' to listOf("whatsapp", "wechat", "word", "weather"),
        'X' to listOf("x", "xender"),
        'Y' to listOf("youtube", "yoyo"),
        'Z' to listOf("zalo", "zing mp3", "zoom")
    )

    fun normalizeAppText(input: String): String {
        val decomposed = Normalizer.normalize(input.lowercase().trim(), Normalizer.Form.NFD)
        return decomposed.replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
            .replace('đ', 'd')
    }

    fun getInstalledLauncherApps(context: Context, forceScan: Boolean = false): List<LauncherAppItem> {
        val now = System.currentTimeMillis()
        if (!forceScan) {
            cachedInstalledApps?.takeIf { it.isNotEmpty() && (now - lastCacheUpdateMs) < 120_000L }?.let {
                return it
            }
        }
        return try {
            val pm = context.packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val prevByPkg = cachedInstalledApps?.associateBy { it.packageName }.orEmpty()
            val scanned = pm.queryIntentActivities(mainIntent, 0)
                .mapNotNull { info ->
                    val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                    val cachedItem = prevByPkg[pkg]
                    if (cachedItem != null) {
                        cachedItem
                    } else {
                        val label = info.loadLabel(pm)?.toString()?.trim().takeUnless { it.isNullOrEmpty() } ?: pkg
                        LauncherAppItem(
                            packageName = pkg,
                            label = label,
                            normalizedLabel = normalizeAppText(label)
                        )
                    }
                }
                .distinctBy { it.packageName }
                .sortedBy { it.normalizedLabel }
            if (scanned.isNotEmpty()) {
                cachedInstalledApps = scanned
                lastCacheUpdateMs = now
                saveInstalledAppsSnapshotToRom(context, scanned)
            }
            scanned
        } catch (_: Exception) {
            cachedInstalledApps ?: emptyList()
        }
    }

    private const val UNASSIGNED_MARKER = "__UNASSIGNED__"

    // Danh sách các chữ cái có nét vẽ gần giống nhau để hiển thị trong bảng gợi ý cuối màn hình vẽ
    private val SIMILAR_LETTER_GROUPS: Map<Char, List<Char>> = mapOf(
        'A' to listOf('A', 'H', 'R', 'M'),
        'B' to listOf('B', 'P', 'R', 'D'),
        'C' to listOf('C', 'G', 'O', 'S'),
        'D' to listOf('D', 'O', 'P', 'B'),
        'E' to listOf('E', 'F', 'B', 'L'),
        'F' to listOf('F', 'E', 'P', 'T'),
        'G' to listOf('G', 'C', 'O', 'Q'),
        'H' to listOf('H', 'N', 'M', 'A'),
        'I' to listOf('I', 'L', 'J', 'T'),
        'J' to listOf('J', 'I', 'U', 'L'),
        'K' to listOf('K', 'R', 'H', 'X'),
        'L' to listOf('L', 'I', 'C', 'U'),
        'M' to listOf('M', 'N', 'W', 'H'),
        'N' to listOf('N', 'M', 'H', 'Z'),
        'O' to listOf('O', 'Q', 'G', 'C'),
        'P' to listOf('P', 'R', 'B', 'F'),
        'Q' to listOf('Q', 'O', 'G', 'D'),
        'R' to listOf('R', 'P', 'B', 'K'),
        'S' to listOf('S', 'Z', 'C', 'G'),
        'T' to listOf('T', 'I', 'F', 'Y'),
        'U' to listOf('U', 'V', 'W', 'O'),
        'V' to listOf('V', 'U', 'Y', 'W'),
        'W' to listOf('W', 'V', 'U', 'M'),
        'X' to listOf('X', 'K', 'Y', 'Z'),
        'Y' to listOf('Y', 'V', 'T', 'X'),
        'Z' to listOf('Z', 'S', 'N', 'E')
    )

    fun getSimilarCandidateLetters(char: Char): List<Char> {
        val upper = char.uppercaseChar()
        return SIMILAR_LETTER_GROUPS[upper] ?: listOf(upper, 'G', 'C', 'S').distinct()
    }

    /**
     * Đồng bộ hóa 100% danh sách 26 chữ cái A-Z giữa Tab 6 (Cài Đặt Chữ) và Bảng Vẽ Mở App.
     * Lưu cố định vào SharedPreferences("magictune_gestures") ngay từ lần đầu để không bao giờ lệch!
     */
    fun getOrInitAllGestureMappings(
        context: Context,
        installedApps: List<LauncherAppItem> = getInstalledLauncherApps(context)
    ): Map<Char, String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val result = mutableMapOf<Char, String>()
        val installedSet = installedApps.map { it.packageName }.toSet()
        var needsSave = false
        val editor = prefs.edit()

        for (c in 'A'..'Z') {
            val key = "gesture_$c"
            val savedPkg = prefs.getString(key, null)
            if (savedPkg == UNASSIGNED_MARKER) {
                continue
            }
            if (!savedPkg.isNullOrBlank() && (installedSet.isEmpty() || installedSet.contains(savedPkg))) {
                result[c] = savedPkg
                continue
            }

            val lowerChar = c.lowercaseChar()
            val candidates = installedApps.filter {
                it.normalizedLabel.startsWith(lowerChar) || it.label.uppercase().startsWith(c)
            }

            val preferredKeywords = PREFERRED_LETTER_KEYWORDS[c].orEmpty()
            val chosen = preferredKeywords.firstNotNullOfOrNull { kw ->
                candidates.firstOrNull { app ->
                    app.normalizedLabel == kw || app.normalizedLabel.startsWith(kw)
                }
            } ?: candidates.firstOrNull()

            if (chosen != null) {
                result[c] = chosen.packageName
                editor.putString(key, chosen.packageName)
                needsSave = true
            }
        }

        if (needsSave) {
            editor.apply()
        }
        cachedMappings = result.toMap()
        return result
    }

    fun setGestureForChar(context: Context, char: Char, packageName: String) {
        val upper = char.uppercaseChar()
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString("gesture_$upper", packageName)
            .apply()
        cachedMappings = null
    }

    fun clearGestureForChar(context: Context, char: Char) {
        val upper = char.uppercaseChar()
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString("gesture_$upper", UNASSIGNED_MARKER)
            .apply()
        // Clear the process cache too; otherwise an open overlay can still launch the old app.
        cachedMappings = null
    }

    fun resetDefaultGestureMappings(context: Context): Map<Char, String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
        for (c in 'A'..'Z') {
            editor.remove("gesture_$c")
        }
        editor.apply()
        return getOrInitAllGestureMappings(context)
    }

    private const val KEY_DIRECT_LAUNCH_AFTER_DRAW = "direct_launch_after_draw"
    private const val KEY_CUSTOM_TEMPLATE_PREFIX = "custom_template_"
    private const val KEY_TEMPLATE_SOURCE_PREFIX = "custom_template_source_"
    private const val KEY_AUTO_TEMPLATES_SEEDED_V1 = "auto_templates_seeded_v1"

    /**
     * V4.9: Chế độ sau khi vẽ:
     * - false (mặc định): Hiện bảng kết quả nhận diện (độ tương đồng %, app khớp nhất & gợi ý) sau khi vẽ.
     * - true: Mở thẳng ứng dụng đã gán ngay lập tức sau khi vẽ xong.
     */
    fun isDirectLaunchAfterDraw(context: Context): Boolean {
        return try {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_DIRECT_LAUNCH_AFTER_DRAW, false)
        } catch (_: Throwable) {
            false
        }
    }

    fun setDirectLaunchAfterDraw(context: Context, directLaunch: Boolean) {
        try {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_DIRECT_LAUNCH_AFTER_DRAW, directLaunch)
                .apply()
        } catch (_: Throwable) {}
    }

    /**
     * V4.9: Chuẩn hóa các nét vẽ thành hệ tọa độ [0..100] x [0..100] giữ nguyên tỉ lệ khung hình (aspect ratio)
     * để lưu làm Nét Vẽ Mẫu và so khớp độ tương đồng chính xác cao.
     */
    fun normalizeStrokesForTemplate(strokes: List<List<Offset>>, pointsPerStroke: Int = 24): List<List<Offset>> {
        val valid = strokes.filter { it.size >= 2 }
        if (valid.isEmpty()) return emptyList()
        val resampled = valid.map { resampleStroke(it, pointsPerStroke) }
        val allPts = resampled.flatten()
        if (allPts.size < 2) return emptyList()

        val minX = allPts.minOf { it.x }
        val maxX = allPts.maxOf { it.x }
        val minY = allPts.minOf { it.y }
        val maxY = allPts.maxOf { it.y }
        val rawW = (maxX - minX).coerceAtLeast(1f)
        val rawH = (maxY - minY).coerceAtLeast(1f)
        val maxSpan = max(rawW, rawH).coerceAtLeast(1f)
        if (maxSpan < 12f) return emptyList()

        val scale = 100f / maxSpan
        val offsetX = (100f - rawW * scale) / 2f
        val offsetY = (100f - rawH * scale) / 2f

        return resampled.map { stroke ->
            stroke.map { pt ->
                Offset(
                    x = ((pt.x - minX) * scale + offsetX).coerceIn(0f, 100f),
                    y = ((pt.y - minY) * scale + offsetY).coerceIn(0f, 100f)
                )
            }
        }
    }

    private fun serializeNormalizedStrokes(normalized: List<List<Offset>>): String {
        return normalized.joinToString("|") { stroke ->
            stroke.joinToString(";") { pt ->
                val rx = (pt.x * 10f).roundToInt() / 10f
                val ry = (pt.y * 10f).roundToInt() / 10f
                "$rx,$ry"
            }
        }
    }

    fun saveCustomTemplate(
        context: Context,
        char: Char,
        strokes: List<List<Offset>>,
        isAutoGenerated: Boolean = false
    ): Boolean {
        val upper = char.uppercaseChar()
        if (upper !in 'A'..'Z') return false
        val normalized = normalizeStrokesForTemplate(strokes, 24)
        if (normalized.isEmpty()) return false
        val serialized = serializeNormalizedStrokes(normalized)
        val sourceVal = if (isAutoGenerated) "auto" else "user"
        cachedParsedTemplates[upper] = normalized
        cachedTemplateSources[upper] = sourceVal
        autoTemplatesSeededInRam = true
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString("$KEY_CUSTOM_TEMPLATE_PREFIX$upper", serialized)
            .putString("$KEY_TEMPLATE_SOURCE_PREFIX$upper", sourceVal)
            .putBoolean(KEY_AUTO_TEMPLATES_SEEDED_V1, true)
            .apply()
        return true
    }

    /**
     * Trả về true nếu mẫu của chữ cái này do người dùng tự vẽ (hoặc từ phiên bản cũ trước v5.4).
     * Trả về false nếu chưa có mẫu hoặc là mẫu tự động chuẩn.
     */
    fun isUserCustomTemplate(context: Context, char: Char): Boolean {
        val upper = char.uppercaseChar()
        if (upper !in 'A'..'Z') return false
        cachedTemplateSources[upper]?.let { cachedSrc ->
            return cachedSrc.isNotEmpty() && cachedSrc != "auto"
        }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString("$KEY_CUSTOM_TEMPLATE_PREFIX$upper", null)
        if (raw.isNullOrBlank()) {
            cachedTemplateSources[upper] = ""
            return false
        }
        val source = prefs.getString("$KEY_TEMPLATE_SOURCE_PREFIX$upper", null) ?: "user"
        cachedTemplateSources[upper] = source
        return source != "auto"
    }

    /**
     * Tự động nạp đủ 26/26 nét vẽ mẫu chuẩn ở lần đầu tiên sử dụng,
     * không ghi đè bất kỳ nét mẫu nào người dùng đã tự vẽ trước đó.
     */
    fun ensureAutoTemplatesSeeded(context: Context) {
        if (autoTemplatesSeededInRam) return
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            if (prefs.getBoolean(KEY_AUTO_TEMPLATES_SEEDED_V1, false)) {
                autoTemplatesSeededInRam = true
                return
            }
            autoGenerateAllTemplates(context, overwriteUserTemplates = false)
            autoTemplatesSeededInRam = true
        } catch (_: Throwable) {}
    }

    /**
     * Tạo tự động bộ 26/26 Nét Vẽ Mẫu chuẩn A–Z (giữ nguyên các mẫu do người dùng tự vẽ trừ khi overwriteUserTemplates = true).
     * Trả về số chữ cái đã được tạo/cập nhật.
     */
    fun autoGenerateAllTemplates(
        context: Context,
        overwriteUserTemplates: Boolean = false
    ): Int {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
        var generatedCount = 0
        for (c in 'A'..'Z') {
            val existingRaw = prefs.getString("$KEY_CUSTOM_TEMPLATE_PREFIX$c", null)
            val source = prefs.getString("$KEY_TEMPLATE_SOURCE_PREFIX$c", null)
            val hasUserTmpl = !existingRaw.isNullOrBlank() && source != "auto"
            if (!overwriteUserTemplates && hasUserTmpl) {
                continue
            }
            val primary = AutoLetterTemplates.getPrimaryTemplate(c) ?: continue
            val serialized = serializeNormalizedStrokes(primary)
            cachedParsedTemplates[c] = primary
            cachedTemplateSources[c] = "auto"
            editor.putString("$KEY_CUSTOM_TEMPLATE_PREFIX$c", serialized)
            editor.putString("$KEY_TEMPLATE_SOURCE_PREFIX$c", "auto")
            generatedCount++
        }
        autoTemplatesSeededInRam = true
        editor.putBoolean(KEY_AUTO_TEMPLATES_SEEDED_V1, true)
        editor.apply()
        return generatedCount
    }

    fun getCustomTemplate(context: Context, char: Char): List<List<Offset>>? {
        ensureAutoTemplatesSeeded(context)
        val upper = char.uppercaseChar()
        cachedParsedTemplates[upper]?.let { return it }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString("$KEY_CUSTOM_TEMPLATE_PREFIX$upper", null)
            ?.takeIf { it.isNotBlank() } ?: return null
        return try {
            val strokes = raw.split("|").mapNotNull { strokeStr ->
                val pts = strokeStr.split(";").mapNotNull { ptStr ->
                    val parts = ptStr.split(",")
                    if (parts.size == 2) {
                        val x = parts[0].toFloatOrNull()
                        val y = parts[1].toFloatOrNull()
                        if (x != null && y != null) Offset(x, y) else null
                    } else null
                }
                if (pts.size >= 2) pts else null
            }
            strokes.takeIf { it.isNotEmpty() }?.also { parsed ->
                cachedParsedTemplates[upper] = parsed
                if (!cachedTemplateSources.containsKey(upper)) {
                    cachedTemplateSources[upper] = prefs.getString("$KEY_TEMPLATE_SOURCE_PREFIX$upper", null) ?: "user"
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    fun hasCustomTemplate(context: Context, char: Char): Boolean {
        ensureAutoTemplatesSeeded(context)
        val upper = char.uppercaseChar()
        if (cachedParsedTemplates.containsKey(upper)) return true
        return !context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString("$KEY_CUSTOM_TEMPLATE_PREFIX$upper", null)
            .isNullOrBlank()
    }

    fun clearCustomTemplate(context: Context, char: Char) {
        val upper = char.uppercaseChar()
        cachedParsedTemplates.remove(upper)
        cachedTemplateSources[upper] = ""
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove("$KEY_CUSTOM_TEMPLATE_PREFIX$upper")
            .remove("$KEY_TEMPLATE_SOURCE_PREFIX$upper")
            .putBoolean(KEY_AUTO_TEMPLATES_SEEDED_V1, true)
            .apply()
    }

    fun clearAllCustomTemplates(context: Context) {
        cachedParsedTemplates.clear()
        cachedTemplateSources.clear()
        val editor = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        for (c in 'A'..'Z') {
            editor.remove("$KEY_CUSTOM_TEMPLATE_PREFIX$c")
            editor.remove("$KEY_TEMPLATE_SOURCE_PREFIX$c")
        }
        editor.putBoolean(KEY_AUTO_TEMPLATES_SEEDED_V1, true)
        editor.apply()
    }

    fun getAllCustomTemplateChars(context: Context): Set<Char> {
        ensureAutoTemplatesSeeded(context)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val set = mutableSetOf<Char>()
        for (c in 'A'..'Z') {
            if (!prefs.getString("$KEY_CUSTOM_TEMPLATE_PREFIX$c", null).isNullOrBlank()) {
                set.add(c)
            }
        }
        return set
    }

    fun getUserTemplateChars(context: Context): Set<Char> {
        ensureAutoTemplatesSeeded(context)
        val set = mutableSetOf<Char>()
        for (c in 'A'..'Z') {
            if (isUserCustomTemplate(context, c)) {
                set.add(c)
            }
        }
        return set
    }

    /**
     * Tính độ tương đồng (0% -> 100%) giữa nét người dùng vừa vẽ và nét vẽ mẫu đã lưu.
     * Kết hợp khoảng cách tuần tự theo đường đi (Sequential Path Distance) và đám mây điểm (Chamfer Cloud Distance)
     * kèm vector hướng để nhận diện chính xác cả nét đơn lẫn chữ nhiều nét.
     */
    fun computeTemplateSimilarity(
        drawnStrokes: List<List<Offset>>,
        templateNormalizedStrokes: List<List<Offset>>
    ): Float {
        val normDrawn = normalizeStrokesForTemplate(drawnStrokes, 24)
        if (normDrawn.isEmpty() || templateNormalizedStrokes.isEmpty()) return 0f

        val flatDrawn = resampleStroke(normDrawn.flatten(), 48)
        val flatTemplate = resampleStroke(templateNormalizedStrokes.flatten(), 48)
        if (flatDrawn.size < 4 || flatTemplate.size < 4) return 0f

        // 1. Khoảng cách tuần tự (Sequential Path Distance)
        val n = min(flatDrawn.size, flatTemplate.size)
        var seqDistSum = 0f
        for (i in 0 until n) {
            seqDistSum += hypot(flatDrawn[i].x - flatTemplate[i].x, flatDrawn[i].y - flatTemplate[i].y)
        }
        val dSeq = seqDistSum / n.toFloat()

        // 2. Khoảng cách đám mây điểm 2 chiều (Bidirectional Chamfer Distance - hỗ trợ đảo thứ tự nét)
        var dToT = 0f
        for (p in flatDrawn) {
            var best = Float.MAX_VALUE
            for (q in flatTemplate) {
                val dist = hypot(p.x - q.x, p.y - q.y)
                if (dist < best) best = dist
            }
            dToT += best
        }
        dToT /= flatDrawn.size.toFloat()

        var tToD = 0f
        for (q in flatTemplate) {
            var best = Float.MAX_VALUE
            for (p in flatDrawn) {
                val dist = hypot(q.x - p.x, q.y - p.y)
                if (dist < best) best = dist
            }
            tToD += best
        }
        tToD /= flatTemplate.size.toFloat()
        val dCloud = (dToT + tToD) / 2f

        // 3. Độ lệch tỉ lệ khung hình & số nét
        val dMinX = flatDrawn.minOf { it.x }
        val dMaxX = flatDrawn.maxOf { it.x }
        val dMinY = flatDrawn.minOf { it.y }
        val dMaxY = flatDrawn.maxOf { it.y }
        val tMinX = flatTemplate.minOf { it.x }
        val tMaxX = flatTemplate.maxOf { it.x }
        val tMinY = flatTemplate.minOf { it.y }
        val tMaxY = flatTemplate.maxOf { it.y }

        val dSpanW = (dMaxX - dMinX).coerceAtLeast(5f)
        val dSpanH = (dMaxY - dMinY).coerceAtLeast(5f)
        val tSpanW = (tMaxX - tMinX).coerceAtLeast(5f)
        val tSpanH = (tMaxY - tMinY).coerceAtLeast(5f)
        val aspectDiff = abs((dSpanW / dSpanH) - (tSpanW / tSpanH)).coerceAtMost(2.5f)
        val strokeDiffPenalty = abs(normDrawn.size - templateNormalizedStrokes.size) * 2.2f

        val combinedDist = (dSeq * 0.45f) + (dCloud * 0.55f) + (aspectDiff * 4.5f) + strokeDiffPenalty
        val rawSim = (100f * (1f - (combinedDist / 44f))).coerceIn(0f, 100f)
        return if (rawSim >= 75f) {
            (rawSim + (100f - rawSim) * 0.25f).coerceAtMost(99.5f)
        } else {
            rawSim
        }
    }

    fun computeBestSimilarityForLetter(
        context: Context,
        char: Char,
        drawnStrokes: List<List<Offset>>
    ): Float? {
        val valid = drawnStrokes.filter { it.size >= 2 }
        if (valid.isEmpty()) return null
        val tmpl = getCustomTemplate(context, char) ?: return null
        var bestSim = computeTemplateSimilarity(valid, tmpl)
        if (!isUserCustomTemplate(context, char)) {
            val variants = AutoLetterTemplates.getAllNormalizedVariants(char)
            for (variant in variants) {
                val simVar = computeTemplateSimilarity(valid, variant)
                if (simVar > bestSim) {
                    bestSim = simVar
                }
            }
        }
        return bestSim
    }

    /**
     * So khớp nét vừa vẽ với toàn bộ các Nét Vẽ Mẫu (bao gồm mẫu người dùng tự vẽ và bộ đa biến thể tự động A–Z).
     * - Nếu chữ đó người dùng đã tự vẽ: Ưu tiên so khớp chính xác 100% theo thói quen tay của người dùng.
     * - Nếu chữ đó đang dùng mẫu tự động: Quét thêm toàn bộ biến thể (1 nét liền, 2–4 nét tách rời, đảo chiều/thứ tự nét).
     * Trả về danh sách xếp hạng theo độ tương đồng giảm dần.
     */
    fun matchAllCustomTemplates(
        context: Context,
        drawnStrokes: List<List<Offset>>
    ): List<CustomTemplateMatch> {
        ensureAutoTemplatesSeeded(context)
        val valid = drawnStrokes.filter { it.size >= 2 }
        if (valid.isEmpty()) return emptyList()
        val matches = mutableListOf<CustomTemplateMatch>()
        for (c in 'A'..'Z') {
            val bestSim = computeBestSimilarityForLetter(context, c, valid) ?: continue
            if (bestSim > 10f) {
                matches.add(CustomTemplateMatch(letter = c, similarityPercent = bestSim))
            }
        }
        return matches.sortedByDescending { it.similarityPercent }
    }

    /**
     * Khi vẽ 1 chữ cái: Lấy chính xác 100% ứng dụng đã cấu hình trong Tab 6 (Cài Đặt Chữ).
     */
    fun getAppForGesture(
        context: Context,
        char: Char,
        installedApps: List<LauncherAppItem> = peekCachedInstalledApps() ?: getInstalledLauncherApps(context)
    ): Pair<String, String>? {
        val upper = char.uppercaseChar()
        val mappings = cachedMappings ?: getOrInitAllGestureMappings(context, installedApps)
        val pkg = mappings[upper] ?: return null
        val matchedApp = installedApps.firstOrNull { it.packageName == pkg }
        if (matchedApp != null) {
            return matchedApp.packageName to matchedApp.label
        }
        return try {
            val pm = context.packageManager
            val info = pm.getApplicationInfo(pkg, 0)
            pkg to pm.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Khi người dùng viết nhiều chữ cái / toàn bộ tên app (VD: "GE", "GEMINI", "ZALO", "LIEN QUAN"):
     * Tìm kiếm thông minh theo tên ứng dụng (không phân biệt hoa thường & dấu tiếng Việt).
     */
    fun findAppsByWrittenName(
        writtenQuery: String,
        installedApps: List<LauncherAppItem>
    ): List<LauncherAppItem> {
        val norm = normalizeAppText(writtenQuery).replace(" ", "")
        if (norm.isEmpty()) return emptyList()

        val scored = installedApps.mapNotNull { app ->
            val compactLabel = app.normalizedLabel.replace(" ", "")
            val words = app.normalizedLabel.split(Regex("\\s+")).filter { it.isNotEmpty() }
            val initials = words.map { it.first() }.joinToString("")

            val score = when {
                compactLabel == norm -> 1000
                compactLabel.startsWith(norm) -> 850 - (compactLabel.length - norm.length).coerceAtMost(40)
                words.any { it.startsWith(norm) } -> 720
                initials.startsWith(norm) && norm.length >= 2 -> 680
                compactLabel.contains(norm) -> 550 - compactLabel.indexOf(norm).coerceAtMost(30)
                else -> 0
            }
            if (score > 0) app to score else null
        }

        return scored.sortedByDescending { it.second }.map { it.first }
    }

    fun show(context: Context) {
        if (!Settings.canDrawOverlays(context)) {
            Toast.makeText(
                context,
                "⚠️ Vui lòng cấp quyền Hiển thị trên ứng dụng khác để mở bảng Vẽ Chữ Mở App!",
                Toast.LENGTH_LONG
            ).show()
            try {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                    data = android.net.Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (_: Exception) {}
            return
        }

        if (overlayView != null) return

        val appContext = context.applicationContext
        val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        windowManager = wm
        currentContext = appContext
        ScreenPowerOptimizer.onFeatureStarted(appContext, "GestureLauncher")

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            ScreenPowerOptimizer.applyEcoRefreshRateToWindow(this)
        }

        val lifecycleOwner = OverlayLifecycleOwner()
        lifecycleOwner.onCreate()
        lifecycleOwner.onResume()

        val composeView = ComposeView(appContext).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)
            setContent {
                GestureOverlayScreen(
                    onDismiss = { dismiss() },
                    onOpenSettingsTab = {
                        dismiss()
                        try {
                            val intent = Intent(appContext, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                putExtra("TARGET_TAB", "GESTURE_SETTINGS")
                            }
                            appContext.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    onAssignCharInSettingsTab = { charToAssign ->
                        dismiss()
                        try {
                            appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                                .edit()
                                .putString("pending_assign_char", charToAssign.uppercaseChar().toString())
                                .apply()
                            val intent = Intent(appContext, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                putExtra("TARGET_TAB", "GESTURE_SETTINGS")
                                putExtra("ASSIGN_GESTURE_CHAR", charToAssign.uppercaseChar().toString())
                            }
                            appContext.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    onLaunchPackage = { pkg, label ->
                        dismiss()
                        try {
                            val launchIntent = appContext.packageManager.getLaunchIntentForPackage(pkg)
                            if (launchIntent != null) {
                                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                MagicTuneAppSearchWidgetProvider.recordAppLaunch(appContext, pkg)
                                appContext.startActivity(launchIntent)
                                Toast.makeText(
                                    appContext,
                                    "🚀 Đang mở $label",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        } catch (_: Exception) {}
                    }
                )
            }
        }

        try {
            wm.addView(composeView, params)
            overlayView = composeView
        } catch (e: Exception) {
            Toast.makeText(appContext, "Không thể mở bảng vẽ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun dismiss() {
        currentContext?.let { ScreenPowerOptimizer.onFeatureStopped(it, "GestureLauncher") }
        currentContext = null
        overlayView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (_: Exception) {}
        }
        overlayView = null
    }

    /**
     * Tách các cụm nét được viết tách rời nhau theo chiều ngang (trái sang phải)
     * để hỗ trợ viết liền nhiều chữ cái trên cùng màn hình (VD: viết "ZA" hoặc "GEM" ngang màn hình).
     */
    fun recognizeWrittenInput(strokes: List<List<Offset>>): String {
        val valid = strokes.filter { it.size >= 2 }
        if (valid.isEmpty()) return ""

        data class StrokeCluster(
            val strokes: MutableList<List<Offset>>,
            var minX: Float,
            var maxX: Float,
            var minY: Float,
            var maxY: Float
        )

        val clusters = mutableListOf<StrokeCluster>()
        for (s in valid) {
            val sMinX = s.minOf { it.x }
            val sMaxX = s.maxOf { it.x }
            val sMinY = s.minOf { it.y }
            val sMaxY = s.maxOf { it.y }

            val existing = clusters.firstOrNull { c ->
                val overlapX = min(c.maxX, sMaxX) - max(c.minX, sMinX)
                val minWidth = min(c.maxX - c.minX, sMaxX - sMinX).coerceAtLeast(30f)
                // Thuộc cùng 1 chữ cái nếu nét giao nhau hoặc chồng lấp theo phương ngang
                overlapX > -18f || (overlapX / minWidth) > -0.15f
            }

            if (existing != null) {
                existing.strokes.add(s)
                existing.minX = min(existing.minX, sMinX)
                existing.maxX = max(existing.maxX, sMaxX)
                existing.minY = min(existing.minY, sMinY)
                existing.maxY = max(existing.maxY, sMaxY)
            } else {
                clusters.add(
                    StrokeCluster(
                        strokes = mutableListOf(s),
                        minX = sMinX,
                        maxX = sMaxX,
                        minY = sMinY,
                        maxY = sMaxY
                    )
                )
            }
        }

        if (clusters.size <= 1) {
            return recognizeGesture(valid)?.toString() ?: ""
        }

        val sortedClusters = clusters.sortedBy { it.minX }
        val recognizedChars = sortedClusters.mapNotNull { cluster ->
            recognizeGesture(cluster.strokes)
        }
        return recognizedChars.joinToString("")
    }

    /**
     * Chuyển đổi các nét vẽ cử chỉ thành ảnh Bitmap độ phân giải chuẩn để phân tích bằng Google ML Kit OCR
     */
    fun renderStrokesToBitmap(strokes: List<List<Offset>>, sizePx: Int = 384): Bitmap? {
        val valid = strokes.filter { it.size >= 2 }
        if (valid.isEmpty()) return null
        val allPts = valid.flatten()
        if (allPts.size < 4) return null

        val minX = allPts.minOf { it.x }
        val maxX = allPts.maxOf { it.x }
        val minY = allPts.minOf { it.y }
        val maxY = allPts.maxOf { it.y }
        val spanW = (maxX - minX).coerceAtLeast(1f)
        val spanH = (maxY - minY).coerceAtLeast(1f)
        val maxSpan = max(spanW, spanH)
        if (maxSpan < 16f) return null

        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = AndroidCanvas(bmp)
        canvas.drawColor(AndroidColor.WHITE)

        val paint = AndroidPaint().apply {
            color = AndroidColor.BLACK
            strokeWidth = (sizePx * 0.065f).coerceIn(16f, 32f)
            style = AndroidPaint.Style.STROKE
            strokeCap = AndroidPaint.Cap.ROUND
            strokeJoin = AndroidPaint.Join.ROUND
            isAntiAlias = true
        }

        val padding = sizePx * 0.18f
        val avail = sizePx - (padding * 2f)
        val scale = avail / maxSpan
        val offsetX = padding + (avail - spanW * scale) / 2f
        val offsetY = padding + (avail - spanH * scale) / 2f

        for (s in valid) {
            val path = AndroidPath()
            val firstX = (s.first().x - minX) * scale + offsetX
            val firstY = (s.first().y - minY) * scale + offsetY
            path.moveTo(firstX, firstY)
            for (i in 1 until s.size) {
                val px = (s[i].x - minX) * scale + offsetX
                val py = (s[i].y - minY) * scale + offsetY
                path.lineTo(px, py)
            }
            canvas.drawPath(path, paint)
        }

        return bmp
    }

    /**
     * Thuật toán nhận diện chữ cái viết tay đa nét (A-Z) chuẩn xác cao trên thiết bị:
     * Kết hợp phân tích hình học đa nét và trợ lực từ Google ML Kit On-Device OCR + Trợ Năng Ngầm.
     */
    fun recognizeGesture(strokes: List<List<Offset>>, ocrHint: Char? = null): Char? {
        val validStrokes = strokes.filter { it.size >= 2 }
        if (validStrokes.isEmpty()) return null

        val resampledStrokes = validStrokes.map { resampleStroke(it, 24) }
        val allPoints = resampledStrokes.flatten()
        if (allPoints.size < 5) return null

        val minX = allPoints.minOf { it.x }
        val maxX = allPoints.maxOf { it.x }
        val minY = allPoints.minOf { it.y }
        val maxY = allPoints.maxOf { it.y }
        val rawW = (maxX - minX).coerceAtLeast(1f)
        val rawH = (maxY - minY).coerceAtLeast(1f)
        val maxSpan = max(rawW, rawH)
        if (maxSpan < 28f) return null

        val aspect = rawW / rawH
        val strokeCount = resampledStrokes.size

        // Chuẩn hóa toàn bộ điểm về [0..100, 0..100]
        val normStrokes = resampledStrokes.map { stroke ->
            stroke.map { pt ->
                Offset(
                    x = ((pt.x - minX) / rawW) * 100f,
                    y = ((pt.y - minY) / rawH) * 100f
                )
            }
        }
        val normPoints = normStrokes.flatten()
        val startPt = normStrokes.first().first()
        val endPt = normStrokes.last().last()

        var totalPathLen = 0f
        for (stroke in normStrokes) {
            for (i in 1 until stroke.size) {
                totalPathLen += hypot(stroke[i].x - stroke[i - 1].x, stroke[i].y - stroke[i - 1].y)
            }
        }
        val startEndDist = hypot(endPt.x - startPt.x, endPt.y - startPt.y)
        val isClosedLoop = startEndDist < 32f && totalPathLen > 210f && aspect in 0.45f..1.8f

        // Mật độ điểm trên lưới 3x3
        val grid = IntArray(9)
        for (p in normPoints) {
            val gx = (p.x / 33.34f).toInt().coerceIn(0, 2)
            val gy = (p.y / 33.34f).toInt().coerceIn(0, 2)
            grid[gy * 3 + gx]++
        }
        val totalN = normPoints.size.toFloat()
        val rTL = grid[0] / totalN
        val rTM = grid[1] / totalN
        val rTR = grid[2] / totalN
        val rML = grid[3] / totalN
        val rMM = grid[4] / totalN
        val rMR = grid[5] / totalN
        val rBL = grid[6] / totalN
        val rBM = grid[7] / totalN
        val rBR = grid[8] / totalN

        val topRow = rTL + rTM + rTR
        val midRow = rML + rMM + rMR
        val botRow = rBL + rBM + rBR
        val leftCol = rTL + rML + rBL
        val centerCol = rTM + rMM + rBM
        val rightCol = rTR + rMR + rBR

        // Đếm số lần đổi chiều dọc (vertical reversals) và ngang (horizontal reversals)
        var vChanges = 0
        var lastVy = 0
        var hChanges = 0
        var lastVx = 0
        val primaryStroke = normStrokes.first()
        val step = (primaryStroke.size / 12).coerceAtLeast(2)
        var i = step
        while (i < primaryStroke.size) {
            val dy = primaryStroke[i].y - primaryStroke[i - step].y
            if (abs(dy) > 9f) {
                val dirY = if (dy > 0) 1 else -1
                if (lastVy != 0 && dirY != lastVy) vChanges++
                lastVy = dirY
            }
            val dx = primaryStroke[i].x - primaryStroke[i - step].x
            if (abs(dx) > 9f) {
                val dirX = if (dx > 0) 1 else -1
                if (lastVx != 0 && dirX != lastVx) hChanges++
                lastVx = dirX
            }
            i += step
        }

        // Phân loại các nét vẽ theo phương ngang (ngang trên, ngang giữa, ngang dưới), thẳng đứng (dọc trái, dọc giữa, dọc phải) và nét chéo
        val horizontalStrokes = normStrokes.filter { s ->
            val dx = abs(s.last().x - s.first().x)
            val dy = abs(s.last().y - s.first().y)
            dx > 16f && dx > dy * 1.2f
        }
        val hasTopBar = horizontalStrokes.any { s -> s.all { it.y < 42f } }
        val hasMidBar = horizontalStrokes.any { s -> s.all { it.y in 25f..78f } }
        val hasBotBar = horizontalStrokes.any { s -> s.all { it.y > 65f } }

        val verticalStrokes = normStrokes.filter { s ->
            val dx = abs(s.last().x - s.first().x)
            val dy = abs(s.last().y - s.first().y)
            dy > 28f && dy > dx * 1.25f
        }
        val hasLeftVertStem = verticalStrokes.any { s -> s.all { it.x < 48f } } || leftCol > 0.25f
        val hasRightVertStem = verticalStrokes.any { s -> s.all { it.x > 52f } } || rightCol > 0.25f
        val hasCenterVertStem = verticalStrokes.any { s -> s.all { it.x in 28f..72f } } || centerCol > 0.26f

        // Kiểm tra 2 nét cắt chéo nhau (X) với bất kỳ hướng vẽ nào
        val hasOppositeDiagonalStrokes = if (strokeCount >= 2) {
            var found = false
            for (idx0 in 0 until normStrokes.size) {
                for (idx1 in idx0 + 1 until normStrokes.size) {
                    val s0 = normStrokes[idx0]
                    val s1 = normStrokes[idx1]
                    val dx0 = s0.last().x - s0.first().x
                    val dy0 = s0.last().y - s0.first().y
                    val dx1 = s1.last().x - s1.first().x
                    val dy1 = s1.last().y - s1.first().y
                    val len0 = hypot(dx0, dy0)
                    val len1 = hypot(dx1, dy1)
                    val opposite = (dx0 * dy1) * (dx1 * dy0) < 0f || (dx0 * dx1 < 0f && dy0 * dy1 > 0f) || (dx0 * dx1 > 0f && dy0 * dy1 < 0f)
                    if (len0 > 38f && len1 > 38f && abs(dx0) > 18f && abs(dy0) > 18f && abs(dx1) > 18f && abs(dy1) > 18f && opposite) {
                        found = true
                        break
                    }
                }
                if (found) break
            }
            found
        } else false

        val scores = mutableMapOf<Char, Float>()
        fun addScore(c: Char, s: Float) {
            scores[c] = (scores[c] ?: 0f) + s
        }

        // Bổ sung trợ lực điểm từ Google ML Kit On-Device OCR và Trợ năng ngầm
        if (ocrHint != null && ocrHint in 'A'..'Z') {
            addScore(ocrHint.uppercaseChar(), 45f)
        }

        // 1. I (Nét thẳng đứng hẹp)
        if (aspect < 0.36f && (strokeCount <= 2 || hasCenterVertStem)) {
            addScore('I', 95f)
        }

        // 2. X (2 nét gạch chéo CẮT NHAU THỰC SỰ ở vùng trung tâm rMM hoặc chữ X nhiều nét)
        if (hasOppositeDiagonalStrokes && (rMM > 0.10f || (rTL > 0.04f && rTR > 0.04f && rBL > 0.04f && rBR > 0.04f))) {
            addScore('X', 98f)
        }

        // 3. K (Cột dọc trái + 2 nhánh chéo hướng lên góc trên-phải và xuống góc dưới-phải - hỗ trợ 1, 2, 3 nét)
        val hasKLeftStem = hasLeftVertStem || leftCol > 0.20f || normStrokes.any { s -> abs(s.last().y - s.first().y) > 36f && s.all { it.x < 48f } }
        val hasKTopRight = rTR > 0.04f || rMR > 0.04f || normPoints.any { it.x > 48f && it.y < 45f }
        val hasKBotRight = rBR > 0.04f || normPoints.any { it.x > 48f && it.y > 55f }
        val hasKCenterMeet = rMM > 0.03f || rML > 0.03f || normPoints.any { it.x in 30f..68f && it.y in 30f..70f }
        val isNotTwoStemsH = !(strokeCount >= 2 && rightCol > 0.22f && hasRightVertStem)
        if (hasKLeftStem && hasKTopRight && hasKBotRight && hasKCenterMeet && !isClosedLoop && isNotTwoStemsH) {
            addScore('K', 98f)
        }

        // 4. Y (Chữ V ở nửa trên hội tụ ở tâm + chân dọc kéo xuống đáy giữa/trái/phải - hỗ trợ 1, 2, 3 nét)
        val hasYTopLeft = rTL > 0.04f || normPoints.any { it.x < 46f && it.y < 42f }
        val hasYTopRight = rTR > 0.04f || normPoints.any { it.x > 54f && it.y < 42f }
        val hasYCenter = rMM > 0.04f || normPoints.any { it.x in 32f..68f && it.y in 32f..65f }
        val hasYStem = rBM > 0.04f || rBL > 0.04f || rBR > 0.04f || normPoints.any { it.y > 66f }
        if (hasYTopLeft && hasYTopRight && hasYCenter && hasYStem && !isClosedLoop) {
            addScore('Y', 98f)
        }

        // 5. L (Đi từ đỉnh trái thẳng xuống đáy trái rồi kéo ngang sang phải)
        if (strokeCount <= 2 &&
            leftCol > 0.30f &&
            botRow > 0.20f &&
            rTM < 0.06f &&
            rTR < 0.06f &&
            rMR < 0.07f &&
            vChanges <= 1 &&
            startPt.x < 45f &&
            startPt.y < 40f &&
            endPt.x > 52f &&
            endPt.y > 68f
        ) {
            addScore('L', 92f)
        }

        // 6. G (Vòng cung C bên trái + móc ngang/lên ở góc phải giữa hoặc dưới)
        if (leftCol > 0.16f && botRow > 0.14f && (topRow > 0.10f || rTM > 0.05f)) {
            val hasRightHook = (endPt.x > 46f && endPt.y in 34f..84f && (rMR > 0.06f || rBR > 0.10f || rMM > 0.05f))
            val hasInnerCrossbar = strokeCount >= 2 && normStrokes.last().first().x > 35f && normStrokes.last().first().y in 35f..78f
            val hasGReversal = (hChanges >= 2 || vChanges >= 1) && (rMR > 0.07f || (endPt.x > 48f && endPt.y < 82f))
            if (hasRightHook || hasInnerCrossbar || hasGReversal) {
                addScore('G', 94f)
            }
        }

        // 7. C (Cong nửa vòng bên trái, hở bên phải)
        if (strokeCount == 1 &&
            leftCol > 0.25f &&
            topRow > 0.14f &&
            botRow > 0.14f &&
            rMR < 0.06f &&
            rMM < 0.08f &&
            startPt.x > 45f &&
            startPt.y < 42f &&
            endPt.x > 45f &&
            endPt.y > 68f &&
            !isClosedLoop
        ) {
            addScore('C', 88f)
        }

        // 8. O (Vòng tròn khép kín quanh tâm rỗng)
        if (isClosedLoop && rMM < 0.11f && topRow > 0.15f && botRow > 0.15f && leftCol > 0.15f && rightCol > 0.15f) {
            addScore('O', 92f)
        }

        // 9. V (Đi từ trên trái xuống đáy giữa rồi vắt lên đỉnh phải)
        if (strokeCount == 1 && vChanges == 1 && startPt.y < 40f && endPt.y < 45f && rBM > 0.12f && rTM < 0.10f) {
            addScore('V', 90f)
        }

        // 10. U (Đi từ trên trái xuống đáy bầu rộng rồi lên đỉnh phải)
        if (strokeCount == 1 && vChanges == 1 && startPt.y < 40f && endPt.y < 45f && (rBL + rBM + rBR) > 0.32f && rBL > 0.06f && rBR > 0.06f) {
            addScore('U', 88f)
        }

        // 11. W (2 đáy đi xuống rồi lên)
        if (vChanges >= 2 && startPt.y < 48f && endPt.y < 50f && botRow > 0.20f) {
            addScore('W', 91f)
        }

        // 12. M (2 đỉnh nhọn hướng lên)
        if ((vChanges >= 2 && (startPt.y > 50f || endPt.y > 52f) && topRow > 0.18f) ||
            (strokeCount >= 2 && leftCol > 0.20f && rightCol > 0.20f && rMM > 0.08f && endPt.y > 58f)
        ) {
            addScore('M', 89f)
        }

        // 13. N (Lên - chéo xuống - lên)
        if (vChanges == 2 && endPt.y < 48f && leftCol > 0.20f && rightCol > 0.20f) {
            addScore('N', 86f)
        }

        // 14. Z (Ngang trên -> Chéo xuống trái -> Ngang đáy phải)
        if (topRow > 0.18f && botRow > 0.18f && startPt.x < 48f && startPt.y < 35f && endPt.x > 52f && endPt.y > 65f && hChanges >= 2) {
            addScore('Z', 94f)
        }

        // 15. S (Uốn lượn chữ S)
        if (strokeCount == 1 && hChanges >= 2 && rMM > 0.08f && startPt.y < 40f && endPt.y > 60f && endPt.x < 60f && !isClosedLoop) {
            addScore('S', 88f)
        }

        // 16. A (Nhọn đỉnh trên, 2 chân dưới hoặc gạch ngang giữa - hỗ trợ 1, 2, 3 nét)
        val hasApex = rTM > 0.06f || normPoints.any { it.y < 28f && it.x in 22f..78f }
        val hasFeet = (rBL > 0.03f || normPoints.any { it.y > 68f && it.x < 48f }) && (rBR > 0.03f || normPoints.any { it.y > 68f && it.x > 52f })
        if ((vChanges >= 1 && (startPt.y > 48f || strokeCount >= 2) && rTM > 0.06f && midRow > 0.16f && endPt.y > 36f) ||
            (strokeCount >= 2 && (hasMidBar || rMM > 0.06f) && hasApex && hasFeet && rBM < 0.18f)
        ) {
            addScore('A', if (hasMidBar && strokeCount >= 2) 98f else 90f)
        }

        // 17. T (Gạch ngang đỉnh trên + trục dọc giữa - hỗ trợ 1 hoặc 2 nét)
        if ((topRow > 0.20f || hasTopBar) && hasCenterVertStem && rBL < 0.09f && rBR < 0.09f) {
            addScore('T', if (strokeCount >= 2) 96f else 90f)
        }

        // 18. F (Ngang đỉnh + dọc trái + gạch giữa, đáy phải trống - hỗ trợ 1, 2, 3 nét)
        if (hasLeftVertStem && (topRow > 0.14f || hasTopBar) && (midRow > 0.12f || hasMidBar) && rBR < 0.06f && rBM < 0.08f && !hasBotBar) {
            addScore('F', if (strokeCount >= 2) 97f else 88f)
        }

        // 19. E (Dọc trái + 3 thanh ngang trên/giữa/dưới - hỗ trợ 1, 2, 3, 4 nét)
        if (hasLeftVertStem && (topRow > 0.14f || hasTopBar) && (midRow > 0.12f || hasMidBar) && (botRow > 0.14f || hasBotBar || rBR > 0.04f) && (hChanges >= 2 || strokeCount >= 2)) {
            addScore('E', if (strokeCount >= 2) 97f else 89f)
        }

        // 20. P (Trục dọc trái + bầu tròn phía trên, góc dưới phải trống)
        if (leftCol > 0.28f && topRow > 0.18f && midRow > 0.16f && rBR < 0.06f && rBM < 0.08f && endPt.x < 62f) {
            addScore('P', 87f)
        }

        // 21. R (Giống P nhưng có chân chéo xuống góc dưới phải rBR)
        if (leftCol > 0.25f && topRow > 0.16f && midRow > 0.16f && rBR > 0.07f && endPt.x > 52f && endPt.y > 62f) {
            addScore('R', 85f)
        }

        // 22. B (Trục dọc trái + 2 bụng tròn trên & dưới bên phải)
        if (leftCol > 0.25f && rightCol > 0.18f && midRow > 0.16f && botRow > 0.16f && endPt.x < 58f && endPt.y > 58f) {
            addScore('B', 84f)
        }

        // 23. D (Trục dọc trái + 1 vòng cung lớn bên phải khép về đáy trái)
        if (leftCol > 0.26f && rightCol > 0.18f && rMM < 0.14f && isClosedLoop) {
            addScore('D', 84f)
        }

        // 24. H (2 cột dọc trái & phải + gạch ngang giữa - hỗ trợ 2 hoặc 3 nét)
        if (strokeCount >= 2 && (hasLeftVertStem && hasRightVertStem) && (hasMidBar || midRow > 0.14f) && rTM < 0.10f && rBM < 0.10f) {
            addScore('H', 97f)
        }

        // 25. J (Móc câu: đi từ trên phải/giữa thẳng xuống rồi cong sang trái ở đáy)
        if (strokeCount <= 2 && (rightCol + centerCol) > 0.42f && botRow > 0.16f && startPt.y < 35f && endPt.x < 48f && endPt.y > 48f && rTL < 0.09f) {
            addScore('J', 87f)
        }

        // 26. Q (Vòng tròn O + đuôi gạch chéo ở góc dưới phải)
        val hasQTail = normStrokes.any { s ->
            s.any { it.x > 50f && it.y > 50f } && (s.first().x in 20f..88f && s.first().y in 20f..88f)
        }
        val isQByMultiStroke = strokeCount >= 2 && (hasQTail || (topRow > 0.14f && botRow > 0.15f && rBR > 0.09f && endPt.x > 52f && endPt.y > 58f))
        val isQByLoop = isClosedLoop && rBR > 0.12f && endPt.x > 52f && endPt.y > 62f
        if (isQByMultiStroke || isQByLoop) {
            addScore('Q', 96f)
        }

        val best = scores.maxByOrNull { it.value }
        if (best != null && best.value >= 45f) {
            return best.key
        }

        // Fallback dự phòng thông minh không thể đoán bừa 'A' hay 'G'
        return when {
            aspect < 0.38f -> 'I'
            isClosedLoop && rBR > 0.10f -> 'Q'
            isClosedLoop -> 'O'
            hasKLeftStem && hasKTopRight && hasKBotRight -> 'K'
            hasYTopLeft && hasYTopRight && hasYStem -> 'Y'
            hasLeftVertStem && (hasTopBar || topRow > 0.18f) && (hasBotBar || botRow > 0.18f) -> 'E'
            hasLeftVertStem && (hasTopBar || topRow > 0.18f) -> 'F'
            hasLeftVertStem && hasRightVertStem -> 'H'
            leftCol > 0.22f && botRow > 0.16f && (topRow > 0.10f || rTM > 0.05f) && (rMR > 0.06f || endPt.x > 46f) -> 'G'
            leftCol > 0.32f && botRow > 0.20f && rTM < 0.06f -> 'L'
            vChanges >= 2 && startPt.y < 50f -> 'W'
            vChanges >= 2 -> 'M'
            vChanges == 1 && startPt.y < 45f && endPt.y < 48f -> 'V'
            hChanges >= 2 && startPt.y < 38f -> 'Z'
            leftCol > 0.28f && topRow > 0.16f && botRow > 0.16f -> 'C'
            hasApex && (rBL > 0.03f || rBR > 0.03f) -> 'A'
            else -> 'A'
        }
    }

    private fun resampleStroke(points: List<Offset>, targetCount: Int): List<Offset> {
        if (points.size <= 2) return points
        var totalLen = 0f
        for (i in 1 until points.size) {
            totalLen += hypot(points[i].x - points[i - 1].x, points[i].y - points[i - 1].y)
        }
        if (totalLen < 1f) return points
        val interval = totalLen / (targetCount - 1)
        val result = mutableListOf(points.first())
        var accDist = 0f
        var prev = points.first()
        var i = 1
        while (i < points.size) {
            val curr = points[i]
            val d = hypot(curr.x - prev.x, curr.y - prev.y)
            if (accDist + d >= interval) {
                val ratio = (interval - accDist) / d.coerceAtLeast(0.0001f)
                val nx = prev.x + ratio * (curr.x - prev.x)
                val ny = prev.y + ratio * (curr.y - prev.y)
                val nextPt = Offset(nx, ny)
                result.add(nextPt)
                prev = nextPt
                accDist = 0f
            } else {
                accDist += d
                prev = curr
                i++
            }
        }
        if (result.size < targetCount) {
            result.add(points.last())
        }
        return result
    }
}

@Composable
private fun GestureOverlayScreen(
    onDismiss: () -> Unit,
    onOpenSettingsTab: () -> Unit,
    onAssignCharInSettingsTab: (Char) -> Unit,
    onLaunchPackage: (String, String) -> Unit
) {
    val context = LocalContext.current
    var installedApps by remember {
        mutableStateOf(GestureLauncherOverlay.peekOrHydrateInstalledApps(context))
    }
    var tab6Mappings by remember {
        mutableStateOf(GestureLauncherOverlay.peekCachedMappingsFast(context))
    }

    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var currentStroke by remember { mutableStateOf<List<Offset>>(emptyList()) }

    var recognizedLetter by remember { mutableStateOf("") }
    var isDrawing by remember { mutableStateOf(false) }
    var lastStrokeFinishedTime by remember { mutableLongStateOf(0L) }
    var ocrDetectedChar by remember { mutableStateOf<Char?>(null) }
    var showResultTable by remember { mutableStateOf(false) }
    var isAnalyzing by remember { mutableStateOf(false) }
    var isDirectLaunch by remember {
        mutableStateOf(GestureLauncherOverlay.isDirectLaunchAfterDraw(context))
    }
    var customTemplateMatches by remember {
        mutableStateOf<List<CustomTemplateMatch>>(emptyList())
    }
    var topCustomSimilarity by remember { mutableStateOf<Int?>(null) }
    var isMatchedByCustomTemplate by remember { mutableStateOf(false) }
    var savedTemplateVersion by remember { mutableIntStateOf(0) }
    var customTemplateCount by remember {
        mutableIntStateOf(GestureLauncherOverlay.peekCachedCustomTemplateCount() ?: 0)
    }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(savedTemplateVersion) {
        val (freshApps, freshMappings, freshTmplCount) = withContext(Dispatchers.IO) {
            val apps = GestureLauncherOverlay.peekCachedInstalledApps()
                ?: GestureLauncherOverlay.getInstalledLauncherApps(context)
            val mappings = GestureLauncherOverlay.getOrInitAllGestureMappings(context, apps)
            val count = GestureLauncherOverlay.getAllCustomTemplateChars(context).size
            Triple(apps, mappings, count)
        }
        installedApps = freshApps
        tab6Mappings = freshMappings
        customTemplateCount = freshTmplCount
        GestureLauncherOverlay.prewarmCacheAsync(context, forceRefresh = true)
    }

    suspend fun finalizeAndRecognize() {
        if (strokes.isEmpty()) return
        isAnalyzing = true
        val currentStrokesList = strokes.toList()
        val appsSnapshot = installedApps
        val shouldDirectLaunch = isDirectLaunch

        // Chạy toàn bộ thuật toán nhận diện nét vẽ, tạo Bitmap và OCR trên Dispatchers.Default để UI đạt 120FPS tuyệt đối!
        val (tmplMatches, ocrCharResult, finalOutcome) = withContext(Dispatchers.Default) {
            val matches = GestureLauncherOverlay.matchAllCustomTemplates(context, currentStrokesList)
            val bestCustom = matches.firstOrNull()

            var ocrChar: Char? = null
            try {
                val bmp = GestureLauncherOverlay.renderStrokesToBitmap(currentStrokesList)
                if (bmp != null) {
                    ocrChar = ScreenOcrEngine.recognizeSingleCharFromBitmap(bmp)
                    bmp.recycle()
                }
            } catch (_: Throwable) {}

            val geoRecognized = GestureLauncherOverlay.recognizeGesture(currentStrokesList, ocrChar)
            val standardChar = if (ocrChar != null && ocrChar in 'A'..'Z') {
                ocrChar
            } else {
                geoRecognized ?: (GestureLauncherOverlay.recognizeGesture(currentStrokesList) ?: 'A')
            }

            val finalChar: Char
            val topSim: Int?
            val isCustomMatched: Boolean
            if (bestCustom != null && bestCustom.similarityPercent >= 60f) {
                finalChar = bestCustom.letter
                topSim = bestCustom.similarityPercent.roundToInt()
                isCustomMatched = true
            } else {
                finalChar = standardChar
                val matchingCustom = matches.firstOrNull { it.letter == finalChar }
                topSim = matchingCustom?.similarityPercent?.roundToInt()
                isCustomMatched = matchingCustom != null && matchingCustom.similarityPercent >= 50f
            }

            val directApp = if (shouldDirectLaunch) {
                GestureLauncherOverlay.getAppForGesture(context, finalChar, appsSnapshot)
            } else {
                null
            }

            Triple(
                matches,
                ocrChar,
                 Pair(Triple(finalChar, topSim, isCustomMatched), directApp)
            )
        }

        val (charSimTriple, directLaunchApp) = finalOutcome
        val (finalChar, topSim, isCustomMatched) = charSimTriple

        customTemplateMatches = tmplMatches
        if (ocrCharResult != null && ocrCharResult in 'A'..'Z') {
            ocrDetectedChar = ocrCharResult
        }
        topCustomSimilarity = topSim
        isMatchedByCustomTemplate = isCustomMatched
        recognizedLetter = finalChar.toString()
        isAnalyzing = false

        // 2. Nếu người dùng chọn chế độ "Mở thẳng sau khi vẽ": Mở ngay ứng dụng đã gán cho chữ cái khớp nhất!
        if (shouldDirectLaunch && directLaunchApp != null) {
            val simTag = if (topCustomSimilarity != null) " (Khớp mẫu ${topCustomSimilarity}%)" else ""
            Toast.makeText(
                context,
                "🚀 Chữ '$finalChar'$simTag -> Mở thẳng ${directLaunchApp.second}",
                Toast.LENGTH_SHORT
            ).show()
            onLaunchPackage(directLaunchApp.first, directLaunchApp.second)
            return
        }

        showResultTable = true
    }

    // Đợi người dùng vẽ xong hoàn toàn các nét (dừng tay 750ms) mới xử lý nhận diện
    LaunchedEffect(strokes.size, isDrawing) {
        if (!isDrawing && strokes.isNotEmpty() && !showResultTable) {
            isAnalyzing = true
            delay(750L) // Chờ người dùng vẽ tiếp nét 2, nét 3 (như chữ A, E, F, H, X, Q, K...)
            finalizeAndRecognize()
        }
    }

    // Hợp nhất danh sách kết quả duy nhất: Chữ khớp nhất, các chữ có nét vẽ mẫu tương đồng, chữ gần giống, và các app liên quan
    val unifiedResultList: List<UnifiedDrawingResultItem> = remember(
        recognizedLetter,
        customTemplateMatches,
        installedApps,
        tab6Mappings
    ) {
        if (recognizedLetter.isEmpty()) {
            emptyList()
        } else {
            val primaryChar = recognizedLetter.first()
            val customCandidateChars = customTemplateMatches
                .filter { it.similarityPercent >= 45f }
                .map { it.letter }
            val candidateChars = (listOf(primaryChar) + customCandidateChars + GestureLauncherOverlay.getSimilarCandidateLetters(primaryChar))
                .distinct()
                .take(6)
            val resultList = mutableListOf<UnifiedDrawingResultItem>()
            val addedPackages = mutableSetOf<String>()

            // 1. Thêm các chữ cái ứng viên (Khớp nhất xếp đầu, các chữ khớp mẫu / gần giống xếp sau)
            candidateChars.forEach { charItem ->
                val isPrimary = (charItem == primaryChar)
                val assignedApp = GestureLauncherOverlay.getAppForGesture(context, charItem, installedApps)
                if (assignedApp != null) {
                    addedPackages.add(assignedApp.first)
                }
                val tmplMatch = customTemplateMatches.firstOrNull { it.letter == charItem }
                val simPct = tmplMatch?.similarityPercent?.roundToInt()
                val tag = when {
                    isPrimary && simPct != null && simPct >= 50 -> "Mẫu ${simPct}%"
                    isPrimary -> "Khớp nhất"
                    simPct != null && simPct >= 50 -> "Mẫu ${simPct}%"
                    else -> "Gần giống"
                }
                resultList.add(
                    UnifiedDrawingResultItem(
                        letter = charItem,
                        packageName = assignedApp?.first,
                        label = assignedApp?.second ?: "Chưa gán",
                        isPrimary = isPrimary,
                        tagText = tag,
                        similarityPercent = simPct,
                        isCustomTemplate = simPct != null
                    )
                )
            }

            // 2. Thêm các app cài trên máy có tên bắt đầu bằng chữ cái đó (xếp ngay sau)
            val primaryApps = installedApps.filter { app ->
                (app.normalizedLabel.startsWith(primaryChar.lowercaseChar()) ||
                    app.label.uppercase().startsWith(primaryChar)) &&
                    !addedPackages.contains(app.packageName)
            }
            primaryApps.forEach { app ->
                addedPackages.add(app.packageName)
                resultList.add(
                    UnifiedDrawingResultItem(
                        letter = primaryChar,
                        packageName = app.packageName,
                        label = app.label,
                        isPrimary = false,
                        tagText = "Tên app khớp"
                    )
                )
            }

            // 3. Thêm các app liên quan đến các chữ cái gần giống
            val secondaryChars = candidateChars.drop(1)
            val secondaryApps = installedApps.filter { app ->
                secondaryChars.any { simChar ->
                    app.normalizedLabel.startsWith(simChar.lowercaseChar()) ||
                        app.label.uppercase().startsWith(simChar)
                } && !addedPackages.contains(app.packageName)
            }
            secondaryApps.forEach { app ->
                addedPackages.add(app.packageName)
                resultList.add(
                    UnifiedDrawingResultItem(
                        letter = app.label.firstOrNull()?.uppercaseChar() ?: primaryChar,
                        packageName = app.packageName,
                        label = app.label,
                        isPrimary = false,
                        tagText = "Gần giống"
                    )
                )
            }

            resultList.take(16)
        }
    }

    val strokeBrush = remember { Brush.linearGradient(listOf(MagicCyanLight, MagicEmerald)) }
    val strokeStyle = remember {
        Stroke(
            width = 24f,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
    }
    val completedPaths = remember(strokes.size) {
        strokes.mapNotNull { s ->
            if (s.size > 1) {
                Path().apply {
                    moveTo(s.first().x, s.first().y)
                    for (i in 1 until s.size) {
                        lineTo(s[i].x, s[i].y)
                    }
                }
            } else null
        }
    }
    val activePath = remember { Path() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xD9020617))
            .windowInsetsPadding(WindowInsets.systemBars)
    ) {
        // Vùng vẽ toàn màn hình: Tối ưu mượt mà, lọc nhiễu điểm chạm & dùng Path tái sử dụng
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val now = System.currentTimeMillis()
                        // Nếu bảng kết quả đang hiện hoặc người dùng đã dừng vẽ lâu: bắt đầu vẽ chữ mới
                        if (showResultTable || (recognizedLetter.isNotEmpty() && (now - lastStrokeFinishedTime > 1400L))) {
                            strokes.clear()
                            recognizedLetter = ""
                            ocrDetectedChar = null
                            showResultTable = false
                            isAnalyzing = false
                        }
                        isDrawing = true
                        var lastAddedPos = down.position
                        val pts = mutableListOf(down.position)
                        currentStroke = pts.toList()

                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull() ?: break
                            if (change.pressed) {
                                val dx = change.position.x - lastAddedPos.x
                                val dy = change.position.y - lastAddedPos.y
                                if (dx * dx + dy * dy >= 20f) {
                                    lastAddedPos = change.position
                                    pts.add(change.position)
                                    currentStroke = pts.toList()
                                }
                                change.consume()
                            } else {
                                break
                            }
                        }

                        if (pts.size >= 2) {
                            strokes.add(pts.toList())
                            lastStrokeFinishedTime = System.currentTimeMillis()
                            // KHÔNG hiện bảng kết quả ngay tại đây: người dùng có thể đang vẽ tiếp nét 2, nét 3!
                        }
                        currentStroke = emptyList()
                        isDrawing = false
                    }
                }
        ) {
            for (path in completedPaths) {
                drawPath(path = path, brush = strokeBrush, style = strokeStyle)
            }

            if (currentStroke.size > 1) {
                activePath.reset()
                activePath.moveTo(currentStroke.first().x, currentStroke.first().y)
                for (i in 1 until currentStroke.size) {
                    activePath.lineTo(currentStroke[i].x, currentStroke[i].y)
                }
                drawPath(path = activePath, brush = strokeBrush, style = strokeStyle)
            }
        }

        // Header trên cùng màn hình vẽ: Gọn gàng, không hiển thị chữ cái đã vẽ và nút hoàn tác
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 14.dp, start = 14.dp, end = 14.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(MagicSurfaceDark.copy(alpha = 0.95f))
                .border(1.2.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "✍️ Vẽ 1 Chữ Cái Để Mở Nhanh App",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.weight(1f)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = onOpenSettingsTab,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MagicCyan.copy(alpha = 0.16f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Cài đặt chữ",
                            tint = MagicCyanLight,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MagicSurfaceCard)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Đóng",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Text(
                text = "💡 Ghi chú: Để vẽ mở thẳng app chính xác tuyệt đối, hãy thiết lập nét vẽ mẫu. Nếu chưa thiết lập, hãy nhấn vào biểu tượng bánh răng ⚙️ ở góc trên để thiết lập đầy đủ nét vẽ mẫu.",
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )

            // Hàng chọn nhanh chế độ: Hiện kết quả sau vẽ vs Mở thẳng sau khi vẽ
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (!isDirectLaunch) MagicCyan.copy(alpha = 0.22f)
                            else Color(0xFF0F172A)
                        )
                        .border(
                            1.dp,
                            if (!isDirectLaunch) MagicCyanLight else Color(0xFF334155),
                            RoundedCornerShape(10.dp)
                        )
                        .clickable {
                            isDirectLaunch = false
                            GestureLauncherOverlay.setDirectLaunchAfterDraw(context, false)
                        }
                        .padding(vertical = 6.dp, horizontal = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (!isDirectLaunch) "👁️ Hiện kết quả sau vẽ ✓" else "👁️ Hiện kết quả sau vẽ",
                        color = if (!isDirectLaunch) MagicCyanLight else TextSecondary,
                        fontSize = 10.5.sp,
                        fontWeight = if (!isDirectLaunch) FontWeight.Black else FontWeight.Bold,
                        maxLines = 1
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (isDirectLaunch) MagicEmerald.copy(alpha = 0.25f)
                            else Color(0xFF0F172A)
                        )
                        .border(
                            1.dp,
                            if (isDirectLaunch) MagicEmeraldLight else Color(0xFF334155),
                            RoundedCornerShape(10.dp)
                        )
                        .clickable {
                            isDirectLaunch = true
                            GestureLauncherOverlay.setDirectLaunchAfterDraw(context, true)
                        }
                        .padding(vertical = 6.dp, horizontal = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isDirectLaunch) "🚀 Mở thẳng sau vẽ ✓" else "🚀 Mở thẳng sau vẽ",
                        color = if (isDirectLaunch) MagicEmeraldLight else TextSecondary,
                        fontSize = 10.5.sp,
                        fontWeight = if (isDirectLaunch) FontWeight.Black else FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }
        }

        // THANH TRẠNG THÁI KHI ĐANG VẼ:
        // Đợi người dùng vẽ xong hoàn toàn mọi nét (dừng tay 0.8s) mới hiện bảng kết quả
        // Có nút [XONG ✓] nếu người dùng vẽ xong nhanh muốn xem kết quả ngay lập tức
        if (strokes.isNotEmpty() && !showResultTable) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 30.dp, start = 16.dp, end = 16.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(MagicSurfaceDark.copy(alpha = 0.96f))
                    .border(
                        1.2.dp,
                        Brush.horizontalGradient(listOf(MagicCyan, MagicEmerald)),
                        RoundedCornerShape(30.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = if (isAnalyzing) "🔍 Đang nhận diện chữ..."
                           else "✍️ Đã vẽ ${strokes.size} nét • Dừng tay 0.8s để hiện kết quả",
                    color = MagicCyanLight,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Brush.horizontalGradient(listOf(MagicCyan, MagicEmerald)))
                        .clickable { coroutineScope.launch { finalizeAndRecognize() } }
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "XONG ✓",
                        color = Color(0xFF020617),
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        // BẢNG KẾT QUẢ Ở CUỐI MÀN HÌNH VẼ:
        // CHỈ HIỆN KHI NGƯỜI DÙNG ĐÃ VẼ XONG HOÀN TOÀN MỌI NÉT (showResultTable == true)
        // Gọn gàng, nút Lưu nét làm mẫu ở hàng riêng không bị bóp hẹp, các ô app thu gọn 20%.
        if (showResultTable && recognizedLetter.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 10.dp, start = 10.dp, end = 10.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(MagicSurfaceDark.copy(alpha = 0.98f))
                    .border(
                        1.2.dp,
                        Brush.linearGradient(listOf(MagicCyan, MagicEmerald)),
                        RoundedCornerShape(18.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Hàng 1: Tiêu đề kết quả + Trạng thái nhận diện + Ghi chú ngắn gọn
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "🎯 KẾT QUẢ: \"$recognizedLetter\"",
                            color = MagicCyanLight,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Black
                        )
                        if (isMatchedByCustomTemplate && topCustomSimilarity != null) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MagicEmerald.copy(alpha = 0.25f))
                                    .border(0.8.dp, MagicEmeraldLight, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 5.dp, vertical = 1.5.dp)
                            ) {
                                Text(
                                    text = "✨ Khớp mẫu ${topCustomSimilarity}%",
                                    color = MagicEmeraldLight,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        } else if (ocrDetectedChar != null) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MagicEmerald.copy(alpha = 0.25f))
                                    .border(0.8.dp, MagicEmeraldLight, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 5.dp, vertical = 1.5.dp)
                            ) {
                                Text(
                                    text = "⚡ OCR Thiết Bị",
                                    color = MagicEmeraldLight,
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }

                    Text(
                        text = "💡 Chạm ô để Mở / Gán",
                        color = MagicEmeraldLight,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }

                // Hàng 2 (HÀNG RIÊNG BIỆT, RỘNG RÃI, KHÔNG BỊ BÓP HẸP): Nút Lưu nét vừa vẽ làm Nét Vẽ Mẫu
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicCyan.copy(alpha = 0.18f))
                        .border(1.dp, MagicCyanLight.copy(alpha = 0.85f), RoundedCornerShape(8.dp))
                        .clickable {
                            val targetChar = recognizedLetter.firstOrNull() ?: return@clickable
                            val ok = GestureLauncherOverlay.saveCustomTemplate(
                                context,
                                targetChar,
                                strokes.toList()
                            )
                            if (ok) {
                                savedTemplateVersion++
                                topCustomSimilarity = 99
                                isMatchedByCustomTemplate = true
                                Toast.makeText(
                                    context,
                                    "✅ Đã lưu nét vừa vẽ làm Nét Vẽ Mẫu chuẩn cho chữ '$targetChar'!",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "✍️ Lưu Nét Vừa Vẽ Làm Nét Mẫu Chuẩn Cho Chữ '$recognizedLetter'",
                        color = MagicCyanLight,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Hàng 3: Danh sách cuộn ngang các ô App (Thu nhỏ 20% gọn gàng: width 94.dp, icon 38.dp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    unifiedResultList.forEach { item ->
                        val assignedPkg = item.packageName?.takeIf { it.isNotEmpty() }
                        val isAssigned = assignedPkg != null

                        Column(
                            modifier = Modifier
                                .width(94.dp)
                                .clip(RoundedCornerShape(13.dp))
                                .background(
                                    if (item.isPrimary) MagicCyan.copy(alpha = 0.18f)
                                    else MagicSurfaceCard
                                )
                                .border(
                                    width = if (item.isPrimary) 1.2.dp else 0.8.dp,
                                    color = if (isAssigned) {
                                        if (item.isPrimary) MagicEmerald else MagicCyan.copy(alpha = 0.5f)
                                    } else {
                                        MagicAmber.copy(alpha = 0.6f)
                                    },
                                    shape = RoundedCornerShape(13.dp)
                                )
                                .clickable {
                                    if (assignedPkg != null) {
                                        onLaunchPackage(assignedPkg, item.label)
                                    } else {
                                        onAssignCharInSettingsTab(item.letter)
                                    }
                                }
                                .padding(vertical = 7.dp, horizontal = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            // Hàng đầu: Badge chữ cái + Nhãn trạng thái (thu nhỏ 20%)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(19.dp)
                                        .clip(RoundedCornerShape(5.dp))
                                        .background(
                                            if (item.isPrimary) MagicCyan.copy(alpha = 0.35f)
                                            else Color(0xFF0F172A)
                                        )
                                        .border(
                                            0.8.dp,
                                            if (item.isPrimary) MagicCyanLight else Color(0xFF334155),
                                            RoundedCornerShape(5.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = item.letter.toString(),
                                        color = if (item.isPrimary) MagicCyanLight else Color.White,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }

                                Text(
                                    text = item.tagText,
                                    color = if (item.isPrimary) MagicEmeraldLight else TextMuted,
                                    fontSize = 7.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            // Icon App ở giữa (38.dp = nhỏ hơn 20% so với 48.dp)
                            if (assignedPkg != null) {
                                AppIconImage(
                                    packageName = assignedPkg,
                                    label = item.label,
                                    modifier = Modifier.size(38.dp),
                                    cornerRadius = 10.dp
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MagicAmber.copy(alpha = 0.15f))
                                        .border(1.dp, MagicAmber.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = item.letter.toString(),
                                        color = MagicAmber,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            // Tên App hiển thị gọn gàng ngay dưới Icon
                            Text(
                                text = item.label,
                                color = Color.White,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 2,
                                minLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center,
                                lineHeight = 11.5.sp,
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Nút MỞ / GÁN gọn ở cuối thẻ
                            if (isAssigned) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MagicEmerald)
                                        .padding(vertical = 3.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "MỞ",
                                        color = Color(0xFF020617),
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MagicAmber)
                                        .padding(vertical = 3.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "GÁN",
                                        color = Color(0xFF020617),
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }

                // Hàng 4: Nút Vẽ Lại & Đóng Bảng Vẽ gọn gàng ở cuối bảng kết quả
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            strokes.clear()
                            currentStroke = emptyList()
                            recognizedLetter = ""
                            ocrDetectedChar = null
                            showResultTable = false
                            isAnalyzing = false
                            lastStrokeFinishedTime = 0L
                        },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 34.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicCyanLight)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Vẽ Lại", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1.2f)
                            .heightIn(min = 34.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(9.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF334155),
                            contentColor = Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Đóng Bảng Vẽ", fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

private class OverlayLifecycleOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle
        get() = lifecycleRegistry

    override val viewModelStore: ViewModelStore
        get() = store

    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    fun onCreate() {
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
    }

    fun onResume() {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }
}
