package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.service.SystemFloatingHudOverlay
import com.example.core.widget.GestureLauncherOverlay
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicPurple
import com.example.ui.theme.MagicPurpleLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicRoseLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

private data class RevertCategoryItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val badgeText: String,
    val accentColor: Color
)

@Composable
fun RevertModal(
    onDismiss: () -> Unit,
    onConfirmRevert: () -> Unit,
    onRevertSingleCategory: (String) -> Unit = {},
    onRevertSelectedCategories: (List<String>) -> Unit = {}
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    var refreshTick by remember { mutableIntStateOf(0) }

    val isNavCentered = remember(refreshTick) {
        SystemFloatingHudOverlay.isNavPillsCentered(context)
    }
    val isPillsHidden = remember(refreshTick) {
        SystemFloatingHudOverlay.isBothPillsHidden(context)
    }
    val customTemplatesCount = remember(refreshTick) {
        GestureLauncherOverlay.getAllCustomTemplateChars(context).size
    }
    val isDirectLaunch = remember(refreshTick) {
        GestureLauncherOverlay.isDirectLaunchAfterDraw(context)
    }

    val categories = remember(isNavCentered, isPillsHidden, customTemplatesCount, isDirectLaunch) {
        listOf(
            RevertCategoryItem(
                id = "NAV_YOYO",
                title = "1. 🎯 Thanh Điều Hướng & Trợ Lý YOYO",
                subtitle = "Trả 2 phím điều hướng về 2 mép màn hình, hiện lại thanh kim điều hướng & khôi phục gọi YOYO ở giữa đáy.",
                badgeText = if (isNavCentered) "Đang ở Giữa (Tắt YOYO)" else if (isPillsHidden) "Đang ẩn 2 phím" else "Đang ở 2 Mép",
                accentColor = MagicCyan
            ),
            RevertCategoryItem(
                id = "DISPLAY_ANIM",
                title = "2. 📱 Tần Số Quét & Tốc Độ Chuyển Cảnh",
                subtitle = "Đưa tần số quét màn hình về Tự động (Dynamic Smart) và tốc độ Animation về 1.0x mặc định.",
                badgeText = "120Hz / 1.0x",
                accentColor = MagicEmerald
            ),
            RevertCategoryItem(
                id = "DNS_ADBLOCK",
                title = "3. 🛡️ Chặn Quảng Cáo DNS & Tăng Tốc Mạng",
                subtitle = "Tắt Private DNS AdGuard, khôi phục DNS mặc định của nhà mạng và cấu hình Wi-Fi gốc.",
                badgeText = "Private DNS & Wi-Fi",
                accentColor = MagicAmber
            ),
            RevertCategoryItem(
                id = "TOUCH_THERMAL",
                title = "4. ⚡ Độ Nhạy Cảm Ứng, Pin MagicOS & Tản Nhiệt",
                subtitle = "Khôi phục độ nhạy cảm ứng kính cường lực, động cơ pin MagicOS và chế độ tản nhiệt về chuẩn nhà sản xuất.",
                badgeText = "Cảm ứng & Pin",
                accentColor = MagicPurple
            ),
            RevertCategoryItem(
                id = "DEV_STEALTH",
                title = "5. 🔓 Chế Độ Ẩn Nhà Phát Triển (Stealth Bypass)",
                subtitle = "Hiển thị lại menu Tùy chọn nhà phát triển (Developer Options) trong Cài đặt hệ thống.",
                badgeText = "Developer Menu",
                accentColor = MagicCyanLight
            ),
            RevertCategoryItem(
                id = "HISEARCH_HIBOARD",
                title = "6. 🔍 HiSearch, HiBoard & Cập Nhật Chợ App",
                subtitle = "Mở lại vuốt tìm kiếm HiSearch, bảng tin HiBoard, tạp chí màn hình khóa & tự động cập nhật App Market.",
                badgeText = "Dịch vụ Honor",
                accentColor = MagicEmeraldLight
            ),
            RevertCategoryItem(
                id = "AUDIO_FONT",
                title = "7. 🔊 Âm Thanh 48kHz, Cỡ Chữ & Chuông Báo",
                subtitle = "Đưa cỡ chữ & độ đậm về 1.0x, khôi phục âm lượng tuyệt đối Bluetooth và chuông thông báo gốc.",
                badgeText = "Âm thanh & Font",
                accentColor = MagicPurpleLight
            ),
            RevertCategoryItem(
                id = "GESTURE_DRAW",
                title = "8. ✍️ Bảng Vẽ Mở App & Nét Vẽ Mẫu (A–Z)",
                subtitle = "Đặt lại danh sách gán chữ A–Z mặc định, xóa toàn bộ Nét Vẽ Mẫu tự tạo và về chế độ Hiện kết quả sau vẽ.",
                badgeText = "${customTemplatesCount}/26 mẫu • ${if (isDirectLaunch) "Mở thẳng" else "Hiện KQ"}",
                accentColor = MagicRoseLight
            )
        )
    }

    val selectedIds = remember {
        mutableStateListOf(
            "NAV_YOYO",
            "DISPLAY_ANIM",
            "DNS_ADBLOCK",
            "TOUCH_THERMAL",
            "DEV_STEALTH",
            "HISEARCH_HIBOARD",
            "AUDIO_FONT"
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 680.dp)
                .padding(6.dp),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.5.dp, Brush.linearGradient(listOf(MagicRose, MagicAmber, MagicCyan)))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScrollWithScrollbar(scrollState = scrollState, thumbColor = MagicRose)
                    .padding(start = 16.dp, top = 16.dp, end = 20.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MagicRose.copy(alpha = 0.2f))
                                .border(1.dp, MagicRose, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = null,
                                tint = MagicRoseLight,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "TRUNG TÂM HOÀN TÁC TOÀN DIỆN",
                                color = Color.White,
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Hoàn tác từng phần tự chọn hoặc khôi phục 100% mặc định gốc",
                                color = MagicEmeraldLight,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicSurfaceCard)
                            .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))
                            .clickable { onDismiss() }
                            .testTag("close_revert_dialog_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Đóng hộp thoại hoàn tác",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Tóm tắt trạng thái nhanh
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MagicSurfaceCard)
                        .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "📌 Đã đánh dấu: ${selectedIds.size}/${categories.size} hạng mục cần hoàn tác",
                        color = MagicCyanLight,
                        fontSize = 11.8.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                // Hàng riêng cho Nút Chọn hết / Bỏ chọn tất cả
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            selectedIds.clear()
                            selectedIds.addAll(categories.map { it.id })
                        },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .heightIn(min = 38.dp, max = 42.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicCyan.copy(alpha = 0.2f),
                            contentColor = MagicCyanLight
                        ),
                        border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "☑️ CHỌN TẤT CẢ (8/8)", fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                    }

                    Button(
                        onClick = { selectedIds.clear() },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .heightIn(min = 38.dp, max = 42.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicSurfaceCard,
                            contentColor = TextSecondary
                        ),
                        border = BorderStroke(1.dp, MagicBorder),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "❌ BỎ CHỌN TẤT CẢ", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Danh sách 8 hạng mục có thể hoàn tác riêng lẻ hoặc tích chọn hàng loạt
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    categories.forEach { cat ->
                        val isChecked = selectedIds.contains(cat.id)
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (isChecked) selectedIds.remove(cat.id) else selectedIds.add(cat.id)
                                },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isChecked) Color(0xFF0F172A) else MagicSurfaceCard.copy(alpha = 0.65f)
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isChecked) cat.accentColor.copy(alpha = 0.65f) else MagicBorder
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        if (checked) {
                                            if (!selectedIds.contains(cat.id)) selectedIds.add(cat.id)
                                        } else {
                                            selectedIds.remove(cat.id)
                                        }
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = cat.accentColor,
                                        uncheckedColor = TextSecondary,
                                        checkmarkColor = Color(0xFF020617)
                                    ),
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = cat.title,
                                            color = Color.White,
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Black,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                    }
                                    Text(
                                        text = cat.subtitle,
                                        color = TextSecondary,
                                        fontSize = 10.sp,
                                        lineHeight = 13.5.sp
                                    )
                                    Box(
                                        modifier = Modifier
                                            .padding(top = 2.dp)
                                            .clip(RoundedCornerShape(5.dp))
                                            .background(cat.accentColor.copy(alpha = 0.15f))
                                            .padding(horizontal = 6.dp, vertical = 1.5.dp)
                                    ) {
                                        Text(
                                            text = cat.badgeText,
                                            color = cat.accentColor,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MagicRose.copy(alpha = 0.18f))
                                        .border(1.dp, MagicRose.copy(alpha = 0.65f), RoundedCornerShape(8.dp))
                                        .clickable {
                                            onRevertSingleCategory(cat.id)
                                            refreshTick++
                                            Toast.makeText(
                                                context,
                                                "🔄 Đang hoàn tác mục: ${cat.title}",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "Hoàn tác\nriêng",
                                        color = MagicRoseLight,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Black,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 11.5.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Nút Hoàn tác các mục đã đánh dấu
                Button(
                    onClick = {
                        if (selectedIds.isEmpty()) {
                            Toast.makeText(
                                context,
                                "⚠️ Vui lòng tích chọn ít nhất 1 mục để hoàn tác!",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            onRevertSelectedCategories(selectedIds.toList())
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicAmber,
                        contentColor = Color(0xFF020617)
                    )
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "⚡ HOÀN TÁC ${selectedIds.size} HẠNG MỤC ĐÃ CHỌN",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                // Hàng cuối: Hủy bỏ vs Hoàn tác Toàn bộ 100% về mặc định gốc
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(0.85f)
                            .fillMaxHeight()
                            .heightIn(min = 40.dp, max = 46.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MagicBorder),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
                    ) {
                        Text(
                            text = "ĐÓNG LẠI",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }

                    Button(
                        onClick = onConfirmRevert,
                        modifier = Modifier
                            .weight(1.45f)
                            .fillMaxHeight()
                            .heightIn(min = 40.dp, max = 46.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicRose,
                            contentColor = Color.White
                        )
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "🔄 HOÀN TÁC TOÀN BỘ 100%",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "(Khôi phục mặc định gốc xuất xưởng)",
                                fontSize = 9.5.sp,
                                color = Color.White.copy(alpha = 0.9f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}
